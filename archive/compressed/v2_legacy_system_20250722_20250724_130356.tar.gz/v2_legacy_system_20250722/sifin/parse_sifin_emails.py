#!/usr/bin/env python3
"""
SIFIN Email Timeline Parser
Extracts referee timeline data from Gmail to complement web-scraped data
"""

import os
import re
import json
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from email.utils import parsedate_to_datetime

# Gmail API imports
try:
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
    GMAIL_AVAILABLE = True
except ImportError:
    GMAIL_AVAILABLE = False

logger = logging.getLogger(__name__)

@dataclass
class EmailEvent:
    """Represents a single email event in the timeline"""
    event_type: str  # 'invitation', 'response', 'reminder', 'submission'
    date: datetime
    manuscript_id: str
    referee_name: Optional[str] = None
    referee_email: Optional[str] = None
    decision: Optional[str] = None  # 'accepted', 'declined'
    subject: str = ""
    message_id: str = ""
    details: Dict = None

@dataclass
class RefereeTimeline:
    """Complete timeline for a referee on a manuscript"""
    referee_name: str
    referee_email: str
    manuscript_id: str
    invitation_date: Optional[datetime] = None
    response_date: Optional[datetime] = None
    response_decision: Optional[str] = None
    response_time_days: Optional[int] = None
    reminder_count: int = 0
    submission_date: Optional[datetime] = None
    review_time_days: Optional[int] = None
    events: List[EmailEvent] = None

class SIFINEmailParser:
    """Parser for SIFIN emails to extract timeline data"""
    
    def __init__(self):
        self.gmail_service = None
        self.email_patterns = {
            'invitation': [
                r'SIFIN.*[Ii]nvitation.*[Mm]anuscript\s+(M\d+)',
                r'SIFIN.*[Rr]eview.*[Rr]equest.*[Mm]anuscript\s+(M\d+)',
                r'SIFIN\s+(M\d+).*[Ii]nvitation',
                r'[Ii]nvitation.*[Rr]eview.*[Mm]anuscript\s+(M\d+).*SIFIN',
                r'SIFIN.*[Rr]eferee.*[Ii]nvitation.*[Mm]anuscript\s+(M\d+)',
            ],
            'response': [
                r'SIFIN.*[Rr]eferee\s+(accepted|declined).*[Mm]anuscript\s+(M\d+)',
                r'SIFIN\s+(M\d+).*[Rr]eferee\s+(accepted|declined)',
                r'[Rr]esponse.*SIFIN.*[Mm]anuscript\s+(M\d+)',
                r'SIFIN.*[Mm]anuscript\s+(M\d+).*[Rr]eferee\s+(accepted|declined)',
            ],
            'reminder': [
                # Updated patterns based on actual SIFIN email subjects
                r'SIFIN\s+(M\d+)\s+--\s+.*[Oo]verdue',
                r'SIFIN\s+(M\d+)\s+-\s+[Ff]ollow-up.*[Mm]essage',
                r'SIFIN\s+(M\d+)\s+--\s+.*[Rr]eview.*[Tt]hree-[Mm]onth.*[Mm]ark',
                r'SIFIN\s+(M\d+)\s+--\s+.*[Rr]eview.*[Rr]equested.*[Oo]verdue',
                r'SIFIN\s+(M\d+)\s+--\s+.*[Rr]eminder',
                r'SIFIN\s+(M\d+)\s+-\s+.*[Rr]eminder',
                r'SIFIN\s+(M\d+).*[Oo]verdue',
                r'SIFIN\s+(M\d+).*[Ff]ollow-up',
                r'SIFIN\s+(M\d+).*[Rr]eminder',
            ],
            'submission': [
                r'SIFIN.*[Rr]eport.*[Rr]eceived.*[Mm]anuscript\s+(M\d+)',
                r'SIFIN\s+(M\d+).*[Rr]eport.*[Rr]eceived',
                r'[Rr]eferee.*[Rr]eport.*SIFIN.*[Mm]anuscript\s+(M\d+)',
                r'SIFIN.*[Mm]anuscript\s+(M\d+).*[Rr]eport.*[Ss]ubmitted',
                r'SIAM.*[Ff]inancial.*[Mm]athematics.*[Mm]anuscript\s+#(M\d+).*[Rr]eport.*[Rr]eceived',
            ]
        }
    
    def setup_gmail_service(self) -> bool:
        """Setup Gmail API service"""
        if not GMAIL_AVAILABLE:
            logger.warning("Gmail API not available")
            return False
        
        try:
            token_paths = [
                "/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/config/token.json",
                "config/token.json",
                "scripts/setup/token.json",
            ]
            
            token_path = None
            for path in token_paths:
                if os.path.exists(path):
                    token_path = path
                    break
            
            if not token_path:
                logger.error("Gmail token not found")
                return False
            
            creds = Credentials.from_authorized_user_file(token_path)
            self.gmail_service = build('gmail', 'v1', credentials=creds)
            logger.info("✅ Gmail service initialized for SIFIN timeline parsing")
            return True
            
        except Exception as e:
            logger.error(f"Failed to setup Gmail service: {e}")
            return False
    
    def fetch_sifin_emails(self, manuscript_ids: List[str] = None, days_back: int = 365) -> List[EmailEvent]:
        """Fetch SIFIN emails for timeline reconstruction"""
        if not self.gmail_service:
            return []
        
        all_events = []
        
        # Build search queries
        queries = []
        if manuscript_ids:
            # Search for specific manuscript IDs
            for ms_id in manuscript_ids:
                queries.extend([
                    f'from:sifin.siam.org {ms_id}',
                    f'subject:SIFIN {ms_id}',
                    f'subject:"{ms_id}"',
                ])
        else:
            # General SIFIN search
            queries = [
                'from:sifin.siam.org',
                'subject:SIFIN',
                'subject:"SIAM Journal on Financial Mathematics"',
            ]
        
        # Add time constraint (Gmail format: after:2024/01/01)
        if days_back:
            from datetime import datetime, timedelta
            cutoff_date = datetime.now() - timedelta(days=days_back)
            date_query = f'after:{cutoff_date.strftime("%Y/%m/%d")}'
            queries = [f'{query} {date_query}' for query in queries]
        
        # Fetch emails
        seen_ids = set()
        for query in queries:
            try:
                logger.info(f"Searching emails with query: {query}")
                response = self.gmail_service.users().messages().list(
                    userId='me',
                    q=query,
                    maxResults=100
                ).execute()
                
                messages = response.get('messages', [])
                logger.info(f"Found {len(messages)} messages for query: {query}")
                
                for msg in messages:
                    if msg['id'] in seen_ids:
                        continue
                    seen_ids.add(msg['id'])
                    
                    event = self._parse_email_to_event(msg['id'])
                    if event:
                        all_events.append(event)
                        
            except Exception as e:
                logger.error(f"Error with query '{query}': {e}")
        
        # Sort events by date
        all_events.sort(key=lambda x: x.date)
        
        logger.info(f"📧 Extracted {len(all_events)} timeline events from SIFIN emails")
        return all_events
    
    def _parse_email_to_event(self, message_id: str) -> Optional[EmailEvent]:
        """Parse a single email message to extract timeline event"""
        try:
            # Get email details
            message = self.gmail_service.users().messages().get(
                userId='me',
                id=message_id,
                format='full'
            ).execute()
            
            # Extract headers
            payload = message.get('payload', {})
            headers = {h['name']: h['value'] for h in payload.get('headers', [])}
            
            subject = headers.get('Subject', '')
            from_email = headers.get('From', '')
            date_str = headers.get('Date', '')
            
            # Parse date
            try:
                email_date = parsedate_to_datetime(date_str)
                if email_date.tzinfo is None:
                    email_date = email_date.replace(tzinfo=timezone.utc)
            except:
                email_date = datetime.now(timezone.utc)
            
            # Extract email body
            body_text = self._extract_email_body(payload)
            
            # Parse event type and details
            event_type, manuscript_id, details = self._classify_email_event(subject, body_text)
            
            if not event_type or not manuscript_id:
                return None
            
            # Extract referee information
            referee_name, referee_email = self._extract_referee_info(subject, body_text, from_email)
            
            return EmailEvent(
                event_type=event_type,
                date=email_date,
                manuscript_id=manuscript_id,
                referee_name=referee_name,
                referee_email=referee_email,
                decision=details.get('decision'),
                subject=subject,
                message_id=message_id,
                details=details
            )
            
        except Exception as e:
            logger.warning(f"Error parsing email {message_id}: {e}")
            return None
    
    def _extract_email_body(self, payload: Dict) -> str:
        """Extract text from email payload - handles nested multipart structures"""
        import base64
        
        def extract_from_part(part):
            """Recursively extract text from a part"""
            text = ""
            
            # If this part has nested parts, process them
            if 'parts' in part:
                for subpart in part['parts']:
                    text += extract_from_part(subpart)
            # If this is a text/plain part with data, extract it
            elif part.get('mimeType') == 'text/plain':
                data = part.get('body', {}).get('data', '')
                if data:
                    try:
                        text = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                    except Exception as e:
                        logger.warning(f"Error decoding email body: {e}")
            
            return text
        
        # Start extraction from the main payload
        body = extract_from_part(payload)
        
        # If no body found and payload has direct data, try that
        if not body and payload.get('mimeType') == 'text/plain':
            data = payload.get('body', {}).get('data', '')
            if data:
                try:
                    body = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                except Exception as e:
                    logger.warning(f"Error decoding email body: {e}")
        
        return body
    
    def _classify_email_event(self, subject: str, body: str) -> Tuple[Optional[str], Optional[str], Dict]:
        """Classify email event type and extract manuscript ID"""
        text = f"{subject} {body}"
        
        # Check each pattern type
        for event_type, patterns in self.email_patterns.items():
            for pattern in patterns:
                match = re.search(pattern, text, re.IGNORECASE)
                if match:
                    manuscript_id = None
                    decision = None
                    
                    # Extract manuscript ID
                    if event_type == 'response':
                        if len(match.groups()) >= 2:
                            decision = match.group(1).lower()
                            manuscript_id = match.group(2)
                        else:
                            manuscript_id = match.group(1)
                    else:
                        manuscript_id = match.group(1)
                    
                    details = {'decision': decision}
                    return event_type, manuscript_id, details
        
        return None, None, {}
    
    def _extract_referee_info(self, subject: str, body: str, from_email: str) -> Tuple[Optional[str], Optional[str]]:
        """Extract referee name and email from email content"""
        referee_name = None
        referee_email = None
        
        # Combine subject and body for searching
        full_text = f"{subject}\n{body}"
        
        # Pattern 1: Report submission emails
        # Example: "Antoine Jack Jacquier has submitted a report for..."
        report_patterns = [
            r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*(?:\s+[A-Z][a-z]+)?)\s+has\s+submitted\s+a\s+report',
            r'Report\s+from\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
            r'Referee\s+report\s+from\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
        ]
        
        for pattern in report_patterns:
            match = re.search(pattern, full_text)
            if match:
                referee_name = match.group(1).strip()
                # Skip if it's actually "Dear" or similar
                if referee_name and not referee_name.startswith('Dear'):
                    break
        
        # Pattern 2: Referee response emails
        response_patterns = [
            r'that\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*(?:\s+[A-Z][a-z]+)?)\s+has\s+(?:accepted|declined)\s+to\s+review',
            r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*(?:\s+[A-Z][a-z]+)?)\s+has\s+(?:accepted|declined)\s+to\s+review',
            r'Referee\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:accepted|declined)',
            r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:accepted|declined)\s+the\s+invitation',
        ]
        
        if not referee_name:
            for pattern in response_patterns:
                match = re.search(pattern, full_text, re.IGNORECASE)
                if match:
                    referee_name = match.group(1).strip()
                    break
        
        # Pattern 3: Invitation emails
        invitation_patterns = [
            r'Invitation\s+sent\s+to\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
            r'invited\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+to\s+review',
            r'Review\s+invitation\s+for\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
        ]
        
        if not referee_name:
            for pattern in invitation_patterns:
                match = re.search(pattern, full_text, re.IGNORECASE)
                if match:
                    referee_name = match.group(1).strip()
                    break
        
        # Extract referee email if present
        if referee_name:
            # Look for email near the referee name
            name_pos = full_text.find(referee_name)
            if name_pos != -1:
                name_vicinity = full_text[max(0, name_pos - 100):name_pos + 200]
                email_pattern = r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})'
                email_match = re.search(email_pattern, name_vicinity)
                if email_match:
                    candidate_email = email_match.group(1)
                    # Filter out SIAM emails
                    if not any(domain in candidate_email.lower() for domain in ['siam.org', 'sifin.siam.org']):
                        referee_email = candidate_email
        
        # If no email found in vicinity, search more broadly
        if referee_name and not referee_email:
            all_emails = re.findall(r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', full_text)
            for email in all_emails:
                # Skip SIAM/system emails
                if not any(domain in email.lower() for domain in ['siam.org', 'sifin.siam.org', 'noreply', 'do-not-reply']):
                    # Check if email username matches referee name
                    email_user = email.split('@')[0].lower()
                    referee_parts = referee_name.lower().split()
                    if any(part in email_user for part in referee_parts if len(part) > 2):
                        referee_email = email
                        break
        
        # Log for debugging
        logger.debug(f"Extracted referee - Name: {referee_name}, Email: {referee_email}")
        
        return referee_name, referee_email
    
    def build_referee_timelines(self, events: List[EmailEvent]) -> Dict[str, Dict[str, RefereeTimeline]]:
        """Build complete referee timelines from events"""
        # Group events by manuscript and referee
        timelines = {}
        
        for event in events:
            ms_id = event.manuscript_id
            if ms_id not in timelines:
                timelines[ms_id] = {}
            
            # Use email as key, fallback to name
            referee_key = event.referee_email or event.referee_name or "unknown"
            
            if referee_key not in timelines[ms_id]:
                timelines[ms_id][referee_key] = RefereeTimeline(
                    referee_name=event.referee_name or "Unknown",
                    referee_email=event.referee_email or "",
                    manuscript_id=ms_id,
                    events=[]
                )
            
            timeline = timelines[ms_id][referee_key]
            timeline.events.append(event)
            
            # Update timeline based on event type
            if event.event_type == 'invitation':
                timeline.invitation_date = event.date
            elif event.event_type == 'response':
                timeline.response_date = event.date
                timeline.response_decision = event.decision
                
                # Calculate response time
                if timeline.invitation_date:
                    delta = event.date - timeline.invitation_date
                    timeline.response_time_days = delta.days
                    
            elif event.event_type == 'reminder':
                timeline.reminder_count += 1
            elif event.event_type == 'submission':
                timeline.submission_date = event.date
                
                # Calculate review time
                if timeline.response_date:
                    delta = event.date - timeline.response_date
                    timeline.review_time_days = delta.days
        
        return timelines
    
    def generate_timeline_report(self, timelines: Dict[str, Dict[str, RefereeTimeline]]) -> str:
        """Generate a comprehensive timeline report"""
        report = []
        report.append("📊 SIFIN Email Timeline Analysis Report")
        report.append("=" * 50)
        
        total_manuscripts = len(timelines)
        total_referees = sum(len(ref_timelines) for ref_timelines in timelines.values())
        
        report.append(f"📄 Total Manuscripts: {total_manuscripts}")
        report.append(f"👥 Total Referees: {total_referees}")
        report.append("")
        
        for ms_id, ref_timelines in timelines.items():
            report.append(f"📄 Manuscript {ms_id}")
            report.append(f"   Referees with timeline data: {len(ref_timelines)}")
            report.append("")
            
            for referee_key, timeline in ref_timelines.items():
                report.append(f"   👤 {timeline.referee_name} ({timeline.referee_email})")
                
                if timeline.invitation_date:
                    report.append(f"      📨 Invited: {timeline.invitation_date.strftime('%Y-%m-%d %H:%M')}")
                
                if timeline.response_date:
                    response_str = f"      📧 Response: {timeline.response_date.strftime('%Y-%m-%d %H:%M')}"
                    if timeline.response_decision:
                        response_str += f" - {timeline.response_decision.upper()}"
                    if timeline.response_time_days is not None:
                        response_str += f" ({timeline.response_time_days} days)"
                    report.append(response_str)
                
                if timeline.reminder_count > 0:
                    report.append(f"      🔔 Reminders sent: {timeline.reminder_count}")
                
                if timeline.submission_date:
                    submission_str = f"      📝 Review submitted: {timeline.submission_date.strftime('%Y-%m-%d %H:%M')}"
                    if timeline.review_time_days is not None:
                        submission_str += f" ({timeline.review_time_days} days to complete)"
                    report.append(submission_str)
                
                report.append(f"      📊 Timeline events: {len(timeline.events)}")
                report.append("")
        
        return "\n".join(report)


def main():
    """Main function for testing SIFIN email parser"""
    parser = SIFINEmailParser()
    
    if not parser.setup_gmail_service():
        print("❌ Failed to setup Gmail service")
        return
    
    # Test with specific manuscript IDs
    test_manuscripts = ["M174160", "M174727", "M175988", "M176140"]
    
    print("🔍 Fetching SIFIN emails for timeline reconstruction...")
    events = parser.fetch_sifin_emails(manuscript_ids=test_manuscripts, days_back=None)
    
    print(f"📧 Found {len(events)} timeline events")
    
    # Build timelines
    timelines = parser.build_referee_timelines(events)
    
    # Generate report
    report = parser.generate_timeline_report(timelines)
    print("\n" + report)
    
    # Save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"sifin_email_timeline_{timestamp}.json"
    
    # Convert to serializable format
    serializable_data = {}
    for ms_id, ref_timelines in timelines.items():
        serializable_data[ms_id] = {}
        for ref_key, timeline in ref_timelines.items():
            serializable_data[ms_id][ref_key] = {
                'referee_name': timeline.referee_name,
                'referee_email': timeline.referee_email,
                'invitation_date': timeline.invitation_date.isoformat() if timeline.invitation_date else None,
                'response_date': timeline.response_date.isoformat() if timeline.response_date else None,
                'response_decision': timeline.response_decision,
                'response_time_days': timeline.response_time_days,
                'reminder_count': timeline.reminder_count,
                'submission_date': timeline.submission_date.isoformat() if timeline.submission_date else None,
                'review_time_days': timeline.review_time_days,
                'event_count': len(timeline.events)
            }
    
    with open(output_file, 'w') as f:
        json.dump(serializable_data, f, indent=2)
    
    print(f"📄 Timeline data saved to: {output_file}")


if __name__ == "__main__":
    main()