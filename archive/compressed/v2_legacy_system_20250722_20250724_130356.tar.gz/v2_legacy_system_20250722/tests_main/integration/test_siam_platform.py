#!/usr/bin/env python3
"""
SIAM platform tests for SICON and SIFIN extractors.
Tests platform-specific features and differences.
"""

import unittest
import sys
from pathlib import Path
from unittest.mock import Mock, patch

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))


class TestSIAMPlatform(unittest.TestCase):
    """Test SIAM platform-specific functionality."""
    
    def setUp(self):
        """Set up test environment."""
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
        from editorial_assistant.extractors.sifin_consolidated import SIFINConsolidatedExtractor
        
        self.sicon_extractor = SICONConsolidatedExtractor()
        self.sifin_extractor = SIFINConsolidatedExtractor()
    
    def test_sicon_vs_sifin_url_differences(self):
        """Test that SICON and SIFIN have different URLs."""
        
        self.assertIn("sicon", self.sicon_extractor.journal_url)
        self.assertIn("sifin", self.sifin_extractor.journal_url)
        self.assertNotEqual(self.sicon_extractor.journal_url, self.sifin_extractor.journal_url)
    
    def test_browser_requirements(self):
        """Test browser requirements - SIFIN needs Firefox, SICON can use Chrome."""
        
        # SIFIN should require Firefox for Cloudflare bypass
        self.assertEqual(self.sifin_extractor.browser_manager.browser_type, 'firefox')
        
        # SICON should have standard browser (default)
        # Note: SICON may not have explicit browser_type set, which defaults to Chrome
        self.assertIsNotNone(self.sicon_extractor.browser_manager.browser_type)
    
    def test_shared_platform_features(self):
        """Test features that should be the same across SIAM journals."""
        
        # Both should use ORCID authentication
        self.assertTrue(hasattr(self.sicon_extractor, '_login'))
        self.assertTrue(hasattr(self.sifin_extractor, '_login'))
        
        # Both should use _orcid_authentication
        self.assertTrue(hasattr(self.sicon_extractor, '_orcid_authentication'))
        self.assertTrue(hasattr(self.sifin_extractor, '_handle_orcid_authentication'))
        
        # Both should have extract_data method
        self.assertTrue(hasattr(self.sicon_extractor, 'extract_data'))
        self.assertTrue(hasattr(self.sifin_extractor, 'extract_data'))
    
    def test_timing_differences(self):
        """Test timing differences between SICON and SIFIN."""
        
        # Both should have fast popup timing (different from ScholarOne)
        self.assertEqual(self.sicon_extractor.popup_wait_time, 1)
        self.assertEqual(self.sifin_extractor.popup_wait_time, 1)
        
        # Both should have same page navigation timing
        self.assertEqual(self.sicon_extractor.page_navigation_wait, 5)
        self.assertEqual(self.sifin_extractor.page_navigation_wait, 5)
        
        # SIFIN should have redirect timeout configured
        self.assertEqual(self.sifin_extractor.redirect_timeout, 30)
    
    def test_inheritance_structure(self):
        """Test that both inherit from SIAMExtractor."""
        
        from editorial_assistant.extractors.base_platform_extractors import SIAMExtractor
        
        self.assertIsInstance(self.sicon_extractor, SIAMExtractor)
        self.assertIsInstance(self.sifin_extractor, SIAMExtractor)
    
    def test_sifin_specific_features(self):
        """Test SIFIN-specific features."""
        
        # SIFIN should have cookie banner removal
        self.assertTrue(hasattr(self.sifin_extractor, '_remove_cookie_banner'))
        
        # SIFIN should have post-login popup handling
        self.assertTrue(hasattr(self.sifin_extractor, '_handle_post_login_popups'))
    
    def test_sicon_specific_features(self):
        """Test SICON-specific features."""
        
        # SICON should have popup handling
        self.assertTrue(hasattr(self.sicon_extractor, '_handle_popups'))
        
        # SICON should have ORCID button clicking
        self.assertTrue(hasattr(self.sicon_extractor, '_click_orcid_button'))
    
    def test_authentication_methods_exist(self):
        """Test that authentication-related methods exist."""
        
        # Common authentication methods
        common_auth_methods = ['_login', '_is_logged_in']
        
        for method in common_auth_methods:
            self.assertTrue(hasattr(self.sicon_extractor, method), f"SICON missing {method}")
            self.assertTrue(hasattr(self.sifin_extractor, method), f"SIFIN missing {method}")
    
    def test_extraction_methods_exist(self):
        """Test that extraction-related methods exist."""
        
        extraction_methods = [
            'extract_data',
            '_extract_from_web',
            '_extract_manuscript_ids',
            '_extract_manuscript_details',
            '_extract_referee_details'
        ]
        
        for method in extraction_methods:
            self.assertTrue(hasattr(self.sicon_extractor, method), f"SICON missing {method}")
            self.assertTrue(hasattr(self.sifin_extractor, method), f"SIFIN missing {method}")
    
    def test_timeline_integration_ready(self):
        """Test that email timeline integration is ready."""
        
        # Both should have timeline methods (even if disabled)
        timeline_methods = ['_extract_from_emails', '_integrate_and_validate']
        
        for method in timeline_methods:
            self.assertTrue(hasattr(self.sicon_extractor, method), f"SICON missing {method}")
            self.assertTrue(hasattr(self.sifin_extractor, method), f"SIFIN missing {method}")


class TestSIAMCompatibility(unittest.TestCase):
    """Test backward compatibility of SIAM extractors."""
    
    def test_sicon_backward_compatibility(self):
        """Test SICON backward compatibility function."""
        from editorial_assistant.extractors.sicon_consolidated import extract_sicon_data
        
        # Should be callable
        self.assertTrue(callable(extract_sicon_data))
        
        # Should accept expected parameters
        import inspect
        sig = inspect.signature(extract_sicon_data)
        params = list(sig.parameters.keys())
        
        expected_params = ['headless', 'validate_timeline']
        for param in expected_params:
            self.assertIn(param, params, f"SICON missing parameter: {param}")
    
    def test_sifin_backward_compatibility(self):
        """Test SIFIN backward compatibility function."""
        from editorial_assistant.extractors.sifin_consolidated import extract_sifin_data
        
        # Should be callable
        self.assertTrue(callable(extract_sifin_data))
        
        # Should accept expected parameters
        import inspect
        sig = inspect.signature(extract_sifin_data)
        params = list(sig.parameters.keys())
        
        expected_params = ['headless', 'validate_timeline']
        for param in expected_params:
            self.assertIn(param, params, f"SIFIN missing parameter: {param}")
    
    def test_orcid_credential_structure(self):
        """Test ORCID credential structure."""
        
        # Both extractors should have journal configs with credential info
        from editorial_assistant.core.unified_config import get_config_manager
        config_manager = get_config_manager()
        
        sicon_config = config_manager.get_journal_config('SICON')
        sifin_config = config_manager.get_journal_config('SIFIN')
        
        self.assertIsNotNone(sicon_config)
        self.assertIsNotNone(sifin_config)
        
        # Should have credential configuration
        self.assertIsNotNone(sicon_config.credentials)
        self.assertIsNotNone(sifin_config.credentials)


class TestSIAMErrorHandling(unittest.TestCase):
    """Test error handling in SIAM extractors."""
    
    def test_missing_config_handling(self):
        """Test graceful handling of missing configuration."""
        
        # Should still initialize even with missing config elements
        try:
            from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
            from editorial_assistant.extractors.sifin_consolidated import SIFINConsolidatedExtractor
            
            sicon = SICONConsolidatedExtractor()
            sifin = SIFINConsolidatedExtractor()
            
            self.assertIsNotNone(sicon)
            self.assertIsNotNone(sifin)
            
        except Exception as e:
            self.fail(f"SIAM extractors should handle missing config gracefully: {e}")
    
    def test_invalid_journal_code_handling(self):
        """Test handling of invalid journal codes."""
        
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
        from editorial_assistant.extractors.sifin_consolidated import SIFINConsolidatedExtractor
        
        # Should handle non-existent journal codes gracefully
        try:
            sicon = SICONConsolidatedExtractor('INVALID_CODE')
            sifin = SIFINConsolidatedExtractor('INVALID_CODE')
            
            # Should still initialize with fallback values
            self.assertIsNotNone(sicon)
            self.assertIsNotNone(sifin)
            
        except Exception as e:
            self.fail(f"Should handle invalid journal codes gracefully: {e}")
    
    def test_timeline_integration_disabled_gracefully(self):
        """Test that timeline integration can be disabled gracefully."""
        
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
        from editorial_assistant.extractors.sifin_consolidated import SIFINConsolidatedExtractor
        
        sicon = SICONConsolidatedExtractor()
        sifin = SIFINConsolidatedExtractor()
        
        # Timeline should be disabled by default (safe mode)
        self.assertFalse(sicon.use_enhanced_timeline)
        self.assertFalse(sifin.use_enhanced_timeline)
        
        # Should still work without timeline integration
        try:
            # These should not fail even with timeline disabled
            sicon_result = sicon._extract_from_emails()
            sifin_result = sifin._extract_from_emails()
            
            # Should return empty list when disabled
            self.assertEqual(sicon_result, [])
            self.assertEqual(sifin_result, [])
            
        except Exception as e:
            self.fail(f"Timeline methods should work gracefully when disabled: {e}")


class TestCrossPlatformComparison(unittest.TestCase):
    """Test differences between SIAM and ScholarOne platforms."""
    
    def test_method_naming_differences(self):
        """Test that method naming follows platform conventions."""
        
        from editorial_assistant.extractors.mf_extractor import MFExtractor
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
        
        mf = MFExtractor()  # ScholarOne
        sicon = SICONConsolidatedExtractor()  # SIAM
        
        # ScholarOne uses 'login', SIAM uses '_login'
        self.assertTrue(hasattr(mf, 'login'))
        self.assertTrue(hasattr(sicon, '_login'))
        
        # ScholarOne uses 'extract_all_data', SIAM uses 'extract_data'
        self.assertTrue(hasattr(mf, 'extract_all_data'))
        self.assertTrue(hasattr(sicon, 'extract_data'))
    
    def test_authentication_differences(self):
        """Test authentication method differences."""
        
        from editorial_assistant.extractors.mf_extractor import MFExtractor
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
        
        mf = MFExtractor()  # ScholarOne
        sicon = SICONConsolidatedExtractor()  # SIAM
        
        # ScholarOne has 2FA methods
        self.assertTrue(hasattr(mf, '_needs_2fa'))
        self.assertTrue(hasattr(mf, '_handle_2fa'))
        
        # SIAM has ORCID methods
        self.assertTrue(hasattr(sicon, '_orcid_authentication'))
        self.assertTrue(hasattr(sicon, '_click_orcid_button'))


if __name__ == '__main__':
    unittest.main(verbosity=2)