#!/bin/bash
# Health Check Script for Editorial Scripts System

echo "🏥 Running health check..."

# Check Python
python3 -c "
import sys
import os
from pathlib import Path

print('✅ Python:', sys.version.split()[0])

# Check required modules
required_modules = [
    'selenium',
    'pandas',
    'pydantic',
    'dotenv',
    'requests'
]

missing = []
for module in required_modules:
    try:
        __import__(module)
    except ImportError:
        missing.append(module)

if missing:
    print('❌ Missing modules:', ', '.join(missing))
    sys.exit(1)
else:
    print('✅ All required modules installed')

# Check directories (from project root)
project_root = Path(__file__).parent.parent if '__file__' in globals() else Path.cwd().parent
required_dirs = ['editorial_assistant', 'config', 'data', 'logs']
for dir_name in required_dirs:
    if not (project_root / dir_name).exists():
        print(f'❌ Missing directory: {dir_name}')
        sys.exit(1)

print('✅ All required directories present')

# Check main entry points
if not (project_root / 'main.py').exists() and not (project_root / 'run_extraction.py').exists():
    print('❌ No entry point found')
    sys.exit(1)

print('✅ Entry points available')

# Check credentials file
if (project_root / 'config/credentials.json').exists() or (project_root / '.env.production').exists():
    print('✅ Credentials configured')
else:
    print('⚠️  No credentials found - please configure')

print('\\n🎉 Health check passed!')
"