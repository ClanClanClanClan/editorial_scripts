# ADR-0004: Mutation Testing Strategy

## Status
Accepted

## Context
Editorial Scripts v3.0 processes mission-critical manuscript data where bugs can lead to:
- Lost or corrupted submissions
- Incorrect editorial decisions
- Privacy breaches and compliance violations
- Researcher reputation damage
- Legal liability

Traditional test coverage metrics (line, branch) can be misleading - high coverage doesn't guarantee test quality. Many tests pass without actually validating behavior, creating false confidence.

The v3.0 specifications mandate:
- **90%+ mutation score** as a gate in CI/CD
- Pristine-plus architecture with correctness guarantees  
- Comprehensive testing strategy beyond basic coverage
- Domain logic must be bulletproof

## Decision
We will implement **mutation testing** with a 90% kill rate target using the following strategy:

### 1. Mutation Testing Tool: mutmut
```bash
# CI Pipeline command
mutmut run --paths-to-mutate src/ --runner "pytest -x --disable-warnings" --CI
mutmut junitxml > mutation-results.xml
```

**Why mutmut:**
- Python-native, actively maintained
- AST-based mutations (more accurate than regex)
- CI integration with JUnit XML output
- Supports parallel execution with pytest-xdist
- Good performance for large codebases

### 2. Mutation Coverage Targets by Layer
```yaml
Domain Layer: 95%+     # Business logic must be bulletproof
Application Layer: 90%  # Use case orchestration critical
Infrastructure: 80%    # Adapter code, some mutations acceptable
```

### 3. CI Integration Strategy
```yaml
# GitHub Actions pipeline
mutation-testing:
  runs-on: ubuntu-latest  
  steps:
    - run: poetry install
    - run: poetry run mutmut run --CI
    - run: |
        SCORE=$(poetry run mutmut results | grep -o '[0-9.]*%' | head -1)
        echo "Mutation score: $SCORE"
        [[ $(echo "$SCORE > 90.0" | bc) -eq 1 ]] || exit 1
```

### 4. Staged Rollout Strategy
**Phase 1 (Weeks 3-6):** Domain entities only, 80% target
**Phase 2 (Weeks 7-10):** Application services, 85% target  
**Phase 3 (Weeks 11+):** Full codebase, 90% target

### 5. Exemption Policy
```python
# Acceptable to not kill certain mutations:
# @mutmut:disable - entire function/class
# @mutmut:disable next - single line

# Valid exemptions:
# - Logging statements 
# - Defensive assertions
# - Performance optimizations
# - Third-party integrations
```

## Implementation Details

### Pre-commit Hooks
```yaml
# .pre-commit-config.yaml
- repo: local
  hooks:
    - id: mutmut-quick
      name: Mutation Testing (changed files)
      entry: bash -c 'mutmut run --paths-to-mutate $(git diff --name-only HEAD^ | grep "\.py$" | tr "\n" " ") --CI'
```

### Parallel Execution
```bash
# Speed up with pytest-xdist
mutmut run --runner "pytest -x -n auto" --processes-to-use 4
```

### Reporting Dashboard
- Integration with SonarQube for trend analysis
- Slack notifications for score degradation
- Per-module breakdown in CI reports
- Historical tracking of mutation kill rates

### Developer Workflow
1. **Write failing test** - TDD approach
2. **Implement minimal code** to make test pass
3. **Run mutation testing** on modified files
4. **Add tests** to kill surviving mutations
5. **Refactor** with confidence

### Common Mutation Types Checked
```python
# Boundary mutations: < becomes <=, > becomes >=
if age >= 18:  # mutant: if age > 18:

# Boolean mutations: and becomes or, True becomes False  
if valid and complete:  # mutant: if valid or complete:

# Arithmetic mutations: + becomes -, * becomes /
total = price + tax  # mutant: total = price - tax

# Return value mutations: return True becomes return False
return is_valid()  # mutant: return not is_valid()
```

## Quality Gates

### CI Pipeline Gates
```bash
# All must pass for merge:
1. pytest --cov=90              # Line coverage ≥ 90%
2. pytest --cov-branch=85       # Branch coverage ≥ 85%  
3. mutmut run --CI              # Mutation score ≥ 90%
4. mypy --strict                # Type checking passes
```

### Performance Targets
- **Full mutation suite**: ≤ 10 minutes on CI
- **Incremental mutations**: ≤ 2 minutes for PR
- **Local development**: ≤ 30 seconds for single file

### Monitoring & Alerting
```python
# Custom metrics
mutation_score_gauge = Gauge('mutation_kill_rate_percent', 'Current mutation test kill rate')
mutation_runtime_histogram = Histogram('mutation_test_duration_seconds', 'Mutation test execution time')
```

## Consequences

### Positive
- **Higher test quality** - Forces thinking about edge cases
- **Bug prevention** - Catches subtle logical errors
- **Refactoring confidence** - Safe to change implementation
- **Documentation value** - Tests become executable specifications
- **Regression protection** - Prevents quality degradation over time

### Negative  
- **CI time overhead** - 5-10x slower than regular tests
- **Developer friction** - Additional step in development flow
- **False positives** - Some mutations may be equivalent/irrelevant
- **Learning curve** - Team needs to understand mutation concepts
- **Tooling limitations** - mutmut bugs or edge cases

### Risk Mitigation
- **Incremental adoption** - Start with core domain, expand gradually  
- **Performance optimization** - Parallel execution, smart caching
- **Developer training** - Workshops on mutation testing concepts
- **Selective execution** - Only test changed files in development
- **Exemption guidelines** - Clear policies for valid exemptions

### Failure Scenarios
1. **CI timeouts** - Implement time boxing with partial results
2. **False failures** - Maintain exemption list for known issues
3. **Performance degradation** - Monitor and optimize slow tests
4. **Developer resistance** - Education and gradual introduction

## Integration with Other Quality Measures

### Property-Based Testing
```python
# Hypothesis + mutation testing = robust domain validation
@given(manuscript_data())
def test_manuscript_submission_invariants(manuscript):
    result = manuscript.submit()
    # Mutations will test edge cases in validation logic
```

### Contract Testing
- Mutation test API contracts for breaking changes
- Ensure consumer tests catch provider mutations
- Cross-service mutation testing for integration points

## References
- [Mutation Testing: Better Code by Making Bugs](https://pitest.org/)  
- [mutmut Documentation](https://mutmut.readthedocs.io/)
- [An Analysis of the Effectiveness of Mutation Testing](https://doi.org/10.1109/TSE.2006.73)
- [Mutation Testing in Practice](https://blog.frankel.ch/introduction-mutation-testing/)