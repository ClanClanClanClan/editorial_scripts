#!/usr/bin/env python3
"""Patch to ensure Take Action clicking works"""

import sys
from pathlib import Path

# Update the _click_manuscript method to match the working test
WORKING_CLICK_METHOD = '''    def _click_manuscript(self, manuscript_id: str) -> bool:
        """SIMPLE Take Action clicking that actually works."""
        try:
            self.logger.info(f"🎯 Clicking Take Action for {manuscript_id}")
        
            # Find ALL table rows on the page
            all_rows = self.driver.find_elements(By.TAG_NAME, "tr")
            self.logger.info(f"Found {len(all_rows)} total rows")
        
            for row in all_rows:
                try:
                    # Check if this row contains our manuscript ID
                    if manuscript_id not in row.text:
                        continue
                    
                    self.logger.info(f"Found row with {manuscript_id}")
                
                    # Get ALL cells in this row
                    cells = row.find_elements(By.TAG_NAME, "td")
                    if not cells:
                        continue
                
                    # The Take Action is ALWAYS in the LAST cell
                    last_cell = cells[-1]
                
                    # Find the Take Action link with check_off.gif in the LAST cell
                    take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
                
                    if not take_action_links:
                        # Try without the image requirement
                        take_action_links = last_cell.find_elements(By.XPATH, ".//a[contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
                
                    if take_action_links:
                        link = take_action_links[0]
                        href = link.get_attribute('href')
                        self.logger.info(f"Found Take Action in last cell! href: {href[:100]}...")
                    
                        # ALWAYS use JavaScript execution - it's more reliable
                        if href and 'javascript:' in href:
                            js_code = href.replace('javascript:', '')
                            self.logger.info(f"Executing JavaScript: {js_code[:100]}...")
                            
                            # Store current URL to verify navigation
                            old_url = self.driver.current_url
                            self.driver.execute_script(js_code)
                            
                            # Wait for navigation
                            time.sleep(5)
                            self._wait_for_page_load()
                            
                            # Verify navigation happened
                            new_url = self.driver.current_url
                            if old_url != new_url:
                                self.logger.info(f"✅ Successfully clicked Take Action for {manuscript_id} - navigated to new page")
                                return True
                            else:
                                self.logger.warning(f"Take Action click didn't navigate - trying again")
                                # Try direct click as fallback
                                self.driver.execute_script("arguments[0].click();", link)
                                time.sleep(3)
                                self._wait_for_page_load()
                                return True
                        else:
                            # Try direct JavaScript click as fallback
                            self.driver.execute_script("arguments[0].click();", link)
                            self._wait_for_page_load()
                            self.logger.info(f"✅ Successfully clicked Take Action (JS click) for {manuscript_id}")
                            return True
                        
                except Exception as e:
                    self.logger.debug(f"Error checking row: {e}")
                    continue
        
            self.logger.error(f"❌ Could not find Take Action for {manuscript_id}")
            
            # Save page for debugging
            with open(f'debug_take_action_{manuscript_id}.html', 'w') as f:
                f.write(self.driver.page_source)
            self.logger.info(f"Saved debug page to debug_take_action_{manuscript_id}.html")
        
            return False
        
        except Exception as e:
            self.logger.error(f"Error in Take Action clicking: {e}")
            return False'''

def patch_scholarone():
    """Apply the working Take Action fix"""
    
    scholarone_path = Path(__file__).parent / "editorial_assistant/extractors/scholarone.py"
    
    print(f"📝 Reading {scholarone_path}")
    with open(scholarone_path, 'r') as f:
        content = f.read()
    
    # Find the _click_manuscript method
    import re
    
    # Pattern to match the entire method
    pattern = r'(    def _click_manuscript\(self, manuscript_id: str\) -> bool:\s*\n(?:.*\n)*?        return False)'
    
    matches = list(re.finditer(pattern, content, re.MULTILINE))
    
    if not matches:
        print("❌ Could not find _click_manuscript method")
        return False
    
    print(f"✅ Found {len(matches)} _click_manuscript method(s)")
    
    # Replace with working version
    new_content = content
    for match in reversed(matches):  # Process in reverse to maintain positions
        start, end = match.span()
        new_content = new_content[:start] + WORKING_CLICK_METHOD + new_content[end:]
    
    # Backup original
    backup_path = scholarone_path.with_suffix('.py.backup_working')
    with open(backup_path, 'w') as f:
        f.write(content)
    print(f"💾 Backed up to {backup_path}")
    
    # Write patched version
    with open(scholarone_path, 'w') as f:
        f.write(new_content)
    print(f"✅ Patched {scholarone_path}")
    
    return True

if __name__ == "__main__":
    if patch_scholarone():
        print("\n🎉 Successfully patched Take Action clicking!")
        print("   The extractor should now work correctly.")
    else:
        print("\n❌ Failed to patch Take Action clicking")