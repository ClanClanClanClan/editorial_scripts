# Contributing to Editorial Scripts V3

We welcome contributions to the Editorial Scripts V3.0 system! This document provides guidelines for contributing to the project.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [Making Contributions](#making-contributions)
- [Code Standards](#code-standards)
- [Testing Requirements](#testing-requirements)
- [Documentation](#documentation)
- [Architecture Decision Records](#architecture-decision-records)
- [Legal Requirements](#legal-requirements)

## Code of Conduct

This project adheres to a professional and respectful code of conduct. All contributors are expected to:

- Be respectful and professional in all interactions
- Focus on constructive feedback and collaboration
- Welcome newcomers and help them get started
- Respect the pristine-plus architecture and quality standards

## Getting Started

1. **Fork the repository** and clone your fork
2. **Set up the development environment** (see Development Setup below)
3. **Read the specifications** in `docs/specs_v3.md`
4. **Review existing ADRs** in `docs/adr/`
5. **Check open issues** for contribution opportunities

## Development Setup

### Prerequisites

- Python 3.11+
- Poetry for dependency management
- Docker and Docker Compose
- PostgreSQL 16 (or use Docker)
- Git

### Quick Setup

```bash
# Clone your fork
git clone https://github.com/your-username/editorial-scripts-v3.git
cd editorial-scripts-v3

# Install dependencies
make dev-install

# Set up environment
cp .env.example .env
# Edit .env with your configuration

# Run verification
make verify-setup

# Run tests
make test
```

### Detailed Setup

1. **Poetry Installation**:
   ```bash
   curl -sSL https://install.python-poetry.org | python3 -
   export PATH="$HOME/.poetry/bin:$PATH"
   ```

2. **Environment Setup**:
   ```bash
   poetry install
   poetry shell
   ```

3. **Database Setup**:
   ```bash
   # Using Docker Compose
   docker-compose up -d postgres redis
   
   # Or install locally
   # Follow PostgreSQL 16 installation for your system
   ```

4. **Pre-commit Hooks**:
   ```bash
   poetry run pre-commit install
   ```

## Making Contributions

### Before You Start

1. **Check existing issues** and discussions
2. **Create an issue** for significant changes
3. **Discuss architecture changes** before implementation
4. **Follow the pristine-plus principles**

### Contribution Process

1. **Create a branch** from `main`:
   ```bash
   git checkout -b feature/your-feature-name
   # or
   git checkout -b fix/issue-description
   ```

2. **Make your changes** following code standards

3. **Run quality checks**:
   ```bash
   make lint
   make type-check
   make test
   make security-check
   ```

4. **Commit your changes** with conventional commit messages:
   ```bash
   git commit -m "feat: add async repository implementation"
   git commit -m "fix: resolve type error in manuscript entity"
   git commit -m "docs: update API documentation"
   ```

5. **Push and create pull request**:
   ```bash
   git push origin feature/your-feature-name
   ```

### Pull Request Guidelines

- **Title**: Use conventional commit format
- **Description**: Explain what and why, not just how
- **Link issues**: Reference related issues with `Fixes #123`
- **ADR**: Include ADR if architecture changes
- **Tests**: Include comprehensive tests
- **Documentation**: Update docs for user-facing changes

## Code Standards

### Python Code Quality

- **Type hints**: 100% type coverage with `mypy --strict`
- **Formatting**: Black with line length 88
- **Imports**: Sorted with isort
- **Linting**: Ruff with comprehensive rules
- **Complexity**: Cyclomatic complexity ≤ 10

### Architecture Principles

- **Hexagonal Architecture**: Domain → Application → Infrastructure
- **Domain-Driven Design**: Rich domain models, ubiquitous language
- **Dependency Inversion**: Depend on abstractions, not concretions
- **CQRS**: Command Query Responsibility Segregation where appropriate

### Security Standards

- **No secrets in code**: Use environment variables
- **Input validation**: Validate all inputs with Pydantic
- **SQL injection prevention**: Use SQLAlchemy ORM
- **Security scanning**: Pass Bandit and Semgrep

## Testing Requirements

### Test Coverage

- **Unit tests**: ≥80% line coverage
- **Integration tests**: Key workflows covered
- **Mutation testing**: ≥90% mutation score target
- **Property-based testing**: Use Hypothesis for value objects

### Test Organization

```
tests/
├── unit/           # Fast, isolated tests
├── integration/    # Database and external service tests
├── e2e/           # End-to-end workflow tests
└── conftest.py    # Shared fixtures
```

### Test Standards

- **Arrange-Act-Assert** pattern
- **Descriptive test names**: `test_submit_manuscript_requires_valid_metadata`
- **Isolated tests**: No test dependencies
- **Fast execution**: Unit tests under 100ms each

## Documentation

### Required Documentation

- **API documentation**: All public APIs documented
- **User guides**: Installation and usage documentation
- **Code comments**: Complex business logic explained
- **ADRs**: Architecture decisions documented

### Documentation Standards

- **MkDocs**: Use configured MkDocs setup
- **Markdown**: Follow standard markdown conventions
- **Code examples**: Include working code examples
- **Screenshots**: For UI features

## Architecture Decision Records

### When to Create an ADR

- **New architectural patterns**
- **Technology choices**
- **Breaking changes**
- **Significant design decisions**

### ADR Format

Use the template in `docs/adr/template.md`:

1. **Status**: Proposed, Accepted, Deprecated
2. **Context**: What is the issue that we're seeing?
3. **Decision**: What is the change that we're proposing?
4. **Consequences**: What becomes easier or more difficult?

### ADR Process

1. **Create ADR draft** before implementation
2. **Discuss with maintainers**
3. **Update based on feedback**
4. **Link to pull request**
5. **Mark as accepted when merged**

## Legal Requirements

### Licensing

- All code must be compatible with Apache 2.0 license
- No GPL-licensed dependencies (except in isolated containers)
- Include license header in new source files:

```python
# Copyright 2024 Editorial Scripts Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
```

### Contributor License Agreement

By contributing to this project, you agree that:

- Your contributions are your original work
- You grant the project maintainers license to use your contributions
- Your contributions are provided under the Apache 2.0 license

## Development Workflow

### Daily Development

1. **Start with tests**: Write failing tests first (TDD)
2. **Implement incrementally**: Small, focused commits
3. **Run checks frequently**: `make lint test` before commits
4. **Update documentation**: Keep docs current with code

### Quality Gates

All contributions must pass:

- **Type checking**: `mypy --strict`
- **Formatting**: `black --check`
- **Linting**: `ruff check`
- **Tests**: `pytest` with coverage
- **Security**: `bandit` and `semgrep`

### Performance Considerations

- **Async patterns**: Use `async`/`await` for I/O operations
- **Database queries**: Optimize N+1 queries
- **Connection pooling**: Reuse database connections
- **Caching**: Use Redis for expensive operations

## Getting Help

### Resources

- **Specifications**: `docs/specs_v3.md`
- **Architecture**: `docs/adr/`
- **API Documentation**: Generated docs (when available)
- **Issue Tracker**: GitHub Issues

### Contact

- **GitHub Issues**: For bugs and feature requests
- **GitHub Discussions**: For questions and ideas
- **Pull Request Reviews**: For code-specific questions

## Recognition

Contributors are recognized in:

- **Git history**: All commits are attributed
- **Release notes**: Significant contributions noted
- **Documentation**: Contributor acknowledgments

Thank you for contributing to Editorial Scripts V3! Your contributions help make scholarly publishing more efficient and accessible.