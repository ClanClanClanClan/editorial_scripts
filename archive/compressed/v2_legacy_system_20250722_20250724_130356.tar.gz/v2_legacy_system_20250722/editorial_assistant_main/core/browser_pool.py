#!/usr/bin/env python3
"""
Browser Pool Management System

This module provides connection pooling for browser instances to improve
performance and resource utilization across multiple extraction operations.

Phase 3: System Integration - Performance Optimization
"""

import time
import logging
import threading
from queue import Queue, Empty
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from contextlib import contextmanager
from enum import Enum

from selenium import webdriver
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.common.exceptions import WebDriverException, InvalidSessionIdException

from .browser_manager import BrowserManager
from .unified_config import get_config_manager
from .exceptions import ConfigurationError

# Logging setup
logger = logging.getLogger(__name__)


class BrowserState(Enum):
    """States for browser instances in the pool."""
    AVAILABLE = "available"
    IN_USE = "in_use"
    INVALID = "invalid"
    SHUTTING_DOWN = "shutting_down"


@dataclass
class PooledBrowser:
    """Wrapper for browser instances in the pool."""
    
    driver: WebDriver
    browser_type: str
    state: BrowserState = BrowserState.AVAILABLE
    created_at: datetime = field(default_factory=datetime.now)
    last_used: datetime = field(default_factory=datetime.now)
    use_count: int = 0
    journal_code: Optional[str] = None
    
    def is_valid(self) -> bool:
        """Check if browser instance is still valid."""
        try:
            # Simple check - try to get current URL
            _ = self.driver.current_url
            return True
        except (WebDriverException, InvalidSessionIdException):
            self.state = BrowserState.INVALID
            return False
    
    def age_minutes(self) -> float:
        """Get age of browser instance in minutes."""
        return (datetime.now() - self.created_at).total_seconds() / 60
    
    def idle_minutes(self) -> float:
        """Get idle time in minutes."""
        return (datetime.now() - self.last_used).total_seconds() / 60


class BrowserPool:
    """
    Browser connection pool for efficient resource management.
    
    Features:
    - Connection pooling with configurable size limits
    - Automatic cleanup of stale connections
    - Thread-safe operations
    - Browser type segregation (Chrome/Firefox)
    - Usage statistics and monitoring
    """
    
    def __init__(self):
        """Initialize the browser pool."""
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Configuration
        config_manager = get_config_manager()
        self.max_pool_size = config_manager.get_global_setting('browser_pool_size', 4)
        self.max_browser_age_minutes = config_manager.get_global_setting('browser_max_age_minutes', 30)
        self.max_idle_minutes = config_manager.get_global_setting('browser_max_idle_minutes', 10)
        self.enable_pooling = config_manager.get_global_setting('enable_browser_pooling', True)
        
        # Pool storage
        self._pools: Dict[str, Queue] = {
            'chrome': Queue(maxsize=self.max_pool_size),
            'firefox': Queue(maxsize=self.max_pool_size)
        }
        
        # Active browsers tracking
        self._active_browsers: Dict[int, PooledBrowser] = {}
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Statistics
        self._stats = {
            'created': 0,
            'reused': 0,
            'destroyed': 0,
            'errors': 0,
            'cache_hits': 0,
            'cache_misses': 0
        }
        
        # Cleanup thread
        self._cleanup_thread = None
        self._shutdown = False
        
        if self.enable_pooling:
            self._start_cleanup_thread()
        
        self.logger.info(f"Browser pool initialized - Max size: {self.max_pool_size}, "
                        f"Max age: {self.max_browser_age_minutes}min, "
                        f"Pooling: {self.enable_pooling}")
    
    def _start_cleanup_thread(self):
        """Start background thread for pool cleanup."""
        self._cleanup_thread = threading.Thread(
            target=self._cleanup_worker,
            daemon=True,
            name="BrowserPoolCleanup"
        )
        self._cleanup_thread.start()
    
    def _cleanup_worker(self):
        """Background worker for cleaning up stale browsers."""
        while not self._shutdown:
            try:
                time.sleep(60)  # Check every minute
                self._cleanup_stale_browsers()
            except Exception as e:
                self.logger.error(f"Cleanup worker error: {e}")
    
    def _cleanup_stale_browsers(self):
        """Remove stale browsers from the pool."""
        with self._lock:
            for browser_type, pool in self._pools.items():
                cleaned = []
                
                # Check all browsers in pool
                while not pool.empty():
                    try:
                        browser = pool.get_nowait()
                        
                        # Check if browser is still valid and not too old
                        if (browser.is_valid() and 
                            browser.age_minutes() < self.max_browser_age_minutes and
                            browser.idle_minutes() < self.max_idle_minutes):
                            cleaned.append(browser)
                        else:
                            # Destroy stale browser
                            self._destroy_browser(browser)
                            self.logger.debug(f"Cleaned stale {browser_type} browser "
                                            f"(age: {browser.age_minutes():.1f}min, "
                                            f"idle: {browser.idle_minutes():.1f}min)")
                    except Empty:
                        break
                
                # Put valid browsers back
                for browser in cleaned:
                    try:
                        pool.put_nowait(browser)
                    except:
                        self._destroy_browser(browser)
    
    @contextmanager
    def get_browser(self, browser_type: str = 'chrome', 
                   journal_code: Optional[str] = None,
                   headless: bool = True):
        """
        Get a browser from the pool or create a new one.
        
        Args:
            browser_type: Type of browser ('chrome' or 'firefox')
            journal_code: Journal code for tracking
            headless: Run browser in headless mode
            
        Yields:
            WebDriver instance
        """
        browser = None
        
        try:
            # Get or create browser
            browser = self._acquire_browser(browser_type, journal_code, headless)
            
            yield browser.driver
            
            # Return to pool if still valid
            if browser.is_valid() and self.enable_pooling:
                self._release_browser(browser)
            else:
                self._destroy_browser(browser)
                
        except Exception as e:
            self.logger.error(f"Browser pool error: {e}")
            if browser:
                self._destroy_browser(browser)
            raise
    
    def _acquire_browser(self, browser_type: str, 
                        journal_code: Optional[str],
                        headless: bool) -> PooledBrowser:
        """Acquire a browser from the pool or create new one."""
        with self._lock:
            # Try to get from pool first
            if self.enable_pooling and browser_type in self._pools:
                pool = self._pools[browser_type]
                
                while not pool.empty():
                    try:
                        browser = pool.get_nowait()
                        if browser.is_valid():
                            # Reuse browser
                            browser.state = BrowserState.IN_USE
                            browser.last_used = datetime.now()
                            browser.use_count += 1
                            browser.journal_code = journal_code
                            
                            self._active_browsers[id(browser.driver)] = browser
                            self._stats['reused'] += 1
                            self._stats['cache_hits'] += 1
                            
                            self.logger.debug(f"Reused {browser_type} browser from pool "
                                            f"(use #{browser.use_count})")
                            return browser
                        else:
                            # Invalid browser, destroy it
                            self._destroy_browser(browser)
                            
                    except Empty:
                        break
            
            # Create new browser
            self._stats['cache_misses'] += 1
            return self._create_browser(browser_type, journal_code, headless)
    
    def _create_browser(self, browser_type: str,
                       journal_code: Optional[str],
                       headless: bool) -> PooledBrowser:
        """Create a new browser instance."""
        try:
            # Use BrowserManager to create driver
            browser_manager = BrowserManager(
                browser_type=browser_type,
                headless=headless
            )
            
            driver = browser_manager.create_driver()
            
            browser = PooledBrowser(
                driver=driver,
                browser_type=browser_type,
                state=BrowserState.IN_USE,
                journal_code=journal_code
            )
            
            self._active_browsers[id(driver)] = browser
            self._stats['created'] += 1
            
            self.logger.info(f"Created new {browser_type} browser for {journal_code or 'general use'}")
            return browser
            
        except Exception as e:
            self._stats['errors'] += 1
            self.logger.error(f"Failed to create {browser_type} browser: {e}")
            raise
    
    def _release_browser(self, browser: PooledBrowser):
        """Release browser back to pool."""
        with self._lock:
            try:
                # Remove from active tracking
                browser_id = id(browser.driver)
                if browser_id in self._active_browsers:
                    del self._active_browsers[browser_id]
                
                # Reset browser state
                browser.state = BrowserState.AVAILABLE
                browser.journal_code = None
                
                # Clear cookies and reset
                try:
                    browser.driver.delete_all_cookies()
                    browser.driver.get("about:blank")
                except:
                    # If reset fails, mark as invalid
                    browser.state = BrowserState.INVALID
                
                # Return to pool if valid and pool not full
                if (browser.state == BrowserState.AVAILABLE and 
                    browser.browser_type in self._pools):
                    
                    pool = self._pools[browser.browser_type]
                    try:
                        pool.put_nowait(browser)
                        self.logger.debug(f"Released {browser.browser_type} browser to pool")
                    except:
                        # Pool full, destroy browser
                        self._destroy_browser(browser)
                else:
                    self._destroy_browser(browser)
                    
            except Exception as e:
                self.logger.error(f"Error releasing browser: {e}")
                self._destroy_browser(browser)
    
    def _destroy_browser(self, browser: PooledBrowser):
        """Destroy a browser instance."""
        try:
            browser.state = BrowserState.SHUTTING_DOWN
            browser.driver.quit()
            self._stats['destroyed'] += 1
            self.logger.debug(f"Destroyed {browser.browser_type} browser")
        except Exception as e:
            self.logger.error(f"Error destroying browser: {e}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get pool statistics."""
        with self._lock:
            stats = self._stats.copy()
            
            # Add current pool sizes
            stats['pool_sizes'] = {
                browser_type: pool.qsize()
                for browser_type, pool in self._pools.items()
            }
            
            # Add active browser count
            stats['active_browsers'] = len(self._active_browsers)
            
            # Calculate efficiency metrics
            total_requests = stats['cache_hits'] + stats['cache_misses']
            if total_requests > 0:
                stats['cache_hit_rate'] = stats['cache_hits'] / total_requests
                stats['reuse_rate'] = stats['reused'] / total_requests
            else:
                stats['cache_hit_rate'] = 0.0
                stats['reuse_rate'] = 0.0
            
            return stats
    
    def clear_pool(self, browser_type: Optional[str] = None):
        """Clear browsers from pool."""
        with self._lock:
            pools_to_clear = [browser_type] if browser_type else list(self._pools.keys())
            
            for bt in pools_to_clear:
                if bt in self._pools:
                    pool = self._pools[bt]
                    cleared = 0
                    
                    while not pool.empty():
                        try:
                            browser = pool.get_nowait()
                            self._destroy_browser(browser)
                            cleared += 1
                        except Empty:
                            break
                    
                    self.logger.info(f"Cleared {cleared} {bt} browsers from pool")
    
    def shutdown(self):
        """Shutdown the browser pool."""
        self.logger.info("Shutting down browser pool...")
        
        with self._lock:
            self._shutdown = True
            
            # Clear all pools
            self.clear_pool()
            
            # Destroy active browsers
            for browser in list(self._active_browsers.values()):
                self._destroy_browser(browser)
            
            self._active_browsers.clear()
        
        # Wait for cleanup thread
        if self._cleanup_thread and self._cleanup_thread.is_alive():
            self._cleanup_thread.join(timeout=5)
        
        self.logger.info(f"Browser pool shutdown complete. Stats: {self.get_stats()}")
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.shutdown()


# Global pool instance
_global_pool: Optional[BrowserPool] = None
_pool_lock = threading.Lock()


def get_browser_pool() -> BrowserPool:
    """Get the global browser pool instance."""
    global _global_pool
    
    if _global_pool is None:
        with _pool_lock:
            if _global_pool is None:
                _global_pool = BrowserPool()
    
    return _global_pool


def shutdown_browser_pool():
    """Shutdown the global browser pool."""
    global _global_pool
    
    if _global_pool is not None:
        with _pool_lock:
            if _global_pool is not None:
                _global_pool.shutdown()
                _global_pool = None