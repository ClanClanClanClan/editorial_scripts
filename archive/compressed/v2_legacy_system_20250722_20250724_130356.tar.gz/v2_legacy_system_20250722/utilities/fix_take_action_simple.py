#!/usr/bin/env python3
"""Simple, bulletproof Take Action fix"""

def fixed_click_manuscript(self, manuscript_id: str) -> bool:
    """SIMPLE Take Action clicking that actually works."""
    try:
        self.logger.info(f"🎯 Clicking Take Action for {manuscript_id}")
        
        # Find ALL table rows on the page
        all_rows = self.driver.find_elements(By.TAG_NAME, "tr")
        
        for row in all_rows:
            try:
                # Check if this row contains our manuscript ID
                if manuscript_id not in row.text:
                    continue
                    
                self.logger.info(f"Found row with {manuscript_id}")
                
                # Get ALL cells in this row
                cells = row.find_elements(By.TAG_NAME, "td")
                if not cells:
                    continue
                
                # The Take Action is ALWAYS in the LAST cell
                last_cell = cells[-1]
                
                # Find the Take Action link with check_off.gif in the LAST cell
                take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
                
                if not take_action_links:
                    # Try without the image requirement
                    take_action_links = last_cell.find_elements(By.XPATH, ".//a[contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
                
                if take_action_links:
                    link = take_action_links[0]
                    href = link.get_attribute('href')
                    self.logger.info(f"Found Take Action in last cell! href: {href[:100]}...")
                    
                    # ALWAYS use JavaScript execution - it's more reliable
                    if href and 'javascript:' in href:
                        js_code = href.replace('javascript:', '')
                        self.logger.info(f"Executing JavaScript: {js_code[:100]}...")
                        self.driver.execute_script(js_code)
                        self._wait_for_page_load()
                        self.logger.info(f"✅ Successfully clicked Take Action for {manuscript_id}")
                        return True
                    else:
                        # Try direct JavaScript click as fallback
                        self.driver.execute_script("arguments[0].click();", link)
                        self._wait_for_page_load()
                        self.logger.info(f"✅ Successfully clicked Take Action (JS click) for {manuscript_id}")
                        return True
                        
            except Exception as e:
                self.logger.debug(f"Error checking row: {e}")
                continue
        
        self.logger.error(f"❌ Could not find Take Action for {manuscript_id}")
        
        # Save page for debugging
        with open(f'debug_take_action_{manuscript_id}.html', 'w') as f:
            f.write(self.driver.page_source)
        self.logger.info(f"Saved debug page to debug_take_action_{manuscript_id}.html")
        
        return False
        
    except Exception as e:
        self.logger.error(f"Error in Take Action clicking: {e}")
        return False


# Apply the fix
if __name__ == "__main__":
    import fileinput
    import sys
    
    print("Applying simple Take Action fix to ScholarOne extractor...")
    
    # Read the fixed method
    with open(__file__, 'r') as f:
        lines = f.readlines()
    
    # Extract just the method definition
    method_lines = []
    in_method = False
    for line in lines:
        if line.strip().startswith('def fixed_click_manuscript'):
            in_method = True
        elif in_method and line.strip() and not line.startswith(' ') and not line.startswith('\t'):
            break
        if in_method:
            # Change the method name back to _click_manuscript
            if 'def fixed_click_manuscript' in line:
                line = line.replace('fixed_click_manuscript', '_click_manuscript')
            method_lines.append(line)
    
    print(f"Extracted {len(method_lines)} lines of fixed method")
    
    # Read the ScholarOne extractor
    extractor_path = '/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/editorial_assistant/extractors/scholarone.py'
    with open(extractor_path, 'r') as f:
        content = f.read()
    
    # Find and replace the _click_manuscript method
    import re
    
    # Pattern to match the entire _click_manuscript method
    pattern = r'(\s*)def _click_manuscript\(self, manuscript_id: str\) -> bool:.*?(?=\n\s*def|\n\s*class|\Z)'
    
    # Find the indentation of the original method
    match = re.search(pattern, content, re.DOTALL)
    if match:
        indent = match.group(1)
        # Add proper indentation to our method
        fixed_method = ''.join([indent + line if line.strip() else line for line in method_lines])
        
        # Replace the method
        new_content = re.sub(pattern, fixed_method.rstrip(), content, flags=re.DOTALL)
        
        # Write back
        with open(extractor_path, 'w') as f:
            f.write(new_content)
        
        print("✅ Successfully applied the fix!")
    else:
        print("❌ Could not find _click_manuscript method")