#!/usr/bin/env python3
"""
Debug the exact login state after attempting to log in
"""

import os
import sys
import time
import logging
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from editorial_assistant.core.browser_manager import BrowserManager
from editorial_assistant.utils.session_manager import session_manager

# Set up logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def debug_login_state():
    """Debug the exact state after login attempt."""
    logger.info("🔍 Debugging login state")
    
    # Load production config
    with open('.env.production', 'r') as f:
        for line in f:
            if '=' in line and not line.startswith('#'):
                key, value = line.strip().split('=', 1)
                os.environ[key] = value
    
    try:
        # Create browser
        browser_manager = BrowserManager(headless=False)
        driver = browser_manager.create_driver()
        
        # Navigate to MF
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        # Accept cookies
        try:
            accept_btn = driver.find_element("id", "onetrust-accept-btn-handler")
            if accept_btn.is_displayed():
                accept_btn.click()
                time.sleep(1)
        except:
            pass
        
        # Get credentials
        user = os.environ.get('MF_EMAIL')
        password = os.environ.get('MF_PASSWORD')
        
        logger.info(f"📧 Using credentials: {user}")
        logger.info(f"🔑 Password length: {len(password)}")
        
        # Fill login form
        user_box = driver.find_element("id", "USERID")
        pw_box = driver.find_element("id", "PASSWORD")
        
        user_box.clear()
        user_box.send_keys(user)
        pw_box.clear()
        pw_box.send_keys(password)
        
        # Submit login
        login_btn = driver.find_element("id", "logInButton")
        login_btn.click()
        
        # Wait and check result
        time.sleep(10)
        
        # Check current state
        current_url = driver.current_url
        page_title = driver.title
        page_source = driver.page_source
        
        logger.info(f"📍 Current URL: {current_url}")
        logger.info(f"📍 Page Title: {page_title}")
        
        # Check for login indicators
        login_indicators = [
            "login failed",
            "invalid credentials", 
            "incorrect password",
            "error",
            "Login Error"
        ]
        
        success_indicators = [
            "Associate Editor Center",
            "Author Center",
            "Reviewer Center", 
            "Editorial Board",
            "Logout",
            "Sign Out"
        ]
        
        # Check for login errors
        found_errors = []
        for indicator in login_indicators:
            if indicator.lower() in page_source.lower():
                found_errors.append(indicator)
        
        # Check for success indicators
        found_success = []
        for indicator in success_indicators:
            if indicator in page_source:
                found_success.append(indicator)
        
        logger.info(f"❌ Login errors found: {found_errors}")
        logger.info(f"✅ Success indicators found: {found_success}")
        
        # Check if we're still on login page
        if "login" in current_url.lower():
            logger.error("❌ Still on login page - login failed")
            
            # Look for specific error messages
            error_elements = driver.find_elements("class name", "error")
            for elem in error_elements:
                if elem.text.strip():
                    logger.error(f"❌ Error message: {elem.text}")
        else:
            logger.info("✅ Not on login page - login may have succeeded")
        
        # Check for device verification modal
        if "unrecognizedDeviceModal" in page_source:
            logger.info("🔍 Device verification modal detected")
        
        # Keep browser open for inspection
        input("Press Enter to close browser...")
        
    except Exception as e:
        logger.error(f"❌ Error debugging login: {e}")
        import traceback
        traceback.print_exc()
    finally:
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    debug_login_state()