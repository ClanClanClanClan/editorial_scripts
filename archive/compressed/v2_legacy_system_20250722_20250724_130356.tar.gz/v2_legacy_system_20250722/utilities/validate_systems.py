#!/usr/bin/env python3
"""
Validate both MF and MOR systems work identically with configuration integration
"""

import sys
sys.path.append('.')

print('COMPARATIVE VALIDATION: MF vs MOR SYSTEMS')
print('='*60)

try:
    import ultrathink_perfect_mf_final as mf
    import ultrathink_perfect_mor_enhanced as mor
    
    print('✅ Both systems imported successfully')
    
    print('\n[HARDCODED MODE COMPARISON]')
    print('-' * 40)
    
    # MF values
    mf_url = mf.get_journal_url()
    mf_categories = mf.get_categories()
    mf_popup = mf.get_popup_wait_time()
    mf_nav = mf.get_page_navigation_wait()
    
    # MOR values  
    mor_url = mor.get_journal_url()
    mor_categories = mor.get_categories()
    mor_popup = mor.get_popup_wait_time()
    mor_nav = mor.get_page_navigation_wait()
    
    print(f'MF URL:  {mf_url}')
    print(f'MOR URL: {mor_url}')
    url_diff = mf_url != mor_url
    print(f'URL difference: {"✅ Expected" if url_diff else "❌ Should differ"}')
    
    print(f'\nMF categories:  {len(mf_categories)} categories')
    print(f'MOR categories: {len(mor_categories)} categories')
    cat_diff = len(mf_categories) != len(mor_categories)
    print(f'Category count difference: {"✅ Expected (6 vs 7)" if cat_diff else "❌ Should differ"}')
    
    print(f'\nMF popup wait:  {mf_popup} seconds')
    print(f'MOR popup wait: {mor_popup} seconds')
    popup_match = mf_popup == mor_popup == 6
    print(f'Critical timing match: {"✅ PASS" if popup_match else "❌ CRITICAL FAIL"}')
    
    print(f'\nMF nav wait:  {mf_nav} seconds')
    print(f'MOR nav wait: {mor_nav} seconds')
    nav_match = mf_nav == mor_nav == 5
    print(f'Navigation timing match: {"✅ PASS" if nav_match else "❌ FAIL"}')
    
    # Test exclusion logic
    mf_exclude = mf.should_exclude_referee('Dylan Possamai')
    mor_exclude = mor.should_exclude_referee('Dylan Possamai')
    
    print(f'\nMF excludes Dylan:  {mf_exclude}')
    print(f'MOR excludes Dylan: {mor_exclude}')
    exclude_match = mf_exclude and mor_exclude
    print(f'Exclusion consistency: {"✅ PASS" if exclude_match else "❌ FAIL"}')
    
    print('\n[SYSTEM DIFFERENCES (EXPECTED)]')
    print(f'Journal URLs: Different (✅)')
    print(f'Category counts: MF={len(mf_categories)}, MOR={len(mor_categories)} (✅)')
    
    print('\n[CRITICAL CONSISTENCIES (REQUIRED)]')
    all_critical_match = popup_match and nav_match and exclude_match
    
    print(f'Popup timing: {"✅" if popup_match else "❌"} (Both 6 seconds)')
    print(f'Navigation timing: {"✅" if nav_match else "❌"} (Both 5 seconds)')
    print(f'Exclusion logic: {"✅" if exclude_match else "❌"} (Both exclude staff)')
    
    print(f'\nOVERALL VALIDATION: {"✅ PASS" if all_critical_match else "❌ FAIL"}')
    
    if all_critical_match:
        print('Both systems have identical critical functionality with appropriate differences')
    else:
        print('CRITICAL: Systems do not match on essential functionality')
    
except Exception as e:
    print(f'❌ Error in comparative validation: {e}')
    import traceback
    traceback.print_exc()