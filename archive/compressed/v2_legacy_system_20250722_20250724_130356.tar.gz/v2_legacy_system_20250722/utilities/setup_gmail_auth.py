#!/usr/bin/env python3
"""
Gmail Authentication Setup Script
=================================

Run this once to set up persistent Gmail credentials for automated access.
The credentials will be saved and can be reused by all scripts.
"""

import os
import json
import sys
from pathlib import Path

# Check for required packages
try:
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    from googleapiclient.discovery import build
    import pickle
except ImportError:
    print("❌ Required packages not installed!")
    print("\nPlease run:")
    print("pip install google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client")
    sys.exit(1)


class GmailAuthSetup:
    # OAuth 2.0 scope for Gmail readonly access
    SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']
    
    def __init__(self):
        self.config_dir = Path("config")
        self.config_dir.mkdir(exist_ok=True)
        
    def setup_credentials(self):
        """Interactive setup for Gmail credentials."""
        print("🔐 Gmail Authentication Setup")
        print("=" * 50)
        
        # Step 1: Check for credentials.json
        print("\n1. Checking for OAuth2 credentials file...")
        
        credential_files = [
            "config/credentials.json",
            "config/gmail_credentials.json",
            "credentials.json",
            "gmail_credentials.json"
        ]
        
        creds_file = None
        for file in credential_files:
            if os.path.exists(file):
                creds_file = file
                print(f"   ✅ Found: {file}")
                break
        
        if not creds_file:
            print("   ❌ No credentials.json found!")
            print("\n   To get credentials.json:")
            print("   1. Go to https://console.cloud.google.com/")
            print("   2. Create a new project or select existing")
            print("   3. Enable Gmail API")
            print("   4. Create OAuth2 credentials (Desktop application)")
            print("   5. Download credentials.json")
            print("   6. Place it in the config/ directory")
            return False
        
        # Step 2: Create new token
        print("\n2. Creating authentication token...")
        print("   A browser window will open for authorization.")
        print("   Please sign in and grant access to Gmail (read-only).")
        
        try:
            flow = InstalledAppFlow.from_client_secrets_file(creds_file, self.SCOPES)
            creds = flow.run_local_server(
                port=0,
                success_message="✅ Authorization successful! You can close this window."
            )
            
            print("   ✅ Authorization completed!")
            
        except Exception as e:
            print(f"   ❌ Authorization failed: {e}")
            return False
        
        # Step 3: Save token in multiple formats
        print("\n3. Saving credentials...")
        
        # Save as JSON (most compatible)
        token_path = self.config_dir / "gmail_token.json"
        with open(token_path, 'w') as token:
            token.write(creds.to_json())
        print(f"   ✅ Saved to {token_path}")
        
        # Also save pickle format for compatibility
        pickle_path = self.config_dir / "token.pickle"
        with open(pickle_path, 'wb') as token:
            pickle.dump(creds, token)
        print(f"   ✅ Saved to {pickle_path}")
        
        # Step 4: Test the connection
        print("\n4. Testing Gmail connection...")
        try:
            service = build('gmail', 'v1', credentials=creds)
            
            # Get user profile
            profile = service.users().getProfile(userId='me').execute()
            email = profile.get('emailAddress', 'Unknown')
            total_messages = profile.get('messagesTotal', 0)
            
            print(f"   ✅ Connected to: {email}")
            print(f"   📧 Total messages: {total_messages:,}")
            
            # Test search
            print("\n5. Testing email search...")
            results = service.users().messages().list(
                userId='me',
                q='newer_than:1d',
                maxResults=5
            ).execute()
            
            recent_count = len(results.get('messages', []))
            print(f"   ✅ Found {recent_count} messages from last 24 hours")
            
        except Exception as e:
            print(f"   ❌ Connection test failed: {e}")
            return False
        
        # Step 5: Create helper script
        print("\n6. Creating helper configuration...")
        
        config_content = {
            "gmail_enabled": True,
            "token_path": str(token_path),
            "email_address": email,
            "scopes": self.SCOPES,
            "last_authenticated": str(Path(token_path).stat().st_mtime)
        }
        
        config_file = self.config_dir / "gmail_config.json"
        with open(config_file, 'w') as f:
            json.dump(config_content, f, indent=2)
        print(f"   ✅ Saved config to {config_file}")
        
        # Step 6: Update .env file
        print("\n7. Updating environment configuration...")
        env_file = Path(".env.production")
        if env_file.exists():
            with open(env_file, 'a') as f:
                f.write(f"\n# Gmail Configuration (added by setup_gmail_auth.py)\n")
                f.write(f"GMAIL_TOKEN_PATH={token_path}\n")
                f.write(f"GMAIL_EMAIL={email}\n")
            print(f"   ✅ Updated {env_file}")
        
        return True
    
    def test_verification_code_fetch(self):
        """Test fetching verification codes."""
        print("\n8. Testing verification code detection...")
        
        try:
            # Load saved credentials
            creds = Credentials.from_authorized_user_file(
                self.config_dir / "gmail_token.json", 
                self.SCOPES
            )
            
            service = build('gmail', 'v1', credentials=creds)
            
            # Search for recent verification emails
            queries = [
                'subject:"verification code" newer_than:7d',
                'subject:"access code" newer_than:7d',
                'subject:"login code" newer_than:7d',
                '(subject:code OR subject:verification) newer_than:7d'
            ]
            
            found_any = False
            for query in queries:
                results = service.users().messages().list(
                    userId='me',
                    q=query,
                    maxResults=3
                ).execute()
                
                messages = results.get('messages', [])
                if messages:
                    print(f"   ✅ Found {len(messages)} potential verification emails")
                    found_any = True
                    break
            
            if not found_any:
                print("   ℹ️  No recent verification emails found (this is normal)")
            
        except Exception as e:
            print(f"   ⚠️  Test failed: {e}")
    
    def show_usage(self):
        """Show how to use the credentials."""
        print("\n" + "="*50)
        print("✅ Setup Complete!")
        print("="*50)
        
        print("\nYour Gmail credentials are now saved and can be used by:")
        print("- MF/MOR extraction scripts (for 2FA codes)")
        print("- Email timeline integration")
        print("- Any script that needs Gmail access")
        
        print("\nExample usage in scripts:")
        print("-"*30)
        print("""
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

# Load saved credentials
creds = Credentials.from_authorized_user_file(
    'config/gmail_token.json',
    ['https://www.googleapis.com/auth/gmail.readonly']
)

# Build Gmail service
service = build('gmail', 'v1', credentials=creds)

# Use the service
results = service.users().messages().list(userId='me', q='query').execute()
""")
        
        print("\nThe credentials will auto-refresh when needed.")
        print("Re-run this script if you ever need to re-authenticate.")


def main():
    setup = GmailAuthSetup()
    
    if setup.setup_credentials():
        setup.test_verification_code_fetch()
        setup.show_usage()
        print("\n✅ Gmail authentication successfully configured!")
    else:
        print("\n❌ Setup failed. Please check the errors above.")
        sys.exit(1)


if __name__ == "__main__":
    main()