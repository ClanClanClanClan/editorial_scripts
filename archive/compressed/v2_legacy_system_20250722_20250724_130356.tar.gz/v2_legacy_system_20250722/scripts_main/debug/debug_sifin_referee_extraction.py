#!/usr/bin/env python3
"""
Debug SIFIN referee extraction from emails
"""

import os
import re
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from email.utils import parsedate_to_datetime
import base64

# Gmail API imports
try:
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
    GMAIL_AVAILABLE = True
except ImportError:
    GMAIL_AVAILABLE = False

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class SIFINRefereeDebugger:
    """Debug SIFIN referee extraction issues"""
    
    def __init__(self):
        self.gmail_service = None
        
    def setup_gmail_service(self) -> bool:
        """Setup Gmail API service"""
        if not GMAIL_AVAILABLE:
            logger.warning("Gmail API not available")
            return False
        
        try:
            token_path = "/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/config/token.json"
            if not os.path.exists(token_path):
                logger.error("Gmail token not found")
                return False
            
            creds = Credentials.from_authorized_user_file(token_path)
            self.gmail_service = build('gmail', 'v1', credentials=creds)
            logger.info("✅ Gmail service initialized")
            return True
            
        except Exception as e:
            logger.error(f"Failed to setup Gmail service: {e}")
            return False
    
    def analyze_sifin_email_content(self, manuscript_id: str = "M174160", sample_size: int = 5):
        """Analyze SIFIN email content to understand referee extraction issues"""
        if not self.gmail_service:
            return
        
        print(f"\n🔍 ANALYZING SIFIN EMAILS FOR REFEREE INFORMATION")
        print(f"   Manuscript: {manuscript_id}")
        print("=" * 60)
        
        # Search for emails
        queries = [
            f'from:sifin.siam.org {manuscript_id}',
            f'subject:SIFIN {manuscript_id}',
            f'subject:"{manuscript_id}"',
        ]
        
        all_messages = []
        seen_ids = set()
        
        for query in queries:
            try:
                response = self.gmail_service.users().messages().list(
                    userId='me',
                    q=query,
                    maxResults=10
                ).execute()
                
                messages = response.get('messages', [])
                for msg in messages:
                    if msg['id'] not in seen_ids:
                        seen_ids.add(msg['id'])
                        all_messages.append(msg)
                        
            except Exception as e:
                logger.error(f"Error with query '{query}': {e}")
        
        print(f"\n📧 Found {len(all_messages)} unique emails")
        
        # Analyze each email
        for i, msg in enumerate(all_messages[:sample_size], 1):
            print(f"\n{'='*60}")
            print(f"EMAIL {i}:")
            self._analyze_email(msg['id'])
    
    def _analyze_email(self, message_id: str):
        """Analyze a single email for referee information"""
        try:
            # Get email details
            message = self.gmail_service.users().messages().get(
                userId='me',
                id=message_id,
                format='full'
            ).execute()
            
            # Extract headers
            payload = message.get('payload', {})
            headers = {h['name']: h['value'] for h in payload.get('headers', [])}
            
            subject = headers.get('Subject', '')
            from_email = headers.get('From', '')
            to_email = headers.get('To', '')
            date_str = headers.get('Date', '')
            
            print(f"\n📬 HEADERS:")
            print(f"   Subject: {subject}")
            print(f"   From: {from_email}")
            print(f"   To: {to_email}")
            print(f"   Date: {date_str}")
            
            # Extract body
            body_text = self._extract_email_body(payload)
            
            print(f"\n📄 BODY CONTENT (first 500 chars):")
            print("-" * 40)
            print(body_text[:500])
            print("-" * 40)
            
            # Look for referee information
            print(f"\n🔍 REFEREE EXTRACTION ATTEMPTS:")
            
            # Method 1: Look in To field
            print(f"\n1. TO FIELD ANALYSIS:")
            to_match = re.search(r'([^<]+)<([^>]+)>', to_email)
            if to_match:
                to_name = to_match.group(1).strip()
                to_addr = to_match.group(2).strip()
                print(f"   Name: {to_name}")
                print(f"   Email: {to_addr}")
            else:
                email_match = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', to_email)
                if email_match:
                    print(f"   Email only: {email_match.group(0)}")
                else:
                    print(f"   No email found in To field")
            
            # Method 2: Look for referee names in body
            print(f"\n2. BODY CONTENT ANALYSIS:")
            
            # Pattern for names after "Dear"
            dear_pattern = r'Dear\s+((?:Dr\.|Prof\.|Professor)?\s*[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)'
            dear_matches = re.findall(dear_pattern, body_text)
            if dear_matches:
                print(f"   'Dear' pattern matches: {dear_matches}")
            
            # Pattern for referee acceptance/decline
            accept_pattern = r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+has\s+(?:accepted|declined)'
            accept_matches = re.findall(accept_pattern, body_text)
            if accept_matches:
                print(f"   Accept/decline pattern matches: {accept_matches}")
            
            # Pattern for email addresses in body
            email_pattern = r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})'
            email_matches = re.findall(email_pattern, body_text)
            if email_matches:
                print(f"   Email addresses in body: {email_matches[:3]}")  # First 3
            
            # Method 3: Look for specific SIFIN patterns
            print(f"\n3. SIFIN-SPECIFIC PATTERNS:")
            
            # Check for invitation patterns
            if re.search(r'invitation.*review|review.*invitation', body_text, re.IGNORECASE):
                print(f"   ✅ Invitation email detected")
                
            # Check for reminder patterns
            if re.search(r'reminder|overdue|follow-up', body_text, re.IGNORECASE):
                print(f"   ✅ Reminder email detected")
                
            # Check for submission patterns
            if re.search(r'report.*received|review.*submitted', body_text, re.IGNORECASE):
                print(f"   ✅ Submission email detected")
            
            # Method 4: Look for referee information in specific locations
            print(f"\n4. CONTEXTUAL EXTRACTION:")
            
            # Look for referee info near keywords
            referee_context_pattern = r'(?:referee|reviewer|report from|submitted by)\s*:?\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)'
            context_matches = re.findall(referee_context_pattern, body_text, re.IGNORECASE)
            if context_matches:
                print(f"   Referee context matches: {context_matches}")
            
        except Exception as e:
            logger.error(f"Error analyzing email {message_id}: {e}")
            import traceback
            traceback.print_exc()
    
    def _extract_email_body(self, payload: Dict) -> str:
        """Extract text from email payload"""
        body = ""
        
        if 'parts' in payload:
            for part in payload['parts']:
                if part['mimeType'] == 'text/plain':
                    data = part.get('body', {}).get('data', '')
                    if data:
                        try:
                            body += base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                        except Exception as e:
                            logger.error(f"Error decoding part: {e}")
                elif 'parts' in part:
                    # Recursive for nested parts
                    body += self._extract_email_body(part)
        else:
            if payload.get('mimeType') == 'text/plain':
                data = payload.get('body', {}).get('data', '')
                if data:
                    try:
                        body = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                    except Exception as e:
                        logger.error(f"Error decoding body: {e}")
        
        return body


def main():
    """Main function"""
    debugger = SIFINRefereeDebugger()
    
    if not debugger.setup_gmail_service():
        print("❌ Failed to setup Gmail service")
        return
    
    # Test with different manuscripts
    test_manuscripts = ["M174160", "M174727", "M175988", "M176140"]
    
    for ms_id in test_manuscripts[:1]:  # Test first one in detail
        debugger.analyze_sifin_email_content(manuscript_id=ms_id, sample_size=3)


if __name__ == "__main__":
    main()