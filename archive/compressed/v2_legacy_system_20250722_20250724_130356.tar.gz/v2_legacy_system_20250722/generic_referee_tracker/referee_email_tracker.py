#!/usr/bin/env python3
"""
Generic Referee-Email Association System
Enables complete timeline reconstruction for any journal's peer review process
"""

import re
import json
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import difflib

logger = logging.getLogger(__name__)

class RefereeState(Enum):
    NOT_INVITED = "not_invited"
    INVITATION_SENT = "invitation_sent"
    INVITATION_PENDING = "invitation_pending"
    ACCEPTED = "accepted"
    DECLINED = "declined"
    REVIEWING = "reviewing"
    REPORT_SUBMITTED = "report_submitted"
    REVISION_REQUESTED = "revision_requested"
    COMPLETED = "completed"

@dataclass
class RefereeAttribution:
    referee_id: str
    confidence: float  # 0.0 to 1.0
    evidence: List[str]  # What led to this attribution
    attribution_method: str  # 'direct', 'thread', 'pattern', 'header', 'fuzzy'

@dataclass
class EmailEvent:
    message_id: str
    thread_id: str
    date: datetime
    subject: str
    from_address: str
    to_addresses: List[str]
    cc_addresses: List[str]
    body: str
    event_type: str  # 'invitation', 'reminder', 'acceptance', 'submission', etc.
    manuscript_id: str
    attribution: Optional[RefereeAttribution] = None

@dataclass
class RefereeProfile:
    """Complete profile of a referee with all name/email variations"""
    referee_id: str
    name_variations: Set[str] = field(default_factory=set)
    email_addresses: Set[str] = field(default_factory=set)
    manuscript_assignments: Dict[str, 'RefereeAssignment'] = field(default_factory=dict)
    communication_history: List[EmailEvent] = field(default_factory=list)
    
    def add_name_variation(self, name: str):
        """Add a name variation for this referee"""
        self.name_variations.add(name.strip())
        
    def add_email_variation(self, email: str):
        """Add an email variation for this referee"""
        self.email_addresses.add(email.strip().lower())
        
    def match_score(self, name: str = None, email: str = None) -> float:
        """Calculate probability this referee matches the given name/email"""
        score = 0.0
        
        if email:
            email = email.strip().lower()
            if email in self.email_addresses:
                score += 0.9
                
        if name:
            name = name.strip()
            # Exact match
            if name in self.name_variations:
                score += 0.8
            else:
                # Fuzzy matching
                best_match = max(
                    difflib.SequenceMatcher(None, name, var).ratio() 
                    for var in self.name_variations
                ) if self.name_variations else 0.0
                score += best_match * 0.6
                
        return min(score, 1.0)

@dataclass
class RefereeAssignment:
    """Referee assignment to a specific manuscript"""
    referee_id: str
    manuscript_id: str
    state: RefereeState = RefereeState.NOT_INVITED
    state_history: List[Tuple[datetime, RefereeState]] = field(default_factory=list)
    invitation_date: Optional[datetime] = None
    response_date: Optional[datetime] = None
    response_decision: Optional[str] = None
    submission_date: Optional[datetime] = None
    reminder_count: int = 0
    
    def transition_to(self, new_state: RefereeState, timestamp: datetime, email_event: EmailEvent):
        """Transition to new state and record it"""
        self.state_history.append((timestamp, new_state))
        self.state = new_state
        
        # Update specific date fields
        if new_state == RefereeState.INVITATION_SENT:
            self.invitation_date = timestamp
        elif new_state in [RefereeState.ACCEPTED, RefereeState.DECLINED]:
            self.response_date = timestamp
            self.response_decision = 'accepted' if new_state == RefereeState.ACCEPTED else 'declined'
        elif new_state == RefereeState.REPORT_SUBMITTED:
            self.submission_date = timestamp

class GenericEmailPatternMatcher:
    """Generic pattern matcher for referee-related emails across all journals"""
    
    def __init__(self):
        self.patterns = {
            'invitation': [
                # Generic invitation patterns
                r'invited?\s+(?:you\s+)?to\s+(?:serve\s+as\s+)?(?:a\s+)?(?:referee|reviewer)',
                r'(?:referee|review)\s+invitation',
                r'would\s+you\s+be\s+(?:willing|able)\s+to\s+(?:referee|review)',
                r'request\s+(?:to\s+)?(?:referee|review)',
                
                # With referee name capture
                r'Dear\s+(?:Dr\.|Prof\.|Professor)?\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)',
                r'invitation\s+(?:sent\s+)?to\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)',
            ],
            
            'acceptance': [
                r'(?:has\s+)?(?:agreed|accepted)\s+to\s+(?:referee|review)',
                r'thank\s+you\s+for\s+(?:agreeing|accepting)',
                r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s+has\s+accepted',
                r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s+has\s+agreed',
            ],
            
            'decline': [
                r'(?:has\s+)?(?:declined|refused)\s+to\s+(?:referee|review)',
                r'unable\s+to\s+(?:referee|review)',
                r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s+has\s+declined',
                r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s+(?:is\s+)?unable',
            ],
            
            'reminder': [
                r'reminder.*(?:review|referee)',
                r'(?:gentle\s+)?reminder.*your\s+(?:referee|review)',
                r'(?:review|referee).*overdue',
                r'(?:overdue|late).*(?:review|referee)',
                r'follow.*up.*(?:review|referee)',
            ],
            
            'submission': [
                r'(?:has\s+)?submitted\s+(?:a\s+)?(?:referee\s+)?(?:report|review)',
                r'(?:report|review)\s+(?:has\s+been\s+)?received',
                r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s+has\s+submitted',
                r'received\s+(?:a\s+)?(?:referee\s+)?(?:report|review)',
            ]
        }
    
    def identify_event_type(self, email_event: EmailEvent) -> str:
        """Identify the type of referee-related event"""
        text = f"{email_event.subject} {email_event.body}".lower()
        
        for event_type, patterns in self.patterns.items():
            for pattern in patterns:
                if re.search(pattern, text, re.IGNORECASE):
                    return event_type
                    
        return 'unknown'
    
    def extract_referee_name(self, email_event: EmailEvent) -> Optional[str]:
        """Extract referee name from email content"""
        text = f"{email_event.subject} {email_event.body}"
        
        # Try patterns with name capture groups
        for patterns in self.patterns.values():
            for pattern in patterns:
                if '(' in pattern:  # Has capture group
                    match = re.search(pattern, text, re.IGNORECASE)
                    if match and match.groups():
                        # Find the first non-empty group
                        for i in range(1, len(match.groups()) + 1):
                            if match.group(i):
                                name = match.group(i).strip()
                                return name
        
        # Try Dear [Name] pattern
        dear_match = re.search(r'Dear\s+(?:Dr\.|Prof\.|Professor)?\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)', text)
        if dear_match:
            name = dear_match.group(1).strip()
            return name
            
        return None

class ThreadTracker:
    """Tracks referee context across email threads"""
    
    def __init__(self):
        self.thread_contexts: Dict[str, str] = {}  # thread_id -> referee_id
        self.thread_emails: Dict[str, List[EmailEvent]] = defaultdict(list)
        
    def add_email_to_thread(self, email_event: EmailEvent):
        """Add email to its thread"""
        self.thread_emails[email_event.thread_id].append(email_event)
        
    def set_referee_for_thread(self, thread_id: str, referee_id: str):
        """Set referee context for entire thread"""
        self.thread_contexts[thread_id] = referee_id
        
    def get_referee_from_thread(self, thread_id: str) -> Optional[str]:
        """Get referee context from thread"""
        return self.thread_contexts.get(thread_id)
        
    def propagate_referee_context(self, thread_id: str):
        """Propagate referee context to all emails in thread"""
        referee_id = self.thread_contexts.get(thread_id)
        if not referee_id:
            return
            
        for email in self.thread_emails[thread_id]:
            if not email.attribution:
                email.attribution = RefereeAttribution(
                    referee_id=referee_id,
                    confidence=0.8,
                    evidence=['thread_propagation'],
                    attribution_method='thread'
                )

class HeaderAnalyzer:
    """Analyzes email headers to identify referees"""
    
    def __init__(self):
        self.journal_domains = {
            'siam.org', 'sifin.siam.org', 'sicon.siam.org',
            'editorialmanager.com', 'manuscriptcentral.com'
        }
        
        # Known editorial/coordinator email patterns
        self.editorial_patterns = {
            'dylan.possamai@math.ethz.ch',
            'dylansmb@gmail.com',
            # Add more editorial patterns as needed
        }
        
        # Domains that typically indicate editorial roles
        self.editorial_domains = {
            'math.ethz.ch'  # Academic institutions often house editors
        }
        
    def extract_referee_from_headers(self, email_event: EmailEvent) -> Optional[str]:
        """Extract referee email from headers, excluding editorial addresses"""
        # Check TO field for non-journal, non-editorial addresses
        for to_addr in email_event.to_addresses:
            if not self._is_journal_address(to_addr) and not self._is_editorial_address(to_addr):
                return to_addr
                
        # Check CC field for referee emails
        for cc_addr in email_event.cc_addresses:
            if not self._is_journal_address(cc_addr) and not self._is_editorial_address(cc_addr):
                return cc_addr
                
        return None
    
    def extract_referee_from_body(self, email_event: EmailEvent) -> Optional[str]:
        """Extract referee email address from email body content"""
        # Pattern to find email addresses in body
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        
        found_emails = re.findall(email_pattern, email_event.body, re.IGNORECASE)
        
        for email in found_emails:
            email = email.lower()
            # Skip journal and editorial addresses
            if not self._is_journal_address(email) and not self._is_editorial_address(email):
                return email
                
        return None
    
    def _is_journal_address(self, email: str) -> bool:
        """Check if email is from journal system"""
        domain = email.split('@')[-1].lower()
        return any(journal_domain in domain for journal_domain in self.journal_domains)
    
    def _is_editorial_address(self, email: str) -> bool:
        """Check if email is from editorial/coordinator"""
        email_lower = email.lower()
        
        # Check exact editorial patterns
        if email_lower in self.editorial_patterns:
            return True
            
        # Check editorial domains
        domain = email_lower.split('@')[-1] if '@' in email_lower else ''
        if domain in self.editorial_domains:
            return True
            
        return False

class GenericRefereeTracker:
    """Main class for tracking referees across all journals"""
    
    def __init__(self):
        self.pattern_matcher = GenericEmailPatternMatcher()
        self.thread_tracker = ThreadTracker()
        self.header_analyzer = HeaderAnalyzer()
        
        self.referee_profiles: Dict[str, RefereeProfile] = {}
        self.manuscript_assignments: Dict[str, Dict[str, RefereeAssignment]] = defaultdict(dict)
        
    def process_email(self, email_event: EmailEvent) -> EmailEvent:
        """Process an email and attempt to attribute it to a referee"""
        # Add to thread tracking
        self.thread_tracker.add_email_to_thread(email_event)
        
        # Identify event type
        email_event.event_type = self.pattern_matcher.identify_event_type(email_event)
        
        # Try to identify referee
        referee_id = self._identify_referee(email_event)
        
        if referee_id:
            # Create attribution
            email_event.attribution = RefereeAttribution(
                referee_id=referee_id,
                confidence=0.9,
                evidence=['pattern_match'],
                attribution_method='pattern'
            )
            
            # Update referee state
            self._update_referee_state(referee_id, email_event)
            
        return email_event
    
    def _identify_referee(self, email_event: EmailEvent) -> Optional[str]:
        """Multi-layer referee identification"""
        
        # Layer 1: Direct email header identification
        referee_email = self.header_analyzer.extract_referee_from_headers(email_event)
        if referee_email:
            referee_id = self._find_or_create_referee_by_email(referee_email, email_event)
            return referee_id
        
        # Layer 2: Email body identification (for SIAM notifications)
        referee_email = self.header_analyzer.extract_referee_from_body(email_event)
        if referee_email:
            referee_id = self._find_or_create_referee_by_email(referee_email, email_event)
            return referee_id
        
        # Layer 3: Thread context
        referee_id = self.thread_tracker.get_referee_from_thread(email_event.thread_id)
        if referee_id:
            return referee_id
        
        # Layer 4: Pattern-based name extraction
        referee_name = self.pattern_matcher.extract_referee_name(email_event)
        if referee_name:
            referee_id = self._find_or_create_referee_by_name(referee_name)
            # Set thread context for future emails
            self.thread_tracker.set_referee_for_thread(email_event.thread_id, referee_id)
            return referee_id
            
        # Layer 5: Fuzzy matching against known referees
        referee_id = self._fuzzy_match_referee(email_event)
        if referee_id:
            return referee_id
            
        return None
    
    def _find_or_create_referee_by_email(self, email: str, email_event: EmailEvent = None) -> str:
        """Find existing referee by email or create new one"""
        email = email.strip().lower()
        
        # Search existing referees
        for referee_id, profile in self.referee_profiles.items():
            if email in profile.email_addresses:
                return referee_id
                
        # Create new referee
        referee_id = f"ref_{len(self.referee_profiles) + 1}"
        profile = RefereeProfile(referee_id=referee_id)
        profile.add_email_variation(email)
        
        # Try to extract name from the same email content
        if email_event:
            referee_name = self.pattern_matcher.extract_referee_name(email_event)
            if referee_name:
                profile.add_name_variation(referee_name)
        
        self.referee_profiles[referee_id] = profile
        
        return referee_id
    
    def _find_or_create_referee_by_name(self, name: str) -> str:
        """Find existing referee by name or create new one"""
        name = name.strip()
        
        # Search existing referees
        best_match = None
        best_score = 0.0
        
        for referee_id, profile in self.referee_profiles.items():
            score = profile.match_score(name=name)
            if score > best_score:
                best_score = score
                best_match = referee_id
                
        # If good match found, use it
        if best_match and best_score > 0.7:
            self.referee_profiles[best_match].add_name_variation(name)
            return best_match
            
        # Create new referee
        referee_id = f"ref_{len(self.referee_profiles) + 1}"
        profile = RefereeProfile(referee_id=referee_id)
        profile.add_name_variation(name)
        self.referee_profiles[referee_id] = profile
        
        return referee_id
    
    def _fuzzy_match_referee(self, email_event: EmailEvent) -> Optional[str]:
        """Attempt fuzzy matching against known referees"""
        # This is a placeholder for more sophisticated fuzzy matching
        # Could analyze email content for partial names, signatures, etc.
        return None
    
    def _update_referee_state(self, referee_id: str, email_event: EmailEvent):
        """Update referee state based on email event"""
        manuscript_id = email_event.manuscript_id
        
        # Get or create assignment
        if referee_id not in self.manuscript_assignments[manuscript_id]:
            self.manuscript_assignments[manuscript_id][referee_id] = RefereeAssignment(
                referee_id=referee_id,
                manuscript_id=manuscript_id
            )
        
        assignment = self.manuscript_assignments[manuscript_id][referee_id]
        
        # State transitions based on event type
        if email_event.event_type == 'invitation':
            assignment.transition_to(RefereeState.INVITATION_SENT, email_event.date, email_event)
        elif email_event.event_type == 'acceptance':
            assignment.transition_to(RefereeState.ACCEPTED, email_event.date, email_event)
        elif email_event.event_type == 'decline':
            assignment.transition_to(RefereeState.DECLINED, email_event.date, email_event)
        elif email_event.event_type == 'reminder':
            assignment.reminder_count += 1
            if assignment.state == RefereeState.INVITATION_SENT:
                assignment.transition_to(RefereeState.INVITATION_PENDING, email_event.date, email_event)
        elif email_event.event_type == 'submission':
            assignment.transition_to(RefereeState.REPORT_SUBMITTED, email_event.date, email_event)
    
    def finalize_processing(self):
        """Finalize processing by propagating thread contexts"""
        for thread_id in self.thread_tracker.thread_emails:
            self.thread_tracker.propagate_referee_context(thread_id)
    
    def get_referee_timeline(self, manuscript_id: str) -> Dict[str, List[EmailEvent]]:
        """Get complete timeline organized by referee"""
        timeline = defaultdict(list)
        
        for thread_id, emails in self.thread_tracker.thread_emails.items():
            for email in emails:
                if email.manuscript_id == manuscript_id and email.attribution:
                    timeline[email.attribution.referee_id].append(email)
        
        # Sort emails by date for each referee
        for referee_id in timeline:
            timeline[referee_id].sort(key=lambda x: x.date)
            
        return dict(timeline)
    
    def generate_analytics(self, manuscript_id: str) -> Dict:
        """Generate comprehensive analytics for a manuscript"""
        assignments = self.manuscript_assignments.get(manuscript_id, {})
        timeline = self.get_referee_timeline(manuscript_id)
        
        # Filter out editorial referees
        actual_referees = {}
        editorial_referees = {}
        
        for referee_id, assignment in assignments.items():
            profile = self.referee_profiles.get(referee_id)
            if profile and profile.email_addresses:
                primary_email = next(iter(profile.email_addresses))
                if self.header_analyzer._is_editorial_address(primary_email):
                    editorial_referees[referee_id] = assignment
                else:
                    actual_referees[referee_id] = assignment
            else:
                actual_referees[referee_id] = assignment
        
        analytics = {
            'manuscript_id': manuscript_id,
            'total_referees': len(actual_referees),
            'total_editorial_contacts': len(editorial_referees),
            'referee_states': {},
            'timeline_coverage': 0.0,
            'referees': {},
            'editorial_contacts': {}
        }
        
        # Calculate state distribution for actual referees only
        for referee_id, assignment in actual_referees.items():
            state = assignment.state.value
            analytics['referee_states'][state] = analytics['referee_states'].get(state, 0) + 1
            
            # Referee-specific analytics
            profile = self.referee_profiles.get(referee_id)
            referee_timeline = timeline.get(referee_id, [])
            
            analytics['referees'][referee_id] = {
                'name': next(iter(profile.name_variations)) if profile and profile.name_variations else 'Unknown',
                'email': next(iter(profile.email_addresses)) if profile and profile.email_addresses else '',
                'state': state,
                'invitation_date': assignment.invitation_date.isoformat() if assignment.invitation_date else None,
                'response_date': assignment.response_date.isoformat() if assignment.response_date else None,
                'submission_date': assignment.submission_date.isoformat() if assignment.submission_date else None,
                'reminder_count': assignment.reminder_count,
                'timeline_events': len(referee_timeline)
            }
        
        # Track editorial contacts separately
        for referee_id, assignment in editorial_referees.items():
            profile = self.referee_profiles.get(referee_id)
            referee_timeline = timeline.get(referee_id, [])
            
            analytics['editorial_contacts'][referee_id] = {
                'name': next(iter(profile.name_variations)) if profile and profile.name_variations else 'Unknown',
                'email': next(iter(profile.email_addresses)) if profile and profile.email_addresses else '',
                'state': assignment.state.value,
                'timeline_events': len(referee_timeline)
            }
        
        # Calculate timeline coverage (percentage of emails attributed to actual referees)
        referee_emails = sum(
            len(emails) for referee_id, emails in timeline.items() 
            if referee_id in actual_referees
        )
        total_emails = sum(len(emails) for emails in timeline.values()) if timeline else 0
        attributed_emails = sum(1 for emails in timeline.values() for email in emails if email.attribution)
        
        analytics['timeline_coverage'] = attributed_emails / total_emails if total_emails > 0 else 0.0
        analytics['referee_email_coverage'] = referee_emails / total_emails if total_emails > 0 else 0.0
        
        return analytics