#!/usr/bin/env python3
"""
Debug Associate Editor Center navigation step by step
"""

import os
import sys
import time
import logging
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from editorial_assistant.core.browser_manager import BrowserManager
from core.email_utils import fetch_latest_verification_code

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def debug_ae_center_navigation():
    """Debug Associate Editor Center navigation."""
    logger.info("🧪 Testing Associate Editor Center navigation")
    
    # Load production config
    with open('.env.production', 'r') as f:
        for line in f:
            if '=' in line and not line.startswith('#'):
                key, value = line.strip().split('=', 1)
                os.environ[key] = value
    
    try:
        # Create browser
        browser_manager = BrowserManager(headless=False)
        driver = browser_manager.create_driver()
        
        # Login process (abbreviated since we know it works)
        logger.info("📍 Logging in...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        # Accept cookies
        try:
            accept_btn = driver.find_element("id", "onetrust-accept-btn-handler")
            if accept_btn.is_displayed():
                accept_btn.click()
                time.sleep(1)
        except:
            pass
        
        # Login
        user = os.environ.get('MF_EMAIL')
        password = os.environ.get('MF_PASSWORD')
        
        user_box = driver.find_element("id", "USERID")
        pw_box = driver.find_element("id", "PASSWORD")
        
        user_box.clear()
        user_box.send_keys(user)
        pw_box.clear()
        pw_box.send_keys(password)
        
        login_btn = driver.find_element("id", "logInButton")
        login_btn.click()
        time.sleep(10)
        
        # Handle device verification if needed
        if "UNRECOGNIZED_DEVICE" in driver.page_source:
            logger.info("📍 Handling device verification...")
            verification_input = driver.find_element("id", "TOKEN_VALUE")
            verification_code = fetch_latest_verification_code(journal="MF", max_wait=300, poll_interval=10)
            
            if verification_code:
                verification_input.clear()
                verification_input.send_keys(verification_code)
                verification_input.send_keys("\n")
                time.sleep(10)
                logger.info("✅ Device verification completed")
        
        # Now debug Associate Editor Center navigation
        logger.info("📍 Looking for Associate Editor Center...")
        
        # Check current page
        current_url = driver.current_url
        page_source = driver.page_source
        
        logger.info(f"Current URL: {current_url}")
        
        # Look for Associate Editor Center link  
        ae_link = None
        all_links = driver.find_elements("tag name", "a")
        logger.info(f"Found {len(all_links)} total links")
        
        for i, link in enumerate(all_links):
            try:
                link_text = link.text.strip()
                href = link.get_attribute('href')
                
                if link_text == "Associate Editor Center":
                    logger.info(f"  ✅ FOUND AE CENTER: Link {i+1}: '{link_text}' -> {href}")
                    ae_link = link
                    break
                elif link_text and len(link_text) > 3:  # Show all meaningful links for debugging
                    logger.info(f"  Link {i+1}: '{link_text}' -> {href}")
            except:
                pass
        
        # Try to click the Associate Editor Center
        if ae_link:
            logger.info("📍 Clicking Associate Editor Center...")
            ae_link.click()
            time.sleep(5)
            
            # Check new page
            new_url = driver.current_url
            logger.info(f"After clicking AE Center: {new_url}")
            
            # Look for manuscript dashboard table
            logger.info("📍 Looking for manuscript dashboard...")
            
            tables = driver.find_elements("tag name", "table")
            logger.info(f"Found {len(tables)} tables")
            
            for i, table in enumerate(tables):
                table_text = table.text
                if "Awaiting Reviewer" in table_text or "Manuscript" in table_text:
                    logger.info(f"📊 Table {i+1} contains manuscript data:")
                    logger.info(f"   Preview: {table_text[:500]}...")
                    
                    # Look for links with numbers
                    links = table.find_elements("tag name", "a")
                    for link in links:
                        link_text = link.text.strip()
                        if link_text.isdigit() and int(link_text) > 0:
                            logger.info(f"   Found manuscript count link: '{link_text}'")
                            
                            # Click on this link
                            logger.info(f"📍 Clicking on count link: {link_text}")
                            link.click()
                            time.sleep(5)
                            
                            # Check what page we're on
                            category_url = driver.current_url
                            logger.info(f"Category page URL: {category_url}")
                            
                            # Look for manuscript table
                            category_tables = driver.find_elements("tag name", "table")
                            logger.info(f"Found {len(category_tables)} tables in category")
                            
                            for j, cat_table in enumerate(category_tables):
                                cat_text = cat_table.text
                                if "MAFI" in cat_text or "MOR" in cat_text:
                                    logger.info(f"📋 Manuscript table {j+1}:")
                                    logger.info(f"   Content: {cat_text[:500]}...")
                            
                            # Go back to dashboard
                            driver.back()
                            time.sleep(3)
                            break
                    break
        else:
            logger.error("❌ No Associate Editor Center link found")
        
        # Keep browser open for inspection
        input("Press Enter to close browser...")
        
    except Exception as e:
        logger.error(f"❌ Error debugging AE Center navigation: {e}")
        import traceback
        traceback.print_exc()
    finally:
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    debug_ae_center_navigation()