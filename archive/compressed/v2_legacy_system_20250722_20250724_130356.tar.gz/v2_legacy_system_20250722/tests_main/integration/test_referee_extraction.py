#!/usr/bin/env python3
"""Test referee extraction after successful Take Action click"""

import os
import sys
import time
from pathlib import Path
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

def test_referee_extraction():
    """Test referee extraction after Take Action"""
    
    print("🎯 TESTING REFEREE EXTRACTION AFTER TAKE ACTION")
    print("=" * 60)
    
    # Chrome setup
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        # Quick login (we know this works)
        print("1. Quick login to MF...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        try:
            reject_btn = driver.find_element(By.ID, "onetrust-reject-all-handler")
            reject_btn.click()
        except:
            pass
        
        email_field = driver.find_element(By.ID, "USERID")
        email_field.send_keys(os.getenv('MF_EMAIL'))
        password_field = driver.find_element(By.ID, "PASSWORD")
        password_field.send_keys(os.getenv('MF_PASSWORD'))
        login_btn = driver.find_element(By.ID, "logInButton")
        driver.execute_script("arguments[0].click();", login_btn)
        time.sleep(3)
        
        # Handle 2FA
        try:
            code_input = driver.find_element(By.ID, "TOKEN_VALUE")
            from core.email_utils import fetch_latest_verification_code
            time.sleep(5)
            verification_code = fetch_latest_verification_code('MF', max_wait=60, poll_interval=3)
            if verification_code:
                code_input.clear()
                code_input.send_keys(verification_code)
                try:
                    remember_checkbox = driver.find_element(By.ID, "REMEMBER_THIS_DEVICE")
                    if not remember_checkbox.is_selected():
                        remember_checkbox.click()
                except:
                    pass
                verify_btn = driver.find_element(By.ID, "VERIFY_BTN")
                verify_btn.click()
                time.sleep(15)
        except:
            pass
        
        # Navigate to manuscripts (we know this works)
        print("2. Navigating to manuscripts...")
        ae_link = driver.find_element(By.LINK_TEXT, "Associate Editor Center")
        ae_link.click()
        time.sleep(5)
        
        category_link = driver.find_element(By.LINK_TEXT, "Awaiting Reviewer Scores")
        category_link.click()
        time.sleep(5)
        
        # Find and click Take Action (we know this works)
        print("3. Finding and clicking Take Action...")
        all_rows = driver.find_elements(By.TAG_NAME, "tr")
        
        for row in all_rows:
            if 'MAFI-' in row.text:
                cells = row.find_elements(By.TAG_NAME, "td")
                if cells:
                    last_cell = cells[-1]
                    take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
                    
                    if take_action_links:
                        href = take_action_links[0].get_attribute('href')
                        if href and 'javascript:' in href:
                            manuscript_id = None
                            # Extract manuscript ID from row
                            for cell in cells:
                                if 'MAFI-' in cell.text:
                                    manuscript_id = cell.text.split()[0] if cell.text.split() else None
                                    break
                            
                            print(f"📄 Clicking Take Action for manuscript: {manuscript_id}")
                            js_code = href.replace('javascript:', '')
                            driver.execute_script(js_code)
                            time.sleep(5)
                            
                            # Now we're on the manuscript details page
                            print("4. ANALYZING MANUSCRIPT DETAILS PAGE...")
                            print("-" * 50)
                            
                            current_url = driver.current_url
                            print(f"Current URL: {current_url}")
                            
                            page_text = driver.find_element(By.TAG_NAME, "body").text
                            print(f"Page contains 'Referee': {'Referee' in page_text}")
                            print(f"Page contains 'Reviewer': {'Reviewer' in page_text}")
                            
                            # Look for referee information
                            print("\n5. LOOKING FOR REFEREE DATA...")
                            print("-" * 50)
                            
                            # Common referee selectors
                            referee_selectors = [
                                "//td[contains(text(), 'Referee')]",
                                "//td[contains(text(), 'Reviewer')]", 
                                "//td[contains(text(), '@')]",  # Email addresses
                                "//table//tr[contains(., 'Referee')]",
                                "//table//tr[contains(., 'Reviewer')]"
                            ]
                            
                            for selector in referee_selectors:
                                elements = driver.find_elements(By.XPATH, selector)
                                if elements:
                                    print(f"✅ Found {len(elements)} elements with selector: {selector}")
                                    for i, elem in enumerate(elements[:3]):  # Show first 3
                                        print(f"   {i+1}: {elem.text[:100]}...")
                                else:
                                    print(f"❌ No elements found with selector: {selector}")
                            
                            # Look for tables
                            print("\n6. ANALYZING TABLES ON PAGE...")
                            print("-" * 50)
                            
                            tables = driver.find_elements(By.TAG_NAME, "table")
                            print(f"Found {len(tables)} tables")
                            
                            for i, table in enumerate(tables):
                                table_text = table.text
                                if any(keyword in table_text.lower() for keyword in ['referee', 'reviewer', '@']):
                                    print(f"\n🎯 Table {i+1} contains referee-related content:")
                                    print(f"   Text preview: {table_text[:200]}...")
                                    
                                    # Try to extract referee rows
                                    rows = table.find_elements(By.TAG_NAME, "tr")
                                    print(f"   Has {len(rows)} rows")
                                    
                                    for j, row in enumerate(rows[:5]):  # Show first 5 rows
                                        cells = row.find_elements(By.TAG_NAME, "td")
                                        if cells and any('@' in cell.text or 'referee' in cell.text.lower() for cell in cells):
                                            row_data = [cell.text.strip() for cell in cells]
                                            print(f"     Row {j+1}: {row_data}")
                            
                            print("\n✅ REFEREE PAGE ANALYSIS COMPLETE")
                            break
                
                if 'take_action_links' in locals():
                    break
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        driver.quit()

if __name__ == "__main__":
    test_referee_extraction()