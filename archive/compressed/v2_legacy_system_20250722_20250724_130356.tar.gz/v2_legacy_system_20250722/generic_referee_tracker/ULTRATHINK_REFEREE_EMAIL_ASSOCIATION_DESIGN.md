# ULTRATHINK: Generic Referee-Email Association System Design

## Executive Summary
A comprehensive system to uniquely associate every referee-related email with the specific referee it concerns, enabling complete timeline reconstruction for any journal's peer review process.

## Core Problem Statement
Current system limitations:
- 95% of emails assigned to "unknown" referee
- Only identifies referees in explicit "X submitted report" patterns
- No context tracking across email threads
- No state machine for referee lifecycle
- Missing critical timeline events (invitations, acceptances, reminders)

## Proposed Solution Architecture

### 1. Email Thread Tracking System
```python
class EmailThread:
    thread_id: str
    manuscript_id: str
    referee_context: RefereeContext
    email_chain: List[EmailMessage]
    
    def track_referee_through_thread(self):
        """Maintain referee identity across entire email conversation"""
```

Key Features:
- Use Gmail thread IDs to group related emails
- Propagate referee context through the thread
- Handle multi-referee threads (CC'd referees)

### 2. Referee State Machine
```
States:
- NOT_INVITED
- INVITATION_SENT → (email: invitation with referee name/email)
- INVITATION_PENDING → (email: reminders)
- ACCEPTED → (email: acceptance confirmation)
- DECLINED → (email: decline notification)
- REVIEWING → (email: reminders, queries)
- REPORT_SUBMITTED → (email: submission confirmation)
- REVISION_REQUESTED → (email: revision request)
```

### 3. Multi-Layer Referee Identification Strategy

#### Layer 1: Direct Identification
- Email TO/FROM fields contain referee email
- Email body contains "Dear [Referee Name]"
- Subject contains referee name/identifier

#### Layer 2: Context-Based Identification
- Previous email in thread identified referee
- Email references manuscript + referee ID
- Email timing matches expected referee action

#### Layer 3: Pattern-Based Identification
- Invitation patterns: "invited to review", "invitation to referee"
- Response patterns: "agreed to review", "unable to review"
- Reminder patterns: "reminder for your review", "overdue review"

#### Layer 4: Header Analysis
```python
def extract_referee_from_headers(email):
    # Check TO field for non-journal addresses
    # Check CC field for referee emails
    # Check Reply-To headers
    # Check X-Original-To headers
```

### 4. Generic Journal Pattern Library

```python
JOURNAL_PATTERNS = {
    'invitation': [
        # Generic patterns
        r'invited?\s+(?:you\s+)?to\s+(?:serve\s+as\s+)?(?:a\s+)?(?:referee|reviewer)',
        r'(?:referee|review)\s+invitation',
        r'would\s+you\s+be\s+(?:willing|able)\s+to\s+(?:referee|review)',
        
        # With referee name capture
        r'Dear\s+(?:Dr\.|Prof\.|Professor)?\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)',
        r'invitation\s+(?:sent\s+)?to\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)',
    ],
    
    'acceptance': [
        r'(?:has\s+)?(?:agreed|accepted)\s+to\s+(?:referee|review)',
        r'thank\s+you\s+for\s+(?:agreeing|accepting)',
        r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s+has\s+accepted',
    ],
    
    'reminder': [
        r'reminder.*(?:review|referee).*(?:for|of)\s+(M\d+)',
        r'(?:gentle\s+)?reminder.*your\s+(?:referee|review)',
        r'(?:review|referee).*overdue',
    ]
}
```

### 5. Referee Profile Builder

```python
@dataclass
class RefereeProfile:
    name_variations: List[str]  # ["John Smith", "J. Smith", "Smith, John"]
    email_addresses: List[str]  # Primary and alternates
    manuscript_assignments: Dict[str, RefereeAssignment]
    communication_history: List[EmailEvent]
    
    def match_score(self, email_data) -> float:
        """Calculate probability this email relates to this referee"""
```

### 6. Implementation Strategy

#### Phase 1: Email Analysis Enhancement
```python
class EnhancedEmailParser:
    def __init__(self):
        self.pattern_matcher = PatternMatcher()
        self.header_parser = HeaderParser()
        self.thread_tracker = ThreadTracker()
    
    def identify_referee(self, email, manuscript_context):
        # 1. Try direct identification
        referee = self.direct_identification(email)
        if referee:
            return referee
            
        # 2. Check thread context
        referee = self.thread_tracker.get_referee_from_thread(email.thread_id)
        if referee:
            return referee
            
        # 3. Pattern matching with context
        referee = self.pattern_based_identification(email, manuscript_context)
        if referee:
            self.thread_tracker.set_referee_for_thread(email.thread_id, referee)
            return referee
            
        # 4. Header analysis
        referee = self.header_based_identification(email)
        if referee:
            return referee
            
        return None
```

#### Phase 2: State Machine Implementation
```python
class RefereeStateMachine:
    def __init__(self, referee_id, manuscript_id):
        self.state = 'NOT_INVITED'
        self.state_history = []
        
    def process_email(self, email, email_type):
        transitions = {
            ('NOT_INVITED', 'invitation'): 'INVITATION_SENT',
            ('INVITATION_SENT', 'acceptance'): 'ACCEPTED',
            ('INVITATION_SENT', 'decline'): 'DECLINED',
            ('ACCEPTED', 'submission'): 'REPORT_SUBMITTED',
            # ... more transitions
        }
        
        new_state = transitions.get((self.state, email_type))
        if new_state:
            self.transition_to(new_state, email)
```

#### Phase 3: Cross-Journal Testing
- Test on SICON emails
- Test on SIFIN emails  
- Test on other SIAM journals
- Identify journal-specific patterns
- Build journal-agnostic core with journal-specific adapters

### 7. Advanced Features

#### Email Deduplication
- Identify duplicate notifications
- Handle email forwards/replies
- Merge related events

#### Fuzzy Matching
```python
def fuzzy_referee_match(referee_name, candidate_name):
    # Handle name variations
    # "John Smith" matches "J. Smith"
    # "Smith, John" matches "John Smith"
    # "John A. Smith" matches "John Smith"
```

#### Confidence Scoring
```python
@dataclass
class RefereeAttribution:
    referee_id: str
    confidence: float  # 0.0 to 1.0
    evidence: List[str]  # What led to this attribution
```

### 8. Expected Outcomes

With this system implemented:
- 90%+ of emails will be attributed to specific referees
- Complete referee timelines showing:
  - Invitation date and method
  - Response time and decision
  - All reminders sent to that specific referee
  - Review submission details
- Accurate performance metrics per referee
- Full manuscript review timeline with all actors identified

### 9. Technical Implementation Plan

1. **Week 1-2**: Build email thread tracking system
2. **Week 3-4**: Implement referee state machine
3. **Week 5-6**: Create pattern library and matching engine
4. **Week 7-8**: Develop referee profile builder
5. **Week 9-10**: Integration and testing across journals
6. **Week 11-12**: Performance optimization and edge cases

### 10. Key Algorithms

#### Thread-Based Referee Propagation
```python
def propagate_referee_context(thread_emails):
    # Find anchor email with clear referee identification
    anchor = find_anchor_email(thread_emails)
    if not anchor:
        return
        
    # Propagate forward and backward in thread
    referee = anchor.identified_referee
    for email in thread_emails:
        if not email.referee:
            email.referee = referee
            email.attribution_method = 'thread_propagation'
```

#### Multi-Signal Attribution
```python
def attribute_referee(email, signals):
    # Combine multiple signals with weights
    scores = {}
    
    if signals.get('to_field_match'):
        scores['direct_email'] = 0.9
        
    if signals.get('thread_context'):
        scores['thread'] = 0.8
        
    if signals.get('pattern_match'):
        scores['pattern'] = 0.6
        
    if signals.get('timing_match'):
        scores['timing'] = 0.4
        
    return weighted_combination(scores)
```

This system will revolutionize referee tracking by ensuring every email is properly attributed, enabling true performance analytics and timeline reconstruction.