#!/usr/bin/env python3
"""
ScholarOne Platform Base - Common functionality for MF and MOR extractors.

This module provides the shared ScholarOne platform implementation,
consolidating common authentication, navigation, and extraction patterns.

Phase 3: System Integration - ScholarOne Platform Abstraction
"""

from typing import Dict, List, Optional, Any
from datetime import datetime
import time
import os

from .platform_extractor import (
    PlatformExtractor, 
    PlatformType, 
    AuthenticationType,
    UnifiedManuscript,
    UnifiedReferee
)
from ..core.exceptions import ExtractionError, ConfigurationError
from ..core.browser_manager import BrowserManager
from ..core.unified_config import get_config_manager


class ScholarOnePlatform(PlatformExtractor):
    """
    Base class for ScholarOne platform extractors (MF, MOR).
    
    Implements common ScholarOne authentication, navigation patterns,
    and extraction workflows shared between MF and MOR journals.
    """
    
    def _determine_platform_type(self) -> PlatformType:
        """ScholarOne platform type."""
        return PlatformType.SCHOLARONE
    
    def _determine_auth_type(self) -> AuthenticationType:
        """ScholarOne uses username/password with 2FA."""
        return AuthenticationType.USERNAME_PASSWORD
    
    def _initialize_platform_components(self, **kwargs):
        """Initialize ScholarOne-specific components."""
        
        # Browser configuration
        self.headless = kwargs.get('headless', True)
        self.browser_type = 'chrome'  # ScholarOne works best with Chrome
        self.browser_manager = BrowserManager(headless=self.headless)
        
        # ScholarOne platform URLs (will be overridden by subclasses)
        self.journal_url = self._get_journal_url()
        self.site_prefix = self._get_site_prefix()
        
        # Common ScholarOne timings (critical for popup handling)
        config_manager = get_config_manager()
        self.popup_wait_time = config_manager.get_global_setting('popup_wait', 6)  # Critical: 6 seconds
        self.page_navigation_wait = config_manager.get_global_setting('page_navigation', 5)
        self.element_wait_time = config_manager.get_global_setting('element_wait', 3)
        
        # ScholarOne-specific categories (will be overridden by subclasses)
        self.categories = self._get_platform_categories()
        
        # Staff exclusion lists (journal-specific)
        self.staff_to_exclude = self._get_staff_exclusions()
        
        # Authentication state
        self._is_authenticated = False
        self._current_session = None
        
        self.logger.info(f"ScholarOne platform initialized - URL: {self.journal_url}, "
                        f"Categories: {len(self.categories)}, Popup wait: {self.popup_wait_time}s")
    
    def _get_journal_url(self) -> str:
        """Get the journal-specific URL (must be implemented by subclasses)."""
        url_map = {
            'MF': 'https://mc.manuscriptcentral.com/mafi',
            'MOR': 'https://mc.manuscriptcentral.com/mor'
        }
        
        if self.journal_code in url_map:
            return url_map[self.journal_code]
        else:
            raise ConfigurationError(f"Unknown journal code for ScholarOne: {self.journal_code}")
    
    def _get_site_prefix(self) -> str:
        """Get the site prefix for URL construction."""
        return self.journal_url.split('/cgi-bin')[0] if '/cgi-bin' in self.journal_url else self.journal_url
    
    def _get_platform_categories(self) -> List[str]:
        """Get platform-specific categories (implemented by subclasses)."""
        # Default ScholarOne categories - subclasses override for specific journals
        return [
            "Reviewer Assignment",
            "Awaiting Reviewer Assignment", 
            "Under Review",
            "Awaiting Final Decision",
            "Required Reviews Completed",
            "Awaiting AE Recommendation"
        ]
    
    def _get_staff_exclusions(self) -> List[str]:
        """Get staff members to exclude from referee lists (journal-specific)."""
        # Default exclusions - subclasses can override
        return [
            "Editorial Office",
            "Managing Editor", 
            "Editor-in-Chief",
            "Associate Editor",
            "Editorial Assistant"
        ]
    
    def authenticate(self, **credentials) -> bool:
        """
        Authenticate with ScholarOne platform.
        
        Args:
            **credentials: Should contain 'username' and 'password'
                          Environment variables used as fallback
        
        Returns:
            bool: True if authentication successful
        """
        # Get credentials
        username = credentials.get('username') or os.environ.get('SCHOLARONE_USERNAME') or os.environ.get(f'{self.journal_code}_USERNAME')
        password = credentials.get('password') or os.environ.get('SCHOLARONE_PASSWORD') or os.environ.get(f'{self.journal_code}_PASSWORD')
        
        if not username or not password:
            raise ExtractionError(f"No credentials provided for {self.journal_code}. "
                                f"Provide username/password or set environment variables.")
        
        try:
            self.logger.info(f"Starting ScholarOne authentication for {self.journal_code}")
            
            # Initialize browser session
            self.driver = self.browser_manager.get_driver()
            
            # Navigate to journal URL
            self.driver.get(self.journal_url)
            time.sleep(self.page_navigation_wait)
            
            # Perform login
            success = self._perform_login(username, password)
            
            if success:
                self._is_authenticated = True
                self.logger.info(f"Authentication successful for {self.journal_code}")
                return True
            else:
                raise ExtractionError("Login failed - credentials may be incorrect")
                
        except Exception as e:
            self.logger.error(f"Authentication failed for {self.journal_code}: {e}")
            raise ExtractionError(f"ScholarOne authentication failed: {e}") from e
    
    def _perform_login(self, username: str, password: str) -> bool:
        """
        Perform the actual login process.
        
        This method handles the ScholarOne login flow including 2FA if required.
        """
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        
        try:
            # Wait for login form
            wait = WebDriverWait(self.driver, 10)
            
            # Find and fill username
            username_field = wait.until(EC.presence_of_element_located((By.NAME, "USER")))
            username_field.clear()
            username_field.send_keys(username)
            
            # Find and fill password
            password_field = self.driver.find_element(By.NAME, "PASSWORD")
            password_field.clear()
            password_field.send_keys(password)
            
            # Submit login form
            login_button = self.driver.find_element(By.NAME, "Submit")
            login_button.click()
            
            # Wait for page load
            time.sleep(self.page_navigation_wait)
            
            # Check if 2FA is required
            if self._needs_2fa():
                self.logger.info("2FA required for ScholarOne login")
                if not self._handle_2fa():
                    return False
            
            # Verify login success
            return self._is_logged_in()
            
        except Exception as e:
            self.logger.error(f"Login process failed: {e}")
            return False
    
    def _needs_2fa(self) -> bool:
        """Check if 2FA verification is required."""
        try:
            # Look for 2FA indicators
            page_text = self.driver.page_source.lower()
            return any(indicator in page_text for indicator in [
                'verification code',
                'two-factor',
                'authenticator',
                'verify your identity'
            ])
        except:
            return False
    
    def _handle_2fa(self) -> bool:
        """Handle 2FA verification process."""
        # This would be implemented based on specific 2FA requirements
        # For now, we'll log and return False to indicate manual intervention needed
        self.logger.warning("2FA detected - manual intervention may be required")
        
        # Wait a bit longer for manual 2FA completion
        time.sleep(30)
        
        return self._is_logged_in()
    
    def _is_logged_in(self) -> bool:
        """Check if successfully logged into ScholarOne."""
        try:
            # Look for common ScholarOne logged-in indicators
            page_text = self.driver.page_source.lower()
            logged_in_indicators = [
                'reviewer assignment',
                'manuscript central',
                'ae center',
                'associate editor'
            ]
            
            return any(indicator in page_text for indicator in logged_in_indicators)
            
        except:
            return False
    
    def extract_manuscripts(self, **filters) -> List[UnifiedManuscript]:
        """
        Extract manuscripts from ScholarOne platform.
        
        Args:
            **filters: categories (list) - specific categories to extract
                      limit (int) - maximum manuscripts per category
        
        Returns:
            List[UnifiedManuscript]: Unified manuscript objects
        """
        if not self._is_authenticated:
            raise ExtractionError("Must authenticate before extracting manuscripts")
        
        categories_to_extract = filters.get('categories', self.categories)
        limit_per_category = filters.get('limit', None)
        
        all_manuscripts = []
        
        self.logger.info(f"Extracting manuscripts from {len(categories_to_extract)} categories")
        
        for category in categories_to_extract:
            try:
                manuscripts = self._extract_manuscripts_for_category(category, limit_per_category)
                all_manuscripts.extend(manuscripts)
                self.logger.info(f"Extracted {len(manuscripts)} manuscripts from category: {category}")
                
            except Exception as e:
                self.logger.warning(f"Failed to extract manuscripts from category {category}: {e}")
        
        self.logger.info(f"Total manuscripts extracted: {len(all_manuscripts)}")
        return all_manuscripts
    
    def _extract_manuscripts_for_category(self, category: str, limit: Optional[int] = None) -> List[UnifiedManuscript]:
        """Extract manuscripts from a specific category."""
        # This will be implemented by subclasses with specific ScholarOne navigation
        raise NotImplementedError("Subclasses must implement category-specific extraction")
    
    def extract_referees(self, manuscript_id: str) -> List[UnifiedReferee]:
        """
        Extract referee information for a specific manuscript.
        
        Args:
            manuscript_id: ScholarOne manuscript identifier
            
        Returns:
            List[UnifiedReferee]: Unified referee objects
        """
        if not self._is_authenticated:
            raise ExtractionError("Must authenticate before extracting referees")
        
        try:
            self.logger.debug(f"Extracting referees for manuscript {manuscript_id}")
            
            # Navigate to manuscript details
            referees = self._extract_referees_for_manuscript(manuscript_id)
            
            # Filter out staff members
            filtered_referees = [r for r in referees if not self._should_exclude_referee(r.name)]
            
            self.logger.debug(f"Extracted {len(filtered_referees)} referees (filtered from {len(referees)})")
            return filtered_referees
            
        except Exception as e:
            self.logger.error(f"Failed to extract referees for manuscript {manuscript_id}: {e}")
            raise ExtractionError(f"Referee extraction failed: {e}") from e
    
    def _extract_referees_for_manuscript(self, manuscript_id: str) -> List[UnifiedReferee]:
        """Extract referees for a specific manuscript (implemented by subclasses)."""
        raise NotImplementedError("Subclasses must implement manuscript-specific referee extraction")
    
    def _should_exclude_referee(self, referee_name: str) -> bool:
        """Check if a referee should be excluded (staff member)."""
        if not referee_name:
            return True
            
        name_lower = referee_name.lower()
        return any(staff.lower() in name_lower for staff in self.staff_to_exclude)
    
    def navigate_to_ae_center(self, wait_for_load: bool = True) -> bool:
        """Navigate to the Associate Editor Center."""
        try:
            ae_center_url = f"{self.site_prefix}/ae?action=main"
            self.driver.get(ae_center_url)
            
            if wait_for_load:
                time.sleep(self.page_navigation_wait)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to navigate to AE Center: {e}")
            return False
    
    def cleanup(self):
        """Clean up ScholarOne platform resources."""
        super().cleanup()
        
        if hasattr(self, 'driver'):
            try:
                self.driver.quit()
                self.logger.info("Browser session closed")
            except:
                pass
        
        if hasattr(self, 'browser_manager'):
            try:
                self.browser_manager.cleanup()
            except:
                pass
        
        self._is_authenticated = False