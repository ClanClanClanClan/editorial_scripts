#!/usr/bin/env python3
"""
Analyze SIFIN Manuscript IDs in Gmail
Extract all manuscript IDs from SIFIN emails to understand the format and range
"""

import re
import json
import logging
from datetime import datetime
from typing import Dict, List, Set
from debug_sifin_gmail_search import SIFINGmailDebugger

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SIFINManuscriptAnalyzer:
    """Analyze SIFIN manuscript IDs found in Gmail"""
    
    def __init__(self):
        self.debugger = SIFINGmailDebugger()
    
    def extract_manuscript_ids_from_gmail(self) -> Dict:
        """Extract all manuscript IDs from SIFIN emails"""
        if not self.debugger.setup_service():
            return {"error": "Failed to setup Gmail service"}
        
        print("🔍 ANALYZING SIFIN MANUSCRIPT IDS IN GMAIL")
        print("=" * 60)
        
        # Get all SIFIN emails
        try:
            response = self.debugger.service.users().messages().list(
                userId='me',
                q='from:sifin.siam.org',
                maxResults=500
            ).execute()
            
            messages = response.get('messages', [])
            print(f"Found {len(messages)} SIFIN emails")
            
            manuscript_ids = set()
            manuscript_data = []
            
            for i, msg in enumerate(messages):
                if i % 50 == 0:
                    print(f"Processing message {i+1}/{len(messages)}")
                
                try:
                    # Get message details
                    msg_data = self.debugger.service.users().messages().get(
                        userId='me',
                        id=msg['id'],
                        format='full'
                    ).execute()
                    
                    # Extract headers
                    headers = {}
                    payload = msg_data.get('payload', {})
                    
                    for header in payload.get('headers', []):
                        name = header.get('name', '').lower()
                        if name in ['subject', 'from', 'date']:
                            headers[name] = header.get('value', '')
                    
                    # Extract body
                    body = self.debugger._extract_body(payload)
                    
                    subject = headers.get('subject', '')
                    full_text = f"{subject} {body}"
                    
                    # Extract manuscript IDs from text
                    ids = self._extract_manuscript_ids(full_text)
                    
                    if ids:
                        manuscript_ids.update(ids)
                        manuscript_data.append({
                            'subject': subject,
                            'from': headers.get('from', ''),
                            'date': headers.get('date', ''),
                            'manuscript_ids': list(ids),
                            'message_id': msg['id']
                        })
                
                except Exception as e:
                    logger.warning(f"Error processing message {msg['id']}: {e}")
                    continue
            
            # Analyze the manuscript IDs
            analysis = self._analyze_manuscript_ids(manuscript_ids, manuscript_data)
            
            return {
                'total_emails': len(messages),
                'unique_manuscript_ids': len(manuscript_ids),
                'manuscript_ids': sorted(list(manuscript_ids)),
                'analysis': analysis,
                'sample_emails': manuscript_data[:10],  # First 10 emails with IDs
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error extracting manuscript IDs: {e}")
            return {"error": str(e)}
    
    def _extract_manuscript_ids(self, text: str) -> Set[str]:
        """Extract manuscript IDs from text"""
        ids = set()
        
        # Pattern for SIFIN manuscript IDs
        patterns = [
            r'M(\d{6})',  # M followed by 6 digits
            r'M(\d{5})',  # M followed by 5 digits  
            r'#M(\d{6})',  # #M followed by 6 digits
            r'#M(\d{5})',  # #M followed by 5 digits
            r'manuscript\s+#?M(\d{5,6})',  # "manuscript M" or "manuscript #M"
            r'SIFIN\s+M(\d{5,6})',  # "SIFIN M"
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                ids.add(f"M{match}")
        
        return ids
    
    def _analyze_manuscript_ids(self, manuscript_ids: Set[str], manuscript_data: List[Dict]) -> Dict:
        """Analyze manuscript ID patterns"""
        analysis = {
            'id_ranges': {},
            'common_patterns': {},
            'recent_ids': [],
            'sample_subjects': {}
        }
        
        # Convert to sorted list for analysis
        sorted_ids = sorted(list(manuscript_ids))
        
        if sorted_ids:
            # Extract numeric parts for range analysis
            numeric_parts = []
            for id_str in sorted_ids:
                match = re.match(r'M(\d+)', id_str)
                if match:
                    numeric_parts.append(int(match.group(1)))
            
            if numeric_parts:
                analysis['id_ranges'] = {
                    'min': min(numeric_parts),
                    'max': max(numeric_parts),
                    'count': len(numeric_parts)
                }
                
                # Get recent IDs (top 10)
                recent_numeric = sorted(numeric_parts)[-10:]
                analysis['recent_ids'] = [f"M{num}" for num in recent_numeric]
        
        # Find common subject patterns
        subject_patterns = {}
        for data in manuscript_data:
            subject = data['subject']
            for id_str in data['manuscript_ids']:
                if id_str not in subject_patterns:
                    subject_patterns[id_str] = []
                subject_patterns[id_str].append(subject)
        
        # Sample subjects for different IDs
        for id_str in sorted_ids[:5]:  # First 5 IDs
            if id_str in subject_patterns:
                analysis['sample_subjects'][id_str] = subject_patterns[id_str][:3]  # First 3 subjects
        
        return analysis
    
    def test_specific_manuscript_ids(self, manuscript_ids: List[str]) -> Dict:
        """Test search for specific manuscript IDs"""
        if not self.debugger.setup_service():
            return {"error": "Failed to setup Gmail service"}
        
        print(f"\n🔍 TESTING SPECIFIC MANUSCRIPT IDS")
        print("=" * 60)
        
        results = {}
        
        for ms_id in manuscript_ids:
            print(f"\nTesting manuscript ID: {ms_id}")
            
            # Test basic search patterns
            patterns = [
                f'subject:{ms_id}',
                f'body:{ms_id}',
                f'from:sifin.siam.org {ms_id}',
                f'subject:SIFIN {ms_id}',
                f'{ms_id}',
            ]
            
            id_results = {}
            total_found = 0
            
            for pattern in patterns:
                try:
                    response = self.debugger.service.users().messages().list(
                        userId='me',
                        q=pattern,
                        maxResults=10
                    ).execute()
                    
                    messages = response.get('messages', [])
                    count = len(messages)
                    total_found += count
                    
                    if count > 0:
                        print(f"  {pattern}: {count} messages")
                        
                        # Get first message subject
                        try:
                            msg_data = self.debugger.service.users().messages().get(
                                userId='me',
                                id=messages[0]['id'],
                                format='metadata'
                            ).execute()
                            
                            headers = {h['name']: h['value'] for h in msg_data.get('payload', {}).get('headers', [])}
                            subject = headers.get('Subject', 'N/A')
                            print(f"    Sample subject: {subject}")
                            
                            id_results[pattern] = {
                                'count': count,
                                'sample_subject': subject
                            }
                            
                        except Exception as e:
                            print(f"    Error getting subject: {e}")
                    
                except Exception as e:
                    print(f"  Error with pattern {pattern}: {e}")
            
            results[ms_id] = {
                'total_found': total_found,
                'patterns': id_results
            }
            
            if total_found == 0:
                print(f"  ❌ No emails found for {ms_id}")
            else:
                print(f"  ✅ Found {total_found} emails for {ms_id}")
        
        return results


def main():
    """Main analysis function"""
    analyzer = SIFINManuscriptAnalyzer()
    
    # Step 1: Extract all manuscript IDs from Gmail
    print("STEP 1: Extract all manuscript IDs from SIFIN emails")
    id_analysis = analyzer.extract_manuscript_ids_from_gmail()
    
    if 'error' in id_analysis:
        print(f"❌ Error: {id_analysis['error']}")
        return
    
    print(f"\n📊 ANALYSIS RESULTS")
    print("=" * 50)
    print(f"Total SIFIN emails: {id_analysis['total_emails']}")
    print(f"Unique manuscript IDs: {id_analysis['unique_manuscript_ids']}")
    
    if id_analysis['manuscript_ids']:
        print(f"Manuscript ID range: {id_analysis['manuscript_ids'][0]} to {id_analysis['manuscript_ids'][-1]}")
        print(f"Recent IDs: {id_analysis['analysis']['recent_ids']}")
    
    # Step 2: Test specific manuscript IDs
    print("\nSTEP 2: Test specific manuscript IDs")
    test_ids = [
        "M147228",  # Original test ID
        "M174727",  # ID seen in recent emails
        "M174160",  # ID from user's original question
        "M175988",  # ID seen in email subjects
    ]
    
    # Add some IDs from the analysis
    if id_analysis['analysis']['recent_ids']:
        test_ids.extend(id_analysis['analysis']['recent_ids'][:3])
    
    test_results = analyzer.test_specific_manuscript_ids(test_ids)
    
    # Step 3: Generate final report
    print(f"\n📋 FINAL ANALYSIS REPORT")
    print("=" * 60)
    
    print(f"Manuscript IDs found in Gmail: {len(id_analysis['manuscript_ids'])}")
    print(f"IDs tested for email search: {len(test_ids)}")
    
    successful_searches = sum(1 for result in test_results.values() if result['total_found'] > 0)
    print(f"IDs with successful email searches: {successful_searches}")
    
    if successful_searches > 0:
        print(f"\n✅ IDs with emails found:")
        for id_str, result in test_results.items():
            if result['total_found'] > 0:
                print(f"  - {id_str}: {result['total_found']} emails")
    
    if successful_searches < len(test_ids):
        print(f"\n❌ IDs with no emails found:")
        for id_str, result in test_results.items():
            if result['total_found'] == 0:
                print(f"  - {id_str}: No emails")
    
    # Save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"sifin_manuscript_analysis_{timestamp}.json"
    
    combined_results = {
        'id_analysis': id_analysis,
        'test_results': test_results,
        'timestamp': timestamp
    }
    
    with open(output_file, 'w') as f:
        json.dump(combined_results, f, indent=2)
    
    print(f"\n📄 Full analysis saved to: {output_file}")


if __name__ == "__main__":
    main()