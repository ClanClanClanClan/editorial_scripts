#!/usr/bin/env python3
"""
SIFIN Exact Workflow Extractor - July 16, 2025
Using EXACT same browser setup as working SICON script
"""

import os
import sys
import time
import logging
import json
from datetime import datetime
from pathlib import Path
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import undetected_chromedriver as uc
from bs4 import BeautifulSoup

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SIFINExactExtractor:
    """SIFIN extractor using EXACT same setup as working SICON script"""
    
    def __init__(self):
        self.driver = None
        self.manuscripts = []
        self.referees = []
        
    def setup_driver(self, headless=True):
        """Setup Chrome driver with stealth - EXACT copy from SICON"""
        options = uc.ChromeOptions()
        if headless:
            options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        
        self.driver = uc.Chrome(options=options)
        self.driver.set_window_size(1920, 1080)
        
        logger.info("✅ Chrome driver setup complete")
        
    def handle_popups(self):
        """Handle cookie banners and privacy modals - EXACT copy from SICON"""
        try:
            # First, try to remove with JavaScript
            js_remove_banners = """
            // Remove common cookie banner elements
            const selectors = [
                '#cookie-policy-layer-bg',
                '#cookie-policy-layer', 
                '.cc_banner-wrapper',
                '#onetrust-banner-sdk',
                '.onetrust-pc-dark-filter',
                '[id*="cookie"]',
                '[class*="cookie"]',
                '[id*="banner"]',
                '[class*="banner"]'
            ];
            
            selectors.forEach(sel => {
                document.querySelectorAll(sel).forEach(el => {
                    el.style.display = 'none';
                    el.remove();
                });
            });
            
            // Also try to find and click accept buttons
            const buttonTexts = ['Accept', 'Accept All', 'Accept Cookies', 'Got it', 'OK', 'Continue'];
            buttonTexts.forEach(text => {
                document.querySelectorAll('button, input[type="button"]').forEach(btn => {
                    if (btn.innerText && btn.innerText.toLowerCase().includes(text.toLowerCase())) {
                        btn.click();
                    }
                });
            });
            """
            
            self.driver.execute_script(js_remove_banners)
            time.sleep(0.5)
            
        except Exception as e:
            logger.debug(f"Popup removal failed: {e}")
            
    def step1_navigate_to_sifin(self):
        """Step 1: Navigate to SIFIN - adapted from SICON"""
        url = "https://sifin.siam.org/cgi-bin/main.plex"
        logger.info("📍 Step 1: Navigating to SIFIN...")
        
        self.driver.get(url)
        time.sleep(3)  # Same timing as SICON
        
        # Handle any popups
        self.handle_popups()
        
        title = self.driver.title
        logger.info(f"✅ Loaded: {title}")
        
        # If Cloudflare protection, wait longer
        if "Just a moment" in title:
            logger.warning("⚠️ Cloudflare detected, waiting 15 seconds...")
            time.sleep(15)
            title = self.driver.title
            logger.info(f"After Cloudflare wait: {title}")
        
    def step2_click_orcid_button(self):
        """Step 2: Click ORCID button - EXACT copy from SICON"""
        logger.info("📍 Step 2: Clicking ORCID button...")
        
        # Ensure all popups are handled first
        self.handle_popups()
        time.sleep(2)
        
        # Look for ORCID image/link using exact selectors from SICON workflow
        orcid_selectors = [
            "a[href*='sso_site_redirect'][href*='orcid']",
            "img[src*='orcid']",
            "img[title='ORCID']", 
            "a img[src*='orcid_32x32.png']",
            "a[href*='orcid']"
        ]
        
        orcid_element = None
        for selector in orcid_selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for element in elements:
                    if element.is_displayed():
                        # If it's an image, get its parent link
                        if element.tag_name == 'img':
                            orcid_element = element.find_element(By.XPATH, "..")
                        else:
                            orcid_element = element
                        break
                if orcid_element:
                    break
            except Exception:
                continue
                
        if orcid_element:
            # Try JavaScript click first
            try:
                self.driver.execute_script("arguments[0].click();", orcid_element)
                logger.info("✅ ORCID button clicked (JavaScript)")
            except Exception:
                # Fallback to regular click
                orcid_element.click()
                logger.info("✅ ORCID button clicked (regular)")
            
            time.sleep(3)
        else:
            raise Exception("❌ No ORCID login button found")
            
    def step3_orcid_authentication(self):
        """Step 3: ORCID authentication - EXACT copy from SICON"""
        logger.info("📍 Step 3: ORCID authentication...")
        
        # Check current URL to see if we're on ORCID
        current_url = self.driver.current_url
        if "orcid.org" not in current_url:
            logger.warning(f"Not on ORCID page: {current_url}")
            
        # Handle popups on ORCID page 
        self.handle_popups()
        
        # Get ORCID credentials from environment
        orcid_user = os.environ.get('ORCID_EMAIL')
        orcid_pass = os.environ.get('ORCID_PASSWORD')
        
        if not orcid_user or not orcid_pass:
            raise Exception("❌ ORCID credentials not found in environment")
        
        # Wait for and fill username - exact same as SICON
        try:
            username_field = WebDriverWait(self.driver, 15).until(
                EC.presence_of_element_located((By.ID, "username-input"))
            )
            username_field.clear()
            username_field.send_keys(orcid_user)
            logger.info("✅ Username entered")
        except TimeoutException:
            # Try alternative selector
            username_field = self.driver.find_element(By.ID, "userId")
            username_field.clear()
            username_field.send_keys(orcid_user)
            logger.info("✅ Username entered (alternative)")
        
        # Wait for and fill password
        password_field = WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.ID, "password"))
        )
        password_field.clear()
        password_field.send_keys(orcid_pass)
        logger.info("✅ Password entered")
        
        # Find and click sign in button - exact same as SICON
        try:
            sign_in_button = self.driver.find_element(By.ID, "signin-button")
        except NoSuchElementException:
            sign_in_button = self.driver.find_element(By.XPATH, "//button[contains(text(), 'Sign in')]")
        
        sign_in_button.click()
        logger.info("✅ Login submitted")
        
        # Wait for redirect back to SIFIN
        time.sleep(5)
        
    def step4_find_manuscript_task_links(self):
        """Step 4: Find manuscript task links - SIFIN-specific (different from SICON)"""
        logger.info("📍 Step 4: Finding manuscript task links...")
        
        # Handle any post-login popups
        self.handle_popups()
        time.sleep(1)
        
        # SIFIN shows manuscripts directly as task links (different from SICON folders)
        soup = BeautifulSoup(self.driver.page_source, "html.parser")
        
        # Find all task links
        task_links = soup.find_all("a", class_="ndt_task_link")
        logger.info(f"🔍 Found {len(task_links)} total task links")
        
        # Filter for manuscript task links (start with # and contain manuscript pattern)
        manuscript_links = []
        for link in task_links:
            text = link.get_text(strip=True)
            href = link.get("href", "")
            
            # Check if it's a manuscript link
            if text.startswith("#") and " - " in text and href:
                # Extract manuscript ID
                manuscript_id = text.split()[0].replace("#", "").replace(" ", "")
                
                # Create full URL
                if not href.startswith("http"):
                    href = f"https://sifin.siam.org{href}" if href.startswith("/") else f"https://sifin.siam.org/cgi-bin/{href}"
                
                manuscript_links.append({
                    'id': manuscript_id,
                    'url': href,
                    'text': text
                })
                
                logger.info(f"📄 Found manuscript: {text}")
        
        logger.info(f"✅ Found {len(manuscript_links)} manuscripts")
        return manuscript_links
        
    def step5_extract_manuscript_details(self, manuscript_links):
        """Step 5: Extract manuscript details - adapted from SICON structure"""
        logger.info("📍 Step 5: Extracting manuscript details...")
        
        manuscripts = []
        
        for i, manuscript in enumerate(manuscript_links, 1):
            try:
                logger.info(f"📄 Processing {manuscript['id']} ({i}/{len(manuscript_links)})...")
                
                # Navigate to manuscript detail page
                self.driver.get(manuscript['url'])
                time.sleep(2)
                
                # Wait for page to load
                WebDriverWait(self.driver, 10).until(
                    EC.presence_of_element_located((By.TAG_NAME, "body"))
                )
                
                # Extract manuscript data
                manuscript_data = self.extract_manuscript_data_from_page(manuscript['id'])
                
                if manuscript_data:
                    manuscripts.append(manuscript_data)
                    logger.info(f"✅ Extracted complete data for {manuscript['id']}")
                else:
                    logger.warning(f"⚠️ No data extracted for {manuscript['id']}")
                    
            except Exception as e:
                logger.error(f"❌ Error processing {manuscript['id']}: {e}")
                continue
                
        return manuscripts
        
    def extract_manuscript_data_from_page(self, manuscript_id):
        """Extract manuscript data from detail page - adapted from SICON"""
        try:
            soup = BeautifulSoup(self.driver.page_source, "html.parser")
            
            # Initialize manuscript data structure (same as SICON)
            manuscript_data = {
                "Manuscript #": manuscript_id,
                "Title": "",
                "Submitted": "",
                "Current Stage": "",
                "Corresponding Author": "",
                "Abstract": "",
                "Keywords": "",
                "Referees": [],
                "PDFs": [],
                "Comments": []
            }
            
            # Find manuscript details table
            table = soup.find("table", id="ms_details_expanded")
            if not table:
                logger.warning(f"⚠️ No manuscript details table found for {manuscript_id}")
                return None
                
            # Extract basic manuscript information
            for row in table.find_all("tr"):
                th = row.find("th")
                td = row.find("td")
                
                if not th or not td:
                    continue
                    
                label = th.get_text(strip=True)
                value = td.get_text(strip=True)
                
                if label == "Title":
                    manuscript_data["Title"] = value
                elif label == "Submission Date":
                    manuscript_data["Submitted"] = value
                elif label == "Current Stage":
                    manuscript_data["Current Stage"] = value
                elif label == "Corresponding Author":
                    manuscript_data["Corresponding Author"] = value
                elif label == "Abstract":
                    manuscript_data["Abstract"] = value
                elif label == "Keywords":
                    manuscript_data["Keywords"] = value
                elif label == "Referees":
                    # Extract accepted referees
                    referees = self.extract_referees_from_table_cell(td, "Accepted")
                    manuscript_data["Referees"].extend(referees)
                elif "Potential Referees" in label:
                    # Extract potential/declined referees
                    potential_referees = self.extract_referees_from_table_cell(td, "Potential")
                    manuscript_data["Referees"].extend(potential_referees)
                    
            # Extract PDFs
            manuscript_data["PDFs"] = self.extract_pdf_links_from_page(soup)
            
            # Extract comments
            manuscript_data["Comments"] = self.extract_comments_from_page(soup)
            
            return manuscript_data
            
        except Exception as e:
            logger.error(f"❌ Error extracting manuscript data: {e}")
            return None
            
    def extract_referees_from_table_cell(self, td_element, referee_type):
        """Extract referee information from table cell"""
        referees = []
        
        try:
            # Find all referee links in the cell
            for ref_link in td_element.find_all("a"):
                referee_name = ref_link.get_text(strip=True)
                referee_url = ref_link.get("href", "")
                
                if referee_name and referee_url:
                    # Make URL absolute
                    if not referee_url.startswith("http"):
                        referee_url = f"https://sifin.siam.org{referee_url}" if referee_url.startswith("/") else f"https://sifin.siam.org/cgi-bin/{referee_url}"
                    
                    # Extract due date or contact date if present
                    due_date = ""
                    context_text = str(ref_link.parent)
                    import re
                    date_match = re.search(r"Due:\s*([\d\-/]+)|Contact:\s*([\d\-/]+)", context_text)
                    if date_match:
                        due_date = date_match.group(1) or date_match.group(2)
                    
                    referee_data = {
                        "Referee Name": referee_name,
                        "Referee URL": referee_url,
                        "Status": referee_type,
                        "Due Date": due_date,
                        "Referee Email": ""  # Will be filled later if needed
                    }
                    
                    referees.append(referee_data)
                    
        except Exception as e:
            logger.error(f"❌ Error extracting referees: {e}")
            
        return referees
        
    def extract_pdf_links_from_page(self, soup):
        """Extract PDF download links"""
        pdfs = []
        
        try:
            for link in soup.find_all("a", href=True):
                href = link.get("href", "")
                if ".pdf" in href and ("sifin.siam.org" in href or href.startswith("/")):
                    # Make URL absolute
                    if not href.startswith("http"):
                        href = f"https://sifin.siam.org{href}"
                    pdfs.append(href)
                    
        except Exception as e:
            logger.error(f"❌ Error extracting PDFs: {e}")
            
        return pdfs
        
    def extract_comments_from_page(self, soup):
        """Extract referee comments"""
        comments = []
        
        try:
            # Look for comment sections
            for textarea in soup.find_all("textarea"):
                text = textarea.get_text(strip=True)
                if text and len(text) > 50:  # Only substantial comments
                    comments.append(text)
                    
            # Also look for div elements with substantial text
            for div in soup.find_all("div"):
                text = div.get_text(strip=True)
                if text and len(text) > 100 and "comment" in text.lower():
                    comments.append(text)
                    
        except Exception as e:
            logger.error(f"❌ Error extracting comments: {e}")
            
        return comments
        
    def run_extraction(self, headless=True):
        """Run the complete SIFIN extraction workflow"""
        try:
            logger.info("🚀 SIFIN EXACT WORKFLOW EXTRACTION")
            logger.info("==================================================")
            
            # Setup driver with exact same settings as SICON
            self.setup_driver(headless)
            
            # Step 1: Navigate to SIFIN
            self.step1_navigate_to_sifin()
            
            # Step 2: Click ORCID button
            self.step2_click_orcid_button()
            
            # Step 3: ORCID authentication
            self.step3_orcid_authentication()
            
            # Step 4: Find manuscript task links
            manuscript_links = self.step4_find_manuscript_task_links()
            
            if not manuscript_links:
                logger.warning("⚠️ No manuscripts found")
                return []
            
            # Step 5: Extract manuscript details
            manuscripts = self.step5_extract_manuscript_details(manuscript_links)
            
            # Save results
            output_file = f"sifin_extraction_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(output_file, 'w') as f:
                json.dump(manuscripts, f, indent=2, default=str)
            
            # Print summary (same format as SICON)
            total_referees = sum(len(ms.get("Referees", [])) for ms in manuscripts)
            declined_referees = sum(len([r for r in ms.get("Referees", []) if r.get("Status") == "Declined"]) for ms in manuscripts)
            accepted_referees = sum(len([r for r in ms.get("Referees", []) if r.get("Status") in ["Accepted", "Potential"]]) for ms in manuscripts)
            total_pdfs = sum(len(ms.get("PDFs", [])) for ms in manuscripts)
            total_comments = sum(len(ms.get("Comments", [])) for ms in manuscripts)
            
            logger.info("\\n📊 EXTRACTION RESULTS:")
            logger.info(f"    Manuscripts: {len(manuscripts)}")
            logger.info(f"    Total Referees: {total_referees}")
            logger.info(f"    - Declined: {declined_referees}")
            logger.info(f"    - Accepted: {accepted_referees}")
            logger.info(f"    Total PDFs: {total_pdfs}")
            logger.info(f"    Total Comments: {total_comments}")
            logger.info(f"💾 Detailed results saved to: {output_file}")
            
            return manuscripts
            
        except Exception as e:
            logger.error(f"❌ Extraction failed: {e}")
            import traceback
            traceback.print_exc()
            return []
            
        finally:
            if self.driver:
                self.driver.quit()
                logger.info("🖥️ Browser closed")

def main():
    """Main execution function"""
    extractor = SIFINExactExtractor()
    
    # Check for credentials
    if not os.environ.get('ORCID_EMAIL') or not os.environ.get('ORCID_PASSWORD'):
        logger.error("❌ Missing ORCID credentials in environment variables")
        logger.error("Please set ORCID_EMAIL and ORCID_PASSWORD")
        sys.exit(1)
    
    # Run extraction
    results = extractor.run_extraction(headless=True)
    
    if results:
        logger.info("✅ EXTRACTION SUCCESSFUL!")
        
        # Print detailed results
        for i, ms in enumerate(results, 1):
            logger.info(f"\\nManuscript {i}: {ms.get('Manuscript #', '')}")
            logger.info(f"  Title: {ms.get('Title', 'N/A')[:60]}...")
            logger.info(f"  Status: {ms.get('Current Stage', 'N/A')}")
            logger.info(f"  Submitted: {ms.get('Submitted', 'N/A')}")
            logger.info(f"  Referees: {len(ms.get('Referees', []))}")
            
            for j, ref in enumerate(ms.get('Referees', [])[:3], 1):
                logger.info(f"    Referee {j}: {ref.get('Referee Name', '')} - {ref.get('Status', '')}")
    else:
        logger.error("❌ EXTRACTION FAILED!")
        sys.exit(1)

if __name__ == "__main__":
    main()