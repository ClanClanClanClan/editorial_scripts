"""
ScholarOne platform extractor implementation.

This module implements the extractor for ScholarOne Manuscripts platform,
used by journals like MF, MOR, MS, RFS, and RAPS.
"""

import time
import re
from datetime import datetime, date
from typing import List, Dict, Any, Optional
from pathlib import Path

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from bs4 import BeautifulSoup

from ..core.base_extractor import BaseExtractor
from ..core.legacy_integration import LegacyIntegrationMixin
from ..core.data_models import (
    Manuscript, Referee, RefereeStatus, RefereeDates, 
    RefereeReport, ManuscriptStatus, Author
)
from ..core.exceptions import LoginError, NavigationError, RefereeDataError
from ..utils.config_loader import ConfigLoader
from ..utils.session_manager import session_manager


class ScholarOneExtractor(BaseExtractor, LegacyIntegrationMixin):
    """Extractor for ScholarOne Manuscripts platform with proven legacy methods."""
    
    def __init__(self, journal_code: str, **kwargs):
        """
        Initialize ScholarOne extractor.
        
        Args:
            journal_code: Journal code (e.g., 'MF', 'MOR')
            **kwargs: Additional arguments passed to base class
        """
        # Load journal configuration
        config_loader = ConfigLoader()
        journal = config_loader.get_journal(journal_code)
        
        super().__init__(journal, **kwargs)
        
        # Platform-specific configuration
        self.platform_config = config_loader.get_platform_config('scholarone')
        self.verification_required = False
        
        # Store manuscripts found during navigation
        self.found_manuscripts = []
        
    def _login(self) -> None:
        """Login to ScholarOne platform."""
        session_manager.add_learning(f"Starting login for {self.journal.name}")
        
        # Navigate to login page
        self.driver.get(self.journal.url)
        self.logger.info(f"Navigating to {self.journal.url}")
        
        # Handle cookie consent first
        self._handle_cookie_consent()
        
        # Wait for login form - try different possible field IDs
        username_field = None
        password_field = None
        
        # Try to find username field with different IDs
        username_selectors = ["USER_NAME", "USERID", "username", "email"]
        for selector in username_selectors:
            try:
                element = WebDriverWait(self.driver, 2).until(
                    EC.presence_of_element_located((By.ID, selector))
                )
                if element.is_displayed():
                    username_field = element
                    self.logger.info(f"Found username field with ID: {selector}")
                    break
            except TimeoutException:
                continue
        
        # Try to find password field
        try:
            password_field = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.ID, "PASSWORD"))
            )
        except TimeoutException:
            self.logger.error("Password field not found")
            raise LoginError("Password field not found")
        
        if not username_field:
            self.logger.error("Username field not found")
            raise LoginError("Username field not found")
        
        # Get credentials from environment variables
        import os
        email = os.getenv(f'{self.journal.code}_EMAIL')
        password = os.getenv(f'{self.journal.code}_PASSWORD')
        
        if not email or not password:
            raise LoginError(f"Missing credentials for {self.journal.code}")
        
        self.logger.info(f"Entering credentials for {email}")
        username_field.clear()
        username_field.send_keys(email)
        self.logger.info("Username entered")
        
        password_field.clear()
        password_field.send_keys(password)
        self.logger.info("Password entered")
        
        # Submit login form - try different button selectors
        login_button = None
        button_selectors = [
            ("id", "logInButton"),
            ("id", "LOGIN"),
            ("id", "loginButton"),
            ("xpath", "//input[@type='submit']"),
            ("xpath", "//button[contains(text(), 'Log') or contains(text(), 'Sign')]"),
            ("xpath", "//input[@value='Log In']"),
            ("xpath", "//input[@value='LOGIN']")
        ]
        
        for selector_type, selector_value in button_selectors:
            try:
                if selector_type == "id":
                    login_button = self.driver.find_element(By.ID, selector_value)
                elif selector_type == "xpath":
                    login_button = self.driver.find_element(By.XPATH, selector_value)
                
                if login_button and login_button.is_displayed():
                    self.logger.info(f"Found login button using {selector_type}: {selector_value}")
                    break
            except:
                continue
        
        if not login_button:
            # Try submitting the form directly
            try:
                form = self.driver.find_element(By.TAG_NAME, "form")
                form.submit()
                self.logger.info("Submitted form directly")
            except:
                raise LoginError("Could not find login button or form")
        else:
            # Use JavaScript to click to avoid cookie consent interception
            try:
                self.driver.execute_script("arguments[0].click();", login_button)
                self.logger.info("Clicked login button using JavaScript")
            except:
                # Fallback to regular click
                login_button.click()
                self.logger.info("Clicked login button normally")
        
        self.logger.info("Login form submitted")
        
        # Wait a bit for page to respond
        time.sleep(3)
        
        # Save page after login submit
        with open(f"{self.journal.code.lower()}_after_submit.html", 'w') as f:
            f.write(self.driver.page_source)
        self.logger.info(f"Saved page after submit to {self.journal.code.lower()}_after_submit.html")
        
        # Handle 2FA if needed
        self.logger.info("Checking for 2FA...")
        self._handle_2fa_if_needed()
        
        # Verify login success with extended wait after 2FA
        time.sleep(10)  # Wait longer for page to load after 2FA
        
        # Save page after login attempt
        with open(f"{self.journal.code.lower()}_after_login.html", 'w') as f:
            f.write(self.driver.page_source)
        self.logger.info(f"Saved post-login page to {self.journal.code.lower()}_after_login.html")
        
        if not self._verify_login_success():
            # Try waiting a bit more and check again
            time.sleep(10)
            if not self._verify_login_success():
                # Save final page state
                with open(f"{self.journal.code.lower()}_login_failed.html", 'w') as f:
                    f.write(self.driver.page_source)
                self.logger.error(f"Login verification failed. Page saved to {self.journal.code.lower()}_login_failed.html")
                raise LoginError(f"Login failed for {self.journal.name}")
        
        session_manager.add_learning(f"Successfully logged into {self.journal.name}")
    
    def _handle_2fa_if_needed(self) -> None:
        """Handle 2FA verification if required."""
        try:
            # Check for verification code input
            code_input = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.ID, "TOKEN_VALUE"))
            )
            
            if code_input.is_displayed():
                self.logger.info("2FA verification required")
                
                # Save 2FA page for debugging
                with open(f"{self.journal.code.lower()}_2fa_page.html", 'w') as f:
                    f.write(self.driver.page_source)
                self.logger.info(f"Saved 2FA page to {self.journal.code.lower()}_2fa_page.html")
                
                # Use email utilities to fetch verification code automatically
                try:
                    import sys
                    from pathlib import Path
                    sys.path.insert(0, str(Path(__file__).parent.parent.parent))
                    from core.email_utils import fetch_latest_verification_code
                    
                    # Wait for email to arrive
                    self.logger.info("Waiting for verification email...")
                    time.sleep(10)
                    
                    # Fetch verification code from Gmail
                    self.logger.info("Fetching verification code from Gmail...")
                    verification_code = fetch_latest_verification_code(
                        journal=self.journal.code,
                        max_wait=120,  # Wait up to 2 minutes
                        poll_interval=10  # Check every 10 seconds
                    )
                    
                    # Fallback: prompt user for verification code if Gmail fails
                    if not verification_code:
                        self.logger.warning("Gmail service failed, trying fallback methods")
                        
                        # Try reading from temp file first
                        import os
                        if os.path.exists('.verification_code.tmp'):
                            with open('.verification_code.tmp', 'r') as f:
                                verification_code = f.read().strip()
                            self.logger.info(f"Read verification code from temp file: {verification_code}")
                        else:
                            # Try interactive input
                            try:
                                print(f"\n⚠️  Gmail authentication failed for {self.journal.name}")
                                print("Please check your email for the verification code and enter it below:")
                                verification_code = input("Enter verification code: ").strip()
                            except EOFError:
                                # Can't use input in non-interactive mode
                                self.logger.error("Cannot read verification code - not in interactive mode")
                                self.logger.error("Please run with: echo 'YOUR_CODE' | python3 run_extraction.py mf")
                                raise Exception("No verification code available in non-interactive mode")
                        
                        if not verification_code:
                            raise Exception("No verification code provided")
                    
                    if verification_code:
                        self.logger.info(f"Entering verification code: {verification_code}")
                        code_input.clear()
                        code_input.send_keys(verification_code)
                        self.logger.info("Verification code entered")
                        
                        # Find and click the verify button with multiple strategies
                        verify_button = None
                        button_selectors = [
                            ("id", "VERIFY_BTN"),  # The actual verify button for ScholarOne
                            ("xpath", "//a[@id='VERIFY_BTN']"),
                            ("xpath", "//a[contains(@class, 'verifyBtn')]"),
                            ("xpath", "//input[@type='submit' and contains(@value, 'Verify')]"),
                            ("xpath", "//button[contains(text(), 'Verify')]"), 
                            ("xpath", "//a[contains(text(), 'Verify')]"),
                            ("xpath", "//input[@value='Verify']"),
                            ("xpath", "//button[@id='verify']"),
                            ("xpath", "//input[@name='verify']")
                        ]
                        
                        for selector_type, selector_value in button_selectors:
                            try:
                                if selector_type == "xpath":
                                    verify_button = WebDriverWait(self.driver, 2).until(
                                        EC.element_to_be_clickable((By.XPATH, selector_value))
                                    )
                                if verify_button:
                                    verify_button.click()
                                    self.logger.info(f"Clicked verify button using {selector_type}: {selector_value}")
                                    break
                            except (TimeoutException, Exception):
                                continue
                        
                        if not verify_button:
                            # Fallback to Enter key
                            self.logger.info("No verify button found, pressing Enter")
                            code_input.send_keys(Keys.RETURN)
                            
                        time.sleep(15)  # Wait longer for verification to complete
                        self.logger.info(f"Verification code submitted: {verification_code}")
                    else:
                        self.logger.error("No verification code found in email")
                        raise LoginError("2FA verification failed - no verification code found")
                        
                except ImportError as e:
                    self.logger.error(f"Email utilities not available for 2FA: {e}")
                    raise LoginError("2FA verification failed - email utilities not available")
                except Exception as e:
                    self.logger.error(f"2FA verification failed: {e}")
                    raise LoginError(f"2FA verification failed: {e}")
                    
        except TimeoutException:
            # No 2FA required
            self.logger.info("No 2FA verification required (TOKEN_VALUE field not found)")
            pass
    
    def _verify_login_success(self) -> bool:
        """Verify login was successful."""
        try:
            current_url = self.driver.current_url
            self.logger.info(f"Verifying login success. Current URL: {current_url}")
            
            # Check URL
            if "login" in current_url.lower():
                self.logger.info("Still on login page")
                return False
            
            # Check for empty page (common issue with ScholarOne)
            page_text = self.driver.find_element(By.TAG_NAME, "body").text
            if len(page_text.strip()) == 0:
                self.logger.warning("Page is empty - possible login failure")
                return False
                
            # Check for logged-in indicators
            indicators = [
                "Associate Editor Center",
                "Author Center", 
                "Reviewer Center",
                "Logout",
                "Sign Out",
                "Dashboard",
                "Manuscript"
            ]
            
            found_indicators = []
            for indicator in indicators:
                if indicator in page_text:
                    found_indicators.append(indicator)
                    self.logger.info(f"Found login indicator: {indicator}")
            
            # Log all role centers found
            if "Author Center" in page_text and "Associate Editor Center" not in page_text:
                self.logger.warning("Only Author Center found - user may not have AE privileges")
            
            return len(found_indicators) > 0
            
            # If no indicators found, check if we're on a different page than login
            if "login" not in current_url.lower() and len(page_text.strip()) > 0:
                self.logger.info("Not on login page and page has content - assuming success")
                return True
                    
            self.logger.warning(f"No login indicators found. Page text length: {len(page_text)}")
            return False
            
        except Exception as e:
            self.logger.error(f"Error verifying login success: {e}")
            return False
    
    def _navigate_to_manuscripts(self) -> None:
        """Navigate to manuscripts list."""
        self.logger.info("Navigating to manuscripts")
        
        try:
            # Click Associate Editor Center
            self.logger.info("Looking for Associate Editor Center link...")
            
            # Try multiple ways to find the Associate Editor Center link
            ae_link = None
            
            # Method 1: Direct link text
            try:
                ae_link = WebDriverWait(self.driver, 10).until(
                    EC.element_to_be_clickable((By.LINK_TEXT, "Associate Editor Center"))
                )
                self.logger.info("Found Associate Editor Center via link text")
            except:
                # Method 2: Partial link text
                try:
                    ae_link = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((By.PARTIAL_LINK_TEXT, "Associate Editor"))
                    )
                    self.logger.info("Found Associate Editor Center via partial link text")
                except:
                    # Method 3: Look for JavaScript link
                    try:
                        ae_link = self.driver.find_element(By.XPATH, "//a[contains(text(), 'Associate Editor Center')]")
                        self.logger.info("Found Associate Editor Center via XPath")
                    except:
                        self.logger.error("Could not find Associate Editor Center link")
                        return
            
            if ae_link:
                self.logger.info("Clicking Associate Editor Center...")
                current_url = self.driver.current_url
                
                # Try regular click first
                ae_link.click()
                self._wait_for_page_load()
                
                # Check if navigation worked
                new_url = self.driver.current_url
                self.logger.info(f"After clicking AE Center, URL: {new_url}")
                
                # If URL didn't change, try JavaScript execution
                if new_url == current_url:
                    self.logger.info("URL didn't change, trying JavaScript execution...")
                    try:
                        href = ae_link.get_attribute('href')
                        if href and 'javascript:' in href:
                            # Extract and execute JavaScript
                            js_code = href.replace('javascript:', '')
                            self.driver.execute_script(js_code)
                            self._wait_for_page_load()
                            final_url = self.driver.current_url
                            self.logger.info(f"After JavaScript execution, URL: {final_url}")
                    except Exception as e:
                        self.logger.warning(f"Error executing JavaScript: {e}")
                
                # Look for manuscript dashboard table
                self._find_and_click_manuscript_categories()
            else:
                self.logger.error("Associate Editor Center link not found")
                
        except Exception as e:
            self.logger.error(f"Error navigating to manuscripts: {e}")
            
    def _find_and_click_manuscript_categories(self) -> None:
        """Find and click on manuscript categories with non-zero counts."""
        self.logger.info("Looking for manuscript categories...")
        
        try:
            # Save page source for debugging
            import os
            debug_file = f"{self.journal.code.lower()}_ae_dashboard.html"
            with open(debug_file, 'w') as f:
                f.write(self.driver.page_source)
            self.logger.info(f"Saved page source to {debug_file}")
            
            # Also save screenshot
            screenshot_file = f"{self.journal.code.lower()}_ae_dashboard.png"
            self.driver.save_screenshot(screenshot_file)
            self.logger.info(f"Saved screenshot to {screenshot_file}")
            
            # Keep track of processed categories
            processed_categories = set()
            
            # Continue until all categories are processed (with max iterations to prevent infinite loop)
            max_iterations = 10
            iteration = 0
            
            while iteration < max_iterations:
                # Wait for the manuscript dashboard table to load
                time.sleep(3)
                
                # Look for table with manuscript categories
                tables = self.driver.find_elements(By.TAG_NAME, "table")
                self.logger.info(f"Found {len(tables)} tables")
                
                # Also look for any text that might indicate manuscripts
                page_text = self.driver.find_element(By.TAG_NAME, "body").text
                self.logger.info(f"Page text length: {len(page_text)}")
                
                # Check for empty Associate Editor Center
                if "Associate Editor Center" in page_text:
                    self.logger.info(f"In Associate Editor Center. Page text starts with: {page_text[:200]}...")
                    if "No manuscripts" in page_text or "There are no manuscripts" in page_text:
                        self.logger.info("Associate Editor Center indicates no manuscripts")
                        break
                    elif len(page_text.strip()) < 100:
                        self.logger.warning("Associate Editor Center appears to be empty or minimal content")
                        # Don't break - continue looking for tables
                
                # Also check if we're on the main dashboard by looking for role indicators
                if "Select Your Role" in page_text or "Author Center" in page_text:
                    self.logger.info("Still on main dashboard, not in AE Center yet")
                
                category_found = False
                
                for i, table in enumerate(tables):
                    table_text = table.text
                    self.logger.info(f"Table {i+1} text: {table_text[:200]}...")
                    
                    if "Awaiting Reviewer" in table_text or "Awaiting AE" in table_text or "Overdue" in table_text:
                        self.logger.info(f"Found manuscript dashboard table {i+1}")
                        
                        # Parse table rows to find categories with manuscripts
                        rows = table.find_elements(By.TAG_NAME, "tr")
                        
                        for row in rows:
                            try:
                                # Look for rows with numbers and category links
                                row_text = row.text
                                links = row.find_elements(By.TAG_NAME, "a")
                                
                                # Check if row contains a number > 0 (manuscript count)
                                import re
                                numbers = re.findall(r'\b(\d+)\b', row_text)
                                
                                for number in numbers:
                                    if int(number) > 0:
                                        # Look for category links in this row (not the number link)
                                        category_links = [link for link in links if not link.text.strip().isdigit()]
                                        
                                        for category_link in category_links:
                                            category_text = category_link.text.strip()
                                            
                                            # Only click on actual manuscript category names (updated with real ScholarOne categories)
                                            valid_categories = [
                                                'Awaiting Reviewer Scores',
                                                'Awaiting Reviewer Selection', 
                                                'Awaiting Reviewer Invitation',
                                                'Awaiting Reviewer Assignment',
                                                'Awaiting Reviewer Reports',  # Added - this is the actual category name
                                                'Overdue Reviewer Scores',
                                                'Overdue Reviewer Response',  # Added - this is the actual category name
                                                'Overdue Reviewer Reports',   # Added - this is the actual category name
                                                'Awaiting AE Recommendation',
                                                'Manuscripts Awaiting Revision',
                                                'Overdue Manuscripts Awaiting Revision'
                                            ]
                                            
                                            if category_text in valid_categories and category_text not in processed_categories:
                                                self.logger.info(f"Found unprocessed category: '{category_text}' with {number} manuscripts")
                                                processed_categories.add(category_text)
                                                
                                                # Click on the category name, not the number
                                                self.logger.info(f"Clicking on category: '{category_text}'")
                                                category_link.click()
                                                self._wait_for_page_load()
                                                
                                                # Extract manuscripts from this category
                                                manuscripts = self._extract_manuscripts_from_category()
                                                self.logger.info(f"Extracted {len(manuscripts)} manuscripts from '{category_text}'")
                                                
                                                # Store manuscripts for later extraction
                                                self.found_manuscripts.extend(manuscripts)
                                                
                                                # Go back to dashboard for next category
                                                # Don't use back button - re-navigate
                                                self.logger.info("Re-navigating to dashboard for next category")
                                                self._navigate_to_manuscripts()
                                                
                                                category_found = True
                                                break  # Break to restart the search
                                        
                                        if category_found:
                                            break
                                            
                            except Exception as e:
                                self.logger.debug(f"Error processing row: {e}")
                                continue
                            
                            if category_found:
                                break
                    
                    if category_found:
                        break
                
                # If no new category was found, we're done
                if not category_found:
                    self.logger.info(f"Finished processing all categories. Total manuscripts found: {len(self.found_manuscripts)}")
                    break
                    
                iteration += 1
                    
            if not self.found_manuscripts:
                self.logger.warning("No manuscripts found in any category")
            
        except Exception as e:
            self.logger.error(f"Error finding manuscript categories: {e}")
            
    def _extract_manuscripts_from_category(self) -> List[Dict]:
        """Extract manuscripts from category page using documented workflow table structure."""
        self.logger.info("Extracting manuscripts from category page...")
        
        manuscripts = []
        
        try:
            # Wait for category page to load
            time.sleep(3)
            
            # Store the category URL for later navigation
            category_url = self.driver.current_url
            self.logger.info(f"Storing category URL: {category_url}")
            
            # Find the manuscript table based on the exact structure provided
            tables = self.driver.find_elements(By.TAG_NAME, "table")
            self.logger.info(f"Found {len(tables)} tables on page")
            
            manuscript_table = None
            for table in tables:
                table_html = table.get_attribute('innerHTML')
                # Look for the table with manuscript data - has both manuscript IDs and Take Action
                if any(pattern in table_html for pattern in ['MAFI-', 'MOR-', 'MS-', 'RFS-', 'RAPS-']):
                    if 'Take Action' in table_html and 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS' in table_html:
                        manuscript_table = table
                        self.logger.info("Found manuscript list table with Take Action")
                        break
            
            if not manuscript_table:
                self.logger.warning("No manuscript table found on page")
                return manuscripts
            
            # Parse based on the documented workflow table structure:
            # The table has grouped rows per manuscript:
            # Row 1: Manuscript ID | Date | Take Action (with rowspan)
            # Row 2: Title (colspan)
            # Row 3: Authors (colspan)
            
            rows = manuscript_table.find_elements(By.TAG_NAME, "tr")
            self.logger.info(f"Found {len(rows)} rows in manuscript table")
            
            import re
            ms_id_pattern = r'(MAFI|MOR|MS|RFS|RAPS)-\d{4}-\d{3,4}'
            
            i = 0
            while i < len(rows):
                try:
                    # Skip header rows
                    row_html = rows[i].get_attribute('innerHTML')
                    if 'Manuscript ID' in row_html or 'transparent.gif' in row_html or not rows[i].text.strip():
                        i += 1
                        continue
                    
                    # Look for a manuscript ID in this row
                    ms_id_match = re.search(ms_id_pattern, rows[i].text)
                    
                    if ms_id_match:
                        manuscript_id = ms_id_match.group(0)
                        self.logger.info(f"Found manuscript: {manuscript_id}")
                        
                        # Group the next few rows that belong to this manuscript
                        manuscript_rows = []
                        manuscript_rows.append(rows[i])  # First row with ID
                        
                        # Add subsequent rows until we hit another manuscript ID or separator
                        j = i + 1
                        while j < len(rows):
                            next_row_text = rows[j].text.strip()
                            next_row_html = rows[j].get_attribute('innerHTML')
                            
                            # Stop if we hit another manuscript ID
                            if re.search(ms_id_pattern, next_row_text):
                                break
                            
                            # Stop if we hit a separator row
                            if 'transparent.gif' in next_row_html or len(next_row_text) == 0:
                                break
                                
                            # This row belongs to the current manuscript
                            manuscript_rows.append(rows[j])
                            j += 1
                        
                        # Parse the grouped rows
                        manuscript_data = self._parse_manuscript_group(manuscript_rows, manuscript_id)
                        if manuscript_data:
                            # Store the category URL so we can navigate back to click Take Action
                            manuscript_data['category_url'] = category_url
                            manuscripts.append(manuscript_data)
                        
                        # Continue from where we left off
                        i = j
                    else:
                        i += 1
                        
                except Exception as e:
                    self.logger.debug(f"Error processing row {i}: {e}")
                    i += 1
                    continue
            
            self.logger.info(f"Extracted {len(manuscripts)} manuscripts from category")
            
        except Exception as e:
            self.logger.error(f"Error extracting manuscripts from category: {e}")
            
        return manuscripts
    
    def _parse_manuscript_group(self, rows: List, manuscript_id: str) -> Optional[Dict]:
        """Parse manuscript data from grouped table rows based on documented workflow."""
        try:
            self.logger.debug(f"Parsing {len(rows)} rows for manuscript {manuscript_id}")
            
            manuscript_data = {
                'id': manuscript_id,
                'title': '',
                'submission_date': '',
                'status': '',
                'authors': [],
                'referees': []
            }
            
            # Row 1: Contains manuscript ID, date, and Take Action link (Take Action is in last column with rowspan)
            if len(rows) > 0:
                first_row_html = rows[0].get_attribute('innerHTML')
                first_row_text = rows[0].text.strip()
                
                # Extract date
                import re
                date_match = re.search(r'(\d{2}-\w{3}-\d{4})', first_row_text)
                if date_match:
                    manuscript_data['submission_date'] = date_match.group(1)
                
                # Note: We do NOT store the take_action_link WebElement anymore
                # because it becomes stale when we navigate away from the page.
                # Instead, we'll re-find it when we need to click it.
            
            # Row 2: Usually contains the title
            if len(rows) > 1:
                second_row_html = rows[1].get_attribute('innerHTML')
                second_row_text = rows[1].text.strip()
                
                # Look for title in <p class="listcontents">
                title_match = re.search(r'<p class="listcontents">\s*([^<\[]+?)(?:\s*\[|</p>)', second_row_html)
                if title_match:
                    manuscript_data['title'] = title_match.group(1).strip()
                elif second_row_text and not re.search(r'(MAFI|MOR|MS|RFS|RAPS)-\d{4}-\d{3,4}', second_row_text):
                    # If no listcontents, use the row text as title (if it's not another manuscript ID)
                    manuscript_data['title'] = second_row_text
            
            # Row 3+: Authors (look for mailpopup links)
            for row in rows[2:]:
                row_html = row.get_attribute('innerHTML')
                # Extract authors from mailpopup links
                author_matches = re.findall(r'<a href="[^"]*mailpopup[^"]*"[^>]*>([^<]+)</a>', row_html)
                manuscript_data['authors'].extend(author_matches)
            
            # Extract status from the current page category or row content
            page_text = self.driver.find_element(By.TAG_NAME, "body").text
            if 'Awaiting Reviewer Scores' in page_text:
                manuscript_data['status'] = 'Awaiting Reviewer Scores'
            elif 'Awaiting AE Recommendation' in page_text:
                manuscript_data['status'] = 'Awaiting AE Recommendation'
            elif 'Awaiting Reviewer Selection' in page_text:
                manuscript_data['status'] = 'Awaiting Reviewer Selection'
            else:
                manuscript_data['status'] = 'Under Review'
            
            self.logger.info(f"Parsed manuscript {manuscript_id}:")
            self.logger.info(f"  Title: {manuscript_data['title'][:60]}..." if manuscript_data['title'] else "  Title: Not found")
            self.logger.info(f"  Date: {manuscript_data['submission_date']}")
            self.logger.info(f"  Authors: {len(manuscript_data['authors'])} found")
            
            return manuscript_data
            
        except Exception as e:
            self.logger.error(f"Error parsing manuscript group: {e}")
            return None
    
    def _parse_manuscript_from_table_rows(self, first_row, second_row, manuscript_id: str) -> Optional[Dict]:
        """Parse manuscript data from the two table rows based on exact HTML structure."""
        try:
            import re
            
            self.logger.debug(f"Parsing manuscript {manuscript_id} from table rows")
            
            # Get the HTML and text from both rows
            first_row_html = first_row.get_attribute('innerHTML')
            first_row_text = first_row.text.strip()
            
            second_row_html = ""
            second_row_text = ""
            if second_row:
                second_row_html = second_row.get_attribute('innerHTML')
                second_row_text = second_row.text.strip()
            
            # Extract title from first row - look for the title in the second cell
            title = ""
            # The title is in the second cell of the first row, inside <p class="listcontents">
            title_pattern = r'<td class="tablelightcolor"><p class="listcontents">\s*([^<\[]+?)(?:\s*\[|</p>)'
            title_match = re.search(title_pattern, first_row_html)
            if title_match:
                title = title_match.group(1).strip()
            
            # Extract submission date from first row - it's in a cell with rowspan=2
            submission_date = ""
            date_pattern = r'(\d{2}-\w{3}-\d{4})'
            date_match = re.search(date_pattern, first_row_text)
            if date_match:
                submission_date = date_match.group(1)
            
            # Extract status from first row - it's in the status cell  
            status = ""
            # Look for status indicators in the first row
            if 'Awaiting Reviewer Scores' in first_row_text:
                status = 'Awaiting Reviewer Scores'
            elif 'Awaiting AE' in first_row_text:
                status = 'Awaiting AE Recommendation'
            elif 'Awaiting Reviewer Selection' in first_row_text:
                status = 'Awaiting Reviewer Selection'
            
            # Extract authors from second row - they're in the second cell of second row
            authors = []
            if second_row_html:
                # Look for author links with mailpopup in the second row
                author_pattern = r'<a href="[^"]*mailpopup[^"]*"[^>]*>([^<]+)</a>'
                author_matches = re.findall(author_pattern, second_row_html)
                for author in author_matches:
                    clean_author = author.strip()
                    if clean_author and clean_author not in authors:
                        authors.append(clean_author)
            
            # Find Take Action link from first row (it has rowspan=2)
            take_action_link = None
            take_action_links = first_row.find_elements(By.XPATH, ".//a[contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
            if take_action_links:
                take_action_link = take_action_links[0]
                self.logger.debug(f"Found Take Action link for {manuscript_id}")
            
            manuscript_data = {
                'id': manuscript_id,
                'title': title,
                'submission_date': submission_date,
                'status': status,
                'take_action_link': take_action_link,
                'authors': authors,
                'referees': []
            }
            
            self.logger.info(f"Parsed manuscript: {manuscript_id}")
            if title:
                self.logger.info(f"  Title: {title[:60]}...")
            if authors:
                self.logger.info(f"  Authors: {', '.join(authors[:2])}{'...' if len(authors) > 2 else ''}")
            if submission_date:
                self.logger.info(f"  Date: {submission_date}")
            if status:
                self.logger.info(f"  Status: {status}")
            
            return manuscript_data
            
        except Exception as e:
            self.logger.error(f"Error parsing manuscript from table rows: {e}")
            return None
    
    def _extract_title_from_row(self, row) -> str:
        """Extract manuscript title from table row."""
        try:
            # Look for title in the row
            row_text = row.text
            # Title is usually the longest text in the row
            parts = [part.strip() for part in row_text.split('\n') if len(part.strip()) > 20]
            if parts:
                return parts[0]
            return ""
        except:
            return ""
    
    def _extract_status_from_row(self, row) -> str:
        """Extract manuscript status from table row."""
        try:
            # Status is usually indicated by the category we're in
            return "Under Review"
        except:
            return ""
    
    def _extract_authors_from_row(self, row) -> List[str]:
        """Extract authors from table row."""
        try:
            # Authors are usually in the row text
            row_text = row.text
            # Look for names pattern
            import re
            name_pattern = r'([A-Z][a-z]+\s+[A-Z][a-z]+)'
            names = re.findall(name_pattern, row_text)
            return names[:3]  # Limit to first 3 authors
        except:
            return []
    
    def _extract_manuscripts(self) -> List[Manuscript]:
        """Extract manuscripts from current page."""
        self.logger.info("Extracting manuscripts")
        
        # If we found manuscripts during navigation, convert them to Manuscript objects
        if self.found_manuscripts:
            manuscripts = []
            for manuscript_data in self.found_manuscripts:
                # Convert author strings to Author objects
                author_objects = []
                for author_name in manuscript_data.get('authors', []):
                    if isinstance(author_name, str):
                        author_objects.append(Author(name=author_name))
                    else:
                        author_objects.append(author_name)
                
                manuscript = Manuscript(
                    manuscript_id=manuscript_data['id'],
                    title=manuscript_data.get('title', '') or manuscript_data['id'],  # Use ID as fallback
                    status=ManuscriptStatus.AWAITING_REVIEWER_SCORES,
                    journal_code=self.journal.code,
                    authors=author_objects
                )
                # Store the category URL for later navigation
                manuscript._category_url = manuscript_data.get('category_url')
                manuscripts.append(manuscript)
            
            self.logger.info(f"Found {len(manuscripts)} manuscripts from navigation")
            
            # Process each manuscript to extract referee details
            self.logger.info("Processing manuscripts to extract referee details...")
            for manuscript in manuscripts:
                try:
                    self._process_manuscript(manuscript)
                except Exception as e:
                    self.logger.error(f"Error processing manuscript {manuscript.manuscript_id}: {e}")
                    continue
            
            return manuscripts
        
        # Fallback to legacy extraction if no manuscripts found during navigation
        manuscripts = []
        
        try:
            # Get page source
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            # Find manuscript IDs using pattern
            pattern = self.journal.patterns.get('manuscript_id', r'\w+-\d{4}-\d{4}')
            manuscript_ids = set()
            
            # Search in all text
            for text in soup.stripped_strings:
                matches = re.findall(pattern, text)
                manuscript_ids.update(matches)
            
            # Create manuscript objects
            for manuscript_id in manuscript_ids:
                manuscript = Manuscript(
                    manuscript_id=manuscript_id,
                    title="",  # Will be filled in _process_manuscript
                    status=ManuscriptStatus.AWAITING_REVIEWER_SCORES,
                    journal_code=self.journal.code
                )
                manuscripts.append(manuscript)
            
            self.logger.info(f"Found {len(manuscripts)} manuscripts")
            return manuscripts
            
        except Exception as e:
            self.logger.error(f"Error extracting manuscripts: {e}")
            return []
    
    def _process_manuscript(self, manuscript: Manuscript) -> None:
        """Process a single manuscript."""
        self.logger.info(f"Processing manuscript: {manuscript.manuscript_id}")
        
        try:
            # Navigate to the category page where this manuscript is listed
            category_url = getattr(manuscript, '_category_url', None)
            
            if category_url:
                self.logger.info(f"Navigating back to category page for {manuscript.manuscript_id}")
                self.driver.get(category_url)
                self._wait_for_page_load()
                time.sleep(2)  # Give page time to fully load
            
            # Now find and click the Take Action link for this specific manuscript
            clicked = self._click_take_action_for_manuscript(manuscript.manuscript_id)
            
            if not clicked:
                # Fallback: Try the old _click_manuscript method
                self.logger.warning(f"Primary Take Action click failed, trying fallback for {manuscript.manuscript_id}")
                if not self._click_manuscript(manuscript.manuscript_id):
                    raise RefereeDataError(f"Could not click Take Action for {manuscript.manuscript_id}")
            
            # Extract manuscript details
            self._extract_manuscript_details(manuscript)
            
            # Extract referees
            referees = self._extract_referees()
            manuscript.referees = referees
            
            # Extract PDFs
            pdf_path = self._extract_manuscript_pdf(manuscript.manuscript_id)
            if pdf_path:
                manuscript.pdf_path = pdf_path
            
            # Extract referee reports
            self._extract_referee_reports(manuscript)
            
            # Navigate back to category page (not using back button)
            if category_url:
                self.logger.info(f"Navigating back to category page after processing {manuscript.manuscript_id}")
                self.driver.get(category_url)
                self._wait_for_page_load()
            
        except Exception as e:
            self.logger.error(f"Error processing {manuscript.manuscript_id}: {e}")
            self.errors.append(f"Failed to process {manuscript.manuscript_id}: {str(e)}")
    
    def _click_take_action_for_manuscript(self, manuscript_id: str) -> bool:
        """Find and click Take Action link for a specific manuscript based on exact HTML structure."""
        try:
            self.logger.info(f"Looking for Take Action link for {manuscript_id}")
            
            # Method 1: Find based on the exact HTML structure provided by user
            # Take Action is in the LAST COLUMN with an image src="/images/en_US/icons/check_off.gif"
            
            # Find all table rows
            rows = self.driver.find_elements(By.TAG_NAME, "tr")
            
            for row in rows:
                try:
                    row_text = row.text
                    
                    # Check if this row contains our manuscript ID
                    if manuscript_id not in row_text:
                        continue
                    
                    self.logger.info(f"Found row containing {manuscript_id}")
                    
                    # Method 1: Look for Take Action with check_off.gif image in this row
                    take_action_links = row.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
                    
                    if take_action_links:
                        link = take_action_links[0]
                        self.logger.info(f"Found Take Action link with check_off.gif for {manuscript_id}")
                        
                        # Try to click it
                        try:
                            link.click()
                            self._wait_for_page_load()
                            self.logger.info(f"✅ Successfully clicked Take Action (check_off.gif) for {manuscript_id}")
                            return True
                        except Exception as e:
                            self.logger.warning(f"Direct click failed: {e}")
                            
                            # Try JavaScript click
                            try:
                                self.driver.execute_script("arguments[0].click();", link)
                                self._wait_for_page_load()
                                self.logger.info(f"✅ Successfully clicked Take Action (JS) for {manuscript_id}")
                                return True
                            except Exception as js_e:
                                self.logger.warning(f"JavaScript click failed: {js_e}")
                    
                    # Method 2: Look for any link with ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS in this row
                    detail_links = row.find_elements(By.XPATH, ".//a[contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
                    
                    if detail_links:
                        link = detail_links[0]
                        self.logger.info(f"Found ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS link for {manuscript_id}")
                        
                        href = link.get_attribute('href')
                        self.logger.info(f"Link href: {href[:100]}...")
                        
                        # Execute the JavaScript directly
                        if href and 'javascript:' in href:
                            js_code = href.replace('javascript:', '')
                            try:
                                self.driver.execute_script(js_code)
                                self._wait_for_page_load()
                                self.logger.info(f"✅ Successfully executed Take Action JavaScript for {manuscript_id}")
                                return True
                            except Exception as js_e:
                                self.logger.warning(f"JavaScript execution failed: {js_e}")
                        
                except Exception as e:
                    self.logger.debug(f"Error processing row: {e}")
                    continue
            
            # Method 3: Look in the last column of the table (as user indicated)
            tables = self.driver.find_elements(By.TAG_NAME, "table")
            for table in tables:
                try:
                    # Check if this table contains our manuscript
                    if manuscript_id not in table.text:
                        continue
                    
                    rows = table.find_elements(By.TAG_NAME, "tr")
                    for row in rows:
                        if manuscript_id in row.text:
                            # Get all cells in this row
                            cells = row.find_elements(By.TAG_NAME, "td")
                            if cells:
                                # Check the last cell (Take Action is in the last column)
                                last_cell = cells[-1]
                                take_action_links = last_cell.find_elements(By.TAG_NAME, "a")
                                
                                for link in take_action_links:
                                    # Check if it has the check_off.gif image
                                    images = link.find_elements(By.TAG_NAME, "img")
                                    for img in images:
                                        if 'check_off.gif' in img.get_attribute('src'):
                                            self.logger.info(f"Found Take Action in last column for {manuscript_id}")
                                            try:
                                                link.click()
                                                self._wait_for_page_load()
                                                self.logger.info(f"✅ Successfully clicked Take Action (last column) for {manuscript_id}")
                                                return True
                                            except:
                                                # Try JS execution
                                                href = link.get_attribute('href')
                                                if href and 'javascript:' in href:
                                                    js_code = href.replace('javascript:', '')
                                                    self.driver.execute_script(js_code)
                                                    self._wait_for_page_load()
                                                    self.logger.info(f"✅ Successfully executed Take Action JS (last column) for {manuscript_id}")
                                                    return True
                                
                except Exception as e:
                    self.logger.debug(f"Error checking table: {e}")
                    continue
            
            self.logger.error(f"❌ Could not find Take Action link for {manuscript_id}")
            
            # Save debug info when Take Action is not found
            try:
                debug_file = f"{self.journal.code.lower()}_no_take_action_{manuscript_id}.html"
                with open(debug_file, 'w') as f:
                    f.write(self.driver.page_source)
                self.logger.error(f"Saved page source to {debug_file} for debugging")
                
                screenshot_file = f"{self.journal.code.lower()}_no_take_action_{manuscript_id}.png"
                self.driver.save_screenshot(screenshot_file)
                self.logger.error(f"Saved screenshot to {screenshot_file} for debugging")
            except:
                pass
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error in _click_take_action_for_manuscript: {e}")
            return False
    
    def _click_manuscript(self, manuscript_id: str) -> bool:
        """Click on manuscript 'Take Action' link for ScholarOne."""
        try:
            self.logger.info(f"Attempting to click Take Action for {manuscript_id}")
            
            # Look for Take Action links with JavaScript pattern that includes ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS
            # Example: <a href="javascript:setField('XIK_TAGACT','xik_...'); setField('MANUSCRIPT_DETAILS_JUMP_TO_TAB_60419983','T533977085_533977085'); setDataAndNextPage('XIK_DOCU_ID','xik_...','ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS');">
            
            # Find all links with JavaScript hrefs containing the manuscript details pattern
            links = self.driver.find_elements(By.XPATH, "//a[starts-with(@href, 'javascript:') and contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
            
            self.logger.info(f"Found {len(links)} JavaScript Take Action links on page")
            
            # Also try finding links with check_off.gif images (the Take Action icon)
            if not links:
                icon_links = self.driver.find_elements(By.XPATH, "//a[.//img[contains(@src, 'check_off.gif')]]")
                self.logger.info(f"Found {len(icon_links)} Take Action icon links as fallback")
                links.extend(icon_links)
            
            for i, link in enumerate(links):
                try:
                    # Find the parent row to check if it contains our manuscript ID
                    parent_row = link.find_element(By.XPATH, "./ancestor::tr")
                    row_text = parent_row.text
                    
                    if manuscript_id in row_text:
                        self.logger.info(f"Found Take Action link {i+1} for {manuscript_id}")
                        
                        # Get the href for logging
                        href = link.get_attribute('href')
                        self.logger.info(f"Take Action href: {href[:200]}...")
                        
                        # Try clicking the link
                        try:
                            self.logger.info(f"Clicking Take Action link for {manuscript_id}...")
                            link.click()
                            self._wait_for_page_load()
                            self.logger.info(f"✅ Successfully clicked Take Action for {manuscript_id}")
                            return True
                        except Exception as click_error:
                            self.logger.warning(f"Direct click failed for {manuscript_id}: {click_error}")
                            
                            # Try JavaScript execution as fallback
                            try:
                                if href and 'javascript:' in href:
                                    js_code = href.replace('javascript:', '')
                                    self.logger.info(f"Executing JavaScript for {manuscript_id}")
                                    self.driver.execute_script(js_code)
                                    self._wait_for_page_load()
                                    self.logger.info(f"Successfully executed JavaScript for {manuscript_id}")
                                    return True
                            except Exception as js_error:
                                self.logger.warning(f"JavaScript execution failed for {manuscript_id}: {js_error}")
                                
                except Exception as e:
                    self.logger.debug(f"Error processing Take Action link {i+1}: {e}")
                    continue
            
            # If no Take Action link found in manuscript rows, try broader search
            self.logger.warning(f"No Take Action link found in manuscript rows for {manuscript_id}")
            
            # Try finding manuscript ID first, then look for nearby Take Action
            try:
                # Find the manuscript ID element
                manuscript_elements = self.driver.find_elements(By.XPATH, f"//*[contains(text(), '{manuscript_id}')]")
                
                for ms_element in manuscript_elements:
                    try:
                        # Look for Take Action link in same row or nearby
                        parent_row = ms_element.find_element(By.XPATH, "./ancestor::tr")
                        take_action_links = parent_row.find_elements(By.XPATH, ".//a[contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
                        
                        if take_action_links:
                            link = take_action_links[0]
                            self.logger.info(f"Found Take Action via manuscript element search for {manuscript_id}")
                            
                            # Try clicking
                            try:
                                link.click()
                                self._wait_for_page_load()
                                return True
                            except:
                                # Try JavaScript execution
                                href = link.get_attribute('href')
                                if href and 'javascript:' in href:
                                    js_code = href.replace('javascript:', '')
                                    self.driver.execute_script(js_code)
                                    self._wait_for_page_load()
                                    return True
                                    
                    except Exception as e:
                        self.logger.debug(f"Error with manuscript element: {e}")
                        continue
                        
            except Exception as e:
                self.logger.debug(f"Broader search failed: {e}")
            
            self.logger.error(f"❌ Could not find or click Take Action for {manuscript_id}")
            return False
            
        except Exception as e:
            self.logger.error(f"Error clicking manuscript {manuscript_id}: {e}")
            return False
    
    def _extract_manuscript_details(self, manuscript: Manuscript) -> None:
        """Extract manuscript title and other details."""
        try:
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            # Extract title
            title_patterns = [
                r'Title:\s*([^\n]+)',
                r'Manuscript Title:\s*([^\n]+)',
                r'<b>Title:</b>\s*([^<]+)'
            ]
            
            page_text = soup.get_text()
            for pattern in title_patterns:
                match = re.search(pattern, page_text, re.IGNORECASE)
                if match:
                    manuscript.title = match.group(1).strip()
                    break
                    
            if not manuscript.title:
                manuscript.title = f"Manuscript {manuscript.manuscript_id}"
                
        except Exception as e:
            self.logger.error(f"Error extracting manuscript details: {e}")
    
    def _extract_referees(self) -> List[Referee]:
        """Extract referee information."""
        referees = []
        
        try:
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            # Find reviewer table
            reviewer_sections = soup.find_all(['table', 'div'], class_=re.compile('reviewer|referee', re.I))
            
            if not reviewer_sections:
                # Try finding by text
                for table in soup.find_all('table'):
                    if 'Reviewer List' in table.get_text():
                        reviewer_sections = [table]
                        break
            
            for section in reviewer_sections:
                # Find reviewer rows
                rows = section.find_all('tr')
                
                for row in rows:
                    cells = row.find_all(['td', 'th'])
                    if len(cells) < 3:
                        continue
                    
                    # Extract referee data
                    referee_data = self._parse_referee_row(cells)
                    if referee_data:
                        referee = self._create_referee_from_data(referee_data)
                        referees.append(referee)
            
            self.logger.info(f"Extracted {len(referees)} referees")
            return referees
            
        except Exception as e:
            self.logger.error(f"Error extracting referees: {e}")
            return []
    
    def _parse_referee_row(self, cells: List) -> Optional[Dict[str, Any]]:
        """Parse a single referee row."""
        try:
            # Get cell texts
            texts = [cell.get_text(strip=True) for cell in cells]
            
            # Skip header rows
            if any(header in texts[0].lower() for header in ['reviewer', 'name', 'referee']):
                return None
            
            data = {
                'raw_name': texts[0] if len(texts) > 0 else '',
                'status': texts[1] if len(texts) > 1 else '',
                'dates_text': ' '.join(texts[2:]) if len(texts) > 2 else ''
            }
            
            # Parse name and institution
            name, institution = self._parse_name_institution(data['raw_name'])
            data['name'] = name
            data['institution'] = institution
            
            # Parse dates
            data['dates'] = self._parse_dates(data['dates_text'])
            
            # Parse status
            data['referee_status'] = self._parse_status(data['status'])
            
            return data
            
        except Exception as e:
            self.logger.debug(f"Error parsing referee row: {e}")
            return None
    
    def _parse_name_institution(self, raw_text: str) -> tuple:
        """Parse referee name and institution."""
        # Clean text
        text = raw_text.strip()
        
        # Patterns for name extraction
        patterns = [
            r'^([A-Za-z\-\'\s]+,\s*[A-Za-z\-\'\s]+?)(?=\s+[A-Z][a-z]|University|College|Institute|School)',
            r'^([A-Za-z\-\'\s]+,\s*[A-Za-z\-\'\s]+?)(?:\s*\([A-Z0-9]+\))',
            r'^([A-Za-z\-\'\s]+,\s*[A-Za-z\-\'\s]+?)$'
        ]
        
        name = text
        institution = None
        
        for pattern in patterns:
            match = re.match(pattern, text)
            if match:
                name = match.group(1).strip()
                # Get remaining text as institution
                institution = text[len(name):].strip()
                break
        
        # Clean up institution
        if institution:
            institution = re.sub(r'^\s*[-,]\s*', '', institution)
            institution = institution.strip()
            if not institution:
                institution = None
                
        return name, institution
    
    def _parse_dates(self, dates_text: str) -> RefereeDates:
        """Parse dates from text."""
        dates = RefereeDates()
        
        # Date patterns
        date_patterns = {
            'invited': r'Invited[:\s]+(\d{1,2}-\w{3}-\d{4})',
            'agreed': r'Agreed[:\s]+(\d{1,2}-\w{3}-\d{4})',
            'declined': r'Declined[:\s]+(\d{1,2}-\w{3}-\d{4})',
            'due': r'Due[:\s]+(\d{1,2}-\w{3}-\d{4})',
            'completed': r'Completed[:\s]+(\d{1,2}-\w{3}-\d{4})'
        }
        
        for field, pattern in date_patterns.items():
            match = re.search(pattern, dates_text, re.IGNORECASE)
            if match:
                try:
                    date_obj = datetime.strptime(match.group(1), '%d-%b-%Y').date()
                    setattr(dates, field, date_obj)
                except:
                    pass
                    
        return dates
    
    def _parse_status(self, status_text: str) -> RefereeStatus:
        """Parse referee status."""
        status_lower = status_text.lower()
        
        if 'agreed' in status_lower:
            return RefereeStatus.AGREED
        elif 'declined' in status_lower:
            return RefereeStatus.DECLINED
        elif 'completed' in status_lower:
            return RefereeStatus.COMPLETED
        elif 'invited' in status_lower:
            return RefereeStatus.INVITED
        elif 'overdue' in status_lower:
            return RefereeStatus.OVERDUE
        else:
            return RefereeStatus.UNKNOWN
    
    def _create_referee_from_data(self, data: Dict[str, Any]) -> Referee:
        """Create Referee object from parsed data."""
        return Referee(
            name=data['name'],
            institution=data.get('institution'),
            status=data.get('referee_status', RefereeStatus.UNKNOWN),
            dates=data.get('dates', RefereeDates()),
            raw_data=data
        )
    
    def _extract_manuscript_pdf(self, manuscript_id: str) -> Optional[Path]:
        """Extract manuscript PDF using proven legacy method."""
        try:
            # Use proven legacy PDF download method
            download_dir = self.output_dir / "pdfs"
            pdf_info = self.legacy_download_pdfs(self.driver, manuscript_id, download_dir)
            
            if pdf_info.get('manuscript_pdf_file'):
                return Path(pdf_info['manuscript_pdf_file'])
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error extracting manuscript PDF: {e}")
            return None
    
    def _extract_referee_reports(self, manuscript: Manuscript) -> None:
        """Extract referee reports if available."""
        try:
            # Look for "view review" links
            review_links = self.driver.find_elements(
                By.PARTIAL_LINK_TEXT, 
                "view review"
            )
            
            for i, link in enumerate(review_links):
                try:
                    # Click to open review
                    link.click()
                    time.sleep(2)
                    
                    # Handle new window/tab
                    if len(self.driver.window_handles) > 1:
                        self.driver.switch_to.window(self.driver.window_handles[-1])
                        
                    # Extract review content
                    review_text = self._extract_review_content()
                    
                    # Try to match with referee
                    if i < len(manuscript.referees):
                        referee = manuscript.referees[i]
                        referee.report = RefereeReport(
                            text_content=review_text,
                            submitted_date=datetime.now()
                        )
                    
                    # Close window/tab
                    if len(self.driver.window_handles) > 1:
                        self.driver.close()
                        self.driver.switch_to.window(self.driver.window_handles[0])
                        
                except Exception as e:
                    self.logger.error(f"Error extracting referee report: {e}")
                    
        except Exception as e:
            self.logger.error(f"Error finding referee reports: {e}")
    
    def _extract_review_content(self) -> str:
        """Extract review content from current page."""
        try:
            # Get page text
            page_text = self.driver.find_element(By.TAG_NAME, "body").text
            
            # Clean up text
            lines = page_text.split('\n')
            
            # Remove common headers/footers
            skip_patterns = [
                r'^Page \d+',
                r'^ScholarOne',
                r'^\s*$'
            ]
            
            cleaned_lines = []
            for line in lines:
                if not any(re.match(pattern, line) for pattern in skip_patterns):
                    cleaned_lines.append(line)
                    
            return '\n'.join(cleaned_lines)
            
        except Exception:
            return ""
    
    def _navigate_back(self) -> None:
        """Navigate back to manuscript list - for ScholarOne we must re-navigate, not use back button."""
        try:
            # For ScholarOne (MF/MOR), using back button disconnects the session
            # Always re-navigate instead
            self.logger.info("Re-navigating to manuscripts (avoiding back button)")
            self._navigate_to_manuscripts()
        except Exception as e:
            self.logger.error(f"Error navigating back: {e}")
    

    def _handle_cookie_consent(self) -> None:
        """Handle cookie consent banners that might block login."""
        try:
            # Wait a moment for cookie banner to appear
            time.sleep(2)
            
            # List of possible cookie consent button selectors
            cookie_selectors = [
                ("id", "onetrust-reject-all-handler"),
                ("id", "onetrust-accept-btn-handler"),
                ("xpath", "//button[contains(text(), 'Accept')]"),
                ("xpath", "//button[contains(text(), 'Reject')]"),
                ("xpath", "//button[contains(text(), 'Continue')]"),
                ("class", "cookie-accept"),
                ("class", "accept-cookies")
            ]
            
            for selector_type, selector_value in cookie_selectors:
                try:
                    if selector_type == "id":
                        element = self.driver.find_element(By.ID, selector_value)
                    elif selector_type == "xpath":
                        element = self.driver.find_element(By.XPATH, selector_value)
                    elif selector_type == "class":
                        element = self.driver.find_element(By.CLASS_NAME, selector_value)
                    
                    if element and element.is_displayed():
                        self.logger.info(f"Found cookie consent button: {selector_value}")
                        element.click()
                        time.sleep(1)
                        break
                except:
                    continue
                    
        except Exception as e:
            self.logger.debug(f"Cookie consent handling: {e}")
    
    def _wait_for_page_load(self) -> None:
        """Wait for page to fully load."""
        try:
            # Wait for jQuery if available
            self.driver.execute_script("""
                if (typeof jQuery !== 'undefined') {
                    return jQuery.active == 0;
                }
                return true;
            """)
            
            # Additional wait
            time.sleep(1)
            
        except:
            time.sleep(2)