#!/usr/bin/env python3
"""
Precise SIFIN Adapter
Integrates the precise referee tracker with SIFIN email data
"""

import sys
import os
import json
import re
from datetime import datetime, timezone
from typing import List, Dict, Optional

# Add path to import existing SIFIN parser
sys.path.append('/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/scripts/sifin')

from precise_referee_tracker import PreciseRefereeTracker

try:
    from parse_sifin_emails import SIFINEmailParser
except ImportError:
    print("Warning: Could not import SIFINEmailParser. Running in standalone mode.")
    SIFINEmailParser = None

class PreciseSIFINAdapter:
    """Precise adapter for SIFIN focusing only on actual referee correspondence"""
    
    def __init__(self):
        self.referee_tracker = PreciseRefereeTracker()
        self.sifin_parser = SIFINEmailParser() if SIFINEmailParser else None
    
    def convert_gmail_to_standard_format(self, gmail_message: Dict) -> Optional[Dict]:
        """Convert Gmail message to standard format for the tracker"""
        try:
            # Extract headers
            headers = {}
            payload = gmail_message.get('payload', {})
            
            for header in payload.get('headers', []):
                name = header.get('name', '').lower()
                if name in ['subject', 'from', 'to', 'date', 'cc', 'bcc']:
                    headers[name] = header.get('value', '')
            
            # Extract and clean body
            body = self._extract_email_body(payload)
            body = self._clean_email_body(body)
            
            # Parse addresses
            to_addresses = self._parse_email_addresses(headers.get('to', ''))
            cc_addresses = self._parse_email_addresses(headers.get('cc', ''))
            
            # Parse date
            date_str = headers.get('date', '')
            try:
                from email.utils import parsedate_to_datetime
                email_date = parsedate_to_datetime(date_str)
                if email_date.tzinfo is None:
                    email_date = email_date.replace(tzinfo=timezone.utc)
            except:
                email_date = datetime.now(timezone.utc)
            
            # Extract manuscript ID for filtering
            manuscript_id = self._extract_manuscript_id(headers.get('subject', ''), body)
            
            return {
                'message_id': gmail_message.get('id', ''),
                'thread_id': gmail_message.get('threadId', ''),
                'date': email_date,
                'subject': headers.get('subject', ''),
                'from_address': headers.get('from', ''),
                'to_addresses': to_addresses,
                'cc_addresses': cc_addresses,
                'body': body,
                'manuscript_id': manuscript_id
            }
            
        except Exception as e:
            print(f"Error converting email: {e}")
            return None
    
    def _extract_email_body(self, payload: Dict) -> str:
        """Extract body text from email payload"""
        body = ""
        
        def extract_text_recursive(part):
            nonlocal body
            if 'parts' in part:
                for subpart in part['parts']:
                    extract_text_recursive(subpart)
            elif part.get('mimeType') == 'text/plain':
                data = part.get('body', {}).get('data', '')
                if data:
                    import base64
                    try:
                        decoded = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                        body += decoded + "\n"
                    except:
                        pass
        
        extract_text_recursive(payload)
        return body
    
    def _clean_email_body(self, body: str) -> str:
        """Clean email body of noise and artifacts"""
        if not body:
            return ""
        
        # Remove email signatures
        body = re.sub(r'--\s*\n.*', '', body, flags=re.DOTALL)
        
        # Remove excessive whitespace
        body = re.sub(r'\n\s*\n', '\n\n', body)
        body = re.sub(r'\s+', ' ', body)
        
        # Remove email threading artifacts
        body = re.sub(r'On\s+.*wrote:', '', body, flags=re.IGNORECASE)
        body = re.sub(r'From:.*To:.*Subject:', '', body, flags=re.IGNORECASE)
        
        return body.strip()
    
    def _parse_email_addresses(self, address_string: str) -> List[str]:
        """Parse and validate email addresses"""
        if not address_string:
            return []
        
        # Extract email addresses
        emails = re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', address_string)
        
        # Validate and filter
        valid_emails = []
        for email in emails:
            if self._is_valid_email(email):
                valid_emails.append(email.lower())
        
        return valid_emails
    
    def _is_valid_email(self, email: str) -> bool:
        """Validate email format"""
        if not email or '@' not in email:
            return False
        
        parts = email.split('@')
        if len(parts) != 2:
            return False
        
        username, domain = parts
        
        if len(username) < 1 or len(domain) < 3:
            return False
        
        if not domain.count('.') >= 1:
            return False
        
        return True
    
    def _extract_manuscript_id(self, subject: str, body: str) -> Optional[str]:
        """Extract manuscript ID for filtering purposes"""
        text = f"{subject} {body}"
        
        # SIFIN patterns for manuscript ID
        patterns = [
            r'SIFIN\s+(M\d+)',
            r'[Mm]anuscript\s+#?(M\d+)',
            r'(M\d{6})',  # 6-digit manuscript IDs
            r'(M\d{5})',  # 5-digit manuscript IDs
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1)
        
        return None
    
    def process_sifin_emails(self, manuscript_ids: List[str]) -> Dict:
        """Process SIFIN emails with precise referee tracking"""
        if not self.sifin_parser:
            print("SIFIN parser not available")
            return {}
        
        print(f"🔍 Processing SIFIN emails with precise referee tracking: {manuscript_ids}")
        
        # Setup Gmail service
        if not self.sifin_parser.setup_gmail_service():
            print("❌ Failed to setup Gmail service")
            return {}
        
        # Fetch emails for all manuscripts
        all_emails = []
        for manuscript_id in manuscript_ids:
            emails = self._fetch_manuscript_emails(manuscript_id)
            all_emails.extend(emails)
        
        print(f"📧 Found {len(all_emails)} emails total")
        
        # Convert and process emails
        processed_count = 0
        referee_correspondence_count = 0
        
        for gmail_msg in all_emails:
            email_data = self.convert_gmail_to_standard_format(gmail_msg)
            if email_data:
                processed_count += 1
                # Process with precise tracker
                if self.referee_tracker.process_email(email_data):
                    referee_correspondence_count += 1
        
        print(f"✅ Processed {processed_count} emails")
        print(f"📧 Found {referee_correspondence_count} referee correspondence emails")
        
        # Consolidate referee profiles for each manuscript
        total_referees = 0
        for manuscript_id in manuscript_ids:
            self.referee_tracker.consolidate_referee_profiles(manuscript_id)
            if manuscript_id in self.referee_tracker.manuscript_referees:
                total_referees += len(self.referee_tracker.manuscript_referees[manuscript_id])
        
        print(f"👥 Identified {total_referees} total referees across all manuscripts")
        
        # Generate results for each manuscript
        results = {}
        for manuscript_id in manuscript_ids:
            analytics = self.referee_tracker.generate_manuscript_analytics(manuscript_id)
            report = self.referee_tracker.generate_report(manuscript_id)
            
            results[manuscript_id] = {
                'analytics': analytics,
                'report': report
            }
        
        return results
    
    def _fetch_manuscript_emails(self, manuscript_id: str) -> List[Dict]:
        """Fetch emails for a specific manuscript"""
        queries = [
            f'from:sifin.siam.org {manuscript_id}',
            f'subject:SIFIN {manuscript_id}',
            f'subject:"{manuscript_id}"',
            f'{manuscript_id}',  # Broader search
        ]
        
        all_emails = []
        seen_ids = set()
        
        for query in queries:
            try:
                response = self.sifin_parser.gmail_service.users().messages().list(
                    userId='me',
                    q=query,
                    maxResults=100  # Increased to catch more emails
                ).execute()
                
                messages = response.get('messages', [])
                
                for msg in messages:
                    if msg['id'] in seen_ids:
                        continue
                    seen_ids.add(msg['id'])
                    
                    full_msg = self.sifin_parser.gmail_service.users().messages().get(
                        userId='me',
                        id=msg['id'],
                        format='full'
                    ).execute()
                    
                    all_emails.append(full_msg)
                    
            except Exception as e:
                print(f"Error with query '{query}': {e}")
        
        return all_emails
    
    def save_results(self, results: Dict, filename: str = None) -> str:
        """Save results to JSON file"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"precise_sifin_results_{timestamp}.json"
        
        # Convert datetime objects to ISO strings for JSON serialization
        serializable_results = {}
        for manuscript_id, data in results.items():
            serializable_data = {'analytics': data['analytics'].copy(), 'report': data['report']}
            
            # Convert datetime objects in analytics
            for referee_id, referee_data in serializable_data['analytics']['referees'].items():
                for timeline_event in referee_data['correspondence_timeline']:
                    if isinstance(timeline_event['date'], datetime):
                        timeline_event['date'] = timeline_event['date'].isoformat()
            
            serializable_results[manuscript_id] = serializable_data
        
        with open(filename, 'w') as f:
            json.dump(serializable_results, f, indent=2)
        
        print(f"📄 Results saved to: {filename}")
        return filename

def main():
    """Test the precise SIFIN adapter"""
    adapter = PreciseSIFINAdapter()
    
    # Test with known SIFIN manuscript IDs
    manuscript_ids = ["M174160", "M174727", "M175988", "M176140"]
    
    print("🚀 Testing Precise SIFIN Adapter")
    print("=" * 60)
    print("🎯 Focus: Only actual referee correspondence")
    print("❌ Ignoring: System notifications, follow-up messages")
    print("=" * 60)
    
    # Process emails
    results = adapter.process_sifin_emails(manuscript_ids)
    
    if results:
        # Display reports
        for manuscript_id, data in results.items():
            print(f"\n{data['report']}")
            print("=" * 60)
        
        # Save results
        filename = adapter.save_results(results)
        
        print(f"\n🎉 Precise SIFIN Processing Complete!")
        print(f"📊 Results saved to: {filename}")
        
        # Summary
        total_referees = sum(data['analytics']['total_referees'] for data in results.values())
        print(f"\n📊 SUMMARY:")
        print(f"   Total Manuscripts: {len(manuscript_ids)}")
        print(f"   Total Referees Found: {total_referees}")
        
    else:
        print("❌ No results generated")

if __name__ == "__main__":
    main()