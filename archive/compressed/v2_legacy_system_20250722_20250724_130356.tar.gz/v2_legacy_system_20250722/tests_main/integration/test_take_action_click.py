#!/usr/bin/env python3
"""
Simple test script to verify Take Action clicking works for MF/MOR (ScholarOne).
This focuses ONLY on clicking the Take Action icon correctly.
"""

import os
import time
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.chrome.options import Options


def setup_driver():
    """Setup Chrome driver with proper options."""
    options = Options()
    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    driver = webdriver.Chrome(options=options)
    driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    return driver


def login(driver, journal_code):
    """Simple login to ScholarOne."""
    print(f"\n=== Logging into {journal_code} ===")
    
    # Get URL and credentials
    urls = {
        'MF': 'https://mc.manuscriptcentral.com/mfi',
        'MOR': 'https://mc.manuscriptcentral.com/mor'
    }
    
    driver.get(urls.get(journal_code.upper()))
    time.sleep(3)
    
    # Handle cookie consent
    try:
        reject_btn = driver.find_element(By.ID, "onetrust-reject-all-handler")
        if reject_btn.is_displayed():
            reject_btn.click()
            print("Rejected cookies")
            time.sleep(1)
    except:
        pass
    
    # Login
    email = os.getenv(f'{journal_code.upper()}_EMAIL')
    password = os.getenv(f'{journal_code.upper()}_PASSWORD')
    
    # Enter credentials
    username_field = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "USERID"))
    )
    username_field.clear()
    username_field.send_keys(email)
    
    password_field = driver.find_element(By.ID, "PASSWORD")
    password_field.clear()
    password_field.send_keys(password)
    
    # Click login
    login_btn = driver.find_element(By.ID, "logInButton")
    login_btn.click()
    
    print("Login submitted")
    time.sleep(5)
    
    # Handle 2FA if needed
    try:
        token_field = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.ID, "TOKEN_VALUE"))
        )
        if token_field.is_displayed():
            print("\n⚠️  2FA Required!")
            print("Please check your email for the verification code.")
            code = input("Enter verification code: ").strip()
            token_field.clear()
            token_field.send_keys(code)
            
            # Click verify
            verify_btn = driver.find_element(By.ID, "VERIFY_BTN")
            verify_btn.click()
            print("2FA submitted")
            time.sleep(10)
    except TimeoutException:
        print("No 2FA required")
    
    # Verify login
    page_text = driver.find_element(By.TAG_NAME, "body").text
    if "Associate Editor Center" in page_text:
        print("✅ Login successful!")
        return True
    else:
        print("❌ Login failed!")
        return False


def navigate_to_ae_center(driver):
    """Navigate to Associate Editor Center."""
    print("\n=== Navigating to AE Center ===")
    
    # Click AE Center link
    ae_link = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.LINK_TEXT, "Associate Editor Center"))
    )
    ae_link.click()
    time.sleep(3)
    
    print("✅ In Associate Editor Center")


def find_category_with_manuscripts(driver):
    """Find and click on a category that has manuscripts."""
    print("\n=== Finding manuscript categories ===")
    
    # Look for the dashboard table
    tables = driver.find_elements(By.TAG_NAME, "table")
    
    for table in tables:
        table_text = table.text
        if any(cat in table_text for cat in ["Awaiting Reviewer", "Awaiting AE", "Overdue"]):
            print("Found manuscript dashboard table")
            
            # Find rows with manuscript counts > 0
            rows = table.find_elements(By.TAG_NAME, "tr")
            for row in rows:
                row_text = row.text
                
                # Look for numbers
                numbers = re.findall(r'\b(\d+)\b', row_text)
                for num in numbers:
                    if int(num) > 0:
                        # Find the category link (not the number)
                        links = row.find_elements(By.TAG_NAME, "a")
                        for link in links:
                            link_text = link.text.strip()
                            if link_text and not link_text.isdigit():
                                # Found a category name
                                print(f"\nFound category: '{link_text}' with {num} manuscripts")
                                link.click()
                                time.sleep(3)
                                return True
    
    print("❌ No categories with manuscripts found")
    return False


def click_take_action_for_manuscript(driver, manuscript_id):
    """
    Click Take Action for a specific manuscript using the EXACT HTML structure provided.
    Take Action is in the LAST COLUMN with image src="/images/en_US/icons/check_off.gif"
    """
    print(f"\n=== Clicking Take Action for {manuscript_id} ===")
    
    # Method 1: Find the row containing the manuscript ID, then find Take Action in last column
    rows = driver.find_elements(By.TAG_NAME, "tr")
    
    for row in rows:
        try:
            row_text = row.text
            if manuscript_id not in row_text:
                continue
            
            print(f"Found row containing {manuscript_id}")
            
            # Get all cells in this row
            cells = row.find_elements(By.TAG_NAME, "td")
            if not cells:
                continue
            
            # Check the LAST cell (Take Action is in the last column)
            last_cell = cells[-1]
            print(f"Checking last cell of row (cell {len(cells)})")
            
            # Look for anchor with check_off.gif image
            take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
            
            if take_action_links:
                link = take_action_links[0]
                print("✅ Found Take Action link with check_off.gif in last column!")
                
                # Get the href for debugging
                href = link.get_attribute('href')
                print(f"Take Action href: {href[:100]}...")
                
                # Try direct click first
                try:
                    link.click()
                    time.sleep(3)
                    print("✅ Successfully clicked Take Action!")
                    return True
                except Exception as e:
                    print(f"Direct click failed: {e}")
                    
                    # Try JavaScript execution
                    if href and 'javascript:' in href:
                        js_code = href.replace('javascript:', '')
                        print("Executing JavaScript directly...")
                        driver.execute_script(js_code)
                        time.sleep(3)
                        print("✅ Successfully executed Take Action JavaScript!")
                        return True
            
            # Also check for any ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS link in last cell
            detail_links = last_cell.find_elements(By.XPATH, ".//a[contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
            if detail_links:
                link = detail_links[0]
                print("Found ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS link in last column")
                href = link.get_attribute('href')
                if href and 'javascript:' in href:
                    js_code = href.replace('javascript:', '')
                    driver.execute_script(js_code)
                    time.sleep(3)
                    print("✅ Successfully executed manuscript details JavaScript!")
                    return True
                    
        except Exception as e:
            print(f"Error processing row: {e}")
            continue
    
    print(f"❌ Could not find Take Action for {manuscript_id}")
    
    # Save debug info
    with open(f"no_take_action_{manuscript_id}.html", 'w') as f:
        f.write(driver.page_source)
    print(f"Saved debug HTML to no_take_action_{manuscript_id}.html")
    
    return False


def extract_referee_info(driver):
    """Extract basic referee information from manuscript details page."""
    print("\n=== Extracting referee information ===")
    
    # Check if we're on the manuscript details page
    page_text = driver.find_element(By.TAG_NAME, "body").text
    if "Manuscript Details" not in page_text and "Reviewer" not in page_text:
        print("❌ Not on manuscript details page!")
        return []
    
    # Look for reviewer/referee information
    referees = []
    
    # Find tables that might contain referee data
    tables = driver.find_elements(By.TAG_NAME, "table")
    for table in tables:
        table_text = table.text
        if any(term in table_text for term in ["Reviewer", "Referee", "Review"]):
            print("Found referee table")
            rows = table.find_elements(By.TAG_NAME, "tr")
            
            for row in rows:
                row_text = row.text.strip()
                # Skip headers
                if any(header in row_text.lower() for header in ["reviewer", "name", "status", "score"]):
                    continue
                
                # Look for referee names (Last, First format)
                if ',' in row_text and len(row_text) > 10:
                    cells = row.find_elements(By.TAG_NAME, "td")
                    if cells:
                        referee_name = cells[0].text.strip()
                        if referee_name and ',' in referee_name:
                            referees.append(referee_name)
                            print(f"  Found referee: {referee_name}")
    
    print(f"Total referees found: {len(referees)}")
    return referees


def process_manuscripts_in_category(driver):
    """Process all manuscripts in the current category."""
    print("\n=== Processing manuscripts in category ===")
    
    # Store the category URL
    category_url = driver.current_url
    print(f"Category URL: {category_url}")
    
    # Find all manuscript IDs on the page
    page_text = driver.find_element(By.TAG_NAME, "body").text
    manuscript_pattern = r'(MAFI|MOR|MS|RFS|RAPS)-\d{4}-\d{3,4}'
    manuscript_ids = list(set(re.findall(manuscript_pattern, page_text)))
    
    print(f"Found {len(manuscript_ids)} manuscripts: {manuscript_ids}")
    
    results = []
    
    for ms_id in manuscript_ids:
        print(f"\n{'='*60}")
        print(f"Processing {ms_id}")
        print(f"{'='*60}")
        
        # Make sure we're on the category page
        if driver.current_url != category_url:
            print("Navigating back to category page...")
            driver.get(category_url)
            time.sleep(3)
        
        # Click Take Action
        if click_take_action_for_manuscript(driver, ms_id):
            # Extract referee info
            referees = extract_referee_info(driver)
            results.append({
                'manuscript_id': ms_id,
                'referees': referees,
                'success': True
            })
            
            # Go back to category page
            print("Going back to category page...")
            driver.get(category_url)
            time.sleep(3)
        else:
            results.append({
                'manuscript_id': ms_id,
                'referees': [],
                'success': False,
                'error': 'Could not click Take Action'
            })
    
    return results


def main():
    """Main test function."""
    print("=== ScholarOne Take Action Click Test ===")
    
    # Get journal code
    journal_code = input("Enter journal code (MF/MOR): ").strip().upper()
    if journal_code not in ['MF', 'MOR']:
        print("Invalid journal code")
        return
    
    driver = setup_driver()
    
    try:
        # Login
        if not login(driver, journal_code):
            print("Login failed!")
            return
        
        # Navigate to AE Center
        navigate_to_ae_center(driver)
        
        # Find a category with manuscripts
        if find_category_with_manuscripts(driver):
            # Process manuscripts
            results = process_manuscripts_in_category(driver)
            
            # Print summary
            print("\n" + "="*60)
            print("SUMMARY")
            print("="*60)
            
            for result in results:
                if result['success']:
                    print(f"✅ {result['manuscript_id']}: {len(result['referees'])} referees")
                    for ref in result['referees']:
                        print(f"   - {ref}")
                else:
                    print(f"❌ {result['manuscript_id']}: {result['error']}")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        print("\nPress Enter to close browser...")
        input()
        driver.quit()


if __name__ == "__main__":
    main()