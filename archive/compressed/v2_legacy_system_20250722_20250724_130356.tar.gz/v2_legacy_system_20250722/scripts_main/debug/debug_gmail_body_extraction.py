#!/usr/bin/env python3
"""
Debug Gmail body extraction issue
"""

import base64
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

def debug_gmail_body():
    """Debug Gmail body extraction"""
    
    # Setup Gmail service
    token_path = "/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/config/token.json"
    creds = Credentials.from_authorized_user_file(token_path)
    service = build('gmail', 'v1', credentials=creds)
    
    # Get the specific email we know has content
    msg_id = "1975f4d74ad15aa2"
    
    print(f"🔍 Fetching message {msg_id}")
    
    message = service.users().messages().get(
        userId='me',
        id=msg_id,
        format='full'
    ).execute()
    
    # Debug the payload structure
    payload = message.get('payload', {})
    
    print(f"\n📊 PAYLOAD STRUCTURE:")
    print(f"   mimeType: {payload.get('mimeType')}")
    print(f"   Has parts: {'parts' in payload}")
    if 'parts' in payload:
        print(f"   Number of parts: {len(payload['parts'])}")
        for i, part in enumerate(payload['parts']):
            print(f"   Part {i}: mimeType={part.get('mimeType')}, has body={'body' in part}")
            if 'body' in part and 'data' in part['body']:
                print(f"           body data length: {len(part['body']['data'])}")
    
    # Try different extraction methods
    print(f"\n📄 BODY EXTRACTION ATTEMPTS:")
    
    # Method 1: Direct body
    if 'body' in payload and 'data' in payload['body']:
        data = payload['body']['data']
        body1 = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
        print(f"\n1. Direct body ({len(body1)} chars):")
        print(body1[:200])
    
    # Method 2: Parts
    if 'parts' in payload:
        for i, part in enumerate(payload['parts']):
            if part.get('mimeType') == 'text/plain':
                if 'body' in part and 'data' in part['body']:
                    data = part['body']['data']
                    body2 = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                    print(f"\n2. Part {i} text/plain ({len(body2)} chars):")
                    print(body2[:500])
            elif part.get('mimeType') == 'text/html':
                if 'body' in part and 'data' in part['body']:
                    data = part['body']['data']
                    body3 = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                    print(f"\n3. Part {i} text/html ({len(body3)} chars):")
                    print(body3[:200])
    
    # Method 3: Check for nested parts (multipart/alternative)
    def extract_nested_parts(part, level=0):
        indent = "  " * level
        if 'parts' in part:
            print(f"{indent}Nested parts in {part.get('mimeType')}:")
            for i, subpart in enumerate(part['parts']):
                print(f"{indent}  Subpart {i}: {subpart.get('mimeType')}")
                if subpart.get('mimeType') == 'text/plain' and 'body' in subpart and 'data' in subpart['body']:
                    data = subpart['body']['data']
                    body = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                    print(f"{indent}    Content ({len(body)} chars): {body[:200]}")
                extract_nested_parts(subpart, level + 1)
    
    print(f"\n4. Checking for nested parts:")
    if 'parts' in payload:
        for i, part in enumerate(payload['parts']):
            extract_nested_parts(part)
    

if __name__ == "__main__":
    debug_gmail_body()