#!/usr/bin/env python3
"""
SICON Email Crosschecking System
Crosschecks web-scraped referee data with actual Gmail exchanges to reconstruct complete timeline
"""

import os
import re
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import time

# Gmail API imports
try:
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
    GMAIL_AVAILABLE = True
except ImportError:
    GMAIL_AVAILABLE = False

logger = logging.getLogger(__name__)

class SICONEmailCrosschecker:
    """Crosscheck SICON referee data with Gmail exchanges"""
    
    def __init__(self):
        self.gmail_service = None
        self.manuscript_patterns = {
            'sicon_subject': r'SICON.*[Mm]anuscript\s+(M\d+)',
            'siam_subject': r'SIAM.*[Cc]ontrol.*[Mm]anuscript\s+(M\d+)',
            'manuscript_id': r'M\d+',
            'referee_invitation': r'(?:referee|reviewer)\s+invitation',
            'referee_response': r'(?:accepted|declined|agreed|unable).*(?:review|referee)',
            'reminder': r'reminder.*(?:review|referee)',
            'overdue': r'overdue.*(?:review|referee)',
        }
    
    def setup_gmail_service(self) -> bool:
        """Setup Gmail API service"""
        if not GMAIL_AVAILABLE:
            logger.error("Gmail API not available")
            return False
            
        try:
            # Look for token file
            token_paths = [
                "scripts/setup/token.json",
                "token.json",
                os.path.expanduser("~/.config/editorial_scripts/gmail_token.json")
            ]
            
            token_path = None
            for path in token_paths:
                if os.path.exists(path):
                    token_path = path
                    break
                    
            if not token_path:
                logger.error("Gmail token not found. Run setup_gmail_api.py first.")
                return False
                
            # Load credentials
            creds = Credentials.from_authorized_user_file(token_path)
            self.gmail_service = build('gmail', 'v1', credentials=creds)
            
            logger.info("✅ Gmail service initialized")
            return True
            
        except Exception as e:
            logger.error(f"Failed to setup Gmail service: {e}")
            return False
    
    def crosscheck_manuscript_referees(self, manuscript: Dict) -> Dict:
        """
        Crosscheck manuscript referee data with Gmail exchanges
        
        Args:
            manuscript: Manuscript data from SICON extraction
            
        Returns:
            Enhanced manuscript data with complete email timeline
        """
        if not self.gmail_service:
            logger.warning("Gmail service not available")
            return manuscript
            
        manuscript_id = manuscript.get('id', '')
        logger.info(f"📧 Crosschecking emails for manuscript {manuscript_id}")
        
        # Get all referee emails for this manuscript
        referee_emails = self.fetch_manuscript_emails(manuscript_id)
        
        # Enhance referee data with email timeline
        enhanced_referees = self.enhance_referees_with_emails(
            manuscript, referee_emails
        )
        
        # Create enhanced manuscript data
        enhanced_manuscript = manuscript.copy()
        enhanced_manuscript['email_crosscheck'] = {
            'total_emails_found': len(referee_emails),
            'crosscheck_date': datetime.now().isoformat(),
            'enhanced_referees': enhanced_referees,
            'timeline_reconstruction': self.reconstruct_timeline(referee_emails)
        }
        
        return enhanced_manuscript
    
    def fetch_manuscript_emails(self, manuscript_id: str, days_back: int = 365) -> List[Dict]:
        """
        Fetch all emails related to a specific manuscript
        
        Args:
            manuscript_id: Manuscript ID (e.g., "M172838")
            days_back: How many days back to search
            
        Returns:
            List of relevant emails
        """
        if not self.gmail_service:
            return []
            
        try:
            # Build comprehensive search queries
            queries = [
                f'subject:{manuscript_id}',
                f'subject:SICON {manuscript_id}',
                f'subject:"SIAM Journal" {manuscript_id}',
                f'body:{manuscript_id}',
                f'(subject:referee OR subject:reviewer) {manuscript_id}',
                f'(subject:invitation OR subject:reminder) {manuscript_id}',
                f'(subject:accepted OR subject:declined) {manuscript_id}',
                f'(subject:overdue OR subject:late) {manuscript_id}',
            ]
            
            all_emails = []
            seen_ids = set()
            
            for query in queries:
                logger.info(f"  Searching: {query}")
                
                try:
                    response = self.gmail_service.users().messages().list(
                        userId='me',
                        q=query,
                        maxResults=100
                    ).execute()
                    
                    messages = response.get('messages', [])
                    logger.info(f"    Found {len(messages)} messages")
                    
                    for msg in messages:
                        if msg['id'] in seen_ids:
                            continue
                            
                        try:
                            full_msg = self.gmail_service.users().messages().get(
                                userId='me',
                                id=msg['id'],
                                format='full'
                            ).execute()
                            
                            email_data = self.parse_email_message(full_msg)
                            if email_data and self.is_manuscript_relevant(email_data, manuscript_id):
                                all_emails.append(email_data)
                                seen_ids.add(msg['id'])
                                
                        except Exception as e:
                            logger.warning(f"Error fetching message {msg['id']}: {e}")
                            
                except Exception as e:
                    logger.error(f"Error with query '{query}': {e}")
                    
            # Sort emails by date
            all_emails.sort(key=lambda x: x.get('date', ''), reverse=True)
            
            logger.info(f"📧 Found {len(all_emails)} relevant emails for {manuscript_id}")
            return all_emails
            
        except Exception as e:
            logger.error(f"Error fetching emails for {manuscript_id}: {e}")
            return []
    
    def parse_email_message(self, message: Dict) -> Optional[Dict]:
        """Parse Gmail message into structured format"""
        try:
            headers = {}
            payload = message.get('payload', {})
            
            # Extract headers
            for header in payload.get('headers', []):
                name = header.get('name', '').lower()
                if name in ['subject', 'from', 'to', 'date', 'cc', 'bcc']:
                    headers[name] = header.get('value', '')
            
            # Extract body
            body = self.extract_email_body(payload)
            
            # Parse date
            date_str = headers.get('date', '')
            parsed_date = self.parse_email_date(date_str)
            
            return {
                'id': message.get('id'),
                'thread_id': message.get('threadId'),
                'subject': headers.get('subject', ''),
                'from': headers.get('from', ''),
                'to': headers.get('to', ''),
                'cc': headers.get('cc', ''),
                'date': parsed_date,
                'body': body,
                'raw_date': date_str
            }
            
        except Exception as e:
            logger.warning(f"Error parsing email: {e}")
            return None
    
    def extract_email_body(self, payload: Dict) -> str:
        """Extract body text from email payload"""
        body = ''
        
        if 'parts' in payload:
            for part in payload['parts']:
                if part.get('mimeType') == 'text/plain':
                    data = part.get('body', {}).get('data', '')
                    if data:
                        import base64
                        try:
                            body = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                            break
                        except:
                            pass
        else:
            data = payload.get('body', {}).get('data', '')
            if data:
                import base64
                try:
                    body = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                except:
                    pass
        
        return body
    
    def parse_email_date(self, date_str: str) -> str:
        """Parse email date to ISO format"""
        if not date_str:
            return ''
            
        try:
            # Try to parse various date formats
            from email.utils import parsedate_to_datetime
            dt = parsedate_to_datetime(date_str)
            return dt.isoformat()
        except:
            return date_str
    
    def is_manuscript_relevant(self, email: Dict, manuscript_id: str) -> bool:
        """Check if email is relevant to manuscript"""
        subject = email.get('subject', '').lower()
        body = email.get('body', '').lower()
        
        # Must contain manuscript ID
        if manuscript_id.lower() not in subject and manuscript_id.lower() not in body:
            return False
            
        # Must be SICON/SIAM related
        sicon_indicators = ['sicon', 'siam', 'control', 'optimization', 'referee', 'reviewer']
        return any(indicator in subject or indicator in body for indicator in sicon_indicators)
    
    def enhance_referees_with_emails(self, manuscript: Dict, emails: List[Dict]) -> List[Dict]:
        """
        Enhance referee data with email exchanges
        
        Args:
            manuscript: Original manuscript data
            emails: List of relevant emails
            
        Returns:
            List of enhanced referee records
        """
        enhanced_referees = []
        
        # Get all referees
        all_referees = (
            manuscript.get('declined_referees', []) + 
            manuscript.get('accepted_referees', [])
        )
        
        for referee in all_referees:
            enhanced_ref = referee.copy()
            
            # Find emails for this referee
            referee_emails = self.find_referee_emails(referee, emails)
            
            # Analyze email timeline
            timeline = self.analyze_referee_timeline(referee_emails)
            
            # Add timeline data
            enhanced_ref['email_timeline'] = timeline
            enhanced_ref['email_count'] = len(referee_emails)
            
            # Add calculated metrics
            if timeline['invitation_date'] and timeline['response_date']:
                enhanced_ref['response_time_days'] = self.calculate_days_between(
                    timeline['invitation_date'], timeline['response_date']
                )
            
            enhanced_referees.append(enhanced_ref)
        
        return enhanced_referees
    
    def find_referee_emails(self, referee: Dict, emails: List[Dict]) -> List[Dict]:
        """Find emails related to specific referee"""
        referee_name = referee.get('name', '').lower()
        referee_email = referee.get('email', '').lower()
        
        referee_emails = []
        
        for email in emails:
            # Check if email involves this referee
            if self.email_involves_referee(email, referee_name, referee_email):
                referee_emails.append(email)
        
        return referee_emails
    
    def email_involves_referee(self, email: Dict, referee_name: str, referee_email: str) -> bool:
        """Check if email involves specific referee"""
        to_field = email.get('to', '').lower()
        from_field = email.get('from', '').lower()
        cc_field = email.get('cc', '').lower()
        body = email.get('body', '').lower()
        
        # Check email address
        if referee_email and (
            referee_email in to_field or 
            referee_email in from_field or 
            referee_email in cc_field
        ):
            return True
        
        # Check name (be careful with partial matches)
        if referee_name and len(referee_name) > 5:
            name_parts = referee_name.split()
            if len(name_parts) >= 2:
                # Check for last name + first name
                last_name = name_parts[-1]
                first_name = name_parts[0]
                
                if (last_name in to_field or last_name in from_field or 
                    last_name in cc_field or last_name in body):
                    return True
        
        return False
    
    def analyze_referee_timeline(self, referee_emails: List[Dict]) -> Dict:
        """Analyze referee email timeline"""
        timeline = {
            'invitation_date': None,
            'response_date': None,
            'reminder_dates': [],
            'overdue_mentions': [],
            'email_types': []
        }
        
        for email in referee_emails:
            subject = email.get('subject', '').lower()
            body = email.get('body', '').lower()
            date = email.get('date', '')
            
            # Categorize email type
            email_type = self.categorize_email_type(subject, body)
            timeline['email_types'].append({
                'date': date,
                'type': email_type,
                'subject': email.get('subject', '')
            })
            
            # Extract specific dates
            if email_type == 'invitation':
                if not timeline['invitation_date'] or date < timeline['invitation_date']:
                    timeline['invitation_date'] = date
                    
            elif email_type == 'response':
                if not timeline['response_date'] or date < timeline['response_date']:
                    timeline['response_date'] = date
                    
            elif email_type == 'reminder':
                timeline['reminder_dates'].append(date)
                
            elif email_type == 'overdue':
                timeline['overdue_mentions'].append(date)
        
        # Sort dates
        timeline['reminder_dates'].sort()
        timeline['overdue_mentions'].sort()
        timeline['email_types'].sort(key=lambda x: x['date'])
        
        return timeline
    
    def categorize_email_type(self, subject: str, body: str) -> str:
        """Categorize email type based on content"""
        text = f"{subject} {body}".lower()
        
        if any(word in text for word in ['invitation', 'invite', 'request to review']):
            return 'invitation'
        elif any(word in text for word in ['accepted', 'agreed', 'willing to review']):
            return 'acceptance'
        elif any(word in text for word in ['declined', 'unable', 'cannot review']):
            return 'decline'
        elif any(word in text for word in ['reminder', 'follow-up', 'pending']):
            return 'reminder'
        elif any(word in text for word in ['overdue', 'late', 'delayed']):
            return 'overdue'
        elif any(word in text for word in ['report', 'review submitted']):
            return 'report_submission'
        else:
            return 'other'
    
    def reconstruct_timeline(self, emails: List[Dict]) -> Dict:
        """Reconstruct complete manuscript timeline from emails"""
        timeline = {
            'manuscript_timeline': [],
            'referee_interactions': {},
            'editorial_actions': []
        }
        
        for email in emails:
            date = email.get('date', '')
            subject = email.get('subject', '')
            email_type = self.categorize_email_type(subject, email.get('body', ''))
            
            timeline['manuscript_timeline'].append({
                'date': date,
                'type': email_type,
                'subject': subject,
                'from': email.get('from', ''),
                'to': email.get('to', '')
            })
        
        # Sort by date
        timeline['manuscript_timeline'].sort(key=lambda x: x['date'])
        
        return timeline
    
    def calculate_days_between(self, date1: str, date2: str) -> Optional[int]:
        """Calculate days between two dates"""
        try:
            dt1 = datetime.fromisoformat(date1.replace('Z', '+00:00'))
            dt2 = datetime.fromisoformat(date2.replace('Z', '+00:00'))
            return abs((dt2 - dt1).days)
        except:
            return None


def crosscheck_sicon_with_emails(input_file: str, output_file: str = None):
    """
    Crosscheck SICON extraction with Gmail emails
    
    Args:
        input_file: Path to SICON extraction JSON
        output_file: Path for enhanced output
    """
    crosschecker = SICONEmailCrosschecker()
    
    if not crosschecker.setup_gmail_service():
        print("❌ Gmail service not available. Cannot perform crosscheck.")
        return
    
    # Load manuscripts
    with open(input_file, 'r') as f:
        manuscripts = json.load(f)
    
    enhanced_manuscripts = []
    
    for i, manuscript in enumerate(manuscripts, 1):
        print(f"📧 Crosschecking manuscript {i}/{len(manuscripts)}: {manuscript.get('id', 'Unknown')}")
        
        # Crosscheck with emails
        enhanced = crosschecker.crosscheck_manuscript_referees(manuscript)
        enhanced_manuscripts.append(enhanced)
        
        # Rate limiting
        time.sleep(2)
    
    # Save enhanced data
    if not output_file:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"sicon_email_crosschecked_{timestamp}.json"
    
    with open(output_file, 'w') as f:
        json.dump(enhanced_manuscripts, f, indent=2)
    
    print(f"✅ Email crosschecked data saved to: {output_file}")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Crosscheck SICON data with Gmail")
    parser.add_argument('input_file', help='Input SICON extraction JSON file')
    parser.add_argument('--output', '-o', help='Output enhanced JSON file')
    
    args = parser.parse_args()
    
    crosscheck_sicon_with_emails(args.input_file, args.output)