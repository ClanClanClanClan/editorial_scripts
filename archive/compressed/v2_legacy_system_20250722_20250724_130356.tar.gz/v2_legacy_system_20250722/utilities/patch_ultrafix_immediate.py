#!/usr/bin/env python3
"""
Patch the ScholarOne extractor to force ULTRAFIX processing immediately after first category
"""

import os
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

def patch_for_immediate_ultrafix():
    """Patch the extract method to do ULTRAFIX processing immediately."""
    
    extractor_file = Path("editorial_assistant/extractors/scholarone.py")
    
    if not extractor_file.exists():
        print(f"❌ Extractor file not found: {extractor_file}")
        return
    
    # Read the current file
    with open(extractor_file, 'r') as f:
        content = f.read()
    
    # Find the pattern where manuscripts are extracted from one category
    pattern_to_find = """# Store manuscripts for later extraction
                                                self.found_manuscripts.extend(manuscripts)"""
    
    replacement = """# Store manuscripts for later extraction
                                                self.found_manuscripts.extend(manuscripts)
                                                
                                                # IMMEDIATE ULTRAFIX: Process manuscripts NOW instead of waiting for all categories
                                                if manuscripts and len(self.found_manuscripts) <= len(manuscripts):  # Only do this for the first category
                                                    self.logger.info("🎯 IMMEDIATE ULTRAFIX: Processing manuscripts NOW instead of waiting for all categories")
                                                    processed_count = 0
                                                    for manuscript in manuscripts[:3]:  # Process first 3 manuscripts only
                                                        try:
                                                            self.logger.info(f"🎯 IMMEDIATE ULTRAFIX: About to process {manuscript.manuscript_id}")
                                                            self.logger.info(f"Category URL: {getattr(manuscript, '_category_url', 'MISSING!')}")
                                                            self._process_manuscript(manuscript)
                                                            processed_count += 1
                                                            self.logger.info(f"✅ IMMEDIATE ULTRAFIX: Successfully processed {manuscript.manuscript_id}")
                                                        except Exception as e:
                                                            self.logger.error(f"❌ IMMEDIATE ULTRAFIX: Error processing manuscript {manuscript.manuscript_id}: {e}")
                                                            import traceback
                                                            traceback.print_exc()
                                                            continue
                                                    
                                                    self.logger.info(f"🎉 IMMEDIATE ULTRAFIX COMPLETE: Processed {processed_count}/{min(3, len(manuscripts))} manuscripts")
                                                    
                                                    # Create final result with processed manuscripts
                                                    from editorial_assistant.extractors.base import ExtractionResult
                                                    return ExtractionResult(
                                                        manuscripts=manuscripts,
                                                        total_manuscripts=len(manuscripts),
                                                        processed_manuscripts=len(manuscripts),
                                                        errors=self.errors or []
                                                    )"""
    
    if pattern_to_find not in content:
        print("❌ Pattern not found - cannot apply immediate ULTRAFIX patch")
        return
    
    # Apply the patch
    patched_content = content.replace(pattern_to_find, replacement)
    
    # Create backup first
    backup_file = extractor_file.with_suffix('.py.backup_immediate_ultrafix')
    with open(backup_file, 'w') as f:
        f.write(content)
    print(f"✅ Created backup: {backup_file}")
    
    # Write the patched version
    with open(extractor_file, 'w') as f:
        f.write(patched_content)
    
    print("🎯 IMMEDIATE ULTRAFIX PATCH APPLIED!")
    print("This will:")
    print("  1. Process manuscripts immediately after first category")
    print("  2. Call the ULTRAFIX Take Action clicking")
    print("  3. Return early to avoid infinite category loop")
    print("  4. Test only the first 3 manuscripts")

def restore_backup():
    """Restore from backup."""
    extractor_file = Path("editorial_assistant/extractors/scholarone.py")
    backup_file = extractor_file.with_suffix('.py.backup_immediate_ultrafix')
    
    if backup_file.exists():
        with open(backup_file, 'r') as f:
            content = f.read()
        with open(extractor_file, 'w') as f:
            f.write(content)
        print(f"✅ Restored from backup: {backup_file}")
    else:
        print(f"❌ Backup not found: {backup_file}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "restore":
        restore_backup()
    else:
        patch_for_immediate_ultrafix()