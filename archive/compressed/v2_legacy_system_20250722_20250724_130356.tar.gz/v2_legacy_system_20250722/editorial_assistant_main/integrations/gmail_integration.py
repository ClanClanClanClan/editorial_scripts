#!/usr/bin/env python3
"""
Gmail Timeline Integration - Email data extraction and harmonization

This module provides Gmail integration for extracting timeline events from 
email communications across all journal platforms.

Phase 3: System Integration - Timeline Integration Component
"""

import os
import re
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from ..core.unified_config import get_config_manager
from ..core.platform_extractor import PlatformType
from ..core.exceptions import ConfigurationError, ExtractionError
from .timeline_manager import TimelineEvent, TimelineEventType, TimelineEventSource

# Logging setup
logger = logging.getLogger(__name__)


class EmailAnalysisMode(Enum):
    """Email analysis modes."""
    BASIC = "basic"           # Basic pattern matching
    ADVANCED = "advanced"     # Advanced NLP and context analysis
    MACHINE_LEARNING = "ml"   # ML-based email classification


@dataclass
class EmailTimelineData:
    """Timeline data extracted from email."""
    
    message_id: str
    thread_id: str
    subject: str
    sender: str
    recipient: str
    date: datetime
    
    # Content analysis
    body_text: str
    event_type: Optional[TimelineEventType] = None
    manuscript_id: Optional[str] = None
    referee_email: Optional[str] = None
    
    # Metadata
    confidence_score: float = 0.0
    analysis_notes: str = ""
    raw_headers: Dict[str, str] = None
    
    def __post_init__(self):
        """Initialize default values."""
        if self.raw_headers is None:
            self.raw_headers = {}


class GmailTimelineIntegration:
    """
    Gmail integration for timeline data extraction.
    
    This class handles:
    - Gmail API authentication and service management
    - Email search and filtering for journal communications
    - Timeline event extraction from email content
    - Cross-platform email format harmonization
    - Integration with TimelineManager
    """
    
    def __init__(self):
        """Initialize Gmail integration."""
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Configuration
        config_manager = get_config_manager()
        self.analysis_mode = EmailAnalysisMode(
            config_manager.get_global_setting('gmail_analysis_mode', 'basic')
        )
        self.max_emails_per_search = config_manager.get_global_setting('gmail_max_emails', 200)
        self.days_to_search = config_manager.get_global_setting('gmail_search_days', 365)
        
        # Gmail service
        self._gmail_service = None
        self._credentials_path = None
        self._token_path = None
        
        # Platform-specific email patterns
        self._initialize_email_patterns()
        
        # Analysis components
        self._manuscript_id_extractors = {}
        self._referee_extractors = {}
        
        self.logger.info(f"Gmail integration initialized - Mode: {self.analysis_mode.value}, "
                        f"Max emails: {self.max_emails_per_search}")
    
    def _initialize_email_patterns(self):
        """Initialize platform-specific email patterns."""
        
        # ScholarOne patterns (MF, MOR)
        self._email_patterns = {
            PlatformType.SCHOLARONE: {
                'sender_patterns': [
                    r'manuscriptcentral\.com',
                    r'mc\.manuscriptcentral\.com',
                    r'mafi\.manuscriptcentral\.com',
                    r'mor\.manuscriptcentral\.com'
                ],
                'subject_patterns': [
                    r'manuscript.*submission',
                    r'review.*invitation',
                    r'reviewer.*assignment',
                    r'review.*reminder',
                    r'review.*response',
                    r'decision.*notification'
                ],
                'manuscript_id_patterns': [
                    r'manuscript.*id[:\s]*([A-Z0-9-]+)',
                    r'ms[:\s]*([A-Z0-9-]+)',
                    r'MAFI-[0-9]{2}-[0-9]{4}',
                    r'MOR-[0-9]{2}-[0-9]{4}'
                ],
                'event_indicators': {
                    TimelineEventType.INVITATION_SENT: [
                        r'invitation.*review',
                        r'reviewer.*assignment',
                        r'review.*request'
                    ],
                    TimelineEventType.REMINDER_SENT: [
                        r'reminder.*review',
                        r'overdue.*review',
                        r'follow.*up.*review'
                    ],
                    TimelineEventType.RESPONSE_RECEIVED: [
                        r'accepted.*review',
                        r'declined.*review',
                        r'review.*response'
                    ]
                }
            },
            
            # SIAM patterns (SICON, SIFIN)
            PlatformType.SIAM: {
                'sender_patterns': [
                    r'siam\.org',
                    r'sicon\.siam\.org',
                    r'sifin\.siam\.org'
                ],
                'subject_patterns': [
                    r'SICON.*manuscript',
                    r'SIFIN.*manuscript',
                    r'referee.*request',
                    r'referee.*invitation',
                    r'referee.*reminder'
                ],
                'manuscript_id_patterns': [
                    r'manuscript.*id[:\s]*([MS][0-9]+)',
                    r'M[0-9]{6}',
                    r'S[0-9]{6}'
                ],
                'event_indicators': {
                    TimelineEventType.INVITATION_SENT: [
                        r'invitation.*referee',
                        r'referee.*request',
                        r'review.*invitation'
                    ],
                    TimelineEventType.REMINDER_SENT: [
                        r'reminder.*referee',
                        r'overdue.*referee',
                        r'follow.*up.*referee'
                    ],
                    TimelineEventType.RESPONSE_RECEIVED: [
                        r'accepted.*referee',
                        r'declined.*referee',
                        r'referee.*response'
                    ]
                }
            }
        }
    
    def _get_gmail_service(self):
        """Get authenticated Gmail service."""
        if self._gmail_service is None:
            try:
                # Try to import Gmail utilities
                from core.working_gmail_utils import get_gmail_service
                self._gmail_service = get_gmail_service()
                self.logger.info("Gmail service authenticated successfully")
                
            except ImportError:
                self.logger.error("Gmail utilities not available")
                raise ConfigurationError("Gmail integration dependencies not available")
            except Exception as e:
                self.logger.error(f"Gmail authentication failed: {e}")
                raise ConfigurationError(f"Gmail authentication failed: {e}")
        
        return self._gmail_service
    
    def extract_timeline_events(self, manuscript_id: str, journal_code: str,
                              referee_emails: List[str] = None,
                              platform_type: PlatformType = None) -> List[TimelineEvent]:
        """
        Extract timeline events from Gmail for a specific manuscript.
        
        Args:
            manuscript_id: Manuscript identifier
            journal_code: Journal code (MF, MOR, SICON, SIFIN)
            referee_emails: List of referee emails to filter
            platform_type: Platform type for pattern matching
            
        Returns:
            List of timeline events extracted from emails
        """
        try:
            self.logger.info(f"Extracting Gmail timeline for manuscript {manuscript_id}")
            
            # Get Gmail service
            service = self._get_gmail_service()
            
            # Build search query
            search_query = self._build_search_query(
                manuscript_id, journal_code, referee_emails, platform_type
            )
            
            # Search for relevant emails
            email_data = self._search_emails(service, search_query)
            self.logger.debug(f"Found {len(email_data)} relevant emails")
            
            # Extract timeline events from emails
            timeline_events = []
            for email in email_data:
                events = self._extract_events_from_email(
                    email, manuscript_id, platform_type
                )
                timeline_events.extend(events)
            
            # Sort events by date
            timeline_events.sort(key=lambda e: e.event_date)
            
            self.logger.info(f"Extracted {len(timeline_events)} timeline events from Gmail")
            return timeline_events
            
        except Exception as e:
            self.logger.error(f"Failed to extract Gmail timeline events: {e}")
            return []
    
    def _build_search_query(self, manuscript_id: str, journal_code: str,
                           referee_emails: List[str] = None,
                           platform_type: PlatformType = None) -> str:
        """Build Gmail search query for manuscript-related emails."""
        
        query_parts = []
        
        # Manuscript ID search
        query_parts.append(f'"{manuscript_id}"')
        
        # Journal-specific terms
        if journal_code:
            query_parts.append(f'subject:{journal_code}')
        
        # Platform-specific sender patterns
        if platform_type and platform_type in self._email_patterns:
            sender_patterns = self._email_patterns[platform_type]['sender_patterns']
            sender_query = " OR ".join([f"from:{pattern}" for pattern in sender_patterns])
            query_parts.append(f"({sender_query})")
        
        # Referee email filters
        if referee_emails:
            email_query = " OR ".join([f'"{email}"' for email in referee_emails if email])
            if email_query:
                query_parts.append(f"({email_query})")
        
        # Date range (last N days)
        if self.days_to_search > 0:
            start_date = datetime.now() - timedelta(days=self.days_to_search)
            date_str = start_date.strftime("%Y/%m/%d")
            query_parts.append(f"after:{date_str}")
        
        return " ".join(query_parts)
    
    def _search_emails(self, service, query: str) -> List[EmailTimelineData]:
        """Search Gmail for emails matching the query."""
        try:
            from core.working_gmail_utils import search_messages, get_message_details
            
            # Search for message IDs
            message_ids = search_messages(
                service, query, max_results=self.max_emails_per_search
            )
            
            # Get detailed email data
            emails = []
            for msg_id in message_ids:
                try:
                    details = get_message_details(service, msg_id)
                    if details:
                        email_data = self._parse_email_details(details)
                        if email_data:
                            emails.append(email_data)
                            
                except Exception as e:
                    self.logger.warning(f"Failed to process email {msg_id}: {e}")
                    continue
            
            return emails
            
        except Exception as e:
            self.logger.error(f"Gmail search failed: {e}")
            return []
    
    def _parse_email_details(self, email_details: Dict[str, Any]) -> Optional[EmailTimelineData]:
        """Parse Gmail API email details into EmailTimelineData."""
        try:
            headers = {h['name']: h['value'] for h in email_details.get('payload', {}).get('headers', [])}
            
            # Extract basic information
            message_id = email_details.get('id', '')
            thread_id = email_details.get('threadId', '')
            subject = headers.get('Subject', '')
            sender = headers.get('From', '')
            recipient = headers.get('To', '')
            
            # Parse date
            date_str = headers.get('Date', '')
            try:
                # Parse Gmail date format
                date = datetime.strptime(date_str.split(' (')[0], '%a, %d %b %Y %H:%M:%S %z')
                date = date.replace(tzinfo=None)  # Remove timezone for consistency
            except:
                date = datetime.now()
            
            # Extract email body
            body_text = self._extract_email_body(email_details.get('payload', {}))
            
            email_data = EmailTimelineData(
                message_id=message_id,
                thread_id=thread_id,
                subject=subject,
                sender=sender,
                recipient=recipient,
                date=date,
                body_text=body_text,
                raw_headers=headers
            )
            
            return email_data
            
        except Exception as e:
            self.logger.warning(f"Failed to parse email details: {e}")
            return None
    
    def _extract_email_body(self, payload: Dict[str, Any]) -> str:
        """Extract text body from email payload."""
        try:
            # Handle multipart messages
            if 'parts' in payload:
                for part in payload['parts']:
                    if part.get('mimeType') == 'text/plain':
                        data = part.get('body', {}).get('data', '')
                        if data:
                            import base64
                            return base64.urlsafe_b64decode(data).decode('utf-8')
            
            # Handle single part messages
            elif payload.get('mimeType') == 'text/plain':
                data = payload.get('body', {}).get('data', '')
                if data:
                    import base64
                    return base64.urlsafe_b64decode(data).decode('utf-8')
            
            return ""
            
        except Exception as e:
            self.logger.warning(f"Failed to extract email body: {e}")
            return ""
    
    def _extract_events_from_email(self, email: EmailTimelineData, manuscript_id: str,
                                  platform_type: PlatformType = None) -> List[TimelineEvent]:
        """Extract timeline events from a single email."""
        events = []
        
        try:
            # Verify this email is relevant to the manuscript
            if not self._is_relevant_email(email, manuscript_id, platform_type):
                return []
            
            # Extract manuscript ID from email (for verification)
            extracted_ms_id = self._extract_manuscript_id(email, platform_type)
            if extracted_ms_id and extracted_ms_id != manuscript_id:
                return []
            
            # Determine event type
            event_type = self._determine_event_type(email, platform_type)
            if not event_type:
                return []
            
            # Extract referee email
            referee_email = self._extract_referee_email(email, platform_type)
            
            # Calculate confidence score
            confidence = self._calculate_confidence_score(email, event_type, platform_type)
            
            # Create timeline event
            event = TimelineEvent(
                event_id=f"gmail_{email.message_id}",
                manuscript_id=manuscript_id,
                event_type=event_type,
                event_date=email.date,
                source=TimelineEventSource.GMAIL_EMAIL,
                platform_type=platform_type or PlatformType.SCHOLARONE,
                description=f"Email: {email.subject[:100]}",
                referee_email=referee_email,
                participants=[email.sender, email.recipient],
                confidence_score=confidence,
                raw_data={
                    'email_id': email.message_id,
                    'thread_id': email.thread_id,
                    'subject': email.subject,
                    'sender': email.sender,
                    'analysis_mode': self.analysis_mode.value
                }
            )
            
            events.append(event)
            
        except Exception as e:
            self.logger.warning(f"Failed to extract events from email: {e}")
        
        return events
    
    def _is_relevant_email(self, email: EmailTimelineData, manuscript_id: str,
                          platform_type: PlatformType = None) -> bool:
        """Check if email is relevant to the manuscript."""
        
        # Check if manuscript ID appears in subject or body
        text_to_search = f"{email.subject} {email.body_text}".lower()
        if manuscript_id.lower() in text_to_search:
            return True
        
        # Check platform-specific patterns
        if platform_type and platform_type in self._email_patterns:
            patterns = self._email_patterns[platform_type]
            
            # Check sender patterns
            for pattern in patterns['sender_patterns']:
                if re.search(pattern, email.sender, re.IGNORECASE):
                    return True
            
            # Check subject patterns
            for pattern in patterns['subject_patterns']:
                if re.search(pattern, email.subject, re.IGNORECASE):
                    return True
        
        return False
    
    def _extract_manuscript_id(self, email: EmailTimelineData,
                              platform_type: PlatformType = None) -> Optional[str]:
        """Extract manuscript ID from email content."""
        
        text_to_search = f"{email.subject} {email.body_text}"
        
        # Use platform-specific patterns if available
        if platform_type and platform_type in self._email_patterns:
            patterns = self._email_patterns[platform_type]['manuscript_id_patterns']
        else:
            # Generic patterns
            patterns = [
                r'manuscript.*id[:\s]*([A-Z0-9-]+)',
                r'ms[:\s]*([A-Z0-9-]+)',
                r'M[0-9]{6}',
                r'S[0-9]{6}'
            ]
        
        for pattern in patterns:
            match = re.search(pattern, text_to_search, re.IGNORECASE)
            if match:
                return match.group(1) if match.groups() else match.group(0)
        
        return None
    
    def _determine_event_type(self, email: EmailTimelineData,
                             platform_type: PlatformType = None) -> Optional[TimelineEventType]:
        """Determine the timeline event type from email content."""
        
        text_to_analyze = f"{email.subject} {email.body_text}".lower()
        
        # Use platform-specific indicators if available
        if platform_type and platform_type in self._email_patterns:
            event_indicators = self._email_patterns[platform_type]['event_indicators']
        else:
            # Generic indicators
            event_indicators = {
                TimelineEventType.INVITATION_SENT: [
                    r'invitation.*review', r'reviewer.*assignment', r'review.*request'
                ],
                TimelineEventType.REMINDER_SENT: [
                    r'reminder.*review', r'overdue.*review', r'follow.*up'
                ],
                TimelineEventType.RESPONSE_RECEIVED: [
                    r'accepted.*review', r'declined.*review', r'review.*response'
                ]
            }
        
        # Check each event type
        for event_type, patterns in event_indicators.items():
            for pattern in patterns:
                if re.search(pattern, text_to_analyze):
                    return event_type
        
        return None
    
    def _extract_referee_email(self, email: EmailTimelineData,
                              platform_type: PlatformType = None) -> Optional[str]:
        """Extract referee email from email content."""
        
        # Simple approach: look for email addresses in the content
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        
        # Search in body first
        matches = re.findall(email_pattern, email.body_text)
        for match in matches:
            # Exclude system emails
            if not any(domain in match.lower() for domain in 
                      ['manuscriptcentral.com', 'siam.org', 'noreply', 'donotreply']):
                return match
        
        # If not found in body, check recipient
        recipient_matches = re.findall(email_pattern, email.recipient)
        for match in recipient_matches:
            if not any(domain in match.lower() for domain in 
                      ['manuscriptcentral.com', 'siam.org', 'noreply', 'donotreply']):
                return match
        
        return None
    
    def _calculate_confidence_score(self, email: EmailTimelineData, 
                                   event_type: TimelineEventType,
                                   platform_type: PlatformType = None) -> float:
        """Calculate confidence score for the extracted event."""
        
        confidence = 0.5  # Base confidence
        
        # Boost confidence for known senders
        if platform_type and platform_type in self._email_patterns:
            sender_patterns = self._email_patterns[platform_type]['sender_patterns']
            for pattern in sender_patterns:
                if re.search(pattern, email.sender, re.IGNORECASE):
                    confidence += 0.3
                    break
        
        # Boost confidence for clear subject patterns
        subject_keywords = {
            TimelineEventType.INVITATION_SENT: ['invitation', 'request', 'assign'],
            TimelineEventType.REMINDER_SENT: ['reminder', 'overdue', 'follow'],
            TimelineEventType.RESPONSE_RECEIVED: ['accepted', 'declined', 'response']
        }
        
        if event_type in subject_keywords:
            for keyword in subject_keywords[event_type]:
                if keyword.lower() in email.subject.lower():
                    confidence += 0.1
        
        # Reduce confidence for generic subjects
        if len(email.subject) < 10 or 'fwd:' in email.subject.lower():
            confidence -= 0.2
        
        # Ensure confidence is within bounds
        return max(0.0, min(1.0, confidence))
    
    def get_email_summary(self, manuscript_id: str, journal_code: str) -> Dict[str, Any]:
        """Get summary of email activity for a manuscript."""
        try:
            # Get platform type from journal code
            platform_type = self._get_platform_type_from_journal(journal_code)
            
            # Extract timeline events
            events = self.extract_timeline_events(manuscript_id, journal_code, platform_type=platform_type)
            
            # Generate summary
            summary = {
                'manuscript_id': manuscript_id,
                'journal_code': journal_code,
                'total_emails': len(events),
                'date_range': {
                    'first_email': min(e.event_date for e in events).isoformat() if events else None,
                    'last_email': max(e.event_date for e in events).isoformat() if events else None
                },
                'event_counts': {},
                'confidence_stats': {
                    'avg_confidence': sum(e.confidence_score for e in events) / len(events) if events else 0,
                    'high_confidence_events': sum(1 for e in events if e.confidence_score > 0.8)
                }
            }
            
            # Count events by type
            for event in events:
                event_type = event.event_type.value
                summary['event_counts'][event_type] = summary['event_counts'].get(event_type, 0) + 1
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Failed to generate email summary: {e}")
            return {'error': str(e)}
    
    def _get_platform_type_from_journal(self, journal_code: str) -> PlatformType:
        """Get platform type from journal code."""
        if journal_code in ['MF', 'MOR']:
            return PlatformType.SCHOLARONE
        elif journal_code in ['SICON', 'SIFIN']:
            return PlatformType.SIAM
        else:
            return PlatformType.SCHOLARONE  # Default
    
    def validate_gmail_connection(self) -> Dict[str, Any]:
        """Validate Gmail connection and return status."""
        try:
            service = self._get_gmail_service()
            
            # Test with a simple query
            from core.working_gmail_utils import search_messages
            test_results = search_messages(service, "test", max_results=1)
            
            return {
                'status': 'connected',
                'service_available': True,
                'test_query_successful': True,
                'message': 'Gmail integration is working correctly'
            }
            
        except Exception as e:
            return {
                'status': 'error',
                'service_available': False,
                'test_query_successful': False,
                'error': str(e),
                'message': 'Gmail integration is not working'
            }
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Get performance metrics for Gmail integration."""
        return {
            'analysis_mode': self.analysis_mode.value,
            'max_emails_per_search': self.max_emails_per_search,
            'search_days_range': self.days_to_search,
            'supported_platforms': list(self._email_patterns.keys()),
            'email_patterns_loaded': len(self._email_patterns),
            'service_status': 'initialized' if self._gmail_service else 'not_initialized'
        }