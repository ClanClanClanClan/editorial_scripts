#!/usr/bin/env python3
"""
Show Current SICON Results
Displays the actual extracted data from the SICON system
"""

import json
import os
from datetime import datetime
from pathlib import Path

def load_sicon_data():
    """Load the most recent SICON extraction data"""
    # Look for the most recent extraction file
    data_file = "scripts/sicon/sicon_extraction_20250716_180808.json"
    
    if os.path.exists(data_file):
        with open(data_file, 'r') as f:
            return json.load(f)
    else:
        print(f"❌ Data file not found: {data_file}")
        return None

def show_manuscript_summary(manuscripts):
    """Show summary statistics for manuscripts"""
    print("📊 SICON MANUSCRIPT SUMMARY")
    print("=" * 50)
    print(f"Total manuscripts: {len(manuscripts)}")
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Count by stage
    stages = {}
    for ms in manuscripts:
        stage = ms.get('current_stage', 'Unknown')
        stages[stage] = stages.get(stage, 0) + 1
    
    print("📈 Manuscripts by Stage:")
    for stage, count in stages.items():
        print(f"  {stage}: {count}")
    print()

def show_referee_statistics(manuscripts):
    """Show referee statistics"""
    print("👥 REFEREE STATISTICS")
    print("=" * 30)
    
    total_declined = 0
    total_accepted = 0
    total_reports_received = 0
    total_reports_pending = 0
    
    for ms in manuscripts:
        declined = ms.get('declined_referees', [])
        accepted = ms.get('accepted_referees', [])
        
        total_declined += len(declined)
        total_accepted += len(accepted)
        
        for ref in accepted:
            if ref.get('report_status') == 'submitted':
                total_reports_received += 1
            elif ref.get('report_status') == 'pending':
                total_reports_pending += 1
    
    print(f"Total referees contacted: {total_declined + total_accepted}")
    print(f"  Declined: {total_declined}")
    print(f"  Accepted: {total_accepted}")
    print(f"  Acceptance rate: {(total_accepted/(total_declined + total_accepted)*100):.1f}%")
    print()
    print(f"Reports received: {total_reports_received}")
    print(f"Reports pending: {total_reports_pending}")
    print(f"Report completion rate: {(total_reports_received/(total_accepted)*100):.1f}%")
    print()

def show_detailed_manuscripts(manuscripts):
    """Show detailed information for each manuscript"""
    print("📄 DETAILED MANUSCRIPT INFORMATION")
    print("=" * 40)
    
    for i, ms in enumerate(manuscripts, 1):
        print(f"\n{i}. {ms['title']}")
        print(f"   ID: {ms['id']}")
        print(f"   Submitted: {ms['submission_date']}")
        print(f"   Status: {ms['current_stage']}")
        print(f"   Corresponding Author: {ms['corresponding_author']}")
        
        # Show referee details
        declined = ms.get('declined_referees', [])
        accepted = ms.get('accepted_referees', [])
        
        if declined:
            print(f"\n   📞 Declined Referees ({len(declined)}):")
            for ref in declined:
                print(f"     • {ref['name']} ({ref['email']})")
                print(f"       Last contact: {ref['last_contact_date']}")
        
        if accepted:
            print(f"\n   ✅ Accepted Referees ({len(accepted)}):")
            for ref in accepted:
                print(f"     • {ref['name']} ({ref['email']})")
                status = ref.get('report_status', 'unknown')
                if status == 'submitted':
                    print(f"       Report received: {ref.get('report_received_date', 'N/A')}")
                elif status == 'pending':
                    print(f"       Report due: {ref.get('report_due_date', 'N/A')}")
                    # Calculate days overdue if applicable
                    if ref.get('report_due_date'):
                        try:
                            due_date = datetime.strptime(ref['report_due_date'], '%Y-%m-%d')
                            days_diff = (datetime.now() - due_date).days
                            if days_diff > 0:
                                print(f"       ({days_diff} days overdue)")
                            elif days_diff < 0:
                                print(f"       ({abs(days_diff)} days remaining)")
                        except:
                            pass
        
        # Show keywords
        keywords = ms.get('keywords', 'N/A')
        if keywords and keywords != 'N/A':
            print(f"\n   🔍 Keywords: {keywords}")
        
        print("-" * 60)

def show_email_attribution_stats(manuscripts):
    """Show email attribution statistics"""
    print("\n📧 EMAIL ATTRIBUTION STATISTICS")
    print("=" * 35)
    
    total_referees = 0
    referees_with_email = 0
    
    for ms in manuscripts:
        declined = ms.get('declined_referees', [])
        accepted = ms.get('accepted_referees', [])
        
        all_referees = declined + accepted
        total_referees += len(all_referees)
        
        for ref in all_referees:
            if ref.get('email'):
                referees_with_email += 1
    
    print(f"Total referees: {total_referees}")
    print(f"Referees with email: {referees_with_email}")
    print(f"Email attribution rate: {(referees_with_email/total_referees*100):.1f}%")
    print()

def main():
    """Main function to display SICON results"""
    
    print("🎯 SICON CURRENT RESULTS")
    print("=" * 25)
    print(f"Data extraction date: 2025-07-16 18:08:08")
    print()
    
    # Load data
    manuscripts = load_sicon_data()
    if not manuscripts:
        return
    
    # Show summaries
    show_manuscript_summary(manuscripts)
    show_referee_statistics(manuscripts)
    show_email_attribution_stats(manuscripts)
    show_detailed_manuscripts(manuscripts)
    
    print("\n✅ SICON RESULTS COMPLETE")
    print("=" * 25)

if __name__ == "__main__":
    main()