#!/usr/bin/env python3
"""
Get detailed info for just ONE manuscript by clicking Take Action
"""

import os
import sys
import time
import logging
import re
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from editorial_assistant.core.browser_manager import BrowserManager
from core.email_utils import fetch_latest_verification_code
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_one_manuscript_details():
    """Get detailed info for one manuscript by going to its details page."""
    print("🎯 Getting DETAILED info for ONE manuscript...")
    
    # Load production config
    try:
        with open('.env.production', 'r') as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    key, value = line.strip().split('=', 1)
                    os.environ[key] = value
    except FileNotFoundError:
        print("❌ No .env.production file found")
        return
    
    try:
        # Create browser
        browser_manager = BrowserManager(headless=False)
        driver = browser_manager.create_driver()
        
        # Navigate and login
        print("🔄 Logging into MF...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        # Accept cookies
        try:
            accept_btn = driver.find_element(By.ID, "onetrust-reject-all-handler")
            if accept_btn.is_displayed():
                accept_btn.click()
                time.sleep(1)
        except:
            pass
        
        # Login
        user = os.environ.get('MF_EMAIL')
        password = os.environ.get('MF_PASSWORD')
        
        user_box = driver.find_element(By.ID, "USERID")
        pw_box = driver.find_element(By.ID, "PASSWORD")
        
        user_box.clear()
        user_box.send_keys(user)
        pw_box.clear()
        pw_box.send_keys(password)
        
        login_btn = driver.find_element(By.ID, "logInButton")
        login_btn.click()
        time.sleep(10)
        
        # Handle 2FA
        if "UNRECOGNIZED_DEVICE" in driver.page_source:
            print("🔐 Handling 2FA...")
            verification_input = driver.find_element(By.ID, "TOKEN_VALUE")
            verification_code = fetch_latest_verification_code(journal="MF", max_wait=60, poll_interval=5)
            
            if verification_code:
                verification_input.clear()
                verification_input.send_keys(verification_code)
                
                verify_links = driver.find_elements(By.XPATH, "//a[text()='Verify']")
                if verify_links:
                    verify_links[0].click()
                else:
                    verification_input.send_keys("\n")
                
                time.sleep(10)
        
        # Navigate to AE Center
        print("📍 Going to Associate Editor Center...")
        ae_links = driver.find_elements(By.PARTIAL_LINK_TEXT, "Associate Editor")
        if ae_links:
            ae_link = ae_links[0]
            href = ae_link.get_attribute('href')
            if href and 'javascript:' in href:
                js_code = href.replace('javascript:', '')
                driver.execute_script(js_code)
                time.sleep(5)
            else:
                ae_link.click()
                time.sleep(5)
        
        # Find and click on a manuscript category
        print("📋 Looking for manuscripts...")
        awaiting_links = driver.find_elements(By.PARTIAL_LINK_TEXT, "Awaiting Reviewer Scores")
        if awaiting_links:
            awaiting_links[0].click()
            time.sleep(5)
        
        # Find the first Take Action link and click it
        print("🔍 Looking for Take Action...")
        take_action_found = False
        
        # Look for Take Action images or links
        take_action_elements = driver.find_elements(By.XPATH, "//a[.//img[contains(@src, 'check_off.gif')]]")
        if not take_action_elements:
            take_action_elements = driver.find_elements(By.XPATH, "//a[contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
        
        if take_action_elements:
            print("🎯 Clicking Take Action for first manuscript...")
            link = take_action_elements[0]
            href = link.get_attribute('href')
            
            if href and 'javascript:' in href:
                js_code = href.replace('javascript:', '')
                driver.execute_script(js_code)
            else:
                driver.execute_script("arguments[0].click();", link)
            
            time.sleep(10)
            take_action_found = True
        
        if not take_action_found:
            print("❌ Could not find Take Action link")
            input("Press Enter to continue manually...")
        
        # Now we should be on the manuscript details page
        print("📄 Extracting manuscript details from details page...")
        
        page_source = driver.page_source
        
        # Extract manuscript ID
        manuscript_id = ""
        id_match = re.search(r'<b>(MAFI-\d{4}-\d{4})</b>', page_source)
        if id_match:
            manuscript_id = id_match.group(1)
        
        # Extract title
        title = ""
        title_patterns = [
            r'<td[^>]*colspan="2"[^>]*><p class="pagecontents">([^<]+?)</p></td>',
            r'<p class="pagecontents"><b>' + re.escape(manuscript_id) + r'</b>[^<]*</p></td>\s*<td[^>]*>\s*<p[^>]*>[^<]*</p>\s*<p[^>]*>[^<]*</p>\s*<p[^>]*>[^<]*</p>\s*</td>\s*</tr>\s*<tr[^>]*>\s*<td[^>]*><img[^>]*></td>\s*<td[^>]*colspan="2"[^>]*><p class="pagecontents">([^<]+)</p>'
        ]
        
        for pattern in title_patterns:
            matches = re.findall(pattern, page_source, re.DOTALL)
            for match in matches:
                if len(match) > 20 and 'Original Article' not in match and 'Wiley' not in match:
                    title = match.strip()
                    break
            if title:
                break
        
        # Extract authors
        authors = []
        author_pattern = r'<a href="\s*javascript:popWindow\([^>]*mailpopup[^>]*\);\s*"[^>]*>([^<]+)</a>'
        author_matches = re.findall(author_pattern, page_source)
        
        for author in author_matches:
            author_name = author.strip()
            if (len(author_name) > 3 and 
                ', ' in author_name and 
                'Possamai, Dylan' not in author_name and 
                'Cont, Rama' not in author_name):
                authors.append(author_name)
        
        # Extract dates
        submission_date = ""
        last_updated = ""
        due_date = ""
        
        dates_match = re.search(r'Submitted:\s*(\d{2}-\w{3}-\d{4});.*?Last Updated:\s*(\d{2}-\w{3}-\d{4});', page_source)
        if dates_match:
            submission_date = dates_match.group(1)
            last_updated = dates_match.group(2)
        
        due_match = re.search(r'\(Due ([^)]+)\)', page_source)
        if due_match:
            due_date = due_match.group(1)
        
        # Check for documents
        has_pdf = 'PDF Proof' in page_source and 'fa-file-pdf-o' in page_source
        has_cover_letter = 'Cover Letter' in page_source and 'cover_letter_popup' in page_source
        has_abstract = 'Abstract' in page_source and 'ms_preview' in page_source
        
        # Extract reviewer stats
        stats_match = re.search(r'(\d+)\s+active selections;\s*(\d+)\s+invited;\s*(\d+)\s+agreed;\s*(\d+)\s+declined;\s*(\d+)\s+returned', page_source)
        reviewer_stats = {}
        if stats_match:
            reviewer_stats = {
                'active_selections': int(stats_match.group(1)),
                'invited': int(stats_match.group(2)),
                'agreed': int(stats_match.group(3)),
                'declined': int(stats_match.group(4)),
                'returned': int(stats_match.group(5))
            }
        
        # Display the actual data
        print("\n" + "="*80)
        print("🎯 ACTUAL MANUSCRIPT DETAILS")
        print("="*80)
        
        print(f"ID: {manuscript_id}")
        print(f"TITLE: {title}")
        print(f"SUBMITTED: {submission_date}")
        print(f"LAST UPDATED: {last_updated}")
        print(f"DUE DATE: {due_date}")
        
        print(f"\nAUTHORS ({len(authors)}):")
        for i, author in enumerate(authors, 1):
            print(f"  {i}. {author}")
        
        print(f"\nDOCUMENTS:")
        print(f"  PDF: {'✅ Available' if has_pdf else '❌ Not available'}")
        print(f"  Cover Letter: {'✅ Available' if has_cover_letter else '❌ Not available'}")
        print(f"  Abstract: {'✅ Available' if has_abstract else '❌ Not available'}")
        
        if reviewer_stats:
            print(f"\nREVIEWER STATISTICS:")
            print(f"  Active Selections: {reviewer_stats['active_selections']}")
            print(f"  Invited: {reviewer_stats['invited']}")
            print(f"  Agreed: {reviewer_stats['agreed']}")
            print(f"  Declined: {reviewer_stats['declined']}")
            print(f"  Returned: {reviewer_stats['returned']}")
        
        # Save the page for further analysis
        with open('manuscript_details_page.html', 'w') as f:
            f.write(page_source)
        print(f"\n💾 Full page saved to: manuscript_details_page.html")
        
        print("\n✅ EXTRACTION COMPLETE")
        input("Press Enter to close browser...")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        input("Press Enter to close browser...")
    finally:
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    get_one_manuscript_details()