#!/usr/bin/env python3
"""
Comprehensive file migration plan for Phase 1 refactoring.
This script provides a detailed analysis and safe migration of all root files.
"""

import os
import shutil
from pathlib import Path
from datetime import datetime
from collections import defaultdict

class FileMigrationPlanner:
    """Plan and execute safe file migrations."""
    
    def __init__(self):
        self.project_root = Path(__file__).parent.parent.parent
        self.migrations = []
        self.keep_files = {
            'README.md', 'Makefile', 'pyproject.toml', 'pytest.ini',
            'requirements.txt', 'alembic.ini', '.gitignore', 
            'run_extraction.py', 'load_credentials.sh',
            # Keep the main ultrathink files for now
            'ultrathink_perfect_mf_final.py',
            'ultrathink_perfect_mor_enhanced.py',
        }
        
    def get_destination(self, file_path):
        """Determine destination for a file based on rules."""
        name = file_path.name
        
        # Skip if should keep in root
        if name in self.keep_files:
            return None
            
        # Skip backups
        if 'backup' in name or file_path.suffix in ['.gz', '.tar']:
            return None
            
        # Python debug scripts
        if name.startswith('debug_') and name.endswith('.py'):
            return 'scripts/debug/'
            
        # Test files - categorize by type
        if name.startswith('test_') and name.endswith('.py'):
            # Integration tests for specific systems
            if any(x in name for x in ['mf_', 'mor_', 'sicon_', 'sifin_']):
                return 'tests/integration/'
            elif any(x in name for x in ['take_action', 'referee', 'gmail', 'extraction']):
                return 'tests/integration/'
            else:
                return 'tests/legacy/'
                
        # Utility scripts
        if name.endswith('.py'):
            if name.startswith(('quick_', 'show_', 'get_')):
                return 'scripts/utilities/'
            elif name.startswith(('extract_', 'run_', 'simple_')):
                return 'scripts/utilities/'
            elif name.startswith(('fix_', 'patch_', 'apply_')):
                return 'scripts/utilities/'
            elif name.startswith(('validate_', 'verify_', 'check_')):
                return 'scripts/utilities/'
            elif name.startswith(('analyze_', 'diagnose_')):
                return 'scripts/utilities/'
                
        # HTML files (debug output)
        if name.endswith('.html'):
            return 'data/debug/'
            
        # JSON files
        if name.endswith('.json'):
            # Keep config files in place
            if 'config' in name or name in ['journal_implementation_report_20250717_225553.json']:
                return None
            # Move extraction results
            return 'data/exports/legacy/'
            
        # Markdown documentation
        if name.endswith('.md'):
            # Keep main docs
            if name in ['README.md']:
                return None
            # Categorize others
            if any(x in name.upper() for x in ['SUMMARY', 'PLAN', 'REPORT', 'ANALYSIS', 'STRATEGY']):
                return 'docs/reference/'
                
        # PNG images
        if name.endswith('.png'):
            return 'data/debug/'
            
        # Text files
        if name.endswith('.txt'):
            return 'data/exports/legacy/'
            
        return None
        
    def analyze_files(self):
        """Analyze all files in root directory."""
        files_by_type = defaultdict(list)
        
        # Scan root directory only
        for item in self.project_root.iterdir():
            if item.is_file() and not item.name.startswith('.'):
                destination = self.get_destination(item)
                
                if destination:
                    self.migrations.append({
                        'source': item,
                        'destination': self.project_root / destination / item.name,
                        'category': destination,
                        'size': item.stat().st_size
                    })
                    files_by_type[destination].append(item.name)
                    
        return files_by_type
        
    def display_plan(self):
        """Display the migration plan."""
        print("\n" + "="*80)
        print("COMPREHENSIVE FILE MIGRATION PLAN")
        print("="*80)
        
        # Group by destination
        by_category = defaultdict(list)
        total_size = 0
        
        for m in self.migrations:
            by_category[m['category']].append(m)
            total_size += m['size']
            
        # Display each category
        for category, files in sorted(by_category.items()):
            cat_size = sum(f['size'] for f in files) / 1024 / 1024
            print(f"\n📁 {category} ({len(files)} files, {cat_size:.1f} MB)")
            print("-" * 60)
            
            # Show first 10 files
            for f in sorted(files, key=lambda x: x['source'].name)[:10]:
                print(f"  • {f['source'].name}")
            if len(files) > 10:
                print(f"  ... and {len(files)-10} more files")
                
        print("\n" + "="*80)
        print(f"TOTAL: {len(self.migrations)} files, {total_size/1024/1024:.1f} MB to migrate")
        print("="*80)
        
    def generate_migration_script(self):
        """Generate the migration script."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        script_path = self.project_root / "scripts" / "maintenance" / f"execute_migration_{timestamp}.py"
        
        script_content = f'''#!/usr/bin/env python3
"""
Auto-generated migration script
Generated: {datetime.now().isoformat()}
Total files: {len(self.migrations)}
"""

import shutil
from pathlib import Path

# Project root
PROJECT_ROOT = Path(__file__).parent.parent.parent

# Migrations
MIGRATIONS = [
'''
        
        for m in self.migrations:
            script_content += f'''    {{
        'source': '{m['source'].name}',
        'destination': '{m['destination'].relative_to(self.project_root)}'
    }},
'''
        
        script_content += ''']

def execute_migrations():
    """Execute all migrations."""
    success = 0
    failed = 0
    
    print("Executing migrations...")
    print("-" * 60)
    
    for m in MIGRATIONS:
        src = PROJECT_ROOT / m['source']
        dst = PROJECT_ROOT / m['destination']
        
        try:
            # Create destination directory
            dst.parent.mkdir(parents=True, exist_ok=True)
            
            # Move file
            shutil.move(str(src), str(dst))
            print(f"✅ {m['source']} → {m['destination']}")
            success += 1
        except Exception as e:
            print(f"❌ {m['source']}: {e}")
            failed += 1
            
    print("-" * 60)
    print(f"Complete: {success} moved, {failed} failed")
    
    return failed == 0

if __name__ == "__main__":
    import sys
    success = execute_migrations()
    sys.exit(0 if success else 1)
'''
        
        script_path.write_text(script_content)
        os.chmod(script_path, 0o755)
        
        return script_path
        
    def run(self):
        """Run the complete analysis and planning."""
        print("Analyzing files in project root...")
        print(f"Project: {self.project_root}")
        
        files_by_type = self.analyze_files()
        
        if not self.migrations:
            print("\n✅ No files need to be migrated!")
            return
            
        self.display_plan()
        
        # Generate script
        script_path = self.generate_migration_script()
        
        print(f"\n✅ Migration script generated: {script_path.name}")
        print("\nNext steps:")
        print(f"1. Review the plan above")
        print(f"2. Run: python3 {script_path.relative_to(self.project_root)}")
        print(f"3. Validate: python3 scripts/maintenance/validate_structure.py")
        

if __name__ == "__main__":
    planner = FileMigrationPlanner()
    planner.run()