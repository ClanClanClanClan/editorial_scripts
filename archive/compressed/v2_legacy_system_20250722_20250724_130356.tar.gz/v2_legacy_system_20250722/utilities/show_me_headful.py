#!/usr/bin/env python3
"""Show Take Action in headful mode so you can see what's actually happening"""

import os
import sys
import time
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from dotenv import load_dotenv

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

from core.email_utils import fetch_latest_verification_code

def show_headful():
    """Show in headful mode with pauses so you can see everything"""
    
    print("🎯 HEADFUL MODE - YOU CAN SEE EVERYTHING")
    print("=" * 60)
    
    # Chrome setup - VISIBLE and maximized
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--start-maximized')
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        print("1. Navigating to MF...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(5)
        
        print("2. Handling cookies...")
        try:
            reject_btn = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.ID, "onetrust-reject-all-handler"))
            )
            reject_btn.click()
            time.sleep(2)
        except:
            print("   No cookies")
        
        print("3. Logging in...")
        email_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "USERID"))
        )
        email_field.send_keys(os.getenv('MF_EMAIL'))
        
        password_field = driver.find_element(By.ID, "PASSWORD")
        password_field.send_keys(os.getenv('MF_PASSWORD'))
        
        login_btn = driver.find_element(By.ID, "logInButton")
        login_btn.click()
        time.sleep(5)
        
        print("4. Handling 2FA...")
        try:
            code_input = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.ID, "TOKEN_VALUE"))
            )
            print("   Getting 2FA code...")
            time.sleep(3)
            code = fetch_latest_verification_code('MF', max_wait=60, poll_interval=3)
            if code:
                print(f"   Got code: {code}")
                code_input.send_keys(code)
                verify_btn = driver.find_element(By.ID, "VERIFY_BTN")
                verify_btn.click()
                time.sleep(10)
        except:
            print("   No 2FA needed")
        
        print("5. Looking for Associate Editor Center...")
        time.sleep(5)
        
        try:
            ae_link = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.LINK_TEXT, "Associate Editor Center"))
            )
            print("   Found AE Center - clicking...")
            ae_link.click()
            time.sleep(5)
        except:
            print("   ❌ Could not find AE Center")
            print("   Current page title:", driver.title)
            print("   Page contains 'Associate':", "Associate" in driver.page_source)
            time.sleep(10)  # Let you see the page
            return
        
        print("6. Looking for manuscript category...")
        try:
            category_link = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.LINK_TEXT, "Awaiting Reviewer Scores"))
            )
            print("   Found category - clicking...")
            category_link.click()
            time.sleep(8)
        except:
            print("   ❌ Could not find category")
            time.sleep(10)
            return
        
        print("7. Analyzing manuscript table...")
        print("   YOU CAN NOW SEE THE MANUSCRIPT TABLE")
        
        # Find Take Action links
        check_off_links = driver.find_elements(By.XPATH, "//a[.//img[contains(@src, 'check_off.gif')]]")
        print(f"   Found {len(check_off_links)} Take Action links")
        
        if check_off_links:
            first_link = check_off_links[0]
            href = first_link.get_attribute('href')
            
            # Find manuscript ID
            parent_row = first_link.find_element(By.XPATH, "./ancestor::tr")
            row_text = parent_row.text
            
            import re
            ms_id_match = re.search(r'MAFI-\d{4}-\d{4}', row_text)
            ms_id = ms_id_match.group(0) if ms_id_match else "Unknown"
            
            print(f"\n8. ABOUT TO CLICK TAKE ACTION FOR {ms_id}")
            print("   WATCH THE BROWSER - IT WILL NAVIGATE TO REFEREE PAGE")
            print("   Press ENTER to click Take Action...")
            time.sleep(3)  # Give you time to see
            
            # Click Take Action
            old_url = driver.current_url
            print(f"   Current URL: {old_url}")
            
            if href and 'javascript:' in href:
                js_code = href.replace('javascript:', '')
                print(f"   Executing JavaScript...")
                driver.execute_script(js_code)
            else:
                first_link.click()
            
            time.sleep(8)  # Give time for navigation
            new_url = driver.current_url
            
            print(f"\n9. NAVIGATION RESULTS:")
            print(f"   Old URL: {old_url}")
            print(f"   New URL: {new_url}")
            print(f"   Navigation: {'SUCCESS' if old_url != new_url else 'FAILED'}")
            
            # Check page
            page_text = driver.find_element(By.TAG_NAME, "body").text
            print(f"   Page contains 'Referee': {'Referee' in page_text}")
            print(f"   Page contains 'Reviewer': {'Reviewer' in page_text}")
            
            if 'Referee' in page_text or 'Reviewer' in page_text:
                print(f"\n✅ SUCCESS! ON REFEREE PAGE!")
                
                # Count emails more carefully
                email_count = page_text.count('@')
                print(f"   Raw @ count: {email_count}")
                
                # Find actual referee table
                tables = driver.find_elements(By.TAG_NAME, "table")
                referee_count = 0
                for table in tables:
                    table_text = table.text
                    if 'Reviewer' in table_text or 'Referee' in table_text:
                        referee_count += table_text.count('@')
                        print(f"   Found referee table with {table_text.count('@')} emails")
                        
                print(f"\n   ACTUAL REFEREE COUNT: {referee_count}")
            else:
                print(f"\n❌ NOT ON REFEREE PAGE")
                print(f"   Page title: {driver.title}")
        
        print(f"\n🔍 BROWSER WILL STAY OPEN FOR 60 SECONDS")
        print(f"   Look at the page and see what's actually there")
        time.sleep(60)
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        time.sleep(30)
    
    finally:
        driver.quit()

if __name__ == "__main__":
    show_headful()