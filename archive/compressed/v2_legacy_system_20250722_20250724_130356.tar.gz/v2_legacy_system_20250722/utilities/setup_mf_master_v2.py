#!/usr/bin/env python3
"""
SETUP SCRIPT FOR MF MASTER SYSTEM V2
====================================

Installs dependencies, sets up directories, and validates the system.
"""

import os
import sys
import subprocess
from pathlib import Path
import json

def run_command(command, description=""):
    """Run shell command with error handling"""
    print(f"⏳ {description}...")
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, check=True)
        print(f"   ✅ {description} completed")
        return True
    except subprocess.CalledProcessError as e:
        print(f"   ❌ {description} failed: {e.stderr}")
        return False

def check_python_version():
    """Check Python version compatibility"""
    print("🐍 Checking Python version...")
    
    if sys.version_info < (3, 7):
        print("   ❌ Python 3.7 or higher is required")
        return False
    
    print(f"   ✅ Python {sys.version_info.major}.{sys.version_info.minor} is compatible")
    return True

def install_dependencies():
    """Install required Python packages"""
    print("\n📦 Installing dependencies...")
    
    # Check if pip is available
    if not run_command("pip --version", "Checking pip availability"):
        print("   ❌ pip is not available. Please install pip first.")
        return False
    
    # Install requirements
    requirements_file = "requirements_mf_master_v2.txt"
    if not Path(requirements_file).exists():
        print(f"   ❌ Requirements file {requirements_file} not found")
        return False
    
    return run_command(f"pip install -r {requirements_file}", "Installing Python packages")

def create_directory_structure():
    """Create required directory structure"""
    print("\n📁 Creating directory structure...")
    
    directories = [
        "config",
        "cache", 
        "logs",
        "analytics",
        "master_outputs_v2",
        "archive"
    ]
    
    for directory in directories:
        dir_path = Path(directory)
        try:
            dir_path.mkdir(exist_ok=True)
            print(f"   ✅ Created/verified directory: {directory}")
        except Exception as e:
            print(f"   ❌ Failed to create directory {directory}: {e}")
            return False
    
    return True

def create_default_configuration():
    """Create default configuration file"""
    print("\n⚙️  Creating default configuration...")
    
    config_file = Path("config/mf_master_config.json")
    
    if config_file.exists():
        print("   ℹ️  Configuration file already exists, skipping")
        return True
    
    default_config = {
        "database": {
            "path": "analytics/referee_analytics.db",
            "backup_enabled": True,
            "backup_interval_hours": 24
        },
        "cache": {
            "directory": "cache",
            "max_age_hours": 24,
            "max_size_mb": 100
        },
        "gmail": {
            "rate_limit_per_minute": 250,
            "batch_size": 10,
            "timeout_seconds": 30
        },
        "extraction": {
            "selenium_timeout": 30,
            "retry_attempts": 3,
            "delay_between_requests": 2
        },
        "logging": {
            "level": "INFO",
            "max_file_size_mb": 10,
            "backup_count": 5
        }
    }
    
    try:
        with open(config_file, 'w') as f:
            json.dump(default_config, f, indent=2)
        print(f"   ✅ Created default configuration: {config_file}")
        return True
    except Exception as e:
        print(f"   ❌ Failed to create configuration: {e}")
        return False

def setup_credentials():
    """Guide user through credential setup"""
    print("\n🔐 Setting up credentials...")
    print("   ℹ️  Credentials will be stored securely using the system keychain")
    
    try:
        import keyring
        
        # Check if credentials already exist
        existing_email = keyring.get_password("mf_master_system", "MF_EMAIL")
        existing_password = keyring.get_password("mf_master_system", "MF_PASSWORD")
        
        if existing_email and existing_password:
            print("   ℹ️  Credentials already configured")
            overwrite = input("   Do you want to update credentials? (y/N): ").lower().strip()
            if overwrite != 'y':
                return True
        
        # Get credentials from user
        print("\n   Please enter your MF platform credentials:")
        email = input("   Email: ").strip()
        
        if not email:
            print("   ❌ Email is required")
            return False
        
        import getpass
        password = getpass.getpass("   Password: ")
        
        if not password:
            print("   ❌ Password is required")
            return False
        
        # Store credentials securely
        keyring.set_password("mf_master_system", "MF_EMAIL", email)
        keyring.set_password("mf_master_system", "MF_PASSWORD", password)
        
        print("   ✅ Credentials stored securely")
        return True
        
    except ImportError:
        print("   ❌ keyring module not available. Install dependencies first.")
        return False
    except Exception as e:
        print(f"   ❌ Failed to setup credentials: {e}")
        return False

def validate_installation():
    """Validate the installation"""
    print("\n🧪 Validating installation...")
    
    # Test imports
    try:
        from mf_master_system_v2 import MFMasterSystemV2
        print("   ✅ MF Master System V2 imports successfully")
    except ImportError as e:
        print(f"   ❌ Failed to import MF Master System V2: {e}")
        return False
    
    # Test system initialization
    try:
        system = MFMasterSystemV2()
        health_status = system.run_health_check()
        
        if health_status['overall_status'] in ['healthy', 'warning']:
            print("   ✅ System health check passed")
        else:
            print("   ⚠️  System health check has issues (may require credentials)")
            print(f"      Status: {health_status['overall_status']}")
        
        return True
        
    except Exception as e:
        print(f"   ❌ System validation failed: {e}")
        return False

def run_tests():
    """Run the test suite"""
    print("\n🧪 Running test suite...")
    
    test_file = Path("test_mf_master_v2.py")
    if not test_file.exists():
        print("   ❌ Test file not found, skipping tests")
        return True
    
    return run_command("python3 test_mf_master_v2.py", "Running comprehensive tests")

def main():
    """Main setup process"""
    print("🚀 MF MASTER SYSTEM V2 - SETUP & INSTALLATION")
    print("=" * 60)
    
    steps = [
        ("Python Version Check", check_python_version),
        ("Dependency Installation", install_dependencies),
        ("Directory Structure", create_directory_structure),
        ("Default Configuration", create_default_configuration),
        ("Credential Setup", setup_credentials),
        ("Installation Validation", validate_installation),
        ("Test Suite", run_tests)
    ]
    
    success_count = 0
    
    for step_name, step_func in steps:
        print(f"\n{'='*20} {step_name} {'='*20}")
        
        if step_func():
            success_count += 1
        else:
            print(f"❌ Setup failed at: {step_name}")
            break
    
    print(f"\n{'='*60}")
    print(f"📊 SETUP SUMMARY")
    print(f"{'='*60}")
    print(f"Completed steps: {success_count}/{len(steps)}")
    
    if success_count == len(steps):
        print("✅ SETUP COMPLETE!")
        print("\nYou can now run the MF Master System V2:")
        print("  python3 mf_master_system_v2.py --health-check")
        print("  python3 mf_master_system_v2.py --force-refresh")
        return True
    else:
        print("❌ SETUP INCOMPLETE!")
        print("Please resolve the issues above and run setup again.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)