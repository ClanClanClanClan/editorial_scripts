#!/usr/bin/env python3
"""Backup Script for Editorial Scripts"""

import shutil
import json
from datetime import datetime
from pathlib import Path

def backup_system():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = Path("backups") / timestamp
    backup_dir.mkdir(parents=True)
    
    # Backup configuration
    if Path("config").exists():
        shutil.copytree("config", backup_dir / "config", dirs_exist_ok=True)
    
    # Backup data
    if Path("data").exists():
        shutil.copytree("data", backup_dir / "data", dirs_exist_ok=True)
    
    # Backup logs
    if Path("production_logs").exists():
        shutil.copytree("production_logs", backup_dir / "logs", dirs_exist_ok=True)
    
    # Create manifest
    manifest = {
        "timestamp": timestamp,
        "created_at": datetime.now().isoformat(),
        "environment": "production",
        "files_backed_up": list(backup_dir.rglob("*"))
    }
    
    with open(backup_dir / "manifest.json", 'w') as f:
        json.dump(manifest, f, indent=2, default=str)
    
    print(f"✅ Backup created at {backup_dir}")
    return backup_dir

if __name__ == "__main__":
    backup_system()
