"""Foundation unit tests."""
