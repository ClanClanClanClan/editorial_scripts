"""SIAM Journal on Control and Optimization (SICON) extractor.

Updated July 16, 2025 to use the exact workflow specified by the user.
Follows the 8-step workflow documented in docs/SICON_EXACT_WORKFLOW_JULY_15_2025.md
"""

from typing import List, Dict, Any, Tuple
import logging
import time
from bs4 import BeautifulSoup
import re
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

from editorial_assistant.core.data_models import JournalConfig
from editorial_assistant.extractors.base_platform_extractors import SIAMExtractor


class SICONExtractor(SIAMExtractor):
    """SIAM Journal on Control and Optimization extractor using ORCID authentication.
    
    Updated to follow the exact 8-step workflow specified by the user:
    1. Initial Navigation
    2. ORCID Button Click
    3. ORCID Authentication
    4. AE Dashboard Navigation
    5. Manuscript ID Extraction
    6. Manuscript Detail Extraction
    7. Referee Profile Details
    8. PDF and Comments Extraction
    """
    
    def __init__(self, journal: JournalConfig):
        super().__init__(journal)
        self.site_prefix = "https://sicon.siam.org/"
        self.manuscripts = []
        self.referees = []
        
    def _login(self) -> None:
        """Login to SICON using ORCID authentication following exact workflow."""
        try:
            # Step 1: Navigate to SICON URL
            self.driver.get(self.journal.url)
            time.sleep(3)
            
            # Handle cookie banners and privacy modals
            self._handle_popups()
            
            # Check if already logged in
            if self._is_logged_in():
                logging.info(f"[{self.journal.code}] Already logged in")
                return
            
            # Step 2: Click ORCID button using exact selectors
            self._click_orcid_button()
            
            # Step 3: ORCID authentication with exact selectors
            self._orcid_authentication()
            
            # Wait for redirect back to SICON
            self._wait_for_url_contains("sicon.siam.org", timeout=30)
            
            # Handle any post-login popups
            self._handle_popups()
            
            logging.info(f"[{self.journal.code}] Successfully logged in")
            
        except Exception as e:
            logging.error(f"[{self.journal.code}] Login failed: {e}")
            raise
    
    def _is_logged_in(self) -> bool:
        """Check if already logged in by looking for AE dashboard elements."""
        try:
            dashboard_indicators = [
                "//tbody[@role='assoc_ed']",
                "//tr[@class='ndt_task']",
                "//a[@class='ndt_task_link']"
            ]
            
            for indicator in dashboard_indicators:
                elements = self.driver.find_elements("xpath", indicator)
                if elements:
                    return True
            
            return False
            
        except Exception:
            return False
    
    def _handle_popups(self) -> None:
        """Handle cookie banners and privacy modals using comprehensive approach."""
        try:
            # JavaScript removal of banners
            js_remove_banners = """
            const selectors = [
                '#cookie-policy-layer-bg',
                '#cookie-policy-layer', 
                '.cc_banner-wrapper',
                '#onetrust-banner-sdk',
                '.onetrust-pc-dark-filter',
                '[id*="cookie"]',
                '[class*="cookie"]',
                '[id*="banner"]',
                '[class*="banner"]'
            ];
            
            selectors.forEach(sel => {
                document.querySelectorAll(sel).forEach(el => {
                    el.style.display = 'none';
                    el.remove();
                });
            });
            
            const buttonTexts = ['Accept', 'Accept All', 'Accept Cookies', 'Got it', 'OK', 'Continue'];
            buttonTexts.forEach(text => {
                document.querySelectorAll('button, input[type="button"]').forEach(btn => {
                    if (btn.innerText && btn.innerText.toLowerCase().includes(text.toLowerCase())) {
                        btn.click();
                    }
                });
            });
            """
            
            self.driver.execute_script(js_remove_banners)
            time.sleep(1)
            
            # Common popup dismissal attempts
            popup_selectors = [
                "button[id*='accept']",
                "button[class*='accept']", 
                "button[id*='cookie']",
                "button[class*='cookie']",
                "button[id*='dismiss']",
                "button[class*='dismiss']",
                ".cookie-accept",
                ".privacy-accept",
                "#accept-cookies",
                "#dismiss-modal"
            ]
            
            for selector in popup_selectors:
                try:
                    elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        if element.is_displayed() and element.is_enabled():
                            element.click()
                            logging.info(f"[{self.journal.code}] Dismissed popup: {selector}")
                            time.sleep(1)
                            break
                except Exception:
                    continue
                    
        except Exception as e:
            logging.debug(f"[{self.journal.code}] Popup handling: {e}")
    
    def _click_orcid_button(self) -> None:
        """Click ORCID button using exact selectors from workflow."""
        try:
            # Ensure all popups are handled first
            self._handle_popups()
            time.sleep(2)
            
            # Look for ORCID image/link using exact selectors from workflow
            orcid_selectors = [
                "a[href*='sso_site_redirect'][href*='orcid']",
                "img[src*='orcid']",
                "img[title='ORCID']", 
                "a img[src*='orcid_32x32.png']",
                "a[href*='orcid']"
            ]
            
            orcid_element = None
            for selector in orcid_selectors:
                try:
                    elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        if element.is_displayed():
                            # If it's an image, get its parent link
                            if element.tag_name == 'img':
                                orcid_element = element.find_element(By.XPATH, "..")
                            else:
                                orcid_element = element
                            break
                    if orcid_element:
                        break
                except Exception:
                    continue
                    
            if orcid_element:
                # Try JavaScript click first
                try:
                    self.driver.execute_script("arguments[0].click();", orcid_element)
                    logging.info(f"[{self.journal.code}] ORCID button clicked (JavaScript)")
                except Exception:
                    # Fallback to regular click
                    orcid_element.click()
                    logging.info(f"[{self.journal.code}] ORCID button clicked (regular)")
                time.sleep(3)
            else:
                raise Exception("ORCID button not found")
                
        except Exception as e:
            logging.error(f"[{self.journal.code}] Failed to click ORCID button: {e}")
            raise
            
    def _orcid_authentication(self) -> None:
        """Handle ORCID authentication with exact selectors."""
        try:
            # Handle popups on ORCID page
            self._handle_popups()
            
            # Get credentials from environment
            username_env = self.journal.credentials.get('username_env', 'ORCID_EMAIL')
            password_env = self.journal.credentials.get('password_env', 'ORCID_PASSWORD')
            
            email = os.getenv(username_env)
            password = os.getenv(password_env)
            
            if not email or not password:
                raise Exception(f"ORCID credentials not found in environment: {username_env}, {password_env}")
                
            # Wait for username field with exact ID from user specs
            username_field = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "username-input"))
            )
            username_field.clear()
            username_field.send_keys(email)
            logging.info(f"[{self.journal.code}] Username entered")
            
            # Password field with exact ID from user specs
            password_field = self.driver.find_element(By.ID, "password")
            password_field.clear()
            password_field.send_keys(password)
            logging.info(f"[{self.journal.code}] Password entered")
            
            # Submit button with exact ID from user specs
            submit_button = self.driver.find_element(By.ID, "signin-button")
            submit_button.click()
            logging.info(f"[{self.journal.code}] Login submitted")
            
            time.sleep(5)
            
        except Exception as e:
            logging.error(f"[{self.journal.code}] ORCID authentication failed: {e}")
            raise
    
    def extract_manuscripts(self) -> List[Dict[str, Any]]:
        """Extract manuscripts from SICON dashboard following exact workflow."""
        try:
            # Initialize browser if not already done
            if not self.driver:
                self.driver = self.browser_manager.create_driver()
            
            # Navigate to dashboard and login
            self.driver.get(self.journal.url)
            self._handle_popups()
            self._login()
            self._handle_popups()
            time.sleep(1)
            
            # Step 4: Navigate to manuscript folders
            task_links = self._navigate_manuscript_folders()
            
            if not task_links:
                logging.warning(f"[{self.journal.code}] No AE task links found")
                return []
            
            # Step 5: Extract manuscript IDs from AE task links
            manuscript_urls = self._extract_manuscript_ids(task_links)
            
            if not manuscript_urls:
                logging.warning(f"[{self.journal.code}] No manuscript URLs found")
                return []
            
            # Step 6: Extract manuscript details
            self._extract_manuscript_details(manuscript_urls)
            
            logging.info(f"[{self.journal.code}] Extracted {len(self.manuscripts)} manuscripts")
            return self.manuscripts
            
        except Exception as e:
            logging.error(f"[{self.journal.code}] Manuscript extraction failed: {e}")
            return []
    
    def _navigate_manuscript_folders(self) -> List[Dict[str, Any]]:
        """Step 4: Navigate to manuscript folders (AE dashboard)."""
        try:
            # Handle any post-login popups
            self._handle_popups()
            
            # Look for the associate editor table
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            # Find AE task links - these are the specific links we need to click
            task_links = []
            target_tasks = [
                'Awaiting Referee Assignment',
                'All Pending Manuscripts'
            ]
            
            # Check ndt_task section
            for row in soup.find_all('tr', class_='ndt_task'):
                task_link = row.find('a', class_='ndt_task_link')
                if task_link:
                    text = task_link.get_text().strip()
                    href = task_link.get('href')
                    
                    for target_task in target_tasks:
                        if target_task in text:
                            try:
                                count_match = re.search(r'\((\d+)\)', text)
                                if count_match:
                                    count = int(count_match.group(1))
                                    if count > 0:  # Only add if there are manuscripts
                                        task_links.append({
                                            'name': target_task,
                                            'count': count,
                                            'url': href,
                                            'full_text': text,
                                            'type': 'task'
                                        })
                                        logging.info(f"[{self.journal.code}] Found AE task: {target_task} ({count} manuscripts)")
                            except Exception:
                                continue
                            break
            
            # Check ndt_folder section  
            for row in soup.find_all('tr', class_='ndt_folder'):
                folder_link = row.find('a', class_='ndt_folder_link')
                if folder_link:
                    text = folder_link.get_text().strip()
                    href = folder_link.get('href')
                    folder_data = row.get('data-folder', '')
                    
                    for target_task in target_tasks:
                        if target_task in text or target_task.lower().replace(' ', '_') in folder_data:
                            try:
                                count_match = re.search(r'(\d+)\s*AE', text)
                                if count_match:
                                    count = int(count_match.group(1))
                                    if count > 0:  # Only add if there are manuscripts
                                        task_links.append({
                                            'name': target_task,
                                            'count': count,
                                            'url': href,
                                            'full_text': text,
                                            'type': 'folder',
                                            'data_folder': folder_data
                                        })
                                        logging.info(f"[{self.journal.code}] Found AE folder: {target_task} ({count} manuscripts)")
                            except Exception:
                                continue
                            break
                            
            return task_links
            
        except Exception as e:
            logging.error(f"[{self.journal.code}] Failed to find AE task links: {e}")
            return []
    
    def _extract_manuscript_ids(self, task_links: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        """Step 5: Extract manuscript IDs from AE task links."""
        manuscript_urls = []
        
        for task in task_links:
            try:
                logging.info(f"[{self.journal.code}] Clicking AE task: {task['name']} ({task['count']} manuscripts)")
                
                # Find the task link element by its text content
                try:
                    if task['type'] == 'folder':
                        # Use data-folder attribute for folder links
                        folder_selector = f"tr[data-folder='{task['data_folder']}'] a.ndt_folder_link"
                        task_element = WebDriverWait(self.driver, 10).until(
                            EC.element_to_be_clickable((By.CSS_SELECTOR, folder_selector))
                        )
                    else:
                        # Use XPath for task links
                        task_xpath = f"//a[@class='ndt_task_link' and contains(text(), '{task['name']}')]"
                        task_element = WebDriverWait(self.driver, 10).until(
                            EC.element_to_be_clickable((By.XPATH, task_xpath))
                        )
                    
                    # Use JavaScript click to avoid interception
                    self.driver.execute_script("arguments[0].click();", task_element)
                    logging.info(f"[{self.journal.code}] Clicked AE {task['type']}: {task['name']}")
                    time.sleep(3)
                    
                except Exception as e:
                    logging.error(f"[{self.journal.code}] Failed to click AE task {task['name']}: {e}")
                    continue
                
                # Handle popups after navigation
                self._handle_popups()
                
                # Find manuscript links (starting with M followed by numbers)
                soup = BeautifulSoup(self.driver.page_source, 'html.parser')
                
                # Look for manuscript IDs in various patterns
                for link in soup.find_all('a'):
                    text = link.get_text().strip()
                    href = link.get('href', '')
                    
                    # Pattern 1: Direct M + digits with form_type=view_ms
                    if text.startswith('M') and len(text) > 1 and text[1:].isdigit() and 'form_type=view_ms' in href:
                        if href:
                            if not href.startswith('http'):
                                # Keep the relative URL structure intact
                                if href.startswith('cgi-bin/'):
                                    href = "https://sicon.siam.org/" + href
                                else:
                                    href = "https://sicon.siam.org/cgi-bin/" + href.lstrip('/')
                            manuscript_urls.append({
                                'id': text,
                                'url': href
                            })
                            logging.info(f"[{self.journal.code}] Found manuscript: {text}")
                    
                    # Pattern 2: Look in href for manuscript IDs
                    elif 'form_type=view_ms' in href and 'ms_id_key=' in href:
                        # Extract ms_id_key parameter
                        match = re.search(r'ms_id_key=([^&]+)', href)
                        if match:
                            ms_id = match.group(1)
                            if not href.startswith('http'):
                                href = "https://sicon.siam.org/cgi-bin/" + href.lstrip('/')
                            manuscript_urls.append({
                                'id': ms_id,
                                'url': href
                            })
                            logging.info(f"[{self.journal.code}] Found manuscript from URL: {ms_id}")
                
                # Navigate back to main dashboard for next task
                self.driver.get(self.journal.url)
                time.sleep(2)
                self._handle_popups()
                            
            except Exception as e:
                logging.error(f"[{self.journal.code}] Error processing AE task {task['name']}: {e}")
                continue
                
        # Remove duplicates
        seen = set()
        unique_manuscripts = []
        for ms in manuscript_urls:
            if ms['id'] not in seen:
                seen.add(ms['id'])
                unique_manuscripts.append(ms)
                
        logging.info(f"[{self.journal.code}] Found {len(unique_manuscripts)} unique manuscripts")
        return unique_manuscripts
    
    def _extract_manuscript_details(self, manuscript_urls: List[Dict[str, str]]) -> None:
        """Step 6: Extract detailed manuscript information."""
        for manuscript in manuscript_urls:
            try:
                logging.info(f"[{self.journal.code}] Processing {manuscript['id']}...")
                
                # Navigate to manuscript detail page
                self.driver.get(manuscript['url'])
                time.sleep(3)
                
                # Handle any popups
                self._handle_popups()
                
                soup = BeautifulSoup(self.driver.page_source, 'html.parser')
                
                # Find the exact table from user's example
                detail_table = soup.find('table', {'id': 'ms_details_expanded'})
                if not detail_table:
                    # Try alternative table selectors
                    detail_table = soup.find('table', class_='dump_ms_details')
                    if not detail_table:
                        logging.warning(f"[{self.journal.code}] Detail table not found for {manuscript['id']}")
                        continue
                
                # Extract manuscript info
                ms_data = {'id': manuscript['id'], 'url': manuscript['url']}
                
                # Parse table rows
                for row in detail_table.find_all('tr'):
                    th = row.find('th')
                    td = row.find('td')
                    
                    if not th or not td:
                        continue
                        
                    label = th.get_text(strip=True)
                    
                    if 'Manuscript #' in label:
                        ms_data['Manuscript #'] = td.get_text(strip=True)
                    elif 'Title' in label:
                        ms_data['Title'] = td.get_text(strip=True)
                    elif 'Submission Date' in label:
                        ms_data['Submitted'] = td.get_text(strip=True)
                    elif 'Current Stage' in label:
                        ms_data['Current Stage'] = td.get_text(strip=True)
                    elif 'Corresponding Author' in label:
                        ms_data['Corresponding Author'] = td.get_text(strip=True)
                    elif 'Contributing Authors' in label:
                        ms_data['Contributing Authors'] = td.get_text(strip=True)
                    elif 'Abstract' in label:
                        ms_data['Abstract'] = td.get_text(strip=True)
                    elif 'Keywords' in label:
                        ms_data['Keywords'] = td.get_text(strip=True)
                    elif 'Potential Referees' in label:
                        # DECLINED referees - get enhanced details
                        declined_refs = self._extract_referee_details(td, status='declined')
                        ms_data['Declined Referees'] = declined_refs
                        logging.info(f"[{self.journal.code}] Declined Referees: {len(declined_refs)}")
                    elif label == 'Referees':
                        # ACCEPTED referees - get enhanced details
                        accepted_refs = self._extract_referee_details(td, status='accepted')
                        ms_data['Referees'] = accepted_refs
                        logging.info(f"[{self.journal.code}] Accepted Referees: {len(accepted_refs)}")
                
                # Extract PDF links
                ms_data['PDFs'] = self._extract_pdf_links(soup)
                logging.info(f"[{self.journal.code}] PDFs: {len(ms_data['PDFs'])}")
                
                # Extract referee comments
                ms_data['Referee Comments'] = self._extract_referee_comments(soup)
                if ms_data['Referee Comments']:
                    logging.info(f"[{self.journal.code}] Referee Comments: {len(ms_data['Referee Comments'])} comments found")
                        
                self.manuscripts.append(ms_data)
                logging.info(f"[{self.journal.code}] Extracted complete data for {manuscript['id']}")
                
            except Exception as e:
                logging.error(f"[{self.journal.code}] Error processing {manuscript['id']}: {e}")
                continue
    
    def _extract_referee_details(self, cell, status: str) -> List[Dict[str, Any]]:
        """Extract complete referee information by clicking on their profile links."""
        referees = []
        
        # Get the full HTML content of the cell to parse contact dates
        cell_html = str(cell)
        
        # Find all referee links (biblio_dump)
        for link in cell.find_all('a'):
            href = link.get('href', '')
            if 'biblio_dump' in href:
                name = link.get_text(strip=True)
                
                # Get full details by clicking the profile link
                full_details = self._get_referee_profile_details(href)
                
                ref_data = {
                    'name': self._normalize_name(full_details.get('full_name', name)),
                    'email': full_details.get('email', '').lower().strip(),
                    'affiliation': full_details.get('affiliation', ''),
                    'profile_url': href,
                    'status': status
                }
                
                # Enhanced contact date parsing based on status
                if status == 'declined':
                    # Parse pattern: "Samuel daudin #1</a> (Last Contact Date: 2025-02-04) (Status: Declined)"
                    link_text = str(link)
                    link_pattern = re.escape(link_text)
                    pattern = link_pattern + r'\s*\(Last Contact Date:\s*([^)]+)\)\s*\(Status:\s*([^)]+)\)'
                    
                    match = re.search(pattern, cell_html, re.IGNORECASE)
                    if match:
                        ref_data['last_contact_date'] = match.group(1).strip()
                        ref_data['confirmed_status'] = match.group(2).strip()
                
                elif status == 'accepted':
                    # Parse pattern: "Giorgio Ferrari #1</a> <font size="-1">(Rcvd: 2025-06-02)</font>"
                    link_text = str(link)
                    link_pattern = re.escape(link_text)
                    
                    # Look for received date pattern
                    rcvd_pattern = link_pattern + r'[^<]*<font[^>]*>\s*\(Rcvd:\s*([^)]+)\)'
                    rcvd_match = re.search(rcvd_pattern, cell_html, re.IGNORECASE)
                    
                    # Look for due date pattern  
                    due_pattern = link_pattern + r'[^<]*<font[^>]*>\s*\(Due:\s*([^)]+)\)'
                    due_match = re.search(due_pattern, cell_html, re.IGNORECASE)
                    
                    if rcvd_match:
                        ref_data['report_status'] = 'submitted'
                        ref_data['report_received_date'] = rcvd_match.group(1).strip()
                    elif due_match:
                        ref_data['report_status'] = 'pending'
                        ref_data['report_due_date'] = due_match.group(1).strip()
                
                referees.append(ref_data)
                
        return referees
        
    def _get_referee_profile_details(self, profile_url: str) -> Dict[str, str]:
        """Click on referee profile link to get full details."""
        try:
            # Construct full URL
            if not profile_url.startswith('http'):
                if profile_url.startswith('cgi-bin/'):
                    profile_url = "https://sicon.siam.org/" + profile_url
                else:
                    profile_url = "https://sicon.siam.org/cgi-bin/" + profile_url.lstrip('/')
            
            # Navigate to profile page
            self.driver.get(profile_url)
            time.sleep(2)
            
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            details = {}
            
            # Find email addresses
            email_links = soup.find_all('a', href=lambda x: x and 'mailto:' in x)
            if email_links:
                details['email'] = email_links[0].get('href').replace('mailto:', '')
            
            # Look for affiliation and full name in text or table cells
            for td in soup.find_all('td'):
                text = td.get_text(strip=True)
                if '@' in text and '.' in text and 'email' not in details:
                    details['email'] = text
                elif 'University' in text or 'Institute' in text or 'College' in text:
                    details['affiliation'] = text
            
            # Try to find full name (often in title or headers)
            for tag in soup.find_all(['h1', 'h2', 'h3', 'title']):
                text = tag.get_text(strip=True)
                if text and len(text.split()) >= 2 and not text.startswith('SIAM'):
                    details['full_name'] = text
                    break
            
            return details
            
        except Exception as e:
            logging.warning(f"[{self.journal.code}] Could not get profile details from {profile_url}: {e}")
            return {}
    
    def _normalize_name(self, name: str) -> str:
        """Normalize referee names to proper title case."""
        if not name:
            return ""
        
        # Handle names with # (like "Samuel daudin #1")
        if '#' in name:
            name = re.sub(r'\s*#\d+', '', name).strip()
        
        # Split into words and capitalize properly
        words = name.split()
        normalized_words = []
        
        for word in words:
            # Handle hyphenated names
            if '-' in word:
                parts = word.split('-')
                normalized_parts = [part.capitalize() for part in parts if part]
                normalized_words.append('-'.join(normalized_parts))
            else:
                # Special handling for common name patterns
                if word.lower() in ['van', 'von', 'de', 'la', 'le', 'du', 'della', 'da']:
                    normalized_words.append(word.lower())
                else:
                    normalized_words.append(word.capitalize())
        
        return ' '.join(normalized_words)
        
    def _extract_pdf_links(self, soup) -> List[Dict[str, str]]:
        """Extract PDF download links from manuscript page."""
        pdfs = []
        seen_base_urls = set()  # Track seen URLs to avoid duplicates
        
        # Look for PDF links in ordered lists (ol) or direct links
        for link in soup.find_all('a'):
            href = link.get('href', '')
            text = link.get_text(strip=True)
            
            # Look for PDF links
            if '.pdf' in href and ('sicon.siam.org' in href or href.startswith('/')):
                full_url = href if href.startswith('http') else f"https://sicon.siam.org{href}"
                
                # Create base URL for deduplication (remove _sc suffix)
                base_url = full_url.replace('_sc.pdf', '.pdf')
                
                # Skip if we've already seen this base URL
                if base_url in seen_base_urls:
                    continue
                seen_base_urls.add(base_url)
                
                pdf_data = {
                    'url': full_url,
                    'type': 'Unknown PDF',
                    'size': ''
                }
                
                # Determine PDF type from context
                if 'art_file' in href:
                    pdf_data['type'] = 'Article File'
                elif 'reviewer_attachment' in href:
                    pdf_data['type'] = 'Referee Review Attachment'
                elif 'cover_letter' in href:
                    pdf_data['type'] = 'Cover Letter'
                
                # Extract size from text
                if 'KB' in text or 'MB' in text:
                    size_match = re.search(r'\(([^)]+[KM]B)\)', text)
                    if size_match:
                        pdf_data['size'] = size_match.group(1)
                
                pdfs.append(pdf_data)
        
        return pdfs
    
    def _extract_referee_comments(self, soup) -> List[Dict[str, str]]:
        """Extract referee comments by clicking on Associate Editor Recommendation link."""
        try:
            # Find the Associate Editor Recommendation link
            ae_link = None
            for link in soup.find_all('a'):
                href = link.get('href', '')
                text = link.get_text(strip=True)
                if 'display_me_review' in href and 'Associate Editor Recommendation' in text:
                    ae_link = href
                    break
            
            if not ae_link:
                return []
            
            # Construct full URL
            if not ae_link.startswith('http'):
                if ae_link.startswith('cgi-bin/'):
                    ae_link = "https://sicon.siam.org/" + ae_link
                else:
                    ae_link = "https://sicon.siam.org/cgi-bin/" + ae_link.lstrip('/')
            
            # Navigate to comments page
            self.driver.get(ae_link)
            time.sleep(2)
            
            comment_soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            # Look for the comments table with Referee, Note, Comment columns
            comments = []
            seen_comments = set()  # Track seen comments to avoid duplicates
            
            for table in comment_soup.find_all('table'):
                # Check if this is the comments table
                headers = table.find_all('th')
                if len(headers) >= 3:
                    header_texts = [th.get_text(strip=True) for th in headers]
                    if 'Referee' in header_texts and 'Comment' in header_texts:
                        # This is the comments table
                        for row in table.find_all('tr')[1:]:  # Skip header row
                            cells = row.find_all('td')
                            if len(cells) >= 3:
                                referee = cells[0].get_text(strip=True)
                                note = cells[1].get_text(strip=True)
                                comment = cells[2].get_text(strip=True)
                                
                                # Create unique identifier for this comment
                                comment_id = f"{referee}|{note}|{comment[:100]}"
                                
                                # Filter out system-generated entries and empty comments
                                is_system_entry = any([
                                    'Attach File' in referee,
                                    'Review Attachment' in referee and not comment,
                                    comment == 'No Comment',
                                    comment == '' and note in ['Remarks to the Author', 'Confidential Message to Review Editor'],
                                    comment.lower().strip() in ['please see pdf', 'see pdf', 'see attached', 'see attachment']
                                ])
                                
                                if referee and not is_system_entry and comment and comment.strip() and comment_id not in seen_comments:
                                    seen_comments.add(comment_id)
                                    comments.append({
                                        'referee': referee,
                                        'note_type': note,
                                        'comment': comment
                                    })
            
            return comments
            
        except Exception as e:
            logging.warning(f"[{self.journal.code}] Could not extract referee comments: {e}")
            return []
    
    def extract_data(self) -> List[Dict[str, Any]]:
        """
        Main extraction method required by the base class.
        
        Returns:
            List of extracted manuscripts
        """
        return self.extract_manuscripts()