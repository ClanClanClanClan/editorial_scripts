#!/usr/bin/env python3
"""
Quick test to see if ULTRAFIX Take Action is working
"""

import os
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from editorial_assistant.extractors.scholarone import ScholarOneExtractor

def quick_ultrafix_test():
    """Quick test of ULTRAFIX."""
    print("🎯 Quick ULTRAFIX test...")
    
    # Load production config
    try:
        with open('.env.production', 'r') as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    key, value = line.strip().split('=', 1)
                    os.environ[key] = value
    except FileNotFoundError:
        print("❌ No .env.production file found")
        return
    
    try:
        extractor = ScholarOneExtractor('MF')
        extractor.headless = True  # Run headless for speed
        
        print("🔄 Testing ULTRAFIX Take Action...")
        result = extractor.extract()
        
        if result.manuscripts:
            print(f"✅ Found {len(result.manuscripts)} manuscripts")
            
            # Check if detailed extraction worked
            detailed_count = 0
            for manuscript in result.manuscripts:
                if manuscript.referees or (hasattr(manuscript, 'pdf_path') and manuscript.pdf_path):
                    detailed_count += 1
            
            if detailed_count > 0:
                print(f"🎉 ULTRAFIX SUCCESS! {detailed_count} manuscripts have detailed data")
            else:
                print("❌ ULTRAFIX FAILED - no detailed data extracted")
                
            # Show first manuscript details
            manuscript = result.manuscripts[0]
            print(f"\nSample data for {manuscript.manuscript_id}:")
            print(f"  Title: {manuscript.title}")
            print(f"  Authors: {len(manuscript.authors)}")
            print(f"  Referees: {len(manuscript.referees)}")
            if hasattr(manuscript, 'pdf_path'):
                print(f"  PDF: {manuscript.pdf_path}")
        else:
            print("❌ No manuscripts found")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    quick_ultrafix_test()