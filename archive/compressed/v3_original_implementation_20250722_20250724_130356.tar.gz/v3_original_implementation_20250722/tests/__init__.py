"""Tests package for Editorial Scripts v3."""
