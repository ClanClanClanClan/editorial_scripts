#!/usr/bin/env python3
"""Test the updated referee extraction"""

import os
import sys
import time
from pathlib import Path
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

def test_updated_extraction():
    """Test the updated referee extraction logic"""
    
    print("🎯 TESTING UPDATED REFEREE EXTRACTION")
    print("=" * 50)
    
    # Chrome setup
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        # Quick login (we know this works from previous tests)
        print("1. Quick login...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        try:
            reject_btn = driver.find_element(By.ID, "onetrust-reject-all-handler")
            reject_btn.click()
        except:
            pass
        
        email_field = driver.find_element(By.ID, "USERID")
        email_field.send_keys(os.getenv('MF_EMAIL'))
        password_field = driver.find_element(By.ID, "PASSWORD")
        password_field.send_keys(os.getenv('MF_PASSWORD'))
        login_btn = driver.find_element(By.ID, "logInButton")
        driver.execute_script("arguments[0].click();", login_btn)
        time.sleep(3)
        
        # Handle 2FA
        try:
            code_input = driver.find_element(By.ID, "TOKEN_VALUE")
            from core.email_utils import fetch_latest_verification_code
            time.sleep(5)
            verification_code = fetch_latest_verification_code('MF', max_wait=60, poll_interval=3)
            if verification_code:
                code_input.clear()
                code_input.send_keys(verification_code)
                try:
                    remember_checkbox = driver.find_element(By.ID, "REMEMBER_THIS_DEVICE")
                    if not remember_checkbox.is_selected():
                        remember_checkbox.click()
                except:
                    pass
                verify_btn = driver.find_element(By.ID, "VERIFY_BTN")
                verify_btn.click()
                time.sleep(15)
        except:
            pass
        
        # Navigate to manuscripts and click Take Action (we know this works)
        print("2. Navigating and clicking Take Action...")
        ae_link = driver.find_element(By.LINK_TEXT, "Associate Editor Center")
        ae_link.click()
        time.sleep(5)
        
        category_link = driver.find_element(By.LINK_TEXT, "Awaiting Reviewer Scores")
        category_link.click()
        time.sleep(5)
        
        # Find and click Take Action (we know this works)
        all_rows = driver.find_elements(By.TAG_NAME, "tr")
        
        for row in all_rows:
            if 'MAFI-' in row.text:
                cells = row.find_elements(By.TAG_NAME, "td")
                if cells:
                    last_cell = cells[-1]
                    take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
                    
                    if take_action_links:
                        href = take_action_links[0].get_attribute('href')
                        if href and 'javascript:' in href:
                            js_code = href.replace('javascript:', '')
                            driver.execute_script(js_code)
                            time.sleep(5)
                            print("✅ Take Action clicked successfully")
                            break
        
        # Now test the referee extraction logic
        print("3. Testing referee extraction...")
        print("-" * 40)
        
        # Use our new extraction method
        from editorial_assistant.extractors.scholarone import ScholarOneExtractor
        
        # Create a temporary extractor instance just to use the parsing methods
        temp_extractor = ScholarOneExtractor('MF')
        temp_extractor.driver = driver
        
        # Set up basic logging with debug output
        import logging
        logging.basicConfig(level=logging.DEBUG)
        temp_extractor.logger = logging.getLogger('test_extractor')
        temp_extractor.logger.setLevel(logging.DEBUG)
        
        # Debug: Check what's on the page first
        print("🔍 Debugging page content...")
        
        # Check for tablelightcolor elements
        tablelightcolor_rows = driver.find_elements(By.XPATH, "//tr[td[contains(@class, 'tablelightcolor')]]")
        print(f"Found {len(tablelightcolor_rows)} rows with tablelightcolor")
        
        # Check for any table rows with referee-like content
        all_rows = driver.find_elements(By.TAG_NAME, "tr")
        referee_like_rows = []
        for row in all_rows:
            row_text = row.text
            if any(name in row_text for name in ['Liang', 'Mrad', 'Dos Reis', 'Strub']):
                referee_like_rows.append(row)
                print(f"Found referee-like row: {row_text[:100]}...")
        
        print(f"Found {len(referee_like_rows)} rows containing referee names")
        
        # Examine the structure of tablelightcolor rows
        print(f"\n🔍 Examining first few tablelightcolor rows:")
        for i, row in enumerate(tablelightcolor_rows[:10]):
            cells = row.find_elements(By.TAG_NAME, "td")
            print(f"Row {i+1}: {len(cells)} cells - {row.text[:80]}...")
            
            if len(cells) >= 4:
                name_cell = cells[1]
                name_text = name_cell.text.strip()
                if any(name in name_text for name in ['Liang', 'Mrad', 'Dos Reis', 'Strub']):
                    print(f"  ⭐ REFEREE ROW: {name_text}")
        
        # Test the referee extraction
        referees = temp_extractor._extract_referees()
        
        print(f"\n📊 EXTRACTION RESULTS:")
        print(f"Total referees found: {len(referees)}")
        
        for i, referee in enumerate(referees):
            print(f"\n📄 Referee {i+1}:")
            print(f"   Name: {referee.name}")
            print(f"   Status: {referee.status}")
            print(f"   Institution: {referee.institution}")
            print(f"   Email: {referee.email}")
            if hasattr(referee, 'orcid') and referee.orcid:
                print(f"   ORCID: {referee.orcid}")
        
        if len(referees) > 0:
            print(f"\n✅ SUCCESS! Extracted {len(referees)} referees using the new parsing logic!")
        else:
            print(f"\n❌ No referees extracted - need to debug the parsing logic")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        driver.quit()

if __name__ == "__main__":
    test_updated_extraction()