#!/usr/bin/env python3
"""
Abstract Platform Extractor - Base class for all editorial journal extractors.

This module provides the unified foundation for all platform-specific extractors,
implementing common patterns, data models, and integration points.

Phase 3: System Integration - Platform Abstraction Layer
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, List, Optional, Any, Union
from datetime import datetime
import logging
from enum import Enum

# Import existing configuration system
from ..core.unified_config import get_config_manager
from ..core.exceptions import ConfigurationError, ExtractionError


class PlatformType(Enum):
    """Platform types for different journal systems."""
    SCHOLARONE = "scholarone"
    SIAM = "siam"
    UNKNOWN = "unknown"


class AuthenticationType(Enum):
    """Authentication types for different platforms."""
    USERNAME_PASSWORD = "username_password"  # ScholarOne 2FA
    ORCID = "orcid"                         # SIAM ORCID auth
    API_KEY = "api_key"                     # Future API integration
    OAUTH = "oauth"                         # Future OAuth integration


@dataclass
class UnifiedManuscript:
    """Unified manuscript model across all platforms."""
    
    # Core identification
    manuscript_id: str
    platform_id: str
    journal_code: str
    platform_type: PlatformType
    
    # Manuscript details
    title: Optional[str] = None
    authors: List[str] = None
    submission_date: Optional[datetime] = None
    status: Optional[str] = None
    category: Optional[str] = None
    
    # Platform-specific data (preserved for compatibility)
    platform_data: Dict[str, Any] = None
    
    # Timeline information
    timeline_events: List[Dict[str, Any]] = None
    
    # Referee information
    referees: List[Dict[str, Any]] = None
    
    def __post_init__(self):
        """Initialize default values."""
        if self.authors is None:
            self.authors = []
        if self.platform_data is None:
            self.platform_data = {}
        if self.timeline_events is None:
            self.timeline_events = []
        if self.referees is None:
            self.referees = []


@dataclass  
class UnifiedReferee:
    """Unified referee model across all platforms."""
    
    # Core identification
    name: str
    email: str
    manuscript_id: str
    platform_type: PlatformType
    
    # Referee details
    affiliation: Optional[str] = None
    country: Optional[str] = None
    expertise: List[str] = None
    
    # Status information
    invitation_date: Optional[datetime] = None
    response_date: Optional[datetime] = None
    due_date: Optional[datetime] = None
    status: Optional[str] = None
    
    # Platform-specific data
    platform_data: Dict[str, Any] = None
    
    def __post_init__(self):
        """Initialize default values."""
        if self.expertise is None:
            self.expertise = []
        if self.platform_data is None:
            self.platform_data = {}


class PlatformExtractor(ABC):
    """
    Abstract base class for all platform-specific extractors.
    
    This class defines the common interface and shared functionality
    that all journal extractors must implement.
    """
    
    def __init__(self, journal_code: str, **kwargs):
        """
        Initialize the platform extractor.
        
        Args:
            journal_code: Journal identifier (e.g., 'MF', 'MOR', 'SICON', 'SIFIN')
            **kwargs: Additional platform-specific configuration
        """
        self.journal_code = journal_code.upper()
        self.logger = logging.getLogger(f"{self.__class__.__name__}")
        
        # Load configuration
        try:
            config_manager = get_config_manager()
            self.config = config_manager.get_journal_config(self.journal_code)
        except Exception as e:
            self.logger.warning(f"Could not load config for {journal_code}: {e}")
            self.config = None
        
        # Platform identification
        self.platform_type = self._determine_platform_type()
        self.authentication_type = self._determine_auth_type()
        
        # Feature flags for Phase 3 integration
        self.use_unified_models = config_manager.is_feature_enabled('use_unified_models', self.journal_code) if config_manager else False
        self.use_timeline_integration = config_manager.is_feature_enabled('use_timeline_integration', self.journal_code) if config_manager else False
        self.use_browser_pool = config_manager.is_feature_enabled('use_browser_pool', self.journal_code) if config_manager else False
        self.use_cache_system = config_manager.is_feature_enabled('use_cache_system', self.journal_code) if config_manager else False
        
        # Initialize platform-specific components
        self._initialize_platform_components(**kwargs)
        
        self.logger.info(f"Platform Extractor initialized - Journal: {self.journal_code}, "
                        f"Platform: {self.platform_type.value}, Auth: {self.authentication_type.value}")
    
    @abstractmethod
    def _determine_platform_type(self) -> PlatformType:
        """Determine the platform type for this extractor."""
        pass
    
    @abstractmethod
    def _determine_auth_type(self) -> AuthenticationType:
        """Determine the authentication type for this platform."""
        pass
    
    @abstractmethod
    def _initialize_platform_components(self, **kwargs):
        """Initialize platform-specific components."""
        pass
    
    @abstractmethod
    def authenticate(self, **credentials) -> bool:
        """
        Authenticate with the platform.
        
        Args:
            **credentials: Platform-specific credentials
            
        Returns:
            bool: True if authentication successful
            
        Raises:
            ExtractionError: If authentication fails
        """
        pass
    
    @abstractmethod
    def extract_manuscripts(self, **filters) -> List[UnifiedManuscript]:
        """
        Extract manuscripts from the platform.
        
        Args:
            **filters: Platform-specific filtering options
            
        Returns:
            List[UnifiedManuscript]: List of unified manuscript objects
            
        Raises:
            ExtractionError: If extraction fails
        """
        pass
    
    @abstractmethod
    def extract_referees(self, manuscript_id: str) -> List[UnifiedReferee]:
        """
        Extract referee information for a specific manuscript.
        
        Args:
            manuscript_id: Platform-specific manuscript identifier
            
        Returns:
            List[UnifiedReferee]: List of unified referee objects
            
        Raises:
            ExtractionError: If extraction fails
        """
        pass
    
    def extract_all_data(self, **kwargs) -> Dict[str, Any]:
        """
        Extract all available data from the platform.
        
        This method provides a high-level interface that orchestrates
        the complete extraction process.
        
        Args:
            **kwargs: Platform-specific extraction parameters
            
        Returns:
            Dict[str, Any]: Complete extraction results in unified format
        """
        self.logger.info(f"Starting complete data extraction for {self.journal_code}")
        
        try:
            # Step 1: Authenticate
            auth_result = self.authenticate(**kwargs.get('credentials', {}))
            if not auth_result:
                raise ExtractionError(f"Authentication failed for {self.journal_code}")
            
            # Step 2: Extract manuscripts
            manuscripts = self.extract_manuscripts(**kwargs.get('manuscript_filters', {}))
            self.logger.info(f"Extracted {len(manuscripts)} manuscripts")
            
            # Step 3: Extract referees for each manuscript
            all_referees = []
            for manuscript in manuscripts:
                try:
                    referees = self.extract_referees(manuscript.manuscript_id)
                    all_referees.extend(referees)
                    self.logger.debug(f"Extracted {len(referees)} referees for manuscript {manuscript.manuscript_id}")
                except Exception as e:
                    self.logger.warning(f"Failed to extract referees for manuscript {manuscript.manuscript_id}: {e}")
            
            # Step 4: Build unified result
            result = {
                'journal_code': self.journal_code,
                'platform_type': self.platform_type.value,
                'extraction_timestamp': datetime.now().isoformat(),
                'manuscripts': [self._manuscript_to_dict(m) for m in manuscripts],
                'referees': [self._referee_to_dict(r) for r in all_referees],
                'summary': {
                    'total_manuscripts': len(manuscripts),
                    'total_referees': len(all_referees),
                    'unique_referees': len(set(r.email for r in all_referees if r.email))
                }
            }
            
            self.logger.info(f"Extraction complete - {len(manuscripts)} manuscripts, {len(all_referees)} referees")
            return result
            
        except Exception as e:
            self.logger.error(f"Extraction failed for {self.journal_code}: {e}")
            raise ExtractionError(f"Complete extraction failed: {e}") from e
    
    def _manuscript_to_dict(self, manuscript: UnifiedManuscript) -> Dict[str, Any]:
        """Convert UnifiedManuscript to dictionary."""
        result = {
            'manuscript_id': manuscript.manuscript_id,
            'platform_id': manuscript.platform_id,
            'journal_code': manuscript.journal_code,
            'platform_type': manuscript.platform_type.value if manuscript.platform_type else None,
            'title': manuscript.title,
            'authors': manuscript.authors,
            'submission_date': manuscript.submission_date.isoformat() if manuscript.submission_date else None,
            'status': manuscript.status,
            'category': manuscript.category,
            'timeline_events': manuscript.timeline_events,
            'referees': manuscript.referees
        }
        
        # Include platform-specific data for backward compatibility
        if manuscript.platform_data:
            result['platform_data'] = manuscript.platform_data
            
        return result
    
    def _referee_to_dict(self, referee: UnifiedReferee) -> Dict[str, Any]:
        """Convert UnifiedReferee to dictionary."""
        result = {
            'name': referee.name,
            'email': referee.email,
            'manuscript_id': referee.manuscript_id,
            'platform_type': referee.platform_type.value if referee.platform_type else None,
            'affiliation': referee.affiliation,
            'country': referee.country,
            'expertise': referee.expertise,
            'invitation_date': referee.invitation_date.isoformat() if referee.invitation_date else None,
            'response_date': referee.response_date.isoformat() if referee.response_date else None,
            'due_date': referee.due_date.isoformat() if referee.due_date else None,
            'status': referee.status
        }
        
        # Include platform-specific data for backward compatibility
        if referee.platform_data:
            result['platform_data'] = referee.platform_data
            
        return result
    
    def get_platform_info(self) -> Dict[str, str]:
        """Get platform identification information."""
        return {
            'journal_code': self.journal_code,
            'platform_type': self.platform_type.value,
            'authentication_type': self.authentication_type.value,
            'extractor_class': self.__class__.__name__
        }
    
    def is_feature_enabled(self, feature_name: str) -> bool:
        """Check if a Phase 3 feature is enabled."""
        try:
            config_manager = get_config_manager()
            return config_manager.is_feature_enabled(feature_name, self.journal_code)
        except:
            return False
    
    def cleanup(self):
        """Clean up platform-specific resources."""
        self.logger.info(f"Cleaning up resources for {self.journal_code}")
        # Subclasses should override to implement specific cleanup
        pass