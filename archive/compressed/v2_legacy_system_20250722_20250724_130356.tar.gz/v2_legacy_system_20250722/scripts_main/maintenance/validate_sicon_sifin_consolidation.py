#!/usr/bin/env python3
"""
Validate the consolidated SICON and SIFIN extractors against the originals.
"""

import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

def validate_sicon_consolidation():
    """Validate that consolidated SICON extractor works correctly."""
    
    print("SICON CONSOLIDATION VALIDATION")
    print("="*60)
    
    # Test 1: Import and initialization
    print("\n1. Testing imports and initialization...")
    print("-"*40)
    
    try:
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
        print("✅ Import successful")
        
        extractor = SICONConsolidatedExtractor()
        print("✅ Extractor initialized")
        print(f"   - Journal: {extractor.journal.code}")
        print(f"   - URL: {extractor.journal_url}")
        print(f"   - Site prefix: {extractor.site_prefix}")
        
    except Exception as e:
        print(f"❌ Import/init failed: {e}")
        return False
    
    # Test 2: SICON-specific features
    print("\n2. Testing SICON-specific features...")
    print("-"*40)
    
    expected_features = {
        'journal_url': "https://sicon.siam.org/cgi-bin/main.plex",  # From config
        'popup_wait_time': 1,
        'page_navigation_wait': 5,
        'has_extract_data_method': True,
        'has_login_method': True,
        'has_orcid_auth': True
    }
    
    actual_features = {
        'journal_url': extractor.journal_url,
        'popup_wait_time': extractor.popup_wait_time,
        'page_navigation_wait': extractor.page_navigation_wait,
        'has_extract_data_method': hasattr(extractor, 'extract_data'),
        'has_login_method': hasattr(extractor, '_login'),
        'has_orcid_auth': hasattr(extractor, '_orcid_authentication')
    }
    
    all_match = True
    for feature, expected in expected_features.items():
        actual = actual_features[feature]
        if actual == expected:
            print(f"✅ {feature}: {actual}")
        else:
            print(f"❌ {feature}: expected {expected}, got {actual}")
            all_match = False
    
    if not all_match:
        return False
    
    # Test 3: Method signatures
    print("\n3. Testing method signatures...")
    print("-"*40)
    
    methods_to_check = [
        ('extract_data', 0),  # No required parameters
        ('_extract_from_web', 0),
        ('_login', 0),
        ('_extract_manuscript_ids', 0),
        ('_extract_manuscript_details', 1),  # manuscript_id parameter
    ]
    
    for method_name, expected_params in methods_to_check:
        if hasattr(extractor, method_name):
            method = getattr(extractor, method_name)
            # Count parameters (excluding self)
            import inspect
            sig = inspect.signature(method)
            param_count = len([p for p in sig.parameters if p != 'self'])
            
            if param_count >= expected_params:
                print(f"✅ {method_name}: {param_count} parameters")
            else:
                print(f"❌ {method_name}: expected {expected_params} params, got {param_count}")
        else:
            print(f"❌ {method_name}: method not found")
    
    # Test 4: Backward compatibility
    print("\n4. Testing backward compatibility...")
    print("-"*40)
    
    try:
        from editorial_assistant.extractors.sicon_consolidated import extract_sicon_data
        print("✅ Backward compatibility function exists")
        
        # Check function signature
        import inspect
        sig = inspect.signature(extract_sicon_data)
        params = list(sig.parameters.keys())
        expected_params = ['headless', 'validate_timeline']
        
        if all(p in params for p in expected_params):
            print("✅ Backward compatibility parameters correct")
        else:
            print(f"❌ Missing parameters: {set(expected_params) - set(params)}")
            
    except ImportError:
        print("❌ Backward compatibility function missing")
    
    # Test 5: Configuration integration
    print("\n5. Testing configuration integration...")
    print("-"*40)
    
    print(f"✅ Config system available: {extractor.use_config_system}")
    print(f"✅ Navigation module ready: {extractor.use_navigation_module}")
    print(f"✅ Enhanced timeline ready: {extractor.use_enhanced_timeline}")
    
    return True


def validate_sifin_consolidation():
    """Validate that consolidated SIFIN extractor works correctly."""
    
    print("\n\nSIFIN CONSOLIDATION VALIDATION")
    print("="*60)
    
    # Test 1: Import and initialization
    print("\n1. Testing imports and initialization...")
    print("-"*40)
    
    try:
        from editorial_assistant.extractors.sifin_consolidated import SIFINConsolidatedExtractor
        print("✅ Import successful")
        
        extractor = SIFINConsolidatedExtractor()
        print("✅ Extractor initialized")
        print(f"   - Journal: {extractor.journal.code}")
        print(f"   - URL: {extractor.journal_url}")
        print(f"   - Browser: {extractor.browser_manager.browser_type}")
        
    except Exception as e:
        print(f"❌ Import/init failed: {e}")
        return False
    
    # Test 2: SIFIN-specific features
    print("\n2. Testing SIFIN-specific features...")
    print("-"*40)
    
    expected_features = {
        'journal_url': "http://sifin.siam.org/",
        'browser_type': 'firefox',  # Required for Cloudflare bypass
        'popup_wait_time': 1,  # SIFIN is faster
        'page_navigation_wait': 5,
        'redirect_timeout': 30,
        'has_extract_data_method': True,
        'has_login_method': True,
        'has_cookie_removal': True
    }
    
    actual_features = {
        'journal_url': extractor.journal_url,
        'browser_type': extractor.browser_manager.browser_type,
        'popup_wait_time': extractor.popup_wait_time,
        'page_navigation_wait': extractor.page_navigation_wait,
        'redirect_timeout': extractor.redirect_timeout,
        'has_extract_data_method': hasattr(extractor, 'extract_data'),
        'has_login_method': hasattr(extractor, '_login'),
        'has_cookie_removal': hasattr(extractor, '_remove_cookie_banner')
    }
    
    all_match = True
    for feature, expected in expected_features.items():
        actual = actual_features[feature]
        if actual == expected:
            print(f"✅ {feature}: {actual}")
        else:
            print(f"❌ {feature}: expected {expected}, got {actual}")
            all_match = False
    
    if not all_match:
        return False
    
    # Test 3: SIFIN-specific methods
    print("\n3. Testing SIFIN-specific methods...")
    print("-"*40)
    
    sifin_methods = [
        '_remove_cookie_banner',
        '_handle_post_login_popups',
        '_extract_from_emails',
        '_integrate_and_validate',
        '_report_validation_issues'
    ]
    
    for method_name in sifin_methods:
        if hasattr(extractor, method_name):
            print(f"✅ {method_name}: exists")
        else:
            print(f"❌ {method_name}: missing")
    
    # Test 4: Backward compatibility
    print("\n4. Testing backward compatibility...")
    print("-"*40)
    
    try:
        from editorial_assistant.extractors.sifin_consolidated import extract_sifin_data
        print("✅ Backward compatibility function exists")
        
        # Check function signature
        import inspect
        sig = inspect.signature(extract_sifin_data)
        params = list(sig.parameters.keys())
        expected_params = ['headless', 'validate_timeline']
        
        if all(p in params for p in expected_params):
            print("✅ Backward compatibility parameters correct")
        else:
            print(f"❌ Missing parameters: {set(expected_params) - set(params)}")
            
    except ImportError:
        print("❌ Backward compatibility function missing")
    
    # Test 5: Firefox requirement
    print("\n5. Testing Firefox requirement...")
    print("-"*40)
    
    if extractor.browser_manager.browser_type == 'firefox':
        print("✅ Firefox browser configured (required for Cloudflare bypass)")
    else:
        print(f"❌ Wrong browser: {extractor.browser_manager.browser_type}, should be firefox")
    
    return True


def main():
    """Run both SICON and SIFIN validation tests."""
    
    sicon_success = validate_sicon_consolidation()
    sifin_success = validate_sifin_consolidation()
    
    # Summary
    print("\n" + "="*60)
    print("SICON/SIFIN CONSOLIDATION SUMMARY")
    print("="*60)
    
    if sicon_success and sifin_success:
        print("\n✅ Both SICON and SIFIN consolidations SUCCESSFUL")
        print("✅ All core functionality preserved")
        print("✅ Platform-specific features implemented")
        print("✅ Feature flags and configuration integration ready")
        print("✅ Backward compatibility maintained")
        
        print("\nNext steps:")
        print("1. Test with actual SIAM credentials")
        print("2. Validate ORCID authentication flow")
        print("3. Test email timeline integration")
        print("4. Update imports in existing code")
        print("5. Enable feature flags after full validation")
        
        return True
    else:
        print("\n❌ VALIDATION FAILED")
        if not sicon_success:
            print("❌ SICON consolidation has issues")
        if not sifin_success:
            print("❌ SIFIN consolidation has issues")
        
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)