# FOOLPROOF REFEREE TRACKER DESIGN

## Current Critical Issues

### 1. Ghost Referees
- **Problem**: System creates fake referees like "M174160", "M174727", "review MS"
- **Cause**: Pattern matching extracts manuscript IDs and process terms as names
- **Impact**: Pollutes referee database with non-human entities

### 2. Duplicate Identities  
- **Problem**: Same person appears multiple times with different representations
- **Example**: "Antoine Jack Jacquier" vs "Unknown (a.jacquier@imperial.ac.uk)"
- **Impact**: Fragments referee timeline and analytics

### 3. Poor Name Validation
- **Problem**: No validation that extracted names are actual people
- **Examples**: "review MS", "M174160", random phrases extracted as names
- **Impact**: False positive referee identifications

### 4. Incomplete Role Detection
- **Problem**: Still mixing editorial, system, and referee communications
- **Impact**: Inaccurate referee counts and analytics

## FOOLPROOF SOLUTION ARCHITECTURE

### Layer 1: Input Validation & Sanitization
```python
class EmailInputValidator:
    def __init__(self):
        self.manuscript_id_patterns = [r'M\d{5,6}', r'MS\d+']
        self.system_patterns = ['review MS', 'manuscript', 'submission']
        self.noise_patterns = ['RE:', 'FW:', 'follow-up', 'reminder']
    
    def clean_email_content(self, email_event):
        """Remove noise and standardize email content"""
        # Remove email threading artifacts
        # Standardize whitespace
        # Remove HTML/formatting
        # Extract clean text sections
```

### Layer 2: Entity Validation
```python
class RefereeEntityValidator:
    def __init__(self):
        self.person_name_patterns = [
            r'^[A-Z][a-z]+\s+[A-Z][a-z]+$',  # First Last
            r'^[A-Z][a-z]+\s+[A-Z]\.\s+[A-Z][a-z]+$',  # First M. Last
            r'^[A-Z][a-z]+\s+[A-Z][a-z]+\s+[A-Z][a-z]+$',  # First Middle Last
        ]
        
        self.blacklist = {
            'manuscript_ids': ['M174160', 'M174727', 'M175988', 'M176140'],
            'process_terms': ['review MS', 'manuscript', 'submission', 'follow-up'],
            'system_terms': ['SIFIN', 'SIAM', 'editorial', 'reminder'],
            'noise_terms': ['RE:', 'FW:', 'Dear', 'Sincerely']
        }
    
    def is_valid_person_name(self, name):
        """Validate if extracted name represents a real person"""
        # Check against blacklists
        # Validate name structure
        # Check for common academic titles
        # Validate character composition
```

### Layer 3: Role Classification
```python
class CommunicationRoleClassifier:
    def __init__(self):
        self.role_patterns = {
            'editorial': {
                'emails': ['dylan.possamai@math.ethz.ch', 'dylansmb@gmail.com'],
                'domains': ['math.ethz.ch'],
                'indicators': ['editor', 'coordinator', 'managing', 'editorial']
            },
            'referee': {
                'indicators': ['reviewer', 'referee', 'review request', 'invitation'],
                'exclusions': ['editorial', 'managing', 'coordinator'],
                'context': ['invited to review', 'submitted report', 'agreed to review']
            },
            'system': {
                'domains': ['sifin.siam.org', 'siam.org', 'editorialmanager.com'],
                'indicators': ['automated', 'system', 'notification', 'reminder']
            },
            'author': {
                'indicators': ['corresponding author', 'submission', 'manuscript author'],
                'context': ['submitted manuscript', 'author response', 'revision']
            }
        }
    
    def classify_email_role(self, email_event):
        """Classify the role of participants in email communication"""
```

### Layer 4: Entity Resolution
```python
class RefereeEntityResolver:
    def __init__(self):
        self.similarity_threshold = 0.85
        self.email_domain_weights = {
            'exact_match': 1.0,
            'same_domain': 0.8,
            'academic_domain': 0.6
        }
    
    def resolve_duplicate_identities(self, referee_candidates):
        """Merge duplicate referee identities"""
        # Group by email address
        # Fuzzy match names
        # Consolidate profiles
        # Merge timelines
    
    def calculate_similarity(self, referee1, referee2):
        """Calculate similarity between two referee profiles"""
        # Email similarity
        # Name similarity (fuzzy matching)
        # Institution similarity
        # Timeline overlap
```

### Layer 5: Confidence Scoring
```python
class RefereeConfidenceScorer:
    def __init__(self):
        self.confidence_weights = {
            'email_validity': 0.3,
            'name_validity': 0.25,
            'role_classification': 0.2,
            'timeline_consistency': 0.15,
            'institutional_validation': 0.1
        }
    
    def calculate_confidence(self, referee_profile):
        """Calculate confidence score for referee identification"""
        # Email format validation
        # Name structure validation
        # Role classification confidence
        # Timeline consistency
        # Institution validation
```

### Layer 6: Quality Filters
```python
class QualityFilter:
    def __init__(self):
        self.minimum_confidence = 0.7
        self.minimum_timeline_events = 1
        self.required_evidence_types = ['email_header', 'pattern_match']
    
    def filter_high_quality_referees(self, referee_profiles):
        """Filter only high-quality, validated referee profiles"""
        # Confidence threshold
        # Evidence requirements
        # Timeline completeness
        # Validation checks
```

## IMPLEMENTATION STRATEGY

### Phase 1: Validation & Sanitization
1. **Input Cleaning**: Remove noise from email content
2. **Pattern Blacklisting**: Exclude known false positives
3. **Name Validation**: Check if extracted names are people
4. **Email Validation**: Validate email formats and domains

### Phase 2: Entity Resolution
1. **Duplicate Detection**: Find potential duplicate referee profiles
2. **Similarity Calculation**: Score similarity between profiles
3. **Profile Merging**: Consolidate duplicate identities
4. **Timeline Consolidation**: Merge related email timelines

### Phase 3: Role Classification
1. **Context Analysis**: Understand email purpose and roles
2. **Pattern Recognition**: Identify editorial vs referee communications
3. **Confidence Scoring**: Score role classification confidence
4. **Quality Filtering**: Apply quality thresholds

### Phase 4: Validation Pipeline
```python
class FoolproofRefereeTracker:
    def __init__(self):
        self.validator = EmailInputValidator()
        self.entity_validator = RefereeEntityValidator()
        self.role_classifier = CommunicationRoleClassifier()
        self.entity_resolver = RefereeEntityResolver()
        self.confidence_scorer = RefereeConfidenceScorer()
        self.quality_filter = QualityFilter()
    
    def process_email_foolproof(self, email_event):
        """Process email with full validation pipeline"""
        # 1. Clean and validate input
        cleaned_email = self.validator.clean_email_content(email_event)
        
        # 2. Extract and validate entities
        referee_candidates = self.extract_referee_candidates(cleaned_email)
        valid_referees = [r for r in referee_candidates 
                         if self.entity_validator.is_valid_person_name(r)]
        
        # 3. Classify roles
        role_classified = self.role_classifier.classify_email_role(cleaned_email)
        
        # 4. Resolve duplicates
        resolved_referees = self.entity_resolver.resolve_duplicate_identities(valid_referees)
        
        # 5. Calculate confidence
        scored_referees = [(r, self.confidence_scorer.calculate_confidence(r)) 
                          for r in resolved_referees]
        
        # 6. Apply quality filters
        high_quality_referees = self.quality_filter.filter_high_quality_referees(scored_referees)
        
        return high_quality_referees
```

## EXPECTED OUTCOMES

### Before (Current System):
- **24 "referees"** identified (including ghosts)
- **Ghost entities**: "M174160", "M174727", "review MS"
- **Duplicates**: "Antoine Jack Jacquier" + "Unknown (a.jacquier@imperial.ac.uk)"
- **No validation**: Accepts any extracted name

### After (Foolproof System):
- **~12 validated referees** (real people only)
- **Zero ghost entities**: All validated as actual people
- **No duplicates**: Merged into single profiles
- **High confidence**: Only includes validated identifications
- **Clear roles**: Distinct editorial, referee, and system communications

## VALIDATION CHECKS

### Name Validation
- ✅ Must match person name patterns
- ✅ Must not be manuscript ID
- ✅ Must not be system term
- ✅ Must have proper capitalization
- ✅ Must be reasonable length (2-50 characters)

### Email Validation
- ✅ Must be valid email format
- ✅ Must not be editorial email
- ✅ Must not be system email
- ✅ Must have reasonable domain
- ✅ Must be consistent with name

### Role Validation
- ✅ Must be classified as referee role
- ✅ Must not be editorial communication
- ✅ Must not be system notification
- ✅ Must have referee context indicators
- ✅ Must have appropriate timeline events

### Timeline Validation
- ✅ Must have at least one meaningful event
- ✅ Events must be chronologically consistent
- ✅ Must have appropriate state transitions
- ✅ Must not contradict other evidence
- ✅ Must fit expected referee lifecycle

This foolproof design will eliminate false positives, merge duplicates, and provide only high-confidence referee identifications with complete validation.