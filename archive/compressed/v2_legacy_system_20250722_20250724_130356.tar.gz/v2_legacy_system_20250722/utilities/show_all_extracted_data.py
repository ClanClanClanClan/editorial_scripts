#!/usr/bin/env python3
"""
Show absolutely all extracted data for both manuscripts
"""

import os
import sys
import json
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from editorial_assistant.extractors.scholarone import ScholarOneExtractor

def show_all_extracted_data():
    """Extract and show absolutely all data for both manuscripts."""
    print("🎯 Extracting ALL data for both manuscripts...")
    
    # Load production config
    try:
        with open('.env.production', 'r') as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    key, value = line.strip().split('=', 1)
                    os.environ[key] = value
    except FileNotFoundError:
        print("❌ No .env.production file found")
        return
    
    try:
        # Create extractor
        extractor = ScholarOneExtractor('MF')
        extractor.headless = True  # Run headless for speed
        
        # Extract manuscripts
        print("🔄 Extracting manuscripts...")
        result = extractor.extract()
        
        if not result.manuscripts:
            print("❌ No manuscripts found")
            return
        
        print(f"\n📋 Found {len(result.manuscripts)} manuscripts")
        print("="*100)
        
        # Show absolutely everything for each manuscript
        for i, manuscript in enumerate(result.manuscripts, 1):
            print(f"\n📄 MANUSCRIPT {i}: {manuscript.manuscript_id}")
            print("="*100)
            
            # Basic Information
            print("📋 BASIC INFORMATION:")
            print(f"  Manuscript ID: {manuscript.manuscript_id}")
            print(f"  Title: {manuscript.title}")
            print(f"  Status: {manuscript.status}")
            print(f"  Journal Code: {manuscript.journal_code}")
            
            # Enhanced Dates and Metadata
            if hasattr(manuscript, 'submission_date'):
                print(f"  Submission Date: {manuscript.submission_date}")
            if hasattr(manuscript, 'last_updated'):
                print(f"  Last Updated: {manuscript.last_updated}")
            if hasattr(manuscript, 'due_date'):
                print(f"  Due Date: {manuscript.due_date}")
            
            # Authors (should be normalized)
            print(f"\n👥 AUTHORS ({len(manuscript.authors)}):")
            if manuscript.authors:
                for j, author in enumerate(manuscript.authors, 1):
                    print(f"  {j}. Name: '{author.name}'")
                    if hasattr(author, 'email') and author.email:
                        print(f"     Email: {author.email}")
                    if hasattr(author, 'institution') and author.institution:
                        print(f"     Institution: {author.institution}")
                    if hasattr(author, 'orcid') and author.orcid:
                        print(f"     ORCID: {author.orcid}")
                    
                    # Check normalization
                    if ',' in author.name:
                        print(f"     ⚠️  WARNING: Name not normalized (still in 'Last, First' format)")
                    else:
                        print(f"     ✅ Name properly normalized to 'First Last' format")
            else:
                print("  No authors found")
            
            # Available Documents
            print(f"\n📁 AVAILABLE DOCUMENTS:")
            if hasattr(manuscript, 'available_documents') and manuscript.available_documents:
                for doc_type, available in manuscript.available_documents.items():
                    status = "✅ Available" if available else "❌ Not available"
                    print(f"  {doc_type.upper()}: {status}")
            else:
                print("  No document availability information")
            
            # PDF Download
            print(f"\n📄 PDF DOWNLOAD:")
            if hasattr(manuscript, 'pdf_path') and manuscript.pdf_path:
                print(f"  ✅ PDF Path: {manuscript.pdf_path}")
                # Check if file exists
                if Path(manuscript.pdf_path).exists():
                    print(f"  ✅ PDF file confirmed on disk")
                else:
                    print(f"  ⚠️  PDF path recorded but file not found on disk")
            else:
                print(f"  ❌ No PDF downloaded")
            
            # Cover Letter
            print(f"\n📝 COVER LETTER:")
            if hasattr(manuscript, 'cover_letter') and manuscript.cover_letter:
                print(f"  ✅ Cover Letter Extracted ({len(manuscript.cover_letter)} characters)")
                print(f"  Content Preview: {manuscript.cover_letter[:300]}...")
                if len(manuscript.cover_letter) > 300:
                    print(f"  [Truncated - full content is {len(manuscript.cover_letter)} characters]")
            else:
                print(f"  ❌ No cover letter extracted")
            
            # Referees (should be normalized with emails and reports)
            print(f"\n🔍 REFEREES ({len(manuscript.referees)}):")
            if manuscript.referees:
                for j, referee in enumerate(manuscript.referees, 1):
                    print(f"\n  {j}. REFEREE #{j}:")
                    print(f"     Name: '{referee.name}'")
                    
                    # Check name normalization
                    if ',' in referee.name:
                        print(f"     ⚠️  WARNING: Referee name not normalized (still in 'Last, First' format)")
                    else:
                        print(f"     ✅ Referee name properly normalized to 'First Last' format")
                    
                    # Status and Institution
                    print(f"     Status: {referee.status}")
                    print(f"     Institution: {referee.institution}")
                    
                    # Email (extracted via popup)
                    if referee.email:
                        print(f"     ✅ Email: {referee.email}")
                    else:
                        print(f"     ❌ Email: Not extracted")
                    
                    # ORCID
                    if referee.orcid:
                        print(f"     ORCID: {referee.orcid}")
                    else:
                        print(f"     ORCID: Not available")
                    
                    # Review Report (extracted via review link)
                    if hasattr(referee, 'review_report') and referee.review_report:
                        print(f"     ✅ Review Report: Extracted ({len(referee.review_report)} characters)")
                        print(f"     Report Preview: {referee.review_report[:200]}...")
                    else:
                        print(f"     ❌ Review Report: Not extracted")
                    
                    # Additional referee data
                    if hasattr(referee, 'dates') and referee.dates:
                        print(f"     Dates: {referee.dates}")
                    if hasattr(referee, 'raw_data') and referee.raw_data:
                        print(f"     Raw Data Available: Yes")
            else:
                print("  No referees found")
            
            # Reviewer Statistics
            print(f"\n📊 REVIEWER STATISTICS:")
            if hasattr(manuscript, 'reviewer_stats') and manuscript.reviewer_stats:
                stats = manuscript.reviewer_stats
                print(f"  Active Selections: {stats.get('active_selections', 'N/A')}")
                print(f"  Invited: {stats.get('invited', 'N/A')}")
                print(f"  Agreed: {stats.get('agreed', 'N/A')}")
                print(f"  Declined: {stats.get('declined', 'N/A')}")
                print(f"  Returned: {stats.get('returned', 'N/A')}")
            else:
                print("  No reviewer statistics available")
            
            # Additional Metadata
            print(f"\n🔧 ADDITIONAL METADATA:")
            if hasattr(manuscript, '_category_url'):
                print(f"  Category URL: {manuscript._category_url}")
            
            # Check for any other attributes
            all_attrs = [attr for attr in dir(manuscript) if not attr.startswith('_') and not callable(getattr(manuscript, attr))]
            other_attrs = [attr for attr in all_attrs if attr not in [
                'manuscript_id', 'title', 'status', 'journal_code', 'authors', 'referees',
                'submission_date', 'last_updated', 'due_date', 'available_documents',
                'pdf_path', 'cover_letter', 'reviewer_stats'
            ]]
            
            if other_attrs:
                print(f"  Other Attributes: {', '.join(other_attrs)}")
                for attr in other_attrs:
                    value = getattr(manuscript, attr)
                    print(f"    {attr}: {value}")
            
            print("="*100)
        
        # Overall Summary
        print(f"\n📈 OVERALL EXTRACTION SUMMARY:")
        print(f"Total Manuscripts: {len(result.manuscripts)}")
        
        # Count various extractions
        total_authors = sum(len(m.authors) for m in result.manuscripts)
        total_referees = sum(len(m.referees) for m in result.manuscripts)
        
        normalized_authors = sum(1 for m in result.manuscripts for a in m.authors if ',' not in a.name)
        normalized_referees = sum(1 for m in result.manuscripts for r in m.referees if ',' not in r.name)
        
        extracted_emails = sum(1 for m in result.manuscripts for r in m.referees if r.email)
        extracted_pdfs = sum(1 for m in result.manuscripts if hasattr(m, 'pdf_path') and m.pdf_path)
        extracted_cover_letters = sum(1 for m in result.manuscripts if hasattr(m, 'cover_letter') and m.cover_letter)
        extracted_reports = sum(1 for m in result.manuscripts for r in m.referees if hasattr(r, 'review_report') and r.review_report)
        
        print(f"\nAuthors: {total_authors} total, {normalized_authors} normalized ({normalized_authors/total_authors*100:.1f}%)")
        print(f"Referees: {total_referees} total, {normalized_referees} normalized ({normalized_referees/total_referees*100:.1f}%)")
        print(f"Emails Extracted: {extracted_emails}/{total_referees} ({extracted_emails/total_referees*100:.1f}%)")
        print(f"PDFs Downloaded: {extracted_pdfs}/{len(result.manuscripts)} ({extracted_pdfs/len(result.manuscripts)*100:.1f}%)")
        print(f"Cover Letters: {extracted_cover_letters}/{len(result.manuscripts)} ({extracted_cover_letters/len(result.manuscripts)*100:.1f}%)")
        print(f"Review Reports: {extracted_reports}/{total_referees} ({extracted_reports/total_referees*100:.1f}%)")
        
        # Save detailed data to JSON for inspection
        detailed_data = []
        for manuscript in result.manuscripts:
            manuscript_dict = {
                'manuscript_id': manuscript.manuscript_id,
                'title': manuscript.title,
                'status': str(manuscript.status),
                'journal_code': manuscript.journal_code,
                'authors': [{'name': a.name} for a in manuscript.authors],
                'referees': []
            }
            
            for referee in manuscript.referees:
                referee_dict = {
                    'name': referee.name,
                    'status': referee.status,
                    'institution': referee.institution,
                    'email': referee.email,
                    'orcid': referee.orcid
                }
                if hasattr(referee, 'review_report') and referee.review_report:
                    referee_dict['review_report_length'] = len(referee.review_report)
                manuscript_dict['referees'].append(referee_dict)
            
            # Add other fields if present
            for attr in ['submission_date', 'last_updated', 'due_date', 'pdf_path', 'reviewer_stats']:
                if hasattr(manuscript, attr):
                    manuscript_dict[attr] = getattr(manuscript, attr)
            
            if hasattr(manuscript, 'cover_letter') and manuscript.cover_letter:
                manuscript_dict['cover_letter_length'] = len(manuscript.cover_letter)
            
            detailed_data.append(manuscript_dict)
        
        # Save to file
        with open('complete_extracted_data.json', 'w') as f:
            json.dump(detailed_data, f, indent=2, default=str)
        
        print(f"\n💾 Complete data saved to: complete_extracted_data.json")
        print(f"✅ EXTRACTION COMPLETE - All data shown above")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    show_all_extracted_data()