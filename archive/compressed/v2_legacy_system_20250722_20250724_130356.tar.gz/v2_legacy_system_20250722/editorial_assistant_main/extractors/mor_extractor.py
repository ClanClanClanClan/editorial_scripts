#!/usr/bin/env python3
"""
Mathematics of Operations Research (MOR) ScholarOne Extractor - Consolidated Version
Combines all MOR extraction functionality with Phase 1 & 2 improvements.
"""

import os
import sys
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import json
from pathlib import Path

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from bs4 import BeautifulSoup

from editorial_assistant.extractors.scholarone import ScholarOneExtractor
from editorial_assistant.core.data_models import JournalConfig
from editorial_assistant.core.unified_config import get_config_manager
from editorial_assistant.utils.email_verification import EmailVerificationManager

# Phase 3: Platform abstraction imports
from editorial_assistant.core.scholarone_platform import ScholarOnePlatform
from editorial_assistant.core.platform_extractor import UnifiedManuscript, UnifiedReferee, PlatformType

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class MORExtractor(ScholarOnePlatform):
    """
    Consolidated Mathematics of Operations Research extractor.
    Integrates all features from various MOR implementations.
    
    Phase 3: Now inherits from ScholarOnePlatform for unified interface.
    """
    
    def __init__(self, journal_code: str = 'MOR', **kwargs):
        """
        Initialize MOR extractor.
        
        Args:
            journal_code: Journal code (default 'MOR')
            **kwargs: Additional arguments passed to base class
        """
        # Initialize base class with platform abstraction
        super().__init__(journal_code, **kwargs)
        
        # MOR-specific configuration (backward compatibility)
        self._legacy_init(**kwargs)
        
        # Get enhanced configuration
        config_manager = get_config_manager()
        journal_config = config_manager.get_journal_config(journal_code)
        
        # Feature flags
        self.use_config_system = journal_config.is_feature_enabled('use_config_system')
        self.use_navigation_module = journal_config.is_feature_enabled('use_navigation_module')
        self.use_enhanced_timeline = journal_config.is_feature_enabled('use_enhanced_timeline')
        
        # Configuration values with fallbacks
        self.journal_url = journal_config.url or "https://mc.manuscriptcentral.com/mor"
        self.popup_wait_time = journal_config.get_timing('popup_wait', 6)
        self.page_navigation_wait = journal_config.get_timing('page_navigation', 5)
        
        # Categories - MOR has 7 categories vs MF's 6
        self.categories = journal_config.get_categories() or [
            "Awaiting Reviewer Selection",
            "Awaiting Reviewer Invitation",
            "Overdue Reviewer Response",
            "Awaiting Reviewer Assignment", 
            "Awaiting Reviewer Reports",
            "Overdue Reviewer Reports",
            "Awaiting AE Recommendation"
        ]
        
        # Staff to exclude - MOR specific
        self.staff_to_exclude = [
            "Editor Name",
            "Name Editor",
            "Staff One",
            "One Staff",
            "Staff Two",
            "Two Staff"
        ]
        
        # Cache for referee data
        self.referee_cache = {}
        
        logger.info(f"MOR Extractor initialized - Config: {self.use_config_system}, "
                   f"Navigation: {self.use_navigation_module}, "
                   f"Timeline: {self.use_enhanced_timeline}")
    
    def _legacy_init(self, **kwargs):
        """Initialize legacy MOR-specific settings for backward compatibility."""
        # Get enhanced configuration
        config_manager = get_config_manager()
        mor_config = config_manager.get_journal_config('MOR')
        
        # Legacy browser setup (will be handled by platform base)
        self.headless = kwargs.get('headless', True)
        
        # Legacy feature flags (Phase 3 integration)
        self.use_config_system = mor_config.is_feature_enabled('use_config_system')
        self.use_navigation_module = mor_config.is_feature_enabled('use_navigation_module')
        self.use_enhanced_timeline = mor_config.is_feature_enabled('use_enhanced_timeline')
        
        # Email verification setup
        self.email_manager = EmailVerificationManager()
    
    def _get_platform_categories(self) -> List[str]:
        """Override: MOR-specific categories (7 categories vs MF's 6)."""
        return [
            "Awaiting Reviewer Selection",
            "Awaiting Reviewer Assignment", 
            "Awaiting Reviewer Scores",
            "Awaiting AE Recommendation",
            "Awaiting EIC Decision",
            "Reviews Complete",
            "Overdue Reviews"  # MOR has this extra category
        ]
    
    def _get_staff_exclusions(self) -> List[str]:
        """Override: MOR-specific staff exclusions."""
        return [
            "Editorial Office",
            "Managing Editor",
            "Editor-in-Chief", 
            "Associate Editor",
            "Editorial Assistant",
            "MOR Editorial Office",
            "Mathematics of Operations Research Editorial Office",
            "Operations Research Editorial Office"
        ]
    
    def _extract_manuscripts_for_category(self, category: str, limit: Optional[int] = None) -> List[UnifiedManuscript]:
        """Override: Extract manuscripts from MOR category."""
        manuscripts = []
        
        try:
            self.logger.info(f"Extracting manuscripts from MOR category: {category}")
            
            # Navigate to category (using legacy method)
            manuscript_ids = self.extract_manuscripts_for_category(self.driver, category)
            
            if limit:
                manuscript_ids = manuscript_ids[:limit]
            
            # Convert to unified manuscripts
            for manuscript_id in manuscript_ids:
                try:
                    manuscript = UnifiedManuscript(
                        manuscript_id=manuscript_id,
                        platform_id=manuscript_id,
                        journal_code=self.journal_code,
                        platform_type=PlatformType.SCHOLARONE,
                        category=category,
                        platform_data={'category': category}
                    )
                    manuscripts.append(manuscript)
                    
                except Exception as e:
                    self.logger.warning(f"Failed to create unified manuscript for {manuscript_id}: {e}")
            
            return manuscripts
            
        except Exception as e:
            self.logger.error(f"Failed to extract manuscripts from category {category}: {e}")
            return []
    
    def _extract_referees_for_manuscript(self, manuscript_id: str) -> List[UnifiedReferee]:
        """Override: Extract referees for MOR manuscript."""
        referees = []
        
        try:
            # Use legacy referee extraction method
            referee_data = self.extract_referee_data_for_manuscript(self.driver, manuscript_id)
            
            # Convert to unified referees
            for referee in referee_data:
                try:
                    unified_referee = UnifiedReferee(
                        name=referee.get('name', ''),
                        email=referee.get('email', ''),
                        manuscript_id=manuscript_id,
                        platform_type=PlatformType.SCHOLARONE,
                        affiliation=referee.get('affiliation'),
                        status=referee.get('status'),
                        platform_data=referee
                    )
                    referees.append(unified_referee)
                    
                except Exception as e:
                    self.logger.warning(f"Failed to create unified referee: {e}")
            
            return referees
            
        except Exception as e:
            self.logger.error(f"Failed to extract referees for manuscript {manuscript_id}: {e}")
            return []
    
    # Legacy method compatibility (maintain existing interface)
    def login(self, driver) -> bool:
        """
        Login to ScholarOne for MOR journal.
        Handles standard login and 2FA if needed.
        
        Args:
            driver: Selenium WebDriver instance
            
        Returns:
            bool: True if login successful
        """
        try:
            logger.info("Starting MOR login process...")
            
            # Navigate to journal URL
            driver.get(self.journal_url)
            time.sleep(self.page_navigation_wait)
            
            # Check if already logged in
            if self._is_logged_in(driver):
                logger.info("Already logged in")
                return True
            
            # Get credentials
            username = os.getenv('SCHOLARONE_USERNAME') or os.getenv('MOR_USERNAME')
            password = os.getenv('SCHOLARONE_PASSWORD') or os.getenv('MOR_PASSWORD')
            
            if not username or not password:
                logger.error("Missing credentials")
                return False
            
            # Find and fill login form
            try:
                username_field = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, "username"))
                )
                password_field = driver.find_element(By.ID, "password")
                
                username_field.clear()
                username_field.send_keys(username)
                password_field.clear()
                password_field.send_keys(password)
                
                # Submit form
                login_button = driver.find_element(By.ID, "loginButton")
                login_button.click()
                
                time.sleep(self.page_navigation_wait)
                
            except TimeoutException:
                logger.error("Login form not found")
                return False
            
            # Check for 2FA
            if self._needs_2fa(driver):
                if not self._handle_2fa(driver):
                    return False
            
            # Verify login success
            if self._is_logged_in(driver):
                logger.info("Login successful")
                return True
            else:
                logger.error("Login failed - unknown reason")
                return False
                
        except Exception as e:
            logger.error(f"Login error: {e}")
            return False
    
    def _is_logged_in(self, driver) -> bool:
        """Check if user is logged in."""
        try:
            # Look for logout link or user menu
            logout_indicators = [
                "//a[contains(@href, 'logout')]",
                "//a[contains(text(), 'Log Out')]",
                "//span[contains(@class, 'username')]"
            ]
            
            for indicator in logout_indicators:
                elements = driver.find_elements(By.XPATH, indicator)
                if elements:
                    return True
                    
            return False
            
        except Exception:
            return False
    
    def _needs_2fa(self, driver) -> bool:
        """Check if 2FA is required."""
        try:
            # Check for 2FA indicators
            page_source = driver.page_source.lower()
            return any(indicator in page_source for indicator in [
                'two-factor', 'verification code', '2fa',
                'authenticator', 'verify your identity'
            ])
        except Exception:
            return False
    
    def _handle_2fa(self, driver) -> bool:
        """
        Handle 2FA authentication.
        
        Args:
            driver: Selenium WebDriver instance
            
        Returns:
            bool: True if 2FA successful
        """
        logger.info("2FA required, waiting for manual input...")
        
        # Wait for user to complete 2FA (up to 5 minutes)
        max_wait = 300  # 5 minutes
        start_time = time.time()
        
        while time.time() - start_time < max_wait:
            if self._is_logged_in(driver):
                logger.info("2FA completed successfully")
                return True
            time.sleep(5)  # Check every 5 seconds
            
        logger.error("2FA timeout - manual intervention required")
        return False
    
    def navigate_to_ae_center(self, driver) -> bool:
        """
        Navigate to Associate Editor Center.
        
        Args:
            driver: Selenium WebDriver instance
            
        Returns:
            bool: True if navigation successful
        """
        try:
            logger.info("Navigating to AE Center...")
            
            # If using navigation module
            if self.use_navigation_module:
                # TODO: Integrate navigation module
                pass
            
            # Standard navigation
            ae_center_link = WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable((By.LINK_TEXT, "Associate Editor Center"))
            )
            ae_center_link.click()
            time.sleep(self.page_navigation_wait)
            
            logger.info("Successfully navigated to AE Center")
            return True
            
        except TimeoutException:
            logger.error("AE Center link not found")
            return False
        except Exception as e:
            logger.error(f"Navigation error: {e}")
            return False
    
    def extract_manuscripts_for_category(self, driver, category: str) -> List[Dict[str, Any]]:
        """
        Extract manuscripts for a specific category.
        
        Args:
            driver: Selenium WebDriver instance
            category: Category name
            
        Returns:
            List of manuscript dictionaries
        """
        manuscripts = []
        
        try:
            logger.info(f"Extracting manuscripts for category: {category}")
            
            # Navigate to category
            category_link = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.LINK_TEXT, category))
            )
            category_link.click()
            time.sleep(self.page_navigation_wait)
            
            # Extract manuscript table
            manuscript_table = driver.find_element(By.XPATH, "//table[contains(@class, 'pageContent')]")
            rows = manuscript_table.find_elements(By.XPATH, ".//tr[@class='trodd' or @class='treven']")
            
            for row in rows:
                try:
                    cells = row.find_elements(By.TAG_NAME, "td")
                    if len(cells) >= 4:
                        manuscript = {
                            'manuscript_id': cells[0].text.strip(),
                            'title': cells[1].text.strip(),
                            'authors': self._parse_authors(cells[2].text.strip()),
                            'status': cells[3].text.strip(),
                            'category': category,
                            'referees': []
                        }
                        manuscripts.append(manuscript)
                        
                except Exception as e:
                    logger.warning(f"Error parsing manuscript row: {e}")
                    continue
            
            logger.info(f"Found {len(manuscripts)} manuscripts in {category}")
            
        except Exception as e:
            logger.error(f"Error extracting manuscripts for {category}: {e}")
            
        return manuscripts
    
    def _parse_authors(self, authors_text: str) -> List[str]:
        """Parse authors from text."""
        if not authors_text:
            return []
            
        # Handle semicolon-separated format
        authors = []
        for author in authors_text.split(';'):
            author = author.strip()
            if author:
                # Convert "Last, First" to "First Last"
                if ',' in author:
                    parts = author.split(',', 1)
                    author = f"{parts[1].strip()} {parts[0].strip()}"
                authors.append(author)
                
        return authors
    
    def extract_referee_data_for_manuscript(self, driver, manuscript: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Extract referee data for a specific manuscript.
        
        Args:
            driver: Selenium WebDriver instance
            manuscript: Manuscript dictionary
            
        Returns:
            List of referee dictionaries
        """
        referees = []
        manuscript_id = manuscript['manuscript_id']
        
        try:
            logger.info(f"Extracting referees for {manuscript_id}")
            
            # Use Take Action to navigate to manuscript details
            if not self._execute_take_action(driver, manuscript_id):
                logger.warning(f"Failed to access details for {manuscript_id}")
                return referees
            
            # Wait for popup to load
            time.sleep(self.popup_wait_time)
            
            # Switch to popup window
            main_window = driver.current_window_handle
            windows = driver.window_handles
            
            for window in windows:
                if window != main_window:
                    driver.switch_to.window(window)
                    break
            
            # Extract referee information
            referees = self._extract_referees_from_popup(driver, manuscript)
            
            # Close popup and return to main window
            driver.close()
            driver.switch_to.window(main_window)
            
            logger.info(f"Found {len(referees)} referees for {manuscript_id}")
            
        except Exception as e:
            logger.error(f"Error extracting referees for {manuscript_id}: {e}")
            
        return referees
    
    def _execute_take_action(self, driver, manuscript_id: str) -> bool:
        """
        Execute Take Action for a manuscript.
        
        Args:
            driver: Selenium WebDriver instance
            manuscript_id: Manuscript ID
            
        Returns:
            bool: True if successful
        """
        try:
            # Find manuscript row
            manuscript_rows = driver.find_elements(By.XPATH, f"//tr[contains(.,'{manuscript_id}')]")
            
            if not manuscript_rows:
                logger.warning(f"No rows found for {manuscript_id}")
                return False
            
            # Find Take Action link
            for row in manuscript_rows:
                take_action_links = row.find_elements(By.XPATH, 
                    ".//a[contains(@href,'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
                
                if take_action_links:
                    link = take_action_links[0]
                    href = link.get_attribute('href')
                    
                    # Execute JavaScript
                    driver.execute_script(href.replace('javascript:', ''))
                    time.sleep(2)
                    
                    logger.info(f"Take Action executed for {manuscript_id}")
                    return True
            
            logger.warning(f"No Take Action link found for {manuscript_id}")
            return False
            
        except Exception as e:
            logger.error(f"Take Action failed for {manuscript_id}: {e}")
            return False
    
    def _extract_referees_from_popup(self, driver, manuscript: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Extract referee information from manuscript details popup.
        
        Args:
            driver: Selenium WebDriver instance
            manuscript: Manuscript dictionary
            
        Returns:
            List of referee dictionaries
        """
        referees = []
        
        try:
            # Find referee table
            referee_tables = driver.find_elements(By.XPATH, 
                "//table[contains(@class, 'pageContent') or contains(@id, 'referee')]")
            
            for table in referee_tables:
                rows = table.find_elements(By.XPATH, ".//tr")
                
                for row in rows:
                    cells = row.find_elements(By.TAG_NAME, "td")
                    
                    if len(cells) >= 3:
                        name = cells[0].text.strip()
                        
                        # Skip if excluded or if it's the author
                        if self._should_exclude_referee(name, manuscript):
                            continue
                        
                        referee = {
                            'name': name,
                            'email': self._extract_email_from_row(row),
                            'affiliation': cells[1].text.strip() if len(cells) > 1 else '',
                            'status': cells[2].text.strip() if len(cells) > 2 else '',
                            'manuscript_id': manuscript['manuscript_id'],
                            'manuscript_title': manuscript['title']
                        }
                        
                        # Extract timeline if enabled
                        if self.use_enhanced_timeline:
                            referee['timeline'] = self._extract_enhanced_timeline(driver, referee)
                        
                        referees.append(referee)
                        
        except Exception as e:
            logger.error(f"Error extracting referees from popup: {e}")
            
        return referees
    
    def _should_exclude_referee(self, name: str, manuscript: Dict[str, Any]) -> bool:
        """Check if referee should be excluded."""
        # Exclude staff
        if any(staff in name for staff in self.staff_to_exclude):
            return True
            
        # Exclude if referee is an author
        for author in manuscript.get('authors', []):
            if author.lower() in name.lower() or name.lower() in author.lower():
                return True
                
        return False
    
    def _extract_email_from_row(self, row) -> str:
        """Extract email from referee row."""
        try:
            # Look for email link
            email_links = row.find_elements(By.XPATH, ".//a[contains(@href, 'mailto:')]")
            if email_links:
                href = email_links[0].get_attribute('href')
                return href.replace('mailto:', '')
                
            # Look for email text pattern
            import re
            text = row.text
            email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
            matches = re.findall(email_pattern, text)
            if matches:
                return matches[0]
                
        except Exception:
            pass
            
        return ''
    
    def _extract_enhanced_timeline(self, driver, referee: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Extract enhanced timeline for referee (placeholder for full implementation).
        
        Args:
            driver: Selenium WebDriver instance
            referee: Referee dictionary
            
        Returns:
            List of timeline events
        """
        # TODO: Implement full enhanced timeline extraction
        # This would integrate the Gmail timeline functionality
        return []
    
    def extract_all_data(self, driver) -> Dict[str, Any]:
        """
        Extract all data for MOR journal.
        
        Args:
            driver: Selenium WebDriver instance
            
        Returns:
            Dictionary containing all extracted data
        """
        start_time = datetime.now()
        
        results = {
            'journal': 'MOR',
            'extraction_date': start_time.isoformat(),
            'manuscripts': [],
            'referees': [],
            'statistics': {}
        }
        
        try:
            # Login
            if not self.login(driver):
                logger.error("Login failed")
                return results
            
            # Navigate to AE Center
            if not self.navigate_to_ae_center(driver):
                logger.error("Failed to navigate to AE Center")
                return results
            
            # Extract manuscripts by category
            all_manuscripts = []
            for category in self.categories:
                manuscripts = self.extract_manuscripts_for_category(driver, category)
                all_manuscripts.extend(manuscripts)
            
            # Extract referee data for each manuscript
            all_referees = []
            for manuscript in all_manuscripts:
                referees = self.extract_referee_data_for_manuscript(driver, manuscript)
                manuscript['referees'] = referees
                all_referees.extend(referees)
            
            # Compile results
            results['manuscripts'] = all_manuscripts
            results['referees'] = self._deduplicate_referees(all_referees)
            
            # Calculate statistics
            results['statistics'] = {
                'total_manuscripts': len(all_manuscripts),
                'total_referees': len(results['referees']),
                'manuscripts_by_category': self._count_by_category(all_manuscripts),
                'extraction_duration': (datetime.now() - start_time).total_seconds()
            }
            
            logger.info(f"Extraction complete: {results['statistics']}")
            
        except Exception as e:
            logger.error(f"Extraction failed: {e}")
            results['error'] = str(e)
            
        return results
    
    def _deduplicate_referees(self, referees: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Remove duplicate referees based on name and email."""
        seen = set()
        unique_referees = []
        
        for referee in referees:
            key = (referee.get('name', '').lower(), referee.get('email', '').lower())
            if key not in seen and key[0]:  # Skip empty names
                seen.add(key)
                unique_referees.append(referee)
                
        return unique_referees
    
    def _count_by_category(self, manuscripts: List[Dict[str, Any]]) -> Dict[str, int]:
        """Count manuscripts by category."""
        counts = {}
        for manuscript in manuscripts:
            category = manuscript.get('category', 'Unknown')
            counts[category] = counts.get(category, 0) + 1
        return counts


# Backward compatibility function
def extract_mor_data(username: Optional[str] = None, 
                    password: Optional[str] = None,
                    headless: bool = True) -> Dict[str, Any]:
    """
    Backward compatible extraction function.
    
    Args:
        username: ScholarOne username (optional, uses env if not provided)
        password: ScholarOne password (optional, uses env if not provided)
        headless: Run browser in headless mode
        
    Returns:
        Dictionary containing extraction results
    """
    # Set credentials if provided
    if username:
        os.environ['SCHOLARONE_USERNAME'] = username
    if password:
        os.environ['SCHOLARONE_PASSWORD'] = password
    
    # Initialize extractor
    extractor = MORExtractor()
    
    # Setup driver
    options = webdriver.ChromeOptions()
    if headless:
        options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    
    driver = webdriver.Chrome(options=options)
    
    try:
        # Extract data
        results = extractor.extract_all_data(driver)
        return results
        
    finally:
        driver.quit()


if __name__ == "__main__":
    # Test the consolidated extractor
    logging.basicConfig(level=logging.INFO)
    
    print("Testing MOR Consolidated Extractor...")
    print("-" * 60)
    
    # Quick test
    extractor = MORExtractor()
    print(f"✅ Extractor initialized")
    print(f"   - Journal URL: {extractor.journal_url}")
    print(f"   - Categories: {len(extractor.categories)} (MOR has 7)")
    print(f"   - Config System: {extractor.use_config_system}")
    print(f"   - Navigation Module: {extractor.use_navigation_module}")
    print(f"   - Enhanced Timeline: {extractor.use_enhanced_timeline}")
    
    print("\n✅ Consolidated MOR Extractor ready for use!")