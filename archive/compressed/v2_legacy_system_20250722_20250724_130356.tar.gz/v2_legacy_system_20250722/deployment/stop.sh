#!/bin/bash
# Production Stop Script

echo "🛑 Stopping Editorial Scripts System..."

# Find and stop processes
pkill -f "ultrathink_production_main.py"
pkill -f "ultrathink_production_monitoring"

echo "✅ All processes stopped"
