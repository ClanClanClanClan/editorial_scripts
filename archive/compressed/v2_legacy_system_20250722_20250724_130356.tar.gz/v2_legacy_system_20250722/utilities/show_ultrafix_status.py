#!/usr/bin/env python3
"""
Show current ULTRAFIX status and debug files
"""

import os
import sys
from pathlib import Path
from datetime import datetime

def show_ultrafix_status():
    """Show current ULTRAFIX status."""
    print("🔍 ULTRAFIX STATUS REPORT")
    print("=" * 50)
    
    # Check for debug files
    debug_files = list(Path('.').glob('debug_*click*.html'))
    if debug_files:
        print(f"✅ Debug files found: {len(debug_files)}")
        for file in debug_files:
            stat = file.stat()
            modified = datetime.fromtimestamp(stat.st_mtime)
            size = stat.st_size
            print(f"   📄 {file.name}")
            print(f"      Size: {size:,} bytes")
            print(f"      Modified: {modified.strftime('%Y-%m-%d %H:%M:%S')}")
            print()
        
        # Check if we have both before and after files
        before_files = [f for f in debug_files if 'before_click' in f.name]
        failed_files = [f for f in debug_files if 'failed_click' in f.name]
        
        print(f"📊 Debug File Analysis:")
        print(f"   Before click files: {len(before_files)}")
        print(f"   Failed click files: {len(failed_files)}")
        
        if before_files and not failed_files:
            print("🎯 STATUS: ULTRAFIX Take Action was attempted but didn't create failure debug files")
            print("   This could mean:")
            print("   1. ✅ Take Action clicking succeeded!")
            print("   2. ⏳ Still in progress (stuck in processing)")
            print("   3. 🔄 Waiting for page navigation")
        elif failed_files:
            print("❌ STATUS: ULTRAFIX Take Action failed")
            print("   Check the failed_click files for details")
        else:
            print("🔍 STATUS: Unknown - unexpected debug file pattern")
    else:
        print("❌ No debug files found")
        print("   ULTRAFIX Take Action method was not called")
    
    # Check for any extraction result files
    result_files = list(Path('.').glob('*extraction*.json'))
    if result_files:
        print(f"\n📄 Extraction result files: {len(result_files)}")
        for file in sorted(result_files, key=lambda x: x.stat().st_mtime, reverse=True)[:3]:
            stat = file.stat()
            modified = datetime.fromtimestamp(stat.st_mtime)
            print(f"   📄 {file.name} ({modified.strftime('%Y-%m-%d %H:%M:%S')})")
    
    # Check current patch status
    backup_file = Path("editorial_assistant/extractors/scholarone.py.backup_immediate_ultrafix")
    if backup_file.exists():
        print(f"\n🔧 PATCH STATUS: ✅ Immediate ULTRAFIX patch is applied")
        print(f"   Backup available: {backup_file}")
    else:
        print(f"\n🔧 PATCH STATUS: ❌ No immediate ULTRAFIX patch detected")
    
    print("\n" + "=" * 50)

if __name__ == "__main__":
    show_ultrafix_status()