#!/usr/bin/env python3
"""
SIAM Platform Base - Common functionality for SICON and SIFIN extractors.

This module provides the shared SIAM platform implementation,
consolidating common ORCID authentication, timeline integration, and extraction patterns.

Phase 3: System Integration - SIAM Platform Abstraction
"""

from typing import Dict, List, Optional, Any
from datetime import datetime
import time
import os

from .platform_extractor import (
    PlatformExtractor, 
    PlatformType, 
    AuthenticationType,
    UnifiedManuscript,
    UnifiedReferee
)
from ..core.exceptions import ExtractionError, ConfigurationError
from ..core.browser_manager import BrowserManager
from ..core.unified_config import get_config_manager


class SIAMPlatform(PlatformExtractor):
    """
    Base class for SIAM platform extractors (SICON, SIFIN).
    
    Implements common SIAM ORCID authentication, timeline integration,
    and extraction workflows shared between SICON and SIFIN journals.
    """
    
    def _determine_platform_type(self) -> PlatformType:
        """SIAM platform type."""
        return PlatformType.SIAM
    
    def _determine_auth_type(self) -> AuthenticationType:
        """SIAM uses ORCID authentication."""
        return AuthenticationType.ORCID
    
    def _initialize_platform_components(self, **kwargs):
        """Initialize SIAM-specific components."""
        
        # Browser configuration (SIFIN requires Firefox for Cloudflare bypass)
        self.headless = kwargs.get('headless', True)
        self.browser_type = self._get_required_browser()
        self.browser_manager = BrowserManager(headless=self.headless)
        
        # SIAM platform URLs (will be overridden by subclasses)
        self.journal_url = self._get_journal_url()
        self.site_prefix = self._get_site_prefix()
        
        # Common SIAM timings (different from ScholarOne)
        config_manager = get_config_manager()
        self.popup_wait_time = config_manager.get_global_setting('popup_wait', 1)  # SIAM: 1 second
        self.page_navigation_wait = config_manager.get_global_setting('page_navigation', 5)
        self.element_wait_time = config_manager.get_global_setting('element_wait', 3)
        self.redirect_timeout = config_manager.get_global_setting('redirect_timeout', 30)
        
        # SIAM-specific workflow steps
        self.workflow_steps = self._get_platform_workflow()
        
        # Email timeline integration settings
        self.enable_timeline_integration = config_manager.is_feature_enabled('timeline_integration', self.journal_code)
        self.timeline_validation_enabled = config_manager.is_feature_enabled('timeline_validation', self.journal_code)
        
        # Authentication state
        self._is_authenticated = False
        self._current_session = None
        self._orcid_token = None
        
        self.logger.info(f"SIAM platform initialized - URL: {self.journal_url}, "
                        f"Browser: {self.browser_type}, Timeline: {self.enable_timeline_integration}")
    
    def _get_required_browser(self) -> str:
        """Get the required browser type for this SIAM journal."""
        # SIFIN requires Firefox for Cloudflare bypass, SICON uses Chrome
        browser_map = {
            'SIFIN': 'firefox',  # Required for Cloudflare bypass
            'SICON': 'chrome'    # Default Chrome
        }
        
        return browser_map.get(self.journal_code, 'chrome')
    
    def _get_journal_url(self) -> str:
        """Get the journal-specific URL (must be implemented by subclasses)."""
        url_map = {
            'SICON': 'https://sicon.siam.org/cgi-bin/main.plex',
            'SIFIN': 'http://sifin.siam.org/'  # Note: HTTP for SIFIN
        }
        
        if self.journal_code in url_map:
            return url_map[self.journal_code]
        else:
            raise ConfigurationError(f"Unknown journal code for SIAM: {self.journal_code}")
    
    def _get_site_prefix(self) -> str:
        """Get the site prefix for URL construction."""
        return self.journal_url.split('/cgi-bin')[0] if '/cgi-bin' in self.journal_url else self.journal_url
    
    def _get_platform_workflow(self) -> List[str]:
        """Get platform-specific workflow steps."""
        # Standard SIAM workflow - can be overridden by subclasses
        return [
            "Authentication",
            "Navigation to Review System", 
            "Manuscript List Extraction",
            "Individual Manuscript Processing",
            "Referee Data Extraction",
            "Timeline Integration",
            "Data Validation",
            "Result Compilation"
        ]
    
    def authenticate(self, **credentials) -> bool:
        """
        Authenticate with SIAM platform using ORCID.
        
        Args:
            **credentials: ORCID credentials or session parameters
        
        Returns:
            bool: True if authentication successful
        """
        try:
            self.logger.info(f"Starting SIAM ORCID authentication for {self.journal_code}")
            
            # Initialize browser session
            self.driver = self.browser_manager.get_driver()
            
            # Handle Cloudflare protection for SIFIN
            if self.journal_code == 'SIFIN':
                self._handle_cloudflare_protection()
            
            # Navigate to journal URL
            self.driver.get(self.journal_url)
            time.sleep(self.page_navigation_wait)
            
            # Perform ORCID authentication
            success = self._perform_orcid_login(**credentials)
            
            if success:
                self._is_authenticated = True
                self.logger.info(f"ORCID authentication successful for {self.journal_code}")
                return True
            else:
                raise ExtractionError("ORCID authentication failed")
                
        except Exception as e:
            self.logger.error(f"Authentication failed for {self.journal_code}: {e}")
            raise ExtractionError(f"SIAM authentication failed: {e}") from e
    
    def _handle_cloudflare_protection(self):
        """Handle Cloudflare protection (required for SIFIN)."""
        if self.journal_code == 'SIFIN':
            self.logger.info("Handling Cloudflare protection for SIFIN")
            # Firefox with specific settings handles Cloudflare better
            # Additional wait time for Cloudflare checks
            time.sleep(5)
    
    def _perform_orcid_login(self, **credentials) -> bool:
        """
        Perform ORCID authentication flow.
        
        This method handles the SIAM ORCID login process.
        """
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        
        try:
            # Look for ORCID login elements
            wait = WebDriverWait(self.driver, 10)
            
            # Check if already logged in
            if self._is_logged_in():
                return True
            
            # Look for ORCID login button/link
            orcid_elements = self.driver.find_elements(By.PARTIAL_LINK_TEXT, "ORCID")
            if not orcid_elements:
                orcid_elements = self.driver.find_elements(By.PARTIAL_LINK_TEXT, "Sign in")
            
            if orcid_elements:
                orcid_elements[0].click()
                time.sleep(self.page_navigation_wait)
            
            # Handle ORCID credentials if provided
            orcid_username = credentials.get('orcid_username') or os.environ.get('ORCID_USERNAME')
            orcid_password = credentials.get('orcid_password') or os.environ.get('ORCID_PASSWORD')
            
            if orcid_username and orcid_password:
                # Fill ORCID login form if present
                username_fields = self.driver.find_elements(By.NAME, "userId")
                if not username_fields:
                    username_fields = self.driver.find_elements(By.ID, "username")
                
                if username_fields:
                    username_fields[0].clear()
                    username_fields[0].send_keys(orcid_username)
                    
                    password_fields = self.driver.find_elements(By.NAME, "password")
                    if password_fields:
                        password_fields[0].clear()
                        password_fields[0].send_keys(orcid_password)
                        
                        # Submit form
                        submit_buttons = self.driver.find_elements(By.XPATH, "//input[@type='submit']")
                        if submit_buttons:
                            submit_buttons[0].click()
                            time.sleep(self.redirect_timeout)
            
            # Verify authentication success
            return self._is_logged_in()
            
        except Exception as e:
            self.logger.error(f"ORCID login process failed: {e}")
            return False
    
    def _is_logged_in(self) -> bool:
        """Check if successfully logged into SIAM platform."""
        try:
            # Look for SIAM platform logged-in indicators
            page_text = self.driver.page_source.lower()
            logged_in_indicators = [
                'reviewer',
                'manuscript',
                'review',
                'dashboard',
                'logout'
            ]
            
            return any(indicator in page_text for indicator in logged_in_indicators)
            
        except:
            return False
    
    def extract_manuscripts(self, **filters) -> List[UnifiedManuscript]:
        """
        Extract manuscripts from SIAM platform.
        
        Args:
            **filters: limit (int) - maximum manuscripts to extract
                      status_filter (str) - filter by manuscript status
        
        Returns:
            List[UnifiedManuscript]: Unified manuscript objects
        """
        if not self._is_authenticated:
            raise ExtractionError("Must authenticate before extracting manuscripts")
        
        limit = filters.get('limit', None)
        status_filter = filters.get('status_filter', None)
        
        self.logger.info(f"Extracting manuscripts from SIAM platform (limit: {limit})")
        
        try:
            # Extract manuscript IDs
            manuscript_ids = self._extract_manuscript_ids()
            
            if limit:
                manuscript_ids = manuscript_ids[:limit]
            
            # Extract details for each manuscript
            manuscripts = []
            for manuscript_id in manuscript_ids:
                try:
                    manuscript = self._extract_manuscript_details(manuscript_id)
                    if manuscript and (not status_filter or manuscript.status == status_filter):
                        manuscripts.append(manuscript)
                        
                except Exception as e:
                    self.logger.warning(f"Failed to extract details for manuscript {manuscript_id}: {e}")
            
            self.logger.info(f"Extracted {len(manuscripts)} manuscripts from SIAM platform")
            return manuscripts
            
        except Exception as e:
            self.logger.error(f"Failed to extract manuscripts: {e}")
            raise ExtractionError(f"Manuscript extraction failed: {e}") from e
    
    def _extract_manuscript_ids(self) -> List[str]:
        """Extract manuscript IDs from the platform (implemented by subclasses)."""
        raise NotImplementedError("Subclasses must implement manuscript ID extraction")
    
    def _extract_manuscript_details(self, manuscript_id: str) -> Optional[UnifiedManuscript]:
        """Extract detailed information for a manuscript (implemented by subclasses)."""
        raise NotImplementedError("Subclasses must implement manuscript detail extraction")
    
    def extract_referees(self, manuscript_id: str) -> List[UnifiedReferee]:
        """
        Extract referee information for a specific manuscript.
        
        Args:
            manuscript_id: SIAM manuscript identifier
            
        Returns:
            List[UnifiedReferee]: Unified referee objects
        """
        if not self._is_authenticated:
            raise ExtractionError("Must authenticate before extracting referees")
        
        try:
            self.logger.debug(f"Extracting referees for manuscript {manuscript_id}")
            
            # Extract referees from web interface
            web_referees = self._extract_referees_from_web(manuscript_id)
            
            # Integrate with email timeline if enabled
            if self.enable_timeline_integration:
                enhanced_referees = self._integrate_email_timeline(manuscript_id, web_referees)
                return enhanced_referees
            else:
                return web_referees
                
        except Exception as e:
            self.logger.error(f"Failed to extract referees for manuscript {manuscript_id}: {e}")
            raise ExtractionError(f"Referee extraction failed: {e}") from e
    
    def _extract_referees_from_web(self, manuscript_id: str) -> List[UnifiedReferee]:
        """Extract referees from web interface (implemented by subclasses)."""
        raise NotImplementedError("Subclasses must implement web referee extraction")
    
    def _integrate_email_timeline(self, manuscript_id: str, web_referees: List[UnifiedReferee]) -> List[UnifiedReferee]:
        """Integrate email timeline data with web-extracted referee information."""
        if not self.enable_timeline_integration:
            return web_referees
        
        try:
            self.logger.debug(f"Integrating email timeline for manuscript {manuscript_id}")
            
            # This would integrate with the Gmail timeline system
            # For now, return web referees (timeline integration is a separate component)
            return web_referees
            
        except Exception as e:
            self.logger.warning(f"Timeline integration failed for manuscript {manuscript_id}: {e}")
            return web_referees
    
    def _remove_cookie_banner(self):
        """Remove cookie consent banners that may interfere with navigation."""
        try:
            from selenium.webdriver.common.by import By
            
            # Common cookie banner selectors
            cookie_selectors = [
                "button[class*='cookie']",
                "button[class*='consent']", 
                "button[class*='accept']",
                ".cookie-banner button",
                "#cookie-consent button"
            ]
            
            for selector in cookie_selectors:
                try:
                    elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        if element.is_displayed():
                            element.click()
                            time.sleep(1)
                            break
                except:
                    continue
                    
        except Exception as e:
            self.logger.debug(f"Cookie banner removal failed: {e}")
    
    def _handle_post_login_popups(self):
        """Handle any popups that appear after login."""
        try:
            time.sleep(self.popup_wait_time)
            
            # Look for common popup close buttons
            from selenium.webdriver.common.by import By
            
            close_selectors = [
                "button[class*='close']",
                "button[class*='dismiss']",
                ".modal button",
                "[role='dialog'] button"
            ]
            
            for selector in close_selectors:
                try:
                    elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        if element.is_displayed():
                            element.click()
                            time.sleep(1)
                except:
                    continue
                    
        except Exception as e:
            self.logger.debug(f"Post-login popup handling failed: {e}")
    
    def cleanup(self):
        """Clean up SIAM platform resources."""
        super().cleanup()
        
        if hasattr(self, 'driver'):
            try:
                self.driver.quit()
                self.logger.info("Browser session closed")
            except:
                pass
        
        if hasattr(self, 'browser_manager'):
            try:
                self.browser_manager.cleanup()
            except:
                pass
        
        self._is_authenticated = False
        self._orcid_token = None