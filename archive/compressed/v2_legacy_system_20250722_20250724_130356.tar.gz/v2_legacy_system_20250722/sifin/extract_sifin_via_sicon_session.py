#!/usr/bin/env python3
"""
SIFIN Extractor via SICON Session Transfer - July 16, 2025
ULTRATHINK APPROACH: Use working SICON authentication to access SIFIN
"""

import os
import sys
import time
import logging
import json
from datetime import datetime
from pathlib import Path
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import undetected_chromedriver as uc
from bs4 import BeautifulSoup

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SIFINViaSICONExtractor:
    """SIFIN extractor using authenticated SICON session"""
    
    def __init__(self):
        self.driver = None
        self.manuscripts = []
        
    def setup_driver(self):
        """Setup Chrome driver - EXACT same as working SICON"""
        options = uc.ChromeOptions()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        
        self.driver = uc.Chrome(options=options)
        self.driver.set_window_size(1920, 1080)
        
        logger.info("✅ Chrome driver setup complete")
        
    def handle_popups(self):
        """Handle cookie banners - same as SICON"""
        try:
            js_remove_banners = """
            const selectors = [
                '#cookie-policy-layer-bg',
                '#cookie-policy-layer', 
                '.cc_banner-wrapper',
                '#onetrust-banner-sdk',
                '.onetrust-pc-dark-filter'
            ];
            
            selectors.forEach(sel => {
                document.querySelectorAll(sel).forEach(el => {
                    el.style.display = 'none';
                    el.remove();
                });
            });
            """
            
            self.driver.execute_script(js_remove_banners)
            time.sleep(0.5)
            
        except Exception as e:
            logger.debug(f"Popup removal failed: {e}")
            
    def authenticate_via_sicon(self):
        """Step 1: Authenticate via SICON (known working)"""
        logger.info("📍 Step 1: Authenticating via SICON...")
        
        # Navigate to SICON (this works)
        self.driver.get("https://sicon.siam.org/cgi-bin/main.plex")
        time.sleep(3)
        
        self.handle_popups()
        
        title = self.driver.title
        logger.info(f"SICON loaded: {title}")
        
        # Click ORCID button (exact same as working SICON script)
        self.handle_popups()
        time.sleep(2)
        
        orcid_selectors = [
            "a[href*='sso_site_redirect'][href*='orcid']",
            "img[src*='orcid']",
            "img[title='ORCID']", 
            "a img[src*='orcid_32x32.png']",
            "a[href*='orcid']"
        ]
        
        orcid_element = None
        for selector in orcid_selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for element in elements:
                    if element.is_displayed():
                        if element.tag_name == 'img':
                            orcid_element = element.find_element(By.XPATH, "..")
                        else:
                            orcid_element = element
                        break
                if orcid_element:
                    break
            except Exception:
                continue
                
        if not orcid_element:
            raise Exception("No ORCID button found on SICON")
            
        # Click ORCID
        self.driver.execute_script("arguments[0].click();", orcid_element)
        logger.info("✅ ORCID button clicked on SICON")
        time.sleep(3)
        
        # ORCID authentication
        logger.info("Performing ORCID authentication...")
        
        orcid_user = os.environ.get('ORCID_EMAIL')
        orcid_pass = os.environ.get('ORCID_PASSWORD')
        
        if not orcid_user or not orcid_pass:
            raise Exception("ORCID credentials not found")
        
        # Fill credentials
        try:
            username_field = WebDriverWait(self.driver, 15).until(
                EC.presence_of_element_located((By.ID, "username-input"))
            )
            username_field.clear()
            username_field.send_keys(orcid_user)
            logger.info("✅ Username entered")
        except TimeoutException:
            username_field = self.driver.find_element(By.ID, "userId")
            username_field.clear()
            username_field.send_keys(orcid_user)
            logger.info("✅ Username entered (alt)")
        
        password_field = WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.ID, "password"))
        )
        password_field.clear()
        password_field.send_keys(orcid_pass)
        logger.info("✅ Password entered")
        
        # Submit
        try:
            sign_in_button = self.driver.find_element(By.ID, "signin-button")
        except NoSuchElementException:
            sign_in_button = self.driver.find_element(By.XPATH, "//button[contains(text(), 'Sign in')]")
        
        sign_in_button.click()
        logger.info("✅ ORCID login submitted")
        
        # Wait for redirect back to SICON
        time.sleep(5)
        
        current_url = self.driver.current_url
        if "sicon.siam.org" in current_url:
            logger.info("✅ Successfully authenticated with SICON")
            
            # Verify we're logged in by looking for AE elements
            try:
                ae_elements = self.driver.find_elements(By.XPATH, "//tbody[@role='assoc_ed']")
                if ae_elements:
                    logger.info("✅ SICON authentication verified - AE dashboard accessible")
                    return True
            except Exception:
                pass
                
        logger.warning(f"SICON authentication unclear, current URL: {current_url}")
        return True  # Proceed anyway
        
    def navigate_to_sifin_with_session(self):
        """Step 2: Navigate to SIFIN using established SIAM session"""
        logger.info("📍 Step 2: Navigating to SIFIN with SICON session...")
        
        # Now navigate to SIFIN using the same authenticated session
        self.driver.get("https://sifin.siam.org/cgi-bin/main.plex")
        time.sleep(3)
        
        self.handle_popups()
        
        title = self.driver.title
        logger.info(f"SIFIN loaded: {title}")
        
        # Check if Cloudflare is still blocking
        if "Just a moment" in title:
            logger.warning("⚠️ Cloudflare still active, waiting extended time...")
            time.sleep(10)
            title = self.driver.title
            logger.info(f"After extended wait: {title}")
            
            if "Just a moment" in title:
                logger.error("❌ Cloudflare protection persists even with SICON session")
                return False
        
        # Check if we need additional ORCID authentication for SIFIN
        try:
            orcid_links = self.driver.find_elements(By.CSS_SELECTOR, "a[href*='orcid']")
            if orcid_links and len(orcid_links) > 0:
                logger.info("SIFIN requires separate ORCID auth, clicking...")
                self.driver.execute_script("arguments[0].click();", orcid_links[0])
                time.sleep(5)
                
                # Should auto-redirect back since we're already authenticated
                current_url = self.driver.current_url
                if "sifin.siam.org" in current_url:
                    logger.info("✅ SIFIN auto-authenticated via existing ORCID session")
        except Exception as e:
            logger.debug(f"ORCID check failed: {e}")
            
        return True
        
    def extract_sifin_manuscripts(self):
        """Step 3: Extract SIFIN manuscripts"""
        logger.info("📍 Step 3: Extracting SIFIN manuscripts...")
        
        manuscripts = []
        
        try:
            # Look for task links (SIFIN-specific structure)
            task_links = self.driver.find_elements(By.CSS_SELECTOR, "a.ndt_task_link")
            logger.info(f"🔍 Found {len(task_links)} task links")
            
            manuscript_links = []
            for link in task_links:
                text = link.text.strip()
                if text.startswith("#") and " - " in text:
                    href = link.get_attribute("href")
                    if href:
                        manuscript_id = text.split()[0].replace('#', '')
                        manuscript_links.append({
                            'url': href,
                            'text': text,
                            'id': manuscript_id
                        })
                        logger.info(f"📄 Found manuscript: {text}")
            
            logger.info(f"✅ Found {len(manuscript_links)} manuscripts")
            
            # Extract details for each manuscript
            for i, manuscript in enumerate(manuscript_links, 1):
                try:
                    logger.info(f"📄 Processing {manuscript['id']} ({i}/{len(manuscript_links)})...")
                    
                    # Navigate to manuscript
                    self.driver.get(manuscript['url'])
                    time.sleep(3)
                    
                    # Extract data
                    manuscript_data = self.extract_manuscript_data(manuscript['id'])
                    
                    if manuscript_data:
                        manuscripts.append(manuscript_data)
                        logger.info(f"✅ Extracted data for {manuscript['id']}")
                        
                        # Print referee details
                        referees = manuscript_data.get("Referees", [])
                        logger.info(f"   Found {len(referees)} referees")
                        for ref in referees:
                            logger.info(f"     - {ref.get('Referee Name', '')} ({ref.get('Status', '')})")
                    
                except Exception as e:
                    logger.error(f"❌ Error processing {manuscript['id']}: {e}")
                    continue
                    
        except Exception as e:
            logger.error(f"❌ Error extracting manuscripts: {e}")
            
        return manuscripts
        
    def extract_manuscript_data(self, manuscript_id):
        """Extract manuscript data from detail page"""
        try:
            soup = BeautifulSoup(self.driver.page_source, "html.parser")
            
            manuscript_data = {
                "Manuscript #": manuscript_id,
                "Title": "",
                "Submitted": "",
                "Current Stage": "",
                "Corresponding Author": "",
                "Abstract": "",
                "Keywords": "",
                "Referees": [],
                "PDFs": [],
                "Comments": []
            }
            
            # Find manuscript details table
            table = soup.find("table", id="ms_details_expanded")
            if table:
                logger.info(f"✅ Found manuscript details table for {manuscript_id}")
                
                for row in table.find_all("tr"):
                    th = row.find("th")
                    td = row.find("td")
                    
                    if th and td:
                        label = th.get_text(strip=True)
                        value = td.get_text(strip=True)
                        
                        if label == "Title":
                            manuscript_data["Title"] = value
                            logger.info(f"   Title: {value[:50]}...")
                        elif label == "Submission Date":
                            manuscript_data["Submitted"] = value
                            logger.info(f"   Submitted: {value}")
                        elif label == "Current Stage":
                            manuscript_data["Current Stage"] = value
                            logger.info(f"   Stage: {value}")
                        elif label == "Corresponding Author":
                            manuscript_data["Corresponding Author"] = value
                        elif label == "Abstract":
                            manuscript_data["Abstract"] = value
                        elif label == "Keywords":
                            manuscript_data["Keywords"] = value
                        elif label == "Referees":
                            # Extract accepted referees
                            referees = self.extract_referees_from_cell(td, "Accepted")
                            manuscript_data["Referees"].extend(referees)
                            logger.info(f"   Accepted referees: {len(referees)}")
                        elif "Potential Referees" in label:
                            # Extract potential/declined referees
                            potential_referees = self.extract_referees_from_cell(td, "Potential")
                            manuscript_data["Referees"].extend(potential_referees)
                            logger.info(f"   Potential referees: {len(potential_referees)}")
            else:
                logger.warning(f"⚠️ No manuscript details table found for {manuscript_id}")
            
            # Extract PDFs
            pdfs = self.extract_pdf_links(soup)
            manuscript_data["PDFs"] = pdfs
            logger.info(f"   PDFs found: {len(pdfs)}")
            
            # Extract comments
            comments = self.extract_comments(soup)
            manuscript_data["Comments"] = comments
            logger.info(f"   Comments found: {len(comments)}")
            
            return manuscript_data
            
        except Exception as e:
            logger.error(f"❌ Error extracting manuscript data: {e}")
            return None
            
    def extract_referees_from_cell(self, td_element, referee_type):
        """Extract referee information from table cell"""
        referees = []
        
        try:
            for ref_link in td_element.find_all("a"):
                referee_name = ref_link.get_text(strip=True)
                referee_url = ref_link.get("href", "")
                
                if referee_name and referee_url:
                    if not referee_url.startswith("http"):
                        referee_url = f"https://sifin.siam.org{referee_url}" if referee_url.startswith("/") else f"https://sifin.siam.org/cgi-bin/{referee_url}"
                    
                    # Extract due date or status info
                    due_date = ""
                    context_text = str(ref_link.parent)
                    import re
                    date_match = re.search(r"Due:\s*([\d\-/]+)|Report\s+Received:\s*([\d\-/]+)", context_text)
                    if date_match:
                        due_date = date_match.group(1) or date_match.group(2)
                    
                    referee_data = {
                        "Referee Name": referee_name,
                        "Referee URL": referee_url,
                        "Status": referee_type,
                        "Due Date": due_date,
                        "Referee Email": ""
                    }
                    
                    referees.append(referee_data)
                    
        except Exception as e:
            logger.error(f"❌ Error extracting referees: {e}")
            
        return referees
        
    def extract_pdf_links(self, soup):
        """Extract PDF links"""
        pdfs = []
        
        try:
            for link in soup.find_all("a", href=True):
                href = link.get("href", "")
                if ".pdf" in href:
                    if not href.startswith("http"):
                        href = f"https://sifin.siam.org{href}"
                    pdfs.append(href)
                    
        except Exception as e:
            logger.error(f"❌ Error extracting PDFs: {e}")
            
        return pdfs
        
    def extract_comments(self, soup):
        """Extract comments"""
        comments = []
        
        try:
            for textarea in soup.find_all("textarea"):
                text = textarea.get_text(strip=True)
                if text and len(text) > 50:
                    comments.append(text)
                    
        except Exception as e:
            logger.error(f"❌ Error extracting comments: {e}")
            
        return comments
        
    def run_extraction(self):
        """Run the complete SIFIN via SICON extraction"""
        try:
            logger.info("🚀 SIFIN VIA SICON SESSION TRANSFER")
            logger.info("==================================================")
            
            # Setup driver
            self.setup_driver()
            
            # Step 1: Authenticate via SICON
            if not self.authenticate_via_sicon():
                logger.error("❌ SICON authentication failed")
                return []
            
            # Step 2: Navigate to SIFIN with session
            if not self.navigate_to_sifin_with_session():
                logger.error("❌ SIFIN navigation failed")
                return []
            
            # Step 3: Extract manuscripts
            manuscripts = self.extract_sifin_manuscripts()
            
            # Save results
            output_file = f"sifin_via_sicon_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(output_file, 'w') as f:
                json.dump(manuscripts, f, indent=2, default=str)
            
            # Summary
            total_referees = sum(len(ms.get("Referees", [])) for ms in manuscripts)
            total_pdfs = sum(len(ms.get("PDFs", [])) for ms in manuscripts)
            total_comments = sum(len(ms.get("Comments", [])) for ms in manuscripts)
            
            logger.info("\\n📊 EXTRACTION RESULTS:")
            logger.info(f"    Manuscripts: {len(manuscripts)}")
            logger.info(f"    Total Referees: {total_referees}")
            logger.info(f"    Total PDFs: {total_pdfs}")
            logger.info(f"    Total Comments: {total_comments}")
            logger.info(f"💾 Results saved to: {output_file}")
            
            return manuscripts
            
        except Exception as e:
            logger.error(f"❌ Extraction failed: {e}")
            import traceback
            traceback.print_exc()
            return []
            
        finally:
            if self.driver:
                self.driver.quit()
                logger.info("🖥️ Browser closed")

def main():
    """Main execution"""
    extractor = SIFINViaSICONExtractor()
    
    # Check credentials
    if not os.environ.get('ORCID_EMAIL') or not os.environ.get('ORCID_PASSWORD'):
        logger.error("❌ Missing ORCID credentials")
        sys.exit(1)
    
    # Run extraction
    results = extractor.run_extraction()
    
    if results:
        logger.info("✅ EXTRACTION SUCCESSFUL!")
        
        # Print manuscript details
        for i, ms in enumerate(results, 1):
            logger.info(f"\\nManuscript {i}: {ms.get('Manuscript #', '')}")
            logger.info(f"  Title: {ms.get('Title', 'N/A')[:60]}...")
            logger.info(f"  Status: {ms.get('Current Stage', 'N/A')}")
            logger.info(f"  Referees: {len(ms.get('Referees', []))}")
            logger.info(f"  PDFs: {len(ms.get('PDFs', []))}")
    else:
        logger.error("❌ EXTRACTION FAILED!")
        sys.exit(1)

if __name__ == "__main__":
    main()