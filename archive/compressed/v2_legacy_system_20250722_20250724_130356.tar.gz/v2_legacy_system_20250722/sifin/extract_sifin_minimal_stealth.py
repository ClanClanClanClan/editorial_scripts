#!/usr/bin/env python3
"""
SIFIN Minimal Stealth Extractor - July 16, 2025
ULTRATHINK APPROACH 2: Use minimal browser settings, no stealth
"""

import os
import sys
import time
import logging
import json
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from bs4 import BeautifulSoup

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SIFINMinimalStealthExtractor:
    """SIFIN extractor with minimal stealth - regular Chrome driver"""
    
    def __init__(self):
        self.driver = None
        self.manuscripts = []
        
    def setup_driver(self):
        """Setup regular Chrome driver with minimal options"""
        options = Options()
        
        # Only essential options
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--window-size=1920,1080')
        
        # NO stealth options - be completely transparent
        
        self.driver = webdriver.Chrome(options=options)
        
        logger.info("✅ Regular Chrome driver setup complete (minimal stealth)")
        
    def navigate_to_sifin(self):
        """Navigate to SIFIN with extended waits"""
        logger.info("📍 Step 1: Navigating to SIFIN (minimal stealth)...")
        
        self.driver.get("https://sifin.siam.org/cgi-bin/main.plex")
        time.sleep(5)
        
        title = self.driver.title
        logger.info(f"Initial page title: {title}")
        
        # If Cloudflare, wait much longer
        if "Just a moment" in title:
            logger.warning("⚠️ Cloudflare detected, waiting 20 seconds...")
            time.sleep(20)
            title = self.driver.title
            logger.info(f"After extended wait: {title}")
            
            if "Just a moment" in title:
                logger.warning("⚠️ Still Cloudflare, waiting another 15 seconds...")
                time.sleep(15)
                title = self.driver.title
                logger.info(f"After second wait: {title}")
        
        return "SIAM Journal on Financial Mathematics" in title or "sifin" in title.lower()
        
    def find_orcid_button(self):
        """Find ORCID button with multiple strategies"""
        logger.info("📍 Step 2: Finding ORCID button...")
        
        # Wait for page to stabilize
        time.sleep(3)
        
        # Try multiple selectors
        selectors = [
            "a[href*='orcid']",
            "a[href*='sso_site_redirect']",
            "img[src*='orcid']",
            "a[title*='ORCID']",
            "button[*='orcid']"
        ]
        
        for i, selector in enumerate(selectors, 1):
            try:
                logger.info(f"  Trying selector {i}: {selector}")
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                
                for element in elements:
                    if element.is_displayed():
                        logger.info(f"✅ Found ORCID element with selector {i}")
                        
                        # If it's an image, get parent
                        if element.tag_name == 'img':
                            element = element.find_element(By.XPATH, "..")
                        
                        return element
                        
            except Exception as e:
                logger.debug(f"  Selector {i} failed: {e}")
                
        # Try XPath approach
        try:
            logger.info("  Trying XPath approach...")
            elements = self.driver.find_elements(By.XPATH, "//a[contains(@href, 'orcid') or contains(text(), 'ORCID')]")
            
            for element in elements:
                if element.is_displayed():
                    logger.info("✅ Found ORCID element with XPath")
                    return element
                    
        except Exception as e:
            logger.debug(f"  XPath approach failed: {e}")
            
        return None
        
    def authenticate_orcid(self):
        """Perform ORCID authentication"""
        logger.info("📍 Step 3: ORCID authentication...")
        
        # Get credentials
        orcid_user = os.environ.get('ORCID_EMAIL')
        orcid_pass = os.environ.get('ORCID_PASSWORD')
        
        if not orcid_user or not orcid_pass:
            raise Exception("ORCID credentials not found")
        
        # Wait for ORCID page
        try:
            WebDriverWait(self.driver, 15).until(
                lambda driver: "orcid.org" in driver.current_url
            )
            logger.info("✅ Reached ORCID login page")
        except TimeoutException:
            logger.warning("⚠️ Not on ORCID page, proceeding anyway")
        
        # Fill username
        try:
            username_field = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "username-input"))
            )
            username_field.clear()
            username_field.send_keys(orcid_user)
            logger.info("✅ Username entered")
        except TimeoutException:
            try:
                username_field = self.driver.find_element(By.ID, "userId")
                username_field.clear()
                username_field.send_keys(orcid_user)
                logger.info("✅ Username entered (alternative)")
            except NoSuchElementException:
                logger.error("❌ Could not find username field")
                return False
        
        # Fill password
        try:
            password_field = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "password"))
            )
            password_field.clear()
            password_field.send_keys(orcid_pass)
            logger.info("✅ Password entered")
        except TimeoutException:
            logger.error("❌ Could not find password field")
            return False
        
        # Submit
        try:
            sign_in_button = self.driver.find_element(By.ID, "signin-button")
            sign_in_button.click()
            logger.info("✅ Login submitted")
        except NoSuchElementException:
            try:
                sign_in_button = self.driver.find_element(By.XPATH, "//button[contains(text(), 'Sign in')]")
                sign_in_button.click()
                logger.info("✅ Login submitted (alternative)")
            except NoSuchElementException:
                logger.error("❌ Could not find sign in button")
                return False
        
        # Wait for redirect
        time.sleep(5)
        
        current_url = self.driver.current_url
        if "sifin.siam.org" in current_url:
            logger.info("✅ Successfully returned to SIFIN")
            return True
        else:
            logger.warning(f"⚠️ Unexpected URL after login: {current_url}")
            return True  # Proceed anyway
        
    def extract_manuscripts(self):
        """Extract SIFIN manuscripts"""
        logger.info("📍 Step 4: Extracting manuscripts...")
        
        manuscripts = []
        
        try:
            # Wait for page to load
            time.sleep(3)
            
            # Look for task links
            task_links = self.driver.find_elements(By.CSS_SELECTOR, "a.ndt_task_link")
            logger.info(f"🔍 Found {len(task_links)} total task links")
            
            manuscript_links = []
            for link in task_links:
                text = link.text.strip()
                if text.startswith("#") and " - " in text:
                    href = link.get_attribute("href")
                    if href:
                        manuscript_id = text.split()[0].replace('#', '')
                        manuscript_links.append({
                            'url': href,
                            'text': text,
                            'id': manuscript_id
                        })
                        logger.info(f"📄 Found manuscript: {text}")
            
            logger.info(f"✅ Found {len(manuscript_links)} manuscripts")
            
            # Extract details for each manuscript
            for i, manuscript in enumerate(manuscript_links, 1):
                try:
                    logger.info(f"📄 Processing {manuscript['id']} ({i}/{len(manuscript_links)})...")
                    
                    # Navigate to manuscript
                    self.driver.get(manuscript['url'])
                    time.sleep(3)
                    
                    # Extract basic data
                    manuscript_data = self.extract_basic_data(manuscript['id'])
                    
                    if manuscript_data:
                        manuscripts.append(manuscript_data)
                        logger.info(f"✅ Extracted data for {manuscript['id']}")
                    
                except Exception as e:
                    logger.error(f"❌ Error processing {manuscript['id']}: {e}")
                    continue
                    
        except Exception as e:
            logger.error(f"❌ Error extracting manuscripts: {e}")
            
        return manuscripts
        
    def extract_basic_data(self, manuscript_id):
        """Extract basic manuscript data"""
        try:
            soup = BeautifulSoup(self.driver.page_source, "html.parser")
            
            manuscript_data = {
                "Manuscript #": manuscript_id,
                "Title": "",
                "Submitted": "",
                "Current Stage": "",
                "Referees": [],
                "PDFs": []
            }
            
            # Look for manuscript details table
            table = soup.find("table", id="ms_details_expanded")
            if table:
                logger.info(f"✅ Found manuscript details table")
                
                for row in table.find_all("tr"):
                    th = row.find("th")
                    td = row.find("td")
                    
                    if th and td:
                        label = th.get_text(strip=True)
                        value = td.get_text(strip=True)
                        
                        if label == "Title":
                            manuscript_data["Title"] = value
                            logger.info(f"   Title: {value[:50]}...")
                        elif label == "Submission Date":
                            manuscript_data["Submitted"] = value
                        elif label == "Current Stage":
                            manuscript_data["Current Stage"] = value
                        elif label == "Referees":
                            # Count referee links
                            ref_links = td.find_all("a")
                            for ref_link in ref_links:
                                ref_name = ref_link.get_text(strip=True)
                                if ref_name:
                                    manuscript_data["Referees"].append({
                                        "Referee Name": ref_name,
                                        "Status": "Accepted"
                                    })
                            logger.info(f"   Referees: {len(manuscript_data['Referees'])}")
            
            # Look for PDFs
            for link in soup.find_all("a", href=True):
                href = link.get("href", "")
                if ".pdf" in href:
                    if not href.startswith("http"):
                        href = f"https://sifin.siam.org{href}"
                    manuscript_data["PDFs"].append(href)
            
            logger.info(f"   PDFs: {len(manuscript_data['PDFs'])}")
            
            return manuscript_data
            
        except Exception as e:
            logger.error(f"❌ Error extracting basic data: {e}")
            return None
        
    def run_extraction(self):
        """Run the complete SIFIN minimal stealth extraction"""
        try:
            logger.info("🚀 SIFIN MINIMAL STEALTH EXTRACTION")
            logger.info("==================================================")
            
            # Setup regular Chrome driver
            self.setup_driver()
            
            # Step 1: Navigate to SIFIN
            if not self.navigate_to_sifin():
                logger.error("❌ Failed to navigate to SIFIN")
                return []
            
            # Step 2: Find ORCID button
            orcid_button = self.find_orcid_button()
            if not orcid_button:
                logger.error("❌ No ORCID button found")
                return []
            
            # Click ORCID button
            try:
                orcid_button.click()
                logger.info("✅ ORCID button clicked")
                time.sleep(3)
            except Exception as e:
                logger.error(f"❌ Failed to click ORCID button: {e}")
                return []
            
            # Step 3: Authenticate
            if not self.authenticate_orcid():
                logger.error("❌ ORCID authentication failed")
                return []
            
            # Step 4: Extract manuscripts
            manuscripts = self.extract_manuscripts()
            
            # Save results
            output_file = f"sifin_minimal_stealth_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(output_file, 'w') as f:
                json.dump(manuscripts, f, indent=2, default=str)
            
            # Summary
            total_referees = sum(len(ms.get("Referees", [])) for ms in manuscripts)
            total_pdfs = sum(len(ms.get("PDFs", [])) for ms in manuscripts)
            
            logger.info("\\n📊 EXTRACTION RESULTS:")
            logger.info(f"    Manuscripts: {len(manuscripts)}")
            logger.info(f"    Total Referees: {total_referees}")
            logger.info(f"    Total PDFs: {total_pdfs}")
            logger.info(f"💾 Results saved to: {output_file}")
            
            return manuscripts
            
        except Exception as e:
            logger.error(f"❌ Extraction failed: {e}")
            import traceback
            traceback.print_exc()
            return []
            
        finally:
            if self.driver:
                self.driver.quit()
                logger.info("🖥️ Browser closed")

def main():
    """Main execution"""
    extractor = SIFINMinimalStealthExtractor()
    
    # Check credentials
    if not os.environ.get('ORCID_EMAIL') or not os.environ.get('ORCID_PASSWORD'):
        logger.error("❌ Missing ORCID credentials")
        sys.exit(1)
    
    # Run extraction
    results = extractor.run_extraction()
    
    if results:
        logger.info("✅ EXTRACTION SUCCESSFUL!")
        
        # Print details
        for i, ms in enumerate(results, 1):
            logger.info(f"\\nManuscript {i}: {ms.get('Manuscript #', '')}")
            logger.info(f"  Title: {ms.get('Title', 'N/A')[:60]}...")
            logger.info(f"  Status: {ms.get('Current Stage', 'N/A')}")
            logger.info(f"  Referees: {len(ms.get('Referees', []))}")
    else:
        logger.error("❌ EXTRACTION FAILED!")
        sys.exit(1)

if __name__ == "__main__":
    main()