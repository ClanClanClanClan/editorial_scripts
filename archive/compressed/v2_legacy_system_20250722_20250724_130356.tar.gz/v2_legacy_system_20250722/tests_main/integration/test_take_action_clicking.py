#!/usr/bin/env python3
"""Test Take Action clicking with fixed selectors"""

import os
import sys
import time
import logging
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from dotenv import load_dotenv

# Load environment
load_dotenv('.env.production')

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_take_action_selectors():
    """Test the Take Action clicking selectors"""
    
    # Set up Chrome driver
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument('--disable-blink-features=AutomationControlled')
    chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    
    driver = webdriver.Chrome(options=chrome_options)
    driver.execute_script('Object.defineProperty(navigator, "webdriver", {get: () => undefined})')
    
    try:
        logger.info("🔍 Testing Take Action selectors...")
        
        # Navigate to MF
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        # Quick login (skip if already logged in from previous session)
        logger.info("🔑 Attempting quick login...")
        try:
            # Handle cookies
            try:
                WebDriverWait(driver, 3).until(
                    EC.element_to_be_clickable((By.ID, "onetrust-reject-all-handler"))
                ).click()
                logger.info("Rejected cookies")
            except:
                pass
            
            # Try login if login form is present
            try:
                email_field = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((By.ID, "USER_NAME"))
                )
                email_field.send_keys(os.getenv('MF_EMAIL'))
                
                password_field = driver.find_element(By.ID, "PASSWORD")
                password_field.send_keys(os.getenv('MF_PASSWORD'))
                
                # Use JavaScript to click login button to avoid interception
                login_button = driver.find_element(By.ID, "logInButton")
                driver.execute_script("arguments[0].click();", login_button)
                
                # Handle 2FA if needed
                try:
                    code_input = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.ID, "TOKEN_VALUE"))
                    )
                    
                    # Get verification code from Gmail
                    sys.path.insert(0, str(Path(__file__).parent))
                    from core.email_utils import fetch_latest_verification_code
                    
                    verification_code = fetch_latest_verification_code('MF', max_wait=60, poll_interval=5)
                    if verification_code:
                        logger.info(f"📧 Got verification code: {verification_code}")
                        code_input.send_keys(verification_code)
                        
                        verify_button = driver.find_element(By.ID, "VERIFY_BTN")
                        verify_button.click()
                        time.sleep(5)
                    else:
                        logger.error("❌ No verification code found")
                        return
                except:
                    logger.info("ℹ️ No 2FA required")
                
                time.sleep(5)  # Wait for login to complete
                
            except:
                logger.info("ℹ️ Already logged in or login not needed")
        
        except Exception as e:
            logger.warning(f"Login issue: {e}")
        
        # Navigate to Associate Editor Center
        logger.info("📋 Navigating to Associate Editor Center...")
        try:
            ae_link = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.LINK_TEXT, "Associate Editor Center"))
            )
            ae_link.click()
            time.sleep(3)
        except:
            logger.warning("Could not find Associate Editor Center link")
        
        # Look for Awaiting Reviewer Scores category
        logger.info("🔍 Looking for manuscript categories...")
        try:
            category_link = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.LINK_TEXT, "Awaiting Reviewer Scores"))
            )
            category_link.click()
            time.sleep(3)
            logger.info("✅ Clicked on Awaiting Reviewer Scores category")
        except:
            logger.warning("Could not find Awaiting Reviewer Scores category")
        
        # Now test the Take Action selectors
        logger.info("🎯 Testing Take Action selectors...")
        
        # Method 1: Look for JavaScript links with ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS
        js_links = driver.find_elements(By.XPATH, "//a[starts-with(@href, 'javascript:') and contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
        logger.info(f"Found {len(js_links)} JavaScript Take Action links")
        
        # Method 2: Look for links with check_off.gif images
        icon_links = driver.find_elements(By.XPATH, "//a[.//img[contains(@src, 'check_off.gif')]]")
        logger.info(f"Found {len(icon_links)} Take Action icon links")
        
        # Method 3: Look for any Take Action related elements
        all_links = driver.find_elements(By.TAG_NAME, "a")
        take_action_links = []
        
        for link in all_links:
            try:
                href = link.get_attribute('href') or ''
                if 'javascript:' in href and 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS' in href:
                    take_action_links.append(link)
            except:
                continue
        
        logger.info(f"Found {len(take_action_links)} total Take Action links")
        
        # Try to find manuscript IDs and match with Take Action links
        page_text = driver.find_element(By.TAG_NAME, "body").text
        import re
        manuscript_ids = re.findall(r'MAFI-\d{4}-\d{4}', page_text)
        logger.info(f"Found manuscript IDs: {manuscript_ids}")
        
        # Test clicking on first Take Action link if found
        if take_action_links:
            first_link = take_action_links[0]
            try:
                href = first_link.get_attribute('href')
                logger.info(f"📋 First Take Action href: {href[:200]}...")
                
                # Find associated manuscript ID
                parent_row = first_link.find_element(By.XPATH, "./ancestor::tr")
                row_text = parent_row.text
                logger.info(f"Row text: {row_text[:100]}...")
                
                # Check if we can identify the manuscript
                for ms_id in manuscript_ids:
                    if ms_id in row_text:
                        logger.info(f"🎯 Found Take Action for manuscript: {ms_id}")
                        logger.info(f"✅ Take Action clicking logic should work!")
                        break
                        
            except Exception as e:
                logger.error(f"Error analyzing Take Action link: {e}")
        
        # Save current page for analysis
        with open('take_action_test_page.html', 'w') as f:
            f.write(driver.page_source)
        logger.info("💾 Saved page source to take_action_test_page.html")
        
        logger.info("🔍 Browser is open for manual inspection...")
        input("Press Enter to close browser...")
        
    except Exception as e:
        logger.error(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        driver.quit()

if __name__ == "__main__":
    test_take_action_selectors()