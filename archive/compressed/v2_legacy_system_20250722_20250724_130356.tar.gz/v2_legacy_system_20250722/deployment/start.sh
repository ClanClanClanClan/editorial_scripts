#!/bin/bash
# Production Start Script

echo "🚀 Starting Editorial Scripts System..."

# Check Python version
python_version=$(python3 --version 2>&1)
echo "Python version: $python_version"

# Set environment
export EDITORIAL_ENV=production
export PYTHONPATH=$PYTHONPATH:$(pwd)

# Start monitoring
echo "Starting monitoring service..."
python3 -c "from ultrathink_production_monitoring import ProductionMonitor; monitor = ProductionMonitor(); print('Monitoring started')" &
MONITOR_PID=$!

# Start main application
echo "Starting main application..."
python3 ultrathink_production_main.py

# Cleanup
kill $MONITOR_PID 2>/dev/null
echo "✅ System stopped"
