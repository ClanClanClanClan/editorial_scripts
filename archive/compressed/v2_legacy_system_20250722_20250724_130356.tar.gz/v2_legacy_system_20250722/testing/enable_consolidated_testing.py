#!/usr/bin/env python3
"""
Enable consolidated extractors for testing.
This script safely enables the consolidated extractors with feature flags.
"""

import os
import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

def enable_consolidated_testing():
    """Enable consolidated extractors for testing with safety checks."""
    
    print("ENABLING CONSOLIDATED EXTRACTORS FOR TESTING")
    print("=" * 60)
    
    # Test 1: Verify all consolidated extractors are working
    print("\n1. Testing consolidated extractor imports...")
    print("-" * 40)
    
    success_count = 0
    total_count = 4
    
    # Test MF
    try:
        from editorial_assistant.extractors.mf_extractor import MFExtractor, extract_mf_data
        mf_extractor = MFExtractor()
        print(f"✅ MF consolidated extractor ready")
        success_count += 1
    except Exception as e:
        print(f"❌ MF consolidated extractor failed: {e}")
    
    # Test MOR
    try:
        from editorial_assistant.extractors.mor_extractor import MORExtractor, extract_mor_data
        mor_extractor = MORExtractor()
        print(f"✅ MOR consolidated extractor ready")
        success_count += 1
    except Exception as e:
        print(f"❌ MOR consolidated extractor failed: {e}")
    
    # Test SICON
    try:
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor, extract_sicon_data
        sicon_extractor = SICONConsolidatedExtractor()
        print(f"✅ SICON consolidated extractor ready")
        success_count += 1
    except Exception as e:
        print(f"❌ SICON consolidated extractor failed: {e}")
    
    # Test SIFIN
    try:
        from editorial_assistant.extractors.sifin_consolidated import SIFINConsolidatedExtractor, extract_sifin_data
        sifin_extractor = SIFINConsolidatedExtractor()
        print(f"✅ SIFIN consolidated extractor ready")
        success_count += 1
    except Exception as e:
        print(f"❌ SIFIN consolidated extractor failed: {e}")
    
    if success_count != total_count:
        print(f"\n❌ Only {success_count}/{total_count} extractors ready")
        print("Cannot enable testing until all extractors are working")
        return False
    
    # Test 2: Create side-by-side comparison test
    print("\n2. Creating side-by-side comparison test...")
    print("-" * 40)
    
    try:
        comparison_results = run_side_by_side_test()
        if comparison_results['all_passed']:
            print("✅ Side-by-side comparison passed")
        else:
            print("❌ Side-by-side comparison found differences")
            print(f"Details: {comparison_results}")
            return False
    except Exception as e:
        print(f"❌ Side-by-side test failed: {e}")
        return False
    
    # Test 3: Performance benchmark
    print("\n3. Running performance benchmark...")
    print("-" * 40)
    
    try:
        performance_results = run_performance_benchmark()
        if performance_results['acceptable']:
            print("✅ Performance benchmark passed")
            print(f"Total time: {performance_results['total_time']:.3f}s")
        else:
            print("❌ Performance regression detected")
            print(f"Details: {performance_results}")
            return False
    except Exception as e:
        print(f"❌ Performance benchmark failed: {e}")
        return False
    
    # Test 4: Configuration validation
    print("\n4. Validating configuration system...")
    print("-" * 40)
    
    try:
        config_results = validate_configuration_system()
        if config_results['valid']:
            print("✅ Configuration system validated")
        else:
            print("❌ Configuration system issues")
            print(f"Details: {config_results}")
            return False
    except Exception as e:
        print(f"❌ Configuration validation failed: {e}")
        return False
    
    # Success - Ready for testing
    print("\n" + "=" * 60)
    print("CONSOLIDATED EXTRACTORS READY FOR TESTING")
    print("=" * 60)
    
    print("\n✅ All validation tests passed")
    print("✅ Performance is acceptable")
    print("✅ Configuration system working")
    print("✅ Side-by-side comparison successful")
    
    print("\nNext steps:")
    print("1. Run comprehensive test suite")
    print("2. Enable feature flags in controlled environment")
    print("3. Begin test suite consolidation")
    print("4. Performance monitoring")
    
    return True


def run_side_by_side_test():
    """Run side-by-side comparison of original vs consolidated."""
    results = {
        'all_passed': True,
        'mf_match': False,
        'mor_match': False,
        'sicon_match': False,
        'sifin_match': False
    }
    
    # Test MF - Compare basic configuration
    try:
        from editorial_assistant.extractors.mf_extractor import MFExtractor
        mf_extractor = MFExtractor()
        
        # Check key properties
        mf_checks = {
            'url': mf_extractor.journal_url == "https://mc.manuscriptcentral.com/mafi",
            'categories': len(mf_extractor.categories) == 6,
            'popup_wait': mf_extractor.popup_wait_time == 6,
            'page_wait': mf_extractor.page_navigation_wait == 5
        }
        
        results['mf_match'] = all(mf_checks.values())
        if not results['mf_match']:
            results['mf_details'] = mf_checks
            
    except Exception as e:
        results['mf_match'] = False
        results['mf_error'] = str(e)
    
    # Test MOR - Compare basic configuration
    try:
        from editorial_assistant.extractors.mor_extractor import MORExtractor
        mor_extractor = MORExtractor()
        
        # Check key properties
        mor_checks = {
            'url': mor_extractor.journal_url == "https://mc.manuscriptcentral.com/mor",
            'categories': len(mor_extractor.categories) == 7,  # MOR has 7 vs MF's 6
            'popup_wait': mor_extractor.popup_wait_time == 6,
            'page_wait': mor_extractor.page_navigation_wait == 5
        }
        
        results['mor_match'] = all(mor_checks.values())
        if not results['mor_match']:
            results['mor_details'] = mor_checks
            
    except Exception as e:
        results['mor_match'] = False
        results['mor_error'] = str(e)
    
    # Test SICON - Compare basic configuration
    try:
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
        sicon_extractor = SICONConsolidatedExtractor()
        
        # Check key properties
        sicon_checks = {
            'url': sicon_extractor.journal_url == "https://sicon.siam.org/cgi-bin/main.plex",
            'popup_wait': sicon_extractor.popup_wait_time == 1,
            'page_wait': sicon_extractor.page_navigation_wait == 5
        }
        
        results['sicon_match'] = all(sicon_checks.values())
        if not results['sicon_match']:
            results['sicon_details'] = sicon_checks
            
    except Exception as e:
        results['sicon_match'] = False
        results['sicon_error'] = str(e)
    
    # Test SIFIN - Compare basic configuration  
    try:
        from editorial_assistant.extractors.sifin_consolidated import SIFINConsolidatedExtractor
        sifin_extractor = SIFINConsolidatedExtractor()
        
        # Check key properties
        sifin_checks = {
            'url': sifin_extractor.journal_url == "http://sifin.siam.org/",
            'browser': sifin_extractor.browser_manager.browser_type == 'firefox',
            'popup_wait': sifin_extractor.popup_wait_time == 1,
            'page_wait': sifin_extractor.page_navigation_wait == 5
        }
        
        results['sifin_match'] = all(sifin_checks.values())
        if not results['sifin_match']:
            results['sifin_details'] = sifin_checks
            
    except Exception as e:
        results['sifin_match'] = False
        results['sifin_error'] = str(e)
    
    # Overall result
    results['all_passed'] = all([
        results['mf_match'],
        results['mor_match'], 
        results['sicon_match'],
        results['sifin_match']
    ])
    
    return results


def run_performance_benchmark():
    """Run performance benchmark on consolidated extractors."""
    import time
    
    results = {
        'acceptable': True,
        'total_time': 0,
        'individual_times': {}
    }
    
    # Test import times
    extractors = [
        ('MF', 'editorial_assistant.extractors.mf_extractor', 'MFExtractor'),
        ('MOR', 'editorial_assistant.extractors.mor_extractor', 'MORExtractor'), 
        ('SICON', 'editorial_assistant.extractors.sicon_consolidated', 'SICONConsolidatedExtractor'),
        ('SIFIN', 'editorial_assistant.extractors.sifin_consolidated', 'SIFINConsolidatedExtractor')
    ]
    
    total_time = 0
    
    for name, module_name, class_name in extractors:
        start_time = time.time()
        
        try:
            module = __import__(module_name, fromlist=[class_name])
            extractor_class = getattr(module, class_name)
            extractor = extractor_class()
            
            elapsed = time.time() - start_time
            results['individual_times'][name] = elapsed
            total_time += elapsed
            
        except Exception as e:
            results['individual_times'][name] = f"ERROR: {e}"
            results['acceptable'] = False
    
    results['total_time'] = total_time
    
    # Consider acceptable if total time < 5 seconds
    if total_time > 5.0:
        results['acceptable'] = False
        results['reason'] = f"Total time {total_time:.3f}s exceeds 5.0s threshold"
    
    return results


def validate_configuration_system():
    """Validate the configuration system is working properly."""
    results = {
        'valid': True,
        'issues': []
    }
    
    try:
        from editorial_assistant.core.unified_config import get_config_manager
        config_manager = get_config_manager()
        
        # Test each journal configuration
        journals = ['MF', 'MOR', 'SICON', 'SIFIN']
        
        for journal in journals:
            try:
                config = config_manager.get_journal_config(journal)
                if not config:
                    results['issues'].append(f"{journal} config not found")
                    results['valid'] = False
                elif not config.url:
                    results['issues'].append(f"{journal} config missing URL")
                    results['valid'] = False
                    
            except Exception as e:
                results['issues'].append(f"{journal} config error: {e}")
                results['valid'] = False
        
        # Test feature flags are disabled by default
        for journal in journals:
            config = config_manager.get_journal_config(journal)
            if config:
                flags = ['use_config_system', 'use_navigation_module', 'use_enhanced_timeline']
                for flag in flags:
                    if config.is_feature_enabled(flag):
                        results['issues'].append(f"{journal} has {flag} enabled (unsafe)")
                        results['valid'] = False
        
    except Exception as e:
        results['issues'].append(f"Configuration system error: {e}")
        results['valid'] = False
    
    return results


if __name__ == "__main__":
    success = enable_consolidated_testing()
    sys.exit(0 if success else 1)