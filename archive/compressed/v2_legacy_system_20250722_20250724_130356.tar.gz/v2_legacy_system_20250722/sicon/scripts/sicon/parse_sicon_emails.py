#!/usr/bin/env python3
"""
SICON Email Timeline Parser
Extracts referee timeline data from SICON emails to crosscheck with web-scraped data
"""

import re
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)

class SICONEmailParser:
    """Parse SICON emails to extract referee timeline information"""
    
    def __init__(self):
        self.invitation_patterns = [
            # "SICON: Referee invitation for manuscript M172838"
            r'SICON:\s*Referee\s+invitation\s+for\s+manuscript\s+(M\d+)',
            r'Invitation\s+to\s+review\s+manuscript\s+(M\d+)\s+for\s+SICON',
            r'SICON\s+Review\s+Request.*manuscript\s+(M\d+)',
            r'You\s+are\s+invited\s+to\s+review.*SICON.*manuscript\s+(M\d+)',
        ]
        
        self.response_patterns = [
            # "SICON: Referee accepted to review M172838"
            r'SICON:\s*Referee\s+(accepted|declined)\s+to\s+review\s+(M\d+)',
            r'(Accepted|Declined)\s+to\s+review\s+SICON\s+manuscript\s+(M\d+)',
            r'SICON.*manuscript\s+(M\d+).*referee\s+has\s+(accepted|declined)',
            r'Response\s+to\s+SICON\s+review\s+invitation.*manuscript\s+(M\d+).*\b(accept|decline)',
        ]
        
        self.reminder_patterns = [
            r'SICON:\s*Reminder.*manuscript\s+(M\d+)',
            r'SICON\s+Review\s+Reminder.*manuscript\s+(M\d+)',
            r'Gentle\s+reminder.*SICON.*manuscript\s+(M\d+)',
        ]
    
    def parse_referee_emails(self, emails: List[Dict], manuscript_id: str = None) -> Dict[str, List[Dict]]:
        """
        Parse emails to extract referee timeline data
        
        Args:
            emails: List of email dictionaries with 'subject', 'body', 'date', 'to' fields
            manuscript_id: Optional filter for specific manuscript
            
        Returns:
            Dictionary with invitation, response, and reminder timeline data
        """
        timeline = {
            'invitations': [],
            'responses': [],
            'reminders': [],
            'unmatched': []
        }
        
        for email in emails:
            subject = email.get('subject', '')
            body = email.get('body', '')
            full_text = f"{subject} {body}"
            
            # Skip if filtering by manuscript and it doesn't match
            if manuscript_id and manuscript_id not in full_text:
                continue
            
            # Parse invitation emails
            invitation_data = self._parse_invitation_email(email, full_text)
            if invitation_data:
                timeline['invitations'].append(invitation_data)
                continue
            
            # Parse response emails
            response_data = self._parse_response_email(email, full_text)
            if response_data:
                timeline['responses'].append(response_data)
                continue
            
            # Parse reminder emails
            reminder_data = self._parse_reminder_email(email, full_text)
            if reminder_data:
                timeline['reminders'].append(reminder_data)
                continue
            
            # Track unmatched SICON emails
            if 'SICON' in subject.upper() or 'SICON' in body[:500].upper():
                timeline['unmatched'].append({
                    'date': email.get('date', ''),
                    'subject': subject,
                    'preview': body[:200] + '...' if len(body) > 200 else body
                })
        
        return timeline
    
    def _parse_invitation_email(self, email: Dict, full_text: str) -> Optional[Dict]:
        """Parse referee invitation emails"""
        for pattern in self.invitation_patterns:
            match = re.search(pattern, full_text, re.IGNORECASE)
            if match:
                manuscript_id = match.group(1) if len(match.groups()) >= 1 else None
                
                # Extract referee name and email
                referee_name, referee_email = self._extract_referee_info(email)
                
                return {
                    'type': 'invitation',
                    'manuscript_id': manuscript_id,
                    'date': email.get('date', ''),
                    'referee_name': referee_name,
                    'referee_email': referee_email,
                    'subject': email.get('subject', ''),
                    'deadline': self._extract_deadline(email.get('body', ''))
                }
        return None
    
    def _parse_response_email(self, email: Dict, full_text: str) -> Optional[Dict]:
        """Parse referee response (accept/decline) emails"""
        for pattern in self.response_patterns:
            match = re.search(pattern, full_text, re.IGNORECASE)
            if match:
                # Extract decision and manuscript ID based on pattern groups
                if 'accepted|declined' in pattern:
                    decision = match.group(1).lower() if len(match.groups()) >= 1 else 'unknown'
                    manuscript_id = match.group(2) if len(match.groups()) >= 2 else None
                else:
                    # For patterns with different group order
                    manuscript_id = match.group(1) if len(match.groups()) >= 1 else None
                    decision = match.group(2).lower() if len(match.groups()) >= 2 else 'unknown'
                
                # Normalize decision
                if 'accept' in decision:
                    decision = 'accepted'
                elif 'decline' in decision:
                    decision = 'declined'
                
                # Extract referee info
                referee_name, referee_email = self._extract_referee_info(email)
                
                return {
                    'type': 'response',
                    'manuscript_id': manuscript_id,
                    'date': email.get('date', ''),
                    'decision': decision,
                    'referee_name': referee_name,
                    'referee_email': referee_email,
                    'subject': email.get('subject', ''),
                    'response_time_from_invitation': None  # Will be calculated later
                }
        return None
    
    def _parse_reminder_email(self, email: Dict, full_text: str) -> Optional[Dict]:
        """Parse reminder emails"""
        for pattern in self.reminder_patterns:
            match = re.search(pattern, full_text, re.IGNORECASE)
            if match:
                manuscript_id = match.group(1) if match.groups() else None
                
                # Extract referee info
                referee_name, referee_email = self._extract_referee_info(email)
                
                # Check if this is the nth reminder
                reminder_count = 1
                if 'second reminder' in full_text.lower():
                    reminder_count = 2
                elif 'third reminder' in full_text.lower():
                    reminder_count = 3
                elif 'final reminder' in full_text.lower():
                    reminder_count = 99  # Special marker for final reminder
                
                return {
                    'type': 'reminder',
                    'manuscript_id': manuscript_id,
                    'date': email.get('date', ''),
                    'referee_name': referee_name,
                    'referee_email': referee_email,
                    'reminder_count': reminder_count,
                    'subject': email.get('subject', '')
                }
        return None
    
    def _extract_referee_info(self, email: Dict) -> Tuple[str, str]:
        """Extract referee name and email from email headers"""
        to_field = email.get('to', '')
        
        # Extract email address
        email_match = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', to_field)
        referee_email = email_match.group(0) if email_match else ''
        
        # Extract name (before email or in quotes)
        name = ''
        if '"' in to_field:
            # Name in quotes: "John Doe" <john@example.com>
            name_match = re.search(r'"([^"]+)"', to_field)
            if name_match:
                name = name_match.group(1)
        elif '<' in to_field:
            # Name before brackets: John Doe <john@example.com>
            name = to_field.split('<')[0].strip()
        else:
            # Try to extract from email body
            body = email.get('body', '')
            dear_match = re.search(r'Dear\s+(Dr\.|Prof\.|Mr\.|Ms\.)?\s*([^,\n]+)', body, re.IGNORECASE)
            if dear_match:
                name = dear_match.group(2).strip()
        
        return name, referee_email
    
    def _extract_deadline(self, body: str) -> Optional[str]:
        """Extract review deadline from email body"""
        deadline_patterns = [
            r'deadline.*?(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})',
            r'due\s+by.*?(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})',
            r'complete.*?by.*?(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})',
            r'before.*?(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})',
            r'(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}).*?deadline',
        ]
        
        for pattern in deadline_patterns:
            match = re.search(pattern, body, re.IGNORECASE)
            if match:
                return match.group(1)
        return None
    
    def crosscheck_with_web_data(self, email_timeline: Dict, web_referees: List[Dict]) -> Dict:
        """
        Crosscheck email timeline with web-scraped referee data
        
        Args:
            email_timeline: Timeline data from emails
            web_referees: Referee data from web scraping
            
        Returns:
            Enhanced referee data with email timeline information
        """
        enhanced_data = {
            'referees': [],
            'timeline_gaps': [],
            'email_only_referees': []
        }
        
        # Create lookup maps
        web_by_email = {ref['email'].lower(): ref for ref in web_referees}
        web_by_name = {self._normalize_name(ref['name']): ref for ref in web_referees}
        
        # Match email timeline to web data
        for invitation in email_timeline['invitations']:
            referee_email = invitation['referee_email'].lower()
            referee_name = self._normalize_name(invitation['referee_name'])
            
            # Try to find matching web referee
            web_ref = web_by_email.get(referee_email) or web_by_name.get(referee_name)
            
            if web_ref:
                # Enhance web data with email timeline
                enhanced_ref = web_ref.copy()
                enhanced_ref['initial_contact_date'] = invitation['date']
                enhanced_ref['invitation_deadline'] = invitation.get('deadline')
                
                # Find matching response
                for response in email_timeline['responses']:
                    if (response['referee_email'].lower() == referee_email or 
                        self._normalize_name(response['referee_name']) == referee_name):
                        enhanced_ref['response_date'] = response['date']
                        enhanced_ref['email_decision'] = response['decision']
                        
                        # Calculate response time
                        if invitation['date'] and response['date']:
                            try:
                                inv_date = datetime.fromisoformat(invitation['date'].replace('Z', '+00:00'))
                                resp_date = datetime.fromisoformat(response['date'].replace('Z', '+00:00'))
                                enhanced_ref['response_time_days'] = (resp_date - inv_date).days
                            except:
                                pass
                        break
                
                # Count reminders
                reminder_count = sum(1 for r in email_timeline['reminders'] 
                                   if r['referee_email'].lower() == referee_email)
                enhanced_ref['reminder_count'] = reminder_count
                
                enhanced_data['referees'].append(enhanced_ref)
            else:
                # Referee found in emails but not web data
                enhanced_data['email_only_referees'].append({
                    'name': invitation['referee_name'],
                    'email': invitation['referee_email'],
                    'manuscript_id': invitation['manuscript_id'],
                    'invitation_date': invitation['date'],
                    'status': 'Found in emails but not web extraction'
                })
        
        # Check for web referees without email data
        for web_ref in web_referees:
            email_lower = web_ref['email'].lower()
            if not any(ref.get('email', '').lower() == email_lower 
                      for ref in enhanced_data['referees']):
                enhanced_data['timeline_gaps'].append({
                    'referee': web_ref['name'],
                    'email': web_ref['email'],
                    'missing': 'No email timeline found'
                })
        
        return enhanced_data
    
    def _normalize_name(self, name: str) -> str:
        """Normalize name for matching"""
        if not name:
            return ''
        # Remove titles, extra spaces, and convert to lowercase
        name = re.sub(r'(Dr\.|Prof\.|Mr\.|Ms\.)\s*', '', name, flags=re.IGNORECASE)
        name = re.sub(r'\s+', ' ', name).strip().lower()
        return name


def integrate_with_sicon_extractor(extractor_instance, gmail_emails: List[Dict]):
    """
    Integrate email timeline parsing with existing SICON extractor
    
    Args:
        extractor_instance: Instance of SICONExactExtractor
        gmail_emails: List of SICON-related emails from Gmail
    """
    parser = SICONEmailParser()
    
    # Parse all SICON emails
    timeline = parser.parse_referee_emails(gmail_emails)
    
    # For each manuscript, enhance referee data
    for manuscript in extractor_instance.manuscripts:
        ms_id = manuscript.get('id', '')
        
        # Get timeline for this manuscript
        ms_timeline = parser.parse_referee_emails(gmail_emails, manuscript_id=ms_id)
        
        # Crosscheck with web data
        all_referees = manuscript.get('declined_referees', []) + manuscript.get('accepted_referees', [])
        enhanced = parser.crosscheck_with_web_data(ms_timeline, all_referees)
        
        # Update manuscript data
        manuscript['email_timeline'] = ms_timeline
        manuscript['enhanced_referees'] = enhanced['referees']
        manuscript['timeline_gaps'] = enhanced['timeline_gaps']
        manuscript['email_only_referees'] = enhanced['email_only_referees']
        
        logger.info(f"Enhanced {ms_id} with email timeline data:")
        logger.info(f"  - {len(enhanced['referees'])} referees with complete timeline")
        logger.info(f"  - {len(enhanced['timeline_gaps'])} referees missing email data")
        logger.info(f"  - {len(enhanced['email_only_referees'])} referees found only in emails")


if __name__ == "__main__":
    # Example usage
    parser = SICONEmailParser()
    
    # Test email samples
    test_emails = [
        {
            'subject': 'SICON: Referee invitation for manuscript M172838',
            'body': 'Dear Dr. Smith, You are invited to review manuscript M172838 for SICON. Deadline: 2025-03-15',
            'date': '2025-02-01T10:00:00Z',
            'to': '"John Smith" <john.smith@university.edu>'
        },
        {
            'subject': 'SICON: Referee accepted to review M172838',
            'body': 'Dr. John Smith has accepted to review manuscript M172838',
            'date': '2025-02-03T14:30:00Z',
            'to': 'editor@sicon.org'
        }
    ]
    
    timeline = parser.parse_referee_emails(test_emails)
    print(json.dumps(timeline, indent=2))