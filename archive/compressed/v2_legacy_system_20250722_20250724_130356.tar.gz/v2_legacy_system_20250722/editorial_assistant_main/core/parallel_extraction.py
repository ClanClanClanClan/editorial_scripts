#!/usr/bin/env python3
"""
Parallel Extraction System

This module provides parallel extraction capabilities to process multiple
journals concurrently, improving overall extraction performance.

Phase 3: System Integration - Performance Optimization
"""

import time
import logging
import threading
import concurrent.futures
from queue import Queue, Empty
from typing import Dict, List, Optional, Any, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from .unified_config import get_config_manager
from .platform_extractor import PlatformExtractor
from .browser_pool import get_browser_pool
from .extraction_cache import get_extraction_cache
from .exceptions import ExtractionError, ConfigurationError

# Logging setup
logger = logging.getLogger(__name__)


class WorkerStatus(Enum):
    """Status of extraction workers."""
    IDLE = "idle"
    WORKING = "working"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class ExtractionTask:
    """Single extraction task for parallel processing."""
    
    task_id: str
    journal_code: str
    extractor: PlatformExtractor
    extraction_params: Dict[str, Any]
    extraction_mode: str  # Changed from ExtractionMode to str to avoid circular import
    priority: int = 0
    created_at: datetime = field(default_factory=datetime.now)
    
    def __lt__(self, other):
        """Compare tasks by priority (higher priority first)."""
        return self.priority > other.priority


@dataclass
class TaskResult:
    """Result of an extraction task."""
    
    task_id: str
    journal_code: str
    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    execution_time: float = 0.0
    worker_id: Optional[int] = None


class ParallelExtractionEngine:
    """
    Engine for parallel extraction operations.
    
    Features:
    - Configurable worker pool
    - Priority-based task scheduling
    - Resource management (browser pool integration)
    - Progress tracking and monitoring
    - Error isolation and recovery
    """
    
    def __init__(self, max_workers: Optional[int] = None):
        """Initialize the parallel extraction engine."""
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Configuration
        config_manager = get_config_manager()
        self.max_workers = max_workers or config_manager.get_global_setting('max_extraction_workers', 3)
        self.enable_parallel = config_manager.get_global_setting('enable_parallel_extraction', True)
        self.task_timeout = config_manager.get_global_setting('extraction_task_timeout', 300)  # 5 minutes
        
        # Worker pool
        self.executor = None
        self.active_workers = 0
        
        # Task management
        self.task_queue = Queue()
        self.results = {}
        self.worker_status = {}
        
        # Resource management
        self.browser_pool = get_browser_pool() if self.enable_parallel else None
        self.cache = get_extraction_cache()
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Statistics
        self._stats = {
            'tasks_submitted': 0,
            'tasks_completed': 0,
            'tasks_failed': 0,
            'total_execution_time': 0.0,
            'worker_utilization': {}
        }
        
        self.logger.info(f"Parallel extraction engine initialized - Workers: {self.max_workers}, "
                        f"Parallel: {self.enable_parallel}")
    
    def execute_parallel(self, tasks: List[ExtractionTask]) -> Dict[str, TaskResult]:
        """
        Execute extraction tasks in parallel.
        
        Args:
            tasks: List of extraction tasks to execute
            
        Returns:
            Dictionary mapping task IDs to results
        """
        if not self.enable_parallel or len(tasks) <= 1:
            # Fall back to sequential execution
            return self._execute_sequential(tasks)
        
        self.logger.info(f"Starting parallel extraction for {len(tasks)} tasks")
        start_time = time.time()
        
        try:
            # Initialize executor
            self.executor = concurrent.futures.ThreadPoolExecutor(
                max_workers=min(self.max_workers, len(tasks)),
                thread_name_prefix="ExtractionWorker"
            )
            
            # Submit all tasks
            future_to_task = {}
            for task in tasks:
                future = self.executor.submit(self._execute_task, task)
                future_to_task[future] = task
                self._stats['tasks_submitted'] += 1
            
            # Collect results as they complete
            results = {}
            for future in concurrent.futures.as_completed(future_to_task, timeout=self.task_timeout * len(tasks)):
                task = future_to_task[future]
                
                try:
                    result = future.result()
                    results[task.task_id] = result
                    
                    if result.success:
                        self._stats['tasks_completed'] += 1
                    else:
                        self._stats['tasks_failed'] += 1
                        
                except Exception as e:
                    self.logger.error(f"Task {task.task_id} failed: {e}")
                    results[task.task_id] = TaskResult(
                        task_id=task.task_id,
                        journal_code=task.journal_code,
                        success=False,
                        error=str(e)
                    )
                    self._stats['tasks_failed'] += 1
            
            # Calculate total execution time
            total_time = time.time() - start_time
            self._stats['total_execution_time'] += total_time
            
            self.logger.info(f"Parallel extraction completed in {total_time:.2f}s - "
                           f"Success: {self._stats['tasks_completed']}, "
                           f"Failed: {self._stats['tasks_failed']}")
            
            return results
            
        except Exception as e:
            self.logger.error(f"Parallel extraction engine error: {e}")
            # Fall back to sequential on engine failure
            return self._execute_sequential(tasks)
            
        finally:
            # Cleanup executor
            if self.executor:
                self.executor.shutdown(wait=True)
                self.executor = None
    
    def _execute_task(self, task: ExtractionTask) -> TaskResult:
        """Execute a single extraction task."""
        worker_id = threading.get_ident()
        start_time = time.time()
        
        # Update worker status
        with self._lock:
            self.worker_status[worker_id] = WorkerStatus.WORKING
            self.active_workers += 1
        
        try:
            self.logger.debug(f"Worker {worker_id} starting task {task.task_id} for {task.journal_code}")
            
            # Check cache first
            cached_data = self.cache.get(
                task.journal_code,
                task.extraction_mode.value,
                task.extraction_params.get('filters')
            )
            
            if cached_data:
                self.logger.debug(f"Cache hit for {task.journal_code}")
                return TaskResult(
                    task_id=task.task_id,
                    journal_code=task.journal_code,
                    success=True,
                    data=cached_data,
                    execution_time=time.time() - start_time,
                    worker_id=worker_id
                )
            
            # Execute extraction based on mode string
            if task.extraction_mode == 'FULL':
                data = task.extractor.extract_all_data(**task.extraction_params)
                
            elif task.extraction_mode == 'MANUSCRIPTS_ONLY':
                task.extractor.authenticate(**task.extraction_params.get('credentials', {}))
                manuscripts = task.extractor.extract_manuscripts(
                    **task.extraction_params.get('manuscript_filters', {})
                )
                data = {
                    'manuscripts': [task.extractor._manuscript_to_dict(m) for m in manuscripts],
                    'referees': []
                }
                
            else:
                # Quick mode
                params = task.extraction_params.copy()
                params.setdefault('manuscript_filters', {})['limit'] = 5
                data = task.extractor.extract_all_data(**params)
            
            # Cache successful results
            if data:
                self.cache.put(
                    task.journal_code,
                    task.extraction_mode.value,
                    data,
                    task.extraction_params.get('filters')
                )
            
            execution_time = time.time() - start_time
            
            # Update statistics
            with self._lock:
                worker_stats = self._stats['worker_utilization'].setdefault(worker_id, {
                    'tasks': 0,
                    'total_time': 0.0,
                    'success': 0,
                    'failed': 0
                })
                worker_stats['tasks'] += 1
                worker_stats['total_time'] += execution_time
                worker_stats['success'] += 1
            
            return TaskResult(
                task_id=task.task_id,
                journal_code=task.journal_code,
                success=True,
                data=data,
                execution_time=execution_time,
                worker_id=worker_id
            )
            
        except Exception as e:
            self.logger.error(f"Worker {worker_id} task {task.task_id} failed: {e}")
            
            # Update failure statistics
            with self._lock:
                worker_stats = self._stats['worker_utilization'].setdefault(worker_id, {
                    'tasks': 0,
                    'total_time': 0.0,
                    'success': 0,
                    'failed': 0
                })
                worker_stats['tasks'] += 1
                worker_stats['failed'] += 1
            
            return TaskResult(
                task_id=task.task_id,
                journal_code=task.journal_code,
                success=False,
                error=str(e),
                execution_time=time.time() - start_time,
                worker_id=worker_id
            )
            
        finally:
            # Update worker status
            with self._lock:
                self.worker_status[worker_id] = WorkerStatus.COMPLETED
                self.active_workers -= 1
    
    def _execute_sequential(self, tasks: List[ExtractionTask]) -> Dict[str, TaskResult]:
        """Execute tasks sequentially (fallback)."""
        self.logger.info(f"Executing {len(tasks)} tasks sequentially")
        
        results = {}
        for task in tasks:
            result = self._execute_task(task)
            results[task.task_id] = result
        
        return results
    
    def get_progress(self) -> Dict[str, Any]:
        """Get current extraction progress."""
        with self._lock:
            return {
                'active_workers': self.active_workers,
                'tasks_submitted': self._stats['tasks_submitted'],
                'tasks_completed': self._stats['tasks_completed'],
                'tasks_failed': self._stats['tasks_failed'],
                'completion_rate': (
                    self._stats['tasks_completed'] / self._stats['tasks_submitted']
                    if self._stats['tasks_submitted'] > 0 else 0.0
                )
            }
    
    def get_stats(self) -> Dict[str, Any]:
        """Get detailed statistics."""
        with self._lock:
            stats = self._stats.copy()
            
            # Calculate average task time
            total_tasks = stats['tasks_completed'] + stats['tasks_failed']
            if total_tasks > 0:
                stats['avg_task_time'] = stats['total_execution_time'] / total_tasks
            else:
                stats['avg_task_time'] = 0.0
            
            # Calculate worker efficiency
            worker_efficiency = {}
            for worker_id, worker_stats in stats['worker_utilization'].items():
                if worker_stats['tasks'] > 0:
                    worker_efficiency[worker_id] = {
                        'tasks': worker_stats['tasks'],
                        'avg_time': worker_stats['total_time'] / worker_stats['tasks'],
                        'success_rate': worker_stats['success'] / worker_stats['tasks']
                    }
            
            stats['worker_efficiency'] = worker_efficiency
            
            # Resource utilization
            if self.browser_pool:
                stats['browser_pool'] = self.browser_pool.get_stats()
            
            if self.cache:
                stats['cache'] = self.cache.get_stats()
            
            return stats
    
    def optimize_task_order(self, tasks: List[ExtractionTask]) -> List[ExtractionTask]:
        """
        Optimize task execution order based on priority and expected duration.
        
        Args:
            tasks: List of tasks to optimize
            
        Returns:
            Optimized task list
        """
        # Sort by priority (already implemented in ExtractionTask.__lt__)
        return sorted(tasks, reverse=True)
    
    def shutdown(self):
        """Shutdown the parallel extraction engine."""
        self.logger.info("Shutting down parallel extraction engine...")
        
        if self.executor:
            self.executor.shutdown(wait=True)
            self.executor = None
        
        self.logger.info(f"Parallel extraction engine shutdown. Final stats: {self.get_stats()}")


# Global engine instance
_global_engine: Optional[ParallelExtractionEngine] = None
_engine_lock = threading.Lock()


def get_parallel_engine() -> ParallelExtractionEngine:
    """Get the global parallel extraction engine."""
    global _global_engine
    
    if _global_engine is None:
        with _engine_lock:
            if _global_engine is None:
                _global_engine = ParallelExtractionEngine()
    
    return _global_engine