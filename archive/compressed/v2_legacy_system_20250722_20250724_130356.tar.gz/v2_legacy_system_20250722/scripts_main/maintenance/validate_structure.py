#!/usr/bin/env python3
"""
Validate the project structure after migration.
Ensures nothing is broken and all imports still work.
"""

import os
import sys
import subprocess
from pathlib import Path
from datetime import datetime

class StructureValidator:
    """Validate project structure and functionality."""
    
    def __init__(self):
        self.project_root = Path(__file__).parent.parent.parent
        self.errors = []
        self.warnings = []
        
    def check_critical_files(self):
        """Check that critical files still exist."""
        print("\n🔍 Checking critical files...")
        
        critical_files = [
            'run_extraction.py',
            'ultrathink_perfect_mf_final.py',
            'ultrathink_perfect_mor_enhanced.py',
            'editorial_assistant/extractors/scholarone.py',
            'editorial_assistant/extractors/sicon.py',
            'editorial_assistant/extractors/sifin.py',
            'config/journals.yaml',
            'requirements.txt',
        ]
        
        for file_path in critical_files:
            full_path = self.project_root / file_path
            if full_path.exists():
                print(f"  ✅ {file_path}")
            else:
                print(f"  ❌ {file_path} - MISSING!")
                self.errors.append(f"Missing critical file: {file_path}")
                
    def check_imports(self):
        """Check that key imports still work."""
        print("\n🔍 Testing imports...")
        
        test_imports = [
            "from editorial_assistant.extractors.scholarone import ScholarOneExtractor",
            "from editorial_assistant.core.browser_manager import BrowserManager",
            "from editorial_assistant.utils.email_verification import EmailVerificationManager",
        ]
        
        for import_stmt in test_imports:
            try:
                # Add project root to Python path
                env = os.environ.copy()
                env['PYTHONPATH'] = str(self.project_root)
                
                result = subprocess.run(
                    [sys.executable, '-c', import_stmt],
                    capture_output=True,
                    text=True,
                    env=env
                )
                
                if result.returncode == 0:
                    print(f"  ✅ {import_stmt}")
                else:
                    print(f"  ❌ {import_stmt}")
                    print(f"     Error: {result.stderr.strip()}")
                    self.errors.append(f"Import failed: {import_stmt}")
                    
            except Exception as e:
                print(f"  ❌ {import_stmt} - Exception: {e}")
                self.errors.append(f"Import test exception: {import_stmt}")
                
    def check_directory_structure(self):
        """Check that new directory structure is in place."""
        print("\n🔍 Checking directory structure...")
        
        expected_dirs = [
            'src/editorial_assistant',
            'tests/unit',
            'tests/integration',
            'scripts/debug',
            'scripts/utilities',
            'docs/reference',
            'data/exports/legacy',
            'config/journals',
        ]
        
        for dir_path in expected_dirs:
            full_path = self.project_root / dir_path
            if full_path.exists() and full_path.is_dir():
                # Count files
                file_count = len(list(full_path.rglob('*')))
                print(f"  ✅ {dir_path} ({file_count} files)")
            else:
                print(f"  ❌ {dir_path} - MISSING!")
                self.errors.append(f"Missing directory: {dir_path}")
                
    def check_root_cleanliness(self):
        """Check that root directory is cleaner."""
        print("\n🔍 Checking root directory cleanliness...")
        
        # Count files in root
        root_files = [f for f in self.project_root.iterdir() 
                     if f.is_file() and not f.name.startswith('.')]
        
        py_files = [f for f in root_files if f.suffix == '.py']
        json_files = [f for f in root_files if f.suffix == '.json']
        md_files = [f for f in root_files if f.suffix == '.md']
        
        print(f"  📊 Total files in root: {len(root_files)}")
        print(f"  📊 Python files: {len(py_files)}")
        print(f"  📊 JSON files: {len(json_files)}")
        print(f"  📊 Markdown files: {len(md_files)}")
        
        # Check for files that shouldn't be in root
        unwanted_patterns = ['debug_', 'test_', 'show_', 'quick_', 'fix_']
        unwanted_files = []
        
        for f in py_files:
            if any(f.name.startswith(pattern) for pattern in unwanted_patterns):
                unwanted_files.append(f.name)
                
        if unwanted_files:
            print(f"\n  ⚠️  Unwanted files still in root:")
            for f in unwanted_files[:10]:
                print(f"     - {f}")
            if len(unwanted_files) > 10:
                print(f"     ... and {len(unwanted_files)-10} more")
            self.warnings.append(f"{len(unwanted_files)} unwanted files still in root")
        else:
            print(f"\n  ✅ No unwanted files in root!")
            
    def run_basic_tests(self):
        """Run basic functionality tests."""
        print("\n🔍 Running basic functionality tests...")
        
        # Test that we can at least import the main modules
        test_script = '''
import sys
sys.path.insert(0, '.')
try:
    from editorial_assistant.core.data_models import JournalConfig
    print("✅ Core imports working")
except Exception as e:
    print(f"❌ Core imports failed: {e}")
    
try:
    import yaml
    with open('config/journals.yaml', 'r') as f:
        config = yaml.safe_load(f)
    print(f"✅ Config loading working ({len(config.get('journals', []))} journals)")
except Exception as e:
    print(f"❌ Config loading failed: {e}")
'''
        
        result = subprocess.run(
            [sys.executable, '-c', test_script],
            capture_output=True,
            text=True,
            cwd=self.project_root
        )
        
        print(result.stdout)
        if result.stderr:
            print(f"  ⚠️  Stderr: {result.stderr}")
            
    def generate_report(self):
        """Generate validation report."""
        print("\n" + "="*80)
        print("VALIDATION REPORT")
        print("="*80)
        
        if not self.errors and not self.warnings:
            print("\n✅ ALL VALIDATIONS PASSED!")
            print("The refactoring appears to be successful.")
        else:
            if self.errors:
                print(f"\n❌ ERRORS ({len(self.errors)}):")
                for error in self.errors:
                    print(f"  - {error}")
                    
            if self.warnings:
                print(f"\n⚠️  WARNINGS ({len(self.warnings)}):")
                for warning in self.warnings:
                    print(f"  - {warning}")
                    
        print("\n" + "="*80)
        
        # Save report
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = self.project_root / "data" / "logs" / f"validation_report_{timestamp}.txt"
        report_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(report_path, 'w') as f:
            f.write(f"Validation Report - {datetime.now().isoformat()}\n")
            f.write("="*80 + "\n\n")
            
            if self.errors:
                f.write(f"ERRORS ({len(self.errors)}):\n")
                for error in self.errors:
                    f.write(f"  - {error}\n")
                f.write("\n")
                
            if self.warnings:
                f.write(f"WARNINGS ({len(self.warnings)}):\n")
                for warning in self.warnings:
                    f.write(f"  - {warning}\n")
                f.write("\n")
                
            if not self.errors and not self.warnings:
                f.write("ALL VALIDATIONS PASSED!\n")
                
        print(f"\n📄 Report saved: {report_path.relative_to(self.project_root)}")
        
        return len(self.errors) == 0
        
    def run(self):
        """Run all validations."""
        print("Starting structure validation...")
        print(f"Project root: {self.project_root}")
        
        self.check_critical_files()
        self.check_imports()
        self.check_directory_structure()
        self.check_root_cleanliness()
        self.run_basic_tests()
        
        return self.generate_report()
        

if __name__ == "__main__":
    validator = StructureValidator()
    success = validator.run()
    sys.exit(0 if success else 1)