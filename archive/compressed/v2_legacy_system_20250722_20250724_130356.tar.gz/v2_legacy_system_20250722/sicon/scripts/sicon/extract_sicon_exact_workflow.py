#!/usr/bin/env python3
"""
SICON Exact Workflow Extractor - July 15, 2025
Following the EXACT workflow provided by the user
"""

import os
import sys
import time
import logging
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import undetected_chromedriver as uc
from bs4 import BeautifulSoup

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SICONExactExtractor:
    """SICON extractor following the exact workflow provided by the user"""
    
    def __init__(self):
        self.driver = None
        self.manuscripts = []
        self.referees = []
        
    def setup_driver(self, headless=True):
        """Setup Chrome driver with stealth"""
        options = uc.ChromeOptions()
        if headless:
            options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        
        self.driver = uc.Chrome(options=options)
        self.driver.set_window_size(1920, 1080)
        
        logger.info("✅ Chrome driver setup complete")
        
    def handle_popups(self):
        """Handle cookie banners and privacy modals"""
        try:
            # First, try to remove with JavaScript
            js_remove_banners = """
            // Remove common cookie banner elements
            const selectors = [
                '#cookie-policy-layer-bg',
                '#cookie-policy-layer', 
                '.cc_banner-wrapper',
                '#onetrust-banner-sdk',
                '.onetrust-pc-dark-filter',
                '[id*="cookie"]',
                '[class*="cookie"]',
                '[id*="banner"]',
                '[class*="banner"]'
            ];
            
            selectors.forEach(sel => {
                document.querySelectorAll(sel).forEach(el => {
                    el.style.display = 'none';
                    el.remove();
                });
            });
            
            // Also try to find and click accept buttons
            const buttonTexts = ['Accept', 'Accept All', 'Accept Cookies', 'Got it', 'OK', 'Continue'];
            buttonTexts.forEach(text => {
                document.querySelectorAll('button, input[type="button"]').forEach(btn => {
                    if (btn.innerText && btn.innerText.toLowerCase().includes(text.toLowerCase())) {
                        btn.click();
                    }
                });
            });
            """
            
            self.driver.execute_script(js_remove_banners)
            time.sleep(1)
            
            # Common popup dismissal attempts
            popup_selectors = [
                "button[id*='accept']",
                "button[class*='accept']", 
                "button[id*='cookie']",
                "button[class*='cookie']",
                "button[id*='dismiss']",
                "button[class*='dismiss']",
                ".cookie-accept",
                ".privacy-accept",
                "#accept-cookies",
                "#dismiss-modal",
                "button:contains('Accept')",
                "button:contains('OK')",
                "button:contains('Continue')"
            ]
            
            for selector in popup_selectors:
                try:
                    element = self.driver.find_element(By.CSS_SELECTOR, selector)
                    if element.is_displayed() and element.is_enabled():
                        element.click()
                        logger.info(f"✅ Dismissed popup: {selector}")
                        time.sleep(1)
                        break
                except:
                    continue
                    
        except Exception as e:
            logger.debug(f"Popup handling: {e}")
    
    def step1_navigate_to_sicon(self):
        """Step 1: Navigate to SICON main page"""
        logger.info("📍 Step 1: Navigating to SICON...")
        
        url = "https://sicon.siam.org/cgi-bin/main.plex"
        self.driver.get(url)
        
        # Wait for Cloudflare to complete
        max_wait = 30
        waited = 0
        while waited < max_wait:
            title = self.driver.title
            if "Just a moment" in title or "Please wait" in title:
                logger.info(f"⏳ Waiting for Cloudflare... ({waited}s)")
                time.sleep(2)
                waited += 2
            else:
                break
        
        time.sleep(3)
        
        # Handle popups
        self.handle_popups()
        
        logger.info(f"✅ Loaded: {self.driver.title}")
        
    def step2_click_orcid_button(self):
        """Step 2: Click ORCID login button"""
        logger.info("📍 Step 2: Clicking ORCID button...")
        
        try:
            # Ensure all popups are handled first
            self.handle_popups()
            time.sleep(2)
            
            # Look for ORCID image/link
            orcid_selectors = [
                "a[href*='sso_site_redirect'][href*='orcid']",
                "img[src*='orcid']",
                "img[title='ORCID']", 
                "a img[src*='orcid_32x32.png']",
                "a[href*='orcid']"
            ]
            
            orcid_element = None
            for selector in orcid_selectors:
                try:
                    elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        if element.is_displayed():
                            # If it's an image, get its parent link
                            if element.tag_name == 'img':
                                orcid_element = element.find_element(By.XPATH, "..")
                            else:
                                orcid_element = element
                            break
                    if orcid_element:
                        break
                except:
                    continue
                    
            if orcid_element:
                # Try JavaScript click first
                try:
                    self.driver.execute_script("arguments[0].click();", orcid_element)
                    logger.info("✅ ORCID button clicked (JavaScript)")
                except:
                    # Fallback to regular click
                    orcid_element.click()
                    logger.info("✅ ORCID button clicked (regular)")
                time.sleep(3)
            else:
                raise Exception("ORCID button not found")
                
        except Exception as e:
            logger.error(f"❌ Failed to click ORCID button: {e}")
            raise
            
    def step3_orcid_authentication(self):
        """Step 3: Authenticate via ORCID"""
        logger.info("📍 Step 3: ORCID authentication...")
        
        # Handle popups on ORCID page
        self.handle_popups()
        
        # Get credentials
        email = os.getenv('ORCID_EMAIL')
        password = os.getenv('ORCID_PASSWORD')
        
        if not email or not password:
            raise Exception("ORCID credentials not found in environment")
            
        try:
            # Wait for username field with exact ID from user
            username_field = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "username-input"))
            )
            username_field.clear()
            username_field.send_keys(email)
            logger.info("✅ Username entered")
            
            # Password field with exact ID from user
            password_field = self.driver.find_element(By.ID, "password")
            password_field.clear()
            password_field.send_keys(password)
            logger.info("✅ Password entered")
            
            # Submit button with exact ID from user
            submit_button = self.driver.find_element(By.ID, "signin-button")
            submit_button.click()
            logger.info("✅ Login submitted")
            
            time.sleep(5)
            
        except Exception as e:
            logger.error(f"❌ ORCID authentication failed: {e}")
            raise
            
    def step4_navigate_manuscript_folders(self):
        """Step 4: Navigate to manuscript folders"""
        logger.info("📍 Step 4: Finding AE task links...")
        
        # Handle any post-login popups
        self.handle_popups()
        
        # Look for the associate editor table
        try:
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            # Find AE task links - these are the specific links we need to click
            task_links = []
            target_tasks = [
                'Awaiting Referee Assignment',
                'All Pending Manuscripts'
            ]
            
            # Debug: Log ALL links found in both sections
            all_tasks_found = []
            all_folders_found = []
            
            # Check ndt_task section
            for row in soup.find_all('tr', class_='ndt_task'):
                task_link = row.find('a', class_='ndt_task_link')
                if task_link:
                    text = task_link.get_text().strip()
                    all_tasks_found.append(text)
            
            # Check ndt_folder section
            for row in soup.find_all('tr', class_='ndt_folder'):
                folder_link = row.find('a', class_='ndt_folder_link')
                if folder_link:
                    text = folder_link.get_text().strip()
                    all_folders_found.append(text)
            
            logger.info(f"🔍 All AE tasks found: {all_tasks_found}")
            logger.info(f"🔍 All AE folders found: {all_folders_found}")
            
            # Look for target tasks in BOTH task rows AND folder rows
            # First check ndt_task section
            for row in soup.find_all('tr', class_='ndt_task'):
                task_link = row.find('a', class_='ndt_task_link')
                if task_link:
                    text = task_link.get_text().strip()
                    href = task_link.get('href')
                    
                    for target_task in target_tasks:
                        if target_task in text:
                            try:
                                import re
                                count_match = re.search(r'\((\d+)\)', text)
                                if count_match:
                                    count = int(count_match.group(1))
                                    task_links.append({
                                        'name': target_task,
                                        'count': count,
                                        'url': href,
                                        'full_text': text,
                                        'type': 'task'
                                    })
                                    logger.info(f"📋 Found AE task: {target_task} ({count} manuscripts)")
                            except:
                                continue
                            break
            
            # Then check ndt_folder section  
            for row in soup.find_all('tr', class_='ndt_folder'):
                folder_link = row.find('a', class_='ndt_folder_link')
                if folder_link:
                    text = folder_link.get_text().strip()
                    href = folder_link.get('href')
                    folder_data = row.get('data-folder', '')
                    
                    for target_task in target_tasks:
                        if target_task in text or target_task.lower().replace(' ', '_') in folder_data:
                            try:
                                import re
                                count_match = re.search(r'(\d+)\s*AE', text)
                                if count_match:
                                    count = int(count_match.group(1))
                                    task_links.append({
                                        'name': target_task,
                                        'count': count,
                                        'url': href,
                                        'full_text': text,
                                        'type': 'folder',
                                        'data_folder': folder_data
                                    })
                                    logger.info(f"📁 Found AE folder: {target_task} ({count} manuscripts)")
                            except:
                                continue
                            break
                            
            return task_links
            
        except Exception as e:
            logger.error(f"❌ Failed to find AE task links: {e}")
            raise
            
    def step5_extract_manuscript_ids(self, task_links):
        """Step 5: Extract manuscript IDs from AE task links"""
        logger.info("📍 Step 5: Extracting manuscript IDs from AE tasks...")
        
        manuscript_urls = []
        
        for task in task_links:
            try:
                logger.info(f"📋 Clicking AE task: {task['name']} ({task['count']} manuscripts)")
                
                # Find the task link element by its text content
                task_text = task['full_text']
                
                try:
                    if task['type'] == 'folder':
                        # Use data-folder attribute for folder links
                        folder_selector = f"tr[data-folder='{task['data_folder']}'] a.ndt_folder_link"
                        task_element = WebDriverWait(self.driver, 10).until(
                            EC.element_to_be_clickable((By.CSS_SELECTOR, folder_selector))
                        )
                    else:
                        # Use XPath for task links
                        task_xpath = f"//a[@class='ndt_task_link' and contains(text(), '{task['name']}')]"
                        task_element = WebDriverWait(self.driver, 10).until(
                            EC.element_to_be_clickable((By.XPATH, task_xpath))
                        )
                    
                    # Use JavaScript click to avoid interception
                    self.driver.execute_script("arguments[0].click();", task_element)
                    logger.info(f"✅ Clicked AE {task['type']}: {task['name']}")
                    time.sleep(3)
                    
                except Exception as e:
                    logger.error(f"❌ Failed to click AE task {task['name']}: {e}")
                    continue
                
                # Handle popups after navigation
                self.handle_popups()
                
                # Find manuscript links (starting with M followed by numbers)
                soup = BeautifulSoup(self.driver.page_source, 'html.parser')
                
                # Debug: Log page structure
                logger.info(f"Page title: {self.driver.title}")
                
                # Look for manuscript IDs in various patterns
                patterns_found = []
                
                # Look for manuscript ID links with form_type=view_ms
                for link in soup.find_all('a'):
                    text = link.get_text().strip()
                    href = link.get('href', '')
                    
                    # Pattern 1: Direct M + digits with form_type=view_ms
                    if text.startswith('M') and len(text) > 1 and text[1:].isdigit() and 'form_type=view_ms' in href:
                        patterns_found.append(f"Direct: {text}")
                        if href:
                            if not href.startswith('http'):
                                # Keep the relative URL structure intact
                                if href.startswith('cgi-bin/'):
                                    href = "https://sicon.siam.org/" + href
                                else:
                                    href = "https://sicon.siam.org/cgi-bin/" + href.lstrip('/')
                            manuscript_urls.append({
                                'id': text,
                                'url': href
                            })
                            logger.info(f"📄 Found manuscript: {text} -> {href}")
                    
                    # Pattern 2: Look in href for manuscript IDs
                    elif 'form_type=view_ms' in href and 'ms_id_key=' in href:
                        # Extract ms_id_key parameter
                        import re
                        match = re.search(r'ms_id_key=([^&]+)', href)
                        if match:
                            ms_id = match.group(1)
                            patterns_found.append(f"URL param: {ms_id}")
                            if not href.startswith('http'):
                                href = "https://sicon.siam.org/cgi-bin/" + href.lstrip('/')
                            manuscript_urls.append({
                                'id': ms_id,
                                'url': href
                            })
                            logger.info(f"📄 Found manuscript from URL: {ms_id}")
                
                # Pattern 3: Look for task links containing manuscripts
                for task_row in soup.find_all('tr', class_='ndt_task'):
                    task_link = task_row.find('a', class_='ndt_task_link')
                    if task_link:
                        text = task_link.get_text().strip()
                        href = task_link.get('href', '')
                        
                        # Look for # followed by manuscript ID
                        if text.startswith('#') and 'M' in text:
                            # Extract manuscript ID from text like "#M172838"
                            import re
                            match = re.search(r'#(M\d+)', text)
                            if match:
                                ms_id = match.group(1)
                                patterns_found.append(f"Task link: {ms_id}")
                                if href:
                                    if not href.startswith('http'):
                                        href = "https://sicon.siam.org/cgi-bin/" + href.lstrip('/')
                                    manuscript_urls.append({
                                        'id': ms_id,
                                        'url': href
                                    })
                                    logger.info(f"📄 Found manuscript from task: {ms_id}")
                
                logger.info(f"Patterns found in {task['name']}: {patterns_found}")
                
                # Navigate back to main dashboard for next task
                self.driver.get("https://sicon.siam.org/cgi-bin/main.plex")
                time.sleep(2)
                self.handle_popups()
                            
            except Exception as e:
                logger.error(f"❌ Error processing AE task {task['name']}: {e}")
                continue
                
        # Remove duplicates
        seen = set()
        unique_manuscripts = []
        for ms in manuscript_urls:
            if ms['id'] not in seen:
                seen.add(ms['id'])
                unique_manuscripts.append(ms)
                
        logger.info(f"✅ Found {len(unique_manuscripts)} unique manuscripts")
        return unique_manuscripts
        
    def step6_extract_manuscript_details(self, manuscript_urls):
        """Step 6: Extract detailed manuscript information"""
        logger.info("📍 Step 6: Extracting manuscript details...")
        
        for manuscript in manuscript_urls:
            try:
                logger.info(f"📄 Processing {manuscript['id']}...")
                
                # Navigate to manuscript detail page
                self.driver.get(manuscript['url'])
                time.sleep(3)
                
                # Handle any popups
                self.handle_popups()
                
                soup = BeautifulSoup(self.driver.page_source, 'html.parser')
                
                # Debug: Log page title and look for any table with details
                logger.info(f"Detail page title: {self.driver.title}")
                
                # Find the exact table from user's example
                detail_table = soup.find('table', {'id': 'ms_details_expanded'})
                if not detail_table:
                    # Try alternative table selectors
                    detail_table = soup.find('table', class_='dump_ms_details')
                    if not detail_table:
                        # Look for any table that might contain manuscript details
                        tables = soup.find_all('table')
                        logger.info(f"Found {len(tables)} tables, looking for manuscript details...")
                        for i, table in enumerate(tables):
                            if 'manuscript' in str(table).lower() or 'title' in str(table).lower():
                                detail_table = table
                                logger.info(f"Using table {i} for manuscript details")
                                break
                
                if not detail_table:
                    logger.warning(f"⚠️ Detail table not found for {manuscript['id']}")
                    continue
                    
                # Extract manuscript info
                ms_data = {'id': manuscript['id'], 'url': manuscript['url']}
                
                # Parse table rows
                for row in detail_table.find_all('tr'):
                    th = row.find('th')
                    td = row.find('td')
                    
                    if not th or not td:
                        continue
                        
                    label = th.get_text(strip=True)
                    
                    if 'Manuscript #' in label:
                        ms_data['manuscript_number'] = td.get_text(strip=True)
                        logger.info(f"   Manuscript #: {ms_data['manuscript_number']}")
                    elif 'Current Revision #' in label:
                        ms_data['revision_number'] = td.get_text(strip=True)
                    elif 'Title' in label:
                        ms_data['title'] = td.get_text(strip=True)
                        logger.info(f"   Title: {ms_data['title'][:100]}...")
                    elif 'Running Title' in label:
                        ms_data['running_title'] = td.get_text(strip=True)
                        logger.info(f"   Running Title: {ms_data['running_title']}")
                    elif 'Manuscript Type' in label:
                        ms_data['manuscript_type'] = td.get_text(strip=True)
                    elif 'Special Section' in label:
                        ms_data['special_section'] = td.get_text(strip=True)
                    elif 'Submission Date' in label:
                        ms_data['submission_date'] = td.get_text(strip=True)
                        logger.info(f"   Submission Date: {ms_data['submission_date']}")
                    elif 'Current Stage' in label:
                        ms_data['current_stage'] = td.get_text(strip=True)
                        logger.info(f"   Current Stage: {ms_data['current_stage']}")
                    elif 'Corresponding Author' in label:
                        ms_data['corresponding_author'] = td.get_text(strip=True)
                        logger.info(f"   Corresponding Author: {ms_data['corresponding_author']}")
                    elif 'Contributing Authors' in label:
                        ms_data['contributing_authors'] = td.get_text(strip=True)
                        logger.info(f"   Contributing Authors: {ms_data['contributing_authors'][:100]}...")
                    elif 'Abstract' in label:
                        ms_data['abstract'] = td.get_text(strip=True)
                        logger.info(f"   Abstract: {len(ms_data['abstract'])} characters")
                    elif 'Associate Editor' in label:
                        ms_data['associate_editor'] = td.get_text(strip=True)
                    elif 'Corresponding Editor' in label:
                        ms_data['corresponding_editor'] = td.get_text(strip=True)
                    elif 'Keywords' in label:
                        ms_data['keywords'] = td.get_text(strip=True)
                        logger.info(f"   Keywords: {ms_data['keywords']}")
                    elif 'Potential Referees' in label:
                        # DECLINED referees - get names and enhanced details
                        declined_refs = self.extract_referee_details_enhanced(td, status='declined')
                        ms_data['declined_referees'] = declined_refs
                        logger.info(f"   Declined Referees: {len(declined_refs)}")
                        for ref in declined_refs:
                            contact_info = f" (Last Contact: {ref.get('last_contact_date', 'N/A')})" if ref.get('last_contact_date') else ""
                            logger.info(f"     - {ref['name']} ({ref['email']}) - {ref['affiliation']}{contact_info}")
                    elif label == 'Referees':
                        # ACCEPTED referees - get names and enhanced details
                        accepted_refs = self.extract_referee_details_enhanced(td, status='accepted')
                        ms_data['accepted_referees'] = accepted_refs
                        logger.info(f"   Accepted Referees: {len(accepted_refs)}")
                        for ref in accepted_refs:
                            status_info = ""
                            if ref.get('report_received_date'):
                                status_info = f" (Report Received: {ref['report_received_date']})"
                            elif ref.get('report_due_date'):
                                status_info = f" (Report Due: {ref['report_due_date']})"
                            logger.info(f"     - {ref['name']} ({ref['email']}) - {ref['affiliation']}{status_info}")
                
                # Extract PDF links
                ms_data['pdfs'] = self.extract_pdf_links(soup)
                logger.info(f"   PDFs: {len(ms_data['pdfs'])}")
                for pdf in ms_data['pdfs']:
                    logger.info(f"     - {pdf['type']}: {pdf['url']}")
                
                # Extract referee comments
                ms_data['referee_comments'] = self.extract_referee_comments(soup)
                if ms_data['referee_comments']:
                    logger.info(f"   Referee Comments: {len(ms_data['referee_comments'])} comments found")
                        
                self.manuscripts.append(ms_data)
                logger.info(f"✅ Extracted complete data for {manuscript['id']}")
                
            except Exception as e:
                logger.error(f"❌ Error processing {manuscript['id']}: {e}")
                continue
                
    def extract_referee_details_enhanced(self, cell, status):
        """Extract complete referee information with enhanced contact date parsing"""
        referees = []
        
        # Get the full HTML content of the cell to parse contact dates
        cell_html = str(cell)
        
        # Find all referee links (biblio_dump)
        for link in cell.find_all('a'):
            href = link.get('href', '')
            if 'biblio_dump' in href:
                name = link.get_text(strip=True)
                
                # Get full details by clicking the profile link
                full_details = self.get_referee_profile_details(href)
                
                ref_data = {
                    'name': self.normalize_name(full_details.get('full_name', name)),
                    'email': full_details.get('email', '').lower().strip(),
                    'affiliation': full_details.get('affiliation', ''),
                    'profile_url': href,
                    'status': status
                }
                
                # Enhanced contact date parsing based on status
                if status == 'declined':
                    # Parse pattern: "Samuel daudin #1</a> (Last Contact Date: 2025-02-04) (Status: Declined)"
                    import re
                    
                    # Find the text that follows this specific link
                    link_text = str(link)
                    link_pattern = re.escape(link_text)
                    pattern = link_pattern + r'\s*\(Last Contact Date:\s*([^)]+)\)\s*\(Status:\s*([^)]+)\)'
                    
                    match = re.search(pattern, cell_html, re.IGNORECASE)
                    if match:
                        ref_data['last_contact_date'] = match.group(1).strip()
                        ref_data['confirmed_status'] = match.group(2).strip()
                        logger.info(f"      Declined: {name} - Last Contact: {ref_data['last_contact_date']}")
                    else:
                        # Try alternative pattern without status
                        alt_pattern = link_pattern + r'\s*\(Last Contact Date:\s*([^)]+)\)'
                        alt_match = re.search(alt_pattern, cell_html, re.IGNORECASE)
                        if alt_match:
                            ref_data['last_contact_date'] = alt_match.group(1).strip()
                            logger.info(f"      Declined: {name} - Last Contact: {ref_data['last_contact_date']}")
                
                elif status == 'accepted':
                    # Parse pattern: "Giorgio Ferrari #1</a> <font size="-1">(Rcvd: 2025-06-02)</font>"
                    # or: "Juan LI #2</a> <font size="-1">(Due: 2025-04-17)</font>"
                    import re
                    
                    link_text = str(link)
                    link_pattern = re.escape(link_text)
                    
                    # Look for received date pattern
                    rcvd_pattern = link_pattern + r'[^<]*<font[^>]*>\s*\(Rcvd:\s*([^)]+)\)'
                    rcvd_match = re.search(rcvd_pattern, cell_html, re.IGNORECASE)
                    
                    # Look for due date pattern  
                    due_pattern = link_pattern + r'[^<]*<font[^>]*>\s*\(Due:\s*([^)]+)\)'
                    due_match = re.search(due_pattern, cell_html, re.IGNORECASE)
                    
                    if rcvd_match:
                        ref_data['report_status'] = 'submitted'
                        ref_data['report_received_date'] = rcvd_match.group(1).strip()
                        logger.info(f"      Accepted: {name} - Report Received: {ref_data['report_received_date']}")
                    elif due_match:
                        ref_data['report_status'] = 'pending'
                        ref_data['report_due_date'] = due_match.group(1).strip()
                        logger.info(f"      Accepted: {name} - Report Due: {ref_data['report_due_date']}")
                    
                    # Also try simpler patterns without font tags
                    if 'report_status' not in ref_data:
                        simple_rcvd = link_pattern + r'[^(]*\(Rcvd:\s*([^)]+)\)'
                        simple_due = link_pattern + r'[^(]*\(Due:\s*([^)]+)\)'
                        
                        simple_rcvd_match = re.search(simple_rcvd, cell_html, re.IGNORECASE)
                        simple_due_match = re.search(simple_due, cell_html, re.IGNORECASE)
                        
                        if simple_rcvd_match:
                            ref_data['report_status'] = 'submitted'
                            ref_data['report_received_date'] = simple_rcvd_match.group(1).strip()
                            logger.info(f"      Accepted: {name} - Report Received: {ref_data['report_received_date']}")
                        elif simple_due_match:
                            ref_data['report_status'] = 'pending'
                            ref_data['report_due_date'] = simple_due_match.group(1).strip()
                            logger.info(f"      Accepted: {name} - Report Due: {ref_data['report_due_date']}")
                
                referees.append(ref_data)
                
        return referees
        
    def extract_referee_details(self, cell, status):
        """Extract complete referee information by clicking on their profile links"""
        referees = []
        
        # Find all referee links (biblio_dump)
        for link in cell.find_all('a'):
            href = link.get('href', '')
            if 'biblio_dump' in href:
                name = link.get_text(strip=True)
                
                # Get full details by clicking the profile link
                full_details = self.get_referee_profile_details(href)
                
                ref_data = {
                    'name': self.normalize_name(full_details.get('full_name', name)),
                    'email': full_details.get('email', '').lower().strip(),
                    'affiliation': full_details.get('affiliation', ''),
                    'profile_url': href,
                    'status': status
                }
                
                # Look for dates and status in surrounding text
                parent_text = str(link.parent)
                
                if status == 'declined':
                    # Look for "(Status: Declined)"
                    if 'Status: Declined' in parent_text:
                        ref_data['confirmed_declined'] = True
                elif status == 'accepted':
                    # Look for "(Rcvd: DATE)" or "(Due: DATE)"
                    import re
                    rcvd_match = re.search(r'\(Rcvd:\s*([^)]+)\)', parent_text)
                    due_match = re.search(r'\(Due:\s*([^)]+)\)', parent_text)
                    if rcvd_match:
                        ref_data['report_status'] = 'submitted'
                        ref_data['report_received_date'] = rcvd_match.group(1)
                    elif due_match:
                        ref_data['report_status'] = 'pending' 
                        ref_data['report_due_date'] = due_match.group(1)
                        
                referees.append(ref_data)
                
        return referees
        
    def get_referee_profile_details(self, profile_url):
        """Click on referee profile link to get full details"""
        try:
            # Construct full URL
            if not profile_url.startswith('http'):
                if profile_url.startswith('cgi-bin/'):
                    profile_url = "https://sicon.siam.org/" + profile_url
                else:
                    profile_url = "https://sicon.siam.org/cgi-bin/" + profile_url.lstrip('/')
            
            # Navigate to profile page
            self.driver.get(profile_url)
            time.sleep(2)
            
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            details = {}
            
            # Look for name, email, affiliation in various patterns
            # Find email addresses
            email_links = soup.find_all('a', href=lambda x: x and 'mailto:' in x)
            if email_links:
                details['email'] = email_links[0].get('href').replace('mailto:', '')
            
            # Look for affiliation and full name in text or table cells
            for td in soup.find_all('td'):
                text = td.get_text(strip=True)
                if '@' in text and '.' in text and 'email' not in details:
                    details['email'] = text
                elif 'University' in text or 'Institute' in text or 'College' in text:
                    details['affiliation'] = text
            
            # Try to find full name (often in title or headers)
            for tag in soup.find_all(['h1', 'h2', 'h3', 'title']):
                text = tag.get_text(strip=True)
                if text and len(text.split()) >= 2 and not text.startswith('SIAM'):
                    details['full_name'] = text
                    break
            
            return details
            
        except Exception as e:
            logger.warning(f"Could not get profile details from {profile_url}: {e}")
            return {}
    
    def normalize_name(self, name):
        """Normalize referee names to proper title case"""
        if not name:
            return ""
        
        # Split by common delimiters and normalize each part
        import re
        
        # Handle names with # (like "Samuel daudin #1")
        if '#' in name:
            name = re.sub(r'\s*#\d+', '', name).strip()
        
        # Split into words and capitalize properly
        words = name.split()
        normalized_words = []
        
        for word in words:
            # Handle hyphenated names
            if '-' in word:
                parts = word.split('-')
                normalized_parts = [part.capitalize() for part in parts if part]
                normalized_words.append('-'.join(normalized_parts))
            else:
                # Special handling for common name patterns
                if word.lower() in ['van', 'von', 'de', 'la', 'le', 'du', 'della', 'da']:
                    normalized_words.append(word.lower())
                elif word.lower() in ['mc', 'mac']:
                    # Handle Scottish names like McDonald, MacLeod
                    if len(word) > 2:
                        normalized_words.append(word[:2].title() + word[2:].capitalize())
                    else:
                        normalized_words.append(word.capitalize())
                else:
                    normalized_words.append(word.capitalize())
        
        return ' '.join(normalized_words)
    
    def extract_pdf_links(self, soup):
        """Extract PDF download links from manuscript page"""
        pdfs = []
        seen_base_urls = set()  # Track seen URLs to avoid duplicates
        
        # Look for PDF links in ordered lists (ol) or direct links
        for link in soup.find_all('a'):
            href = link.get('href', '')
            text = link.get_text(strip=True)
            
            # Look for PDF links
            if '.pdf' in href and ('sicon.siam.org' in href or href.startswith('/')):
                full_url = href if href.startswith('http') else f"https://sicon.siam.org{href}"
                
                # Create base URL for deduplication (remove _sc suffix)
                base_url = full_url.replace('_sc.pdf', '.pdf')
                
                # Skip if we've already seen this base URL
                if base_url in seen_base_urls:
                    continue
                seen_base_urls.add(base_url)
                
                pdf_data = {
                    'url': full_url,
                    'type': 'Unknown PDF',
                    'size': ''
                }
                
                # Determine PDF type from context
                if 'art_file' in href:
                    pdf_data['type'] = 'Article File'
                elif 'reviewer_attachment' in href:
                    pdf_data['type'] = 'Referee Review Attachment'
                elif 'cover_letter' in href:
                    pdf_data['type'] = 'Cover Letter'
                
                # Extract size from text
                if 'KB' in text or 'MB' in text:
                    import re
                    size_match = re.search(r'\(([^)]+[KM]B)\)', text)
                    if size_match:
                        pdf_data['size'] = size_match.group(1)
                
                pdfs.append(pdf_data)
        
        return pdfs
    
    def extract_referee_comments(self, soup):
        """Extract referee comments by clicking on Associate Editor Recommendation link"""
        try:
            # Find the Associate Editor Recommendation link
            ae_link = None
            for link in soup.find_all('a'):
                href = link.get('href', '')
                text = link.get_text(strip=True)
                if 'display_me_review' in href and 'Associate Editor Recommendation' in text:
                    ae_link = href
                    break
            
            if not ae_link:
                return []
            
            # Construct full URL
            if not ae_link.startswith('http'):
                if ae_link.startswith('cgi-bin/'):
                    ae_link = "https://sicon.siam.org/" + ae_link
                else:
                    ae_link = "https://sicon.siam.org/cgi-bin/" + ae_link.lstrip('/')
            
            # Navigate to comments page
            self.driver.get(ae_link)
            time.sleep(2)
            
            comment_soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            # Look for the comments table with Referee, Note, Comment columns
            comments = []
            seen_comments = set()  # Track seen comments to avoid duplicates
            
            for table in comment_soup.find_all('table'):
                # Check if this is the comments table
                headers = table.find_all('th')
                if len(headers) >= 3:
                    header_texts = [th.get_text(strip=True) for th in headers]
                    if 'Referee' in header_texts and 'Comment' in header_texts:
                        # This is the comments table
                        for row in table.find_all('tr')[1:]:  # Skip header row
                            cells = row.find_all('td')
                            if len(cells) >= 3:
                                referee = cells[0].get_text(strip=True)
                                note = cells[1].get_text(strip=True)
                                comment = cells[2].get_text(strip=True)
                                
                                # Create unique identifier for this comment
                                comment_id = f"{referee}|{note}|{comment[:100]}"
                                
                                # Filter out system-generated entries and empty/pointer comments
                                is_system_entry = any([
                                    'Attach File' in referee,
                                    'Review Attachment' in referee and not comment,
                                    note == '' and 'Review Attachment' in comment,
                                    'Return to the author' in referee or 'Publish after' in referee or 'Reject outright' in referee,
                                    comment == 'No Comment',
                                    comment == '' and note in ['Remarks to the Author', 'Confidential Message to Review Editor'],
                                    comment.lower().strip() in ['please see pdf', 'see pdf', 'see attached', 'see attachment', 'please see attached']
                                ])
                                
                                if referee and not is_system_entry and comment and comment.strip() and comment_id not in seen_comments:
                                    seen_comments.add(comment_id)
                                    comments.append({
                                        'referee': referee,
                                        'note_type': note,
                                        'comment': comment
                                    })
            
            return comments
            
        except Exception as e:
            logger.warning(f"Could not extract referee comments: {e}")
            return []
        
    def run_extraction(self, headless=True):
        """Run the complete SICON extraction following exact workflow"""
        try:
            self.setup_driver(headless=headless)
            
            # Follow exact workflow steps
            self.step1_navigate_to_sicon()
            self.step2_click_orcid_button() 
            self.step3_orcid_authentication()
            
            task_links = self.step4_navigate_manuscript_folders()
            manuscript_urls = self.step5_extract_manuscript_ids(task_links)
            self.step6_extract_manuscript_details(manuscript_urls)
            
            # Count results
            total_manuscripts = len(self.manuscripts)
            total_declined = sum(len(ms.get('declined_referees', [])) for ms in self.manuscripts)
            total_accepted = sum(len(ms.get('accepted_referees', [])) for ms in self.manuscripts)
            total_referees = total_declined + total_accepted
            total_pdfs = sum(len(ms.get('pdfs', [])) for ms in self.manuscripts)
            total_comments = sum(len(ms.get('referee_comments', [])) for ms in self.manuscripts)
            
            logger.info(f"\n📊 EXTRACTION RESULTS:")
            logger.info(f"   Manuscripts: {total_manuscripts}")
            logger.info(f"   Total Referees: {total_referees}")
            logger.info(f"   - Declined: {total_declined}")
            logger.info(f"   - Accepted: {total_accepted}")
            logger.info(f"   Total PDFs: {total_pdfs}")
            logger.info(f"   Total Comments: {total_comments}")
            
            # Save detailed results to file
            self.save_detailed_results()
            
            # Validate against baseline
            expected = {'manuscripts': 4, 'referees': 13, 'declined': 5, 'accepted': 8}
            
            logger.info(f"\n📈 BASELINE VALIDATION:")
            logger.info(f"   Manuscripts: {total_manuscripts}/{expected['manuscripts']} ({'✅' if total_manuscripts >= expected['manuscripts'] else '❌'})")
            logger.info(f"   Referees: {total_referees}/{expected['referees']} ({'✅' if total_referees >= expected['referees'] else '❌'})")
            logger.info(f"   Declined: {total_declined}/{expected['declined']} ({'✅' if total_declined >= expected['declined'] else '❌'})")
            logger.info(f"   Accepted: {total_accepted}/{expected['accepted']} ({'✅' if total_accepted >= expected['accepted'] else '❌'})")
            
            return {
                'success': True,
                'manuscripts': self.manuscripts,
                'summary': {
                    'total_manuscripts': total_manuscripts,
                    'total_referees': total_referees, 
                    'declined_referees': total_declined,
                    'accepted_referees': total_accepted,
                    'total_pdfs': total_pdfs,
                    'total_comments': total_comments
                }
            }
            
        except Exception as e:
            logger.error(f"❌ Extraction failed: {e}")
            return {'success': False, 'error': str(e)}
            
        finally:
            if self.driver:
                try:
                    self.driver.quit()
                    logger.info("🖥️ Browser closed")
                except Exception as e:
                    logger.debug(f"Browser quit error (ignoring): {e}")
            
    def save_detailed_results(self):
        """Save detailed extraction results to JSON file"""
        try:
            import json
            from datetime import datetime
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"sicon_extraction_{timestamp}.json"
            
            with open(filename, 'w') as f:
                json.dump(self.manuscripts, f, indent=2, default=str)
            
            logger.info(f"💾 Detailed results saved to: {filename}")
            
        except Exception as e:
            logger.error(f"Failed to save results: {e}")

def main():
    """Main execution"""
    
    # Check credentials
    if not os.getenv('ORCID_EMAIL') or not os.getenv('ORCID_PASSWORD'):
        logger.error("❌ ORCID credentials not found in environment")
        print("Please set ORCID_EMAIL and ORCID_PASSWORD environment variables")
        return 1
        
    logger.info("🚀 SICON EXACT WORKFLOW EXTRACTION")
    logger.info("=" * 50)
    
    extractor = SICONExactExtractor()
    result = extractor.run_extraction(headless=False)  # Use visible mode to bypass Cloudflare
    
    if result['success']:
        logger.info("✅ EXTRACTION SUCCESSFUL!")
        return 0
    else:
        logger.error("❌ EXTRACTION FAILED!")
        return 1

if __name__ == "__main__":
    sys.exit(main())