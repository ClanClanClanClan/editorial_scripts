#!/usr/bin/env python3
"""
Auto-generated migration script
Generated: 2025-07-20T04:20:25.195687
Total files: 200
"""

import shutil
from pathlib import Path

# Project root
PROJECT_ROOT = Path(__file__).parent.parent.parent

# Migrations
MIGRATIONS = [
    {
        'source': 'show_all_extracted_data.py',
        'destination': 'scripts/utilities/show_all_extracted_data.py'
    },
    {
        'source': 'test_gmail_simple.py',
        'destination': 'tests/integration/test_gmail_simple.py'
    },
    {
        'source': 'TEST_RESULTS_ANALYSIS.md',
        'destination': 'docs/reference/TEST_RESULTS_ANALYSIS.md'
    },
    {
        'source': 'test_mf_take_action.py',
        'destination': 'tests/integration/test_mf_take_action.py'
    },
    {
        'source': 'sifin_gmail_debug_M147228_20250717_093253.json',
        'destination': 'data/exports/legacy/sifin_gmail_debug_M147228_20250717_093253.json'
    },
    {
        'source': 'sifin_extraction_20250716_181436.json',
        'destination': 'data/exports/legacy/sifin_extraction_20250716_181436.json'
    },
    {
        'source': 'debug_gmail_body_extraction.py',
        'destination': 'scripts/debug/debug_gmail_body_extraction.py'
    },
    {
        'source': 'test_updated_extraction.py',
        'destination': 'tests/integration/test_updated_extraction.py'
    },
    {
        'source': 'sifin_debug_page.html',
        'destination': 'data/debug/sifin_debug_page.html'
    },
    {
        'source': 'run_simple_mf_extraction.py',
        'destination': 'scripts/utilities/run_simple_mf_extraction.py'
    },
    {
        'source': 'mor_post_login.html',
        'destination': 'data/debug/mor_post_login.html'
    },
    {
        'source': 'test_take_action_click.py',
        'destination': 'tests/integration/test_take_action_click.py'
    },
    {
        'source': 'ULTRATHINK_REFACTORING_PLAN.md',
        'destination': 'docs/reference/ULTRATHINK_REFACTORING_PLAN.md'
    },
    {
        'source': 'debug_referee_cells.py',
        'destination': 'scripts/debug/debug_referee_cells.py'
    },
    {
        'source': 'debug_device_verification.py',
        'destination': 'scripts/debug/debug_device_verification.py'
    },
    {
        'source': 'sifin_firefox_20250717_000735.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_000735.json'
    },
    {
        'source': 'IMPLEMENTATION_AUDIT_SUMMARY.md',
        'destination': 'docs/reference/IMPLEMENTATION_AUDIT_SUMMARY.md'
    },
    {
        'source': 'SICON_SIFIN_VERIFICATION_REPORT.md',
        'destination': 'docs/reference/SICON_SIFIN_VERIFICATION_REPORT.md'
    },
    {
        'source': 'apply_take_action_fix.py',
        'destination': 'scripts/utilities/apply_take_action_fix.py'
    },
    {
        'source': 'sifin_firefox_20250717_005218.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_005218.json'
    },
    {
        'source': 'test_mf_headfull.py',
        'destination': 'tests/integration/test_mf_headfull.py'
    },
    {
        'source': 'test_basic_sicon.py',
        'destination': 'tests/legacy/test_basic_sicon.py'
    },
    {
        'source': 'test_referee_extraction.py',
        'destination': 'tests/integration/test_referee_extraction.py'
    },
    {
        'source': 'sifin_extraction_20250716_232130.json',
        'destination': 'data/exports/legacy/sifin_extraction_20250716_232130.json'
    },
    {
        'source': 'test_mf_mor_login.py',
        'destination': 'tests/integration/test_mf_mor_login.py'
    },
    {
        'source': 'sicon_extraction_20250716_234739.json',
        'destination': 'data/exports/legacy/sicon_extraction_20250716_234739.json'
    },
    {
        'source': 'sicon_extraction_20250716_233443.json',
        'destination': 'data/exports/legacy/sicon_extraction_20250716_233443.json'
    },
    {
        'source': 'test_exact_take_action.py',
        'destination': 'tests/integration/test_exact_take_action.py'
    },
    {
        'source': 'debug_sifin_detailed.py',
        'destination': 'scripts/debug/debug_sifin_detailed.py'
    },
    {
        'source': 'sifin_enhanced_timeline_20250717_131623.json',
        'destination': 'data/exports/legacy/sifin_enhanced_timeline_20250717_131623.json'
    },
    {
        'source': 'mor_after_login.html',
        'destination': 'data/debug/mor_after_login.html'
    },
    {
        'source': 'test_mf_simple_direct.py',
        'destination': 'tests/integration/test_mf_simple_direct.py'
    },
    {
        'source': 'sifin_email_timeline_20250717_130703.json',
        'destination': 'data/exports/legacy/sifin_email_timeline_20250717_130703.json'
    },
    {
        'source': 'quick_ultrafix_test.py',
        'destination': 'scripts/utilities/quick_ultrafix_test.py'
    },
    {
        'source': 'mor_ae_dashboard.png',
        'destination': 'data/debug/mor_ae_dashboard.png'
    },
    {
        'source': 'sifin_firefox_20250717_091706.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_091706.json'
    },
    {
        'source': 'MASTER_REFACTORING_PLAN_2025.md',
        'destination': 'docs/reference/MASTER_REFACTORING_PLAN_2025.md'
    },
    {
        'source': 'test_fresh_2fa.py',
        'destination': 'tests/legacy/test_fresh_2fa.py'
    },
    {
        'source': 'sifin_email_timeline_20250717_121935.json',
        'destination': 'data/exports/legacy/sifin_email_timeline_20250717_121935.json'
    },
    {
        'source': 'test_sicon_sifin_maniac.py',
        'destination': 'tests/integration/test_sicon_sifin_maniac.py'
    },
    {
        'source': 'sifin_firefox_20250717_005310.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_005310.json'
    },
    {
        'source': 'sifin_extraction_20250716_181708.json',
        'destination': 'data/exports/legacy/sifin_extraction_20250716_181708.json'
    },
    {
        'source': 'sifin_email_timeline_20250717_120559.json',
        'destination': 'data/exports/legacy/sifin_email_timeline_20250717_120559.json'
    },
    {
        'source': 'sifin_firefox_20250717_094617.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_094617.json'
    },
    {
        'source': 'mf_login_debug.html',
        'destination': 'data/debug/mf_login_debug.html'
    },
    {
        'source': 'test_regex_extraction.py',
        'destination': 'tests/integration/test_regex_extraction.py'
    },
    {
        'source': 'test_mf_device_verification_flow.py',
        'destination': 'tests/integration/test_mf_device_verification_flow.py'
    },
    {
        'source': 'debug_mf_manuscript_content.py',
        'destination': 'scripts/debug/debug_mf_manuscript_content.py'
    },
    {
        'source': 'test_mf_parsing_fixes.py',
        'destination': 'tests/integration/test_mf_parsing_fixes.py'
    },
    {
        'source': 'test_mf_headful_now.py',
        'destination': 'tests/integration/test_mf_headful_now.py'
    },
    {
        'source': 'sifin_firefox_20250717_091326.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_091326.json'
    },
    {
        'source': 'test_sicon_sifin_simple.py',
        'destination': 'tests/integration/test_sicon_sifin_simple.py'
    },
    {
        'source': 'show_me_take_action_working.py',
        'destination': 'scripts/utilities/show_me_take_action_working.py'
    },
    {
        'source': 'sifin_firefox_20250717_080433.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_080433.json'
    },
    {
        'source': 'complete_mf_everything_20250719_200156.json',
        'destination': 'data/exports/legacy/complete_mf_everything_20250719_200156.json'
    },
    {
        'source': 'diagnose_take_action_issue.py',
        'destination': 'scripts/utilities/diagnose_take_action_issue.py'
    },
    {
        'source': 'test_immediate_ultrafix.py',
        'destination': 'tests/legacy/test_immediate_ultrafix.py'
    },
    {
        'source': 'run_mf_no_loop.py',
        'destination': 'scripts/utilities/run_mf_no_loop.py'
    },
    {
        'source': 'show_me_headful.py',
        'destination': 'scripts/utilities/show_me_headful.py'
    },
    {
        'source': 'sifin_email_timeline_20250717_131210.json',
        'destination': 'data/exports/legacy/sifin_email_timeline_20250717_131210.json'
    },
    {
        'source': 'fix_take_action_simple.py',
        'destination': 'scripts/utilities/fix_take_action_simple.py'
    },
    {
        'source': 'mf_ae_dashboard.html',
        'destination': 'data/debug/mf_ae_dashboard.html'
    },
    {
        'source': 'test_mf_headful.py',
        'destination': 'tests/integration/test_mf_headful.py'
    },
    {
        'source': 'mf_verification_page.html',
        'destination': 'data/debug/mf_verification_page.html'
    },
    {
        'source': 'sifin_firefox_20250717_082843.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_082843.json'
    },
    {
        'source': 'test_ultrafix_take_action.py',
        'destination': 'tests/integration/test_ultrafix_take_action.py'
    },
    {
        'source': 'test_take_action_clicking.py',
        'destination': 'tests/integration/test_take_action_clicking.py'
    },
    {
        'source': 'show_mf_extraction_details.py',
        'destination': 'scripts/utilities/show_mf_extraction_details.py'
    },
    {
        'source': 'test_sicon_timeline_consistency.py',
        'destination': 'tests/integration/test_sicon_timeline_consistency.py'
    },
    {
        'source': 'show_mf_extraction_summary.py',
        'destination': 'scripts/utilities/show_mf_extraction_summary.py'
    },
    {
        'source': 'manuscript_details_page.html',
        'destination': 'data/debug/manuscript_details_page.html'
    },
    {
        'source': 'test_mor_connection.py',
        'destination': 'tests/integration/test_mor_connection.py'
    },
    {
        'source': 'sifin_manuscript_analysis_20250717_092431.json',
        'destination': 'data/exports/legacy/sifin_manuscript_analysis_20250717_092431.json'
    },
    {
        'source': 'extract_everything_mf.py',
        'destination': 'scripts/utilities/extract_everything_mf.py'
    },
    {
        'source': 'debug_ae_center_navigation.py',
        'destination': 'scripts/debug/debug_ae_center_navigation.py'
    },
    {
        'source': 'show_ultrafix_status.py',
        'destination': 'scripts/utilities/show_ultrafix_status.py'
    },
    {
        'source': 'mor_after_submit.html',
        'destination': 'data/debug/mor_after_submit.html'
    },
    {
        'source': 'mf_debug_page.html',
        'destination': 'data/debug/mf_debug_page.html'
    },
    {
        'source': 'show_mf_data.py',
        'destination': 'scripts/utilities/show_mf_data.py'
    },
    {
        'source': 'patch_ultrafix_immediate.py',
        'destination': 'scripts/utilities/patch_ultrafix_immediate.py'
    },
    {
        'source': 'test_mf_mor_login_verification.py',
        'destination': 'tests/integration/test_mf_mor_login_verification.py'
    },
    {
        'source': 'test_mf_complete_flow.py',
        'destination': 'tests/integration/test_mf_complete_flow.py'
    },
    {
        'source': 'ULTRATHINK_SOLUTION_SUMMARY.md',
        'destination': 'docs/reference/ULTRATHINK_SOLUTION_SUMMARY.md'
    },
    {
        'source': 'show_mf_results.py',
        'destination': 'scripts/utilities/show_mf_results.py'
    },
    {
        'source': 'mf_login_page.html',
        'destination': 'data/debug/mf_login_page.html'
    },
    {
        'source': 'sicon_extraction_20250716_235712.json',
        'destination': 'data/exports/legacy/sicon_extraction_20250716_235712.json'
    },
    {
        'source': 'test_mf_complete_working.py',
        'destination': 'tests/integration/test_mf_complete_working.py'
    },
    {
        'source': 'sifin_firefox_20250717_080127.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_080127.json'
    },
    {
        'source': 'test_mf_final.py',
        'destination': 'tests/integration/test_mf_final.py'
    },
    {
        'source': 'debug_mf_mor_pages.py',
        'destination': 'scripts/debug/debug_mf_mor_pages.py'
    },
    {
        'source': 'mf_initial_page.html',
        'destination': 'data/debug/mf_initial_page.html'
    },
    {
        'source': 'test_take_action_fix.py',
        'destination': 'tests/integration/test_take_action_fix.py'
    },
    {
        'source': 'sifin_email_timeline_20250717_130907.json',
        'destination': 'data/exports/legacy/sifin_email_timeline_20250717_130907.json'
    },
    {
        'source': 'fix_sifin_referee_extraction.py',
        'destination': 'scripts/utilities/fix_sifin_referee_extraction.py'
    },
    {
        'source': 'sifin_email_timeline_20250717_120854.json',
        'destination': 'data/exports/legacy/sifin_email_timeline_20250717_120854.json'
    },
    {
        'source': 'EXECUTIVE_ACTION_PLAN.md',
        'destination': 'docs/reference/EXECUTIVE_ACTION_PLAN.md'
    },
    {
        'source': 'debug_correct_rows.py',
        'destination': 'scripts/debug/debug_correct_rows.py'
    },
    {
        'source': 'debug_mf_timeout.py',
        'destination': 'scripts/debug/debug_mf_timeout.py'
    },
    {
        'source': 'mor_login_page.html',
        'destination': 'data/debug/mor_login_page.html'
    },
    {
        'source': 'debug_sifin_referee_extraction.py',
        'destination': 'scripts/debug/debug_sifin_referee_extraction.py'
    },
    {
        'source': 'sifin_firefox_20250717_090112.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_090112.json'
    },
    {
        'source': 'get_one_manuscript_details.py',
        'destination': 'scripts/utilities/get_one_manuscript_details.py'
    },
    {
        'source': 'debug_mf_extraction.py',
        'destination': 'scripts/debug/debug_mf_extraction.py'
    },
    {
        'source': 'sifin_firefox_20250717_094413.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_094413.json'
    },
    {
        'source': 'mor_debug_page.html',
        'destination': 'data/debug/mor_debug_page.html'
    },
    {
        'source': 'mf_2fa_page.html',
        'destination': 'data/debug/mf_2fa_page.html'
    },
    {
        'source': 'test_complete_mf_extraction.py',
        'destination': 'tests/integration/test_complete_mf_extraction.py'
    },
    {
        'source': 'test_all_journals_implementation.py',
        'destination': 'tests/legacy/test_all_journals_implementation.py'
    },
    {
        'source': 'debug_sifin_body_extraction.py',
        'destination': 'scripts/debug/debug_sifin_body_extraction.py'
    },
    {
        'source': 'patch_take_action.py',
        'destination': 'scripts/utilities/patch_take_action.py'
    },
    {
        'source': 'get_actual_manuscript_details.py',
        'destination': 'scripts/utilities/get_actual_manuscript_details.py'
    },
    {
        'source': 'MF_TAKE_ACTION_WORKING_SUMMARY.md',
        'destination': 'docs/reference/MF_TAKE_ACTION_WORKING_SUMMARY.md'
    },
    {
        'source': 'test_take_action_manual.py',
        'destination': 'tests/integration/test_take_action_manual.py'
    },
    {
        'source': 'test_mf_working_flow.py',
        'destination': 'tests/integration/test_mf_working_flow.py'
    },
    {
        'source': 'mor_ae_dashboard.html',
        'destination': 'data/debug/mor_ae_dashboard.html'
    },
    {
        'source': 'validate_systems.py',
        'destination': 'scripts/utilities/validate_systems.py'
    },
    {
        'source': 'debug_mf_navigation_timed.py',
        'destination': 'scripts/debug/debug_mf_navigation_timed.py'
    },
    {
        'source': 'show_mf_current_status.py',
        'destination': 'scripts/utilities/show_mf_current_status.py'
    },
    {
        'source': 'sifin_enhanced_timeline_20250717_121451.json',
        'destination': 'data/exports/legacy/sifin_enhanced_timeline_20250717_121451.json'
    },
    {
        'source': 'mor_2fa_page.html',
        'destination': 'data/debug/mor_2fa_page.html'
    },
    {
        'source': 'quick_mf_check.py',
        'destination': 'scripts/utilities/quick_mf_check.py'
    },
    {
        'source': 'test_mf_parsing_detailed.py',
        'destination': 'tests/integration/test_mf_parsing_detailed.py'
    },
    {
        'source': 'COMPREHENSIVE_AUDIT_AND_CONTINUATION_SUMMARY.md',
        'destination': 'docs/reference/COMPREHENSIVE_AUDIT_AND_CONTINUATION_SUMMARY.md'
    },
    {
        'source': 'sifin_gmail_solution_20250717_092615.json',
        'destination': 'data/exports/legacy/sifin_gmail_solution_20250717_092615.json'
    },
    {
        'source': 'simple_mf_data_extraction.py',
        'destination': 'scripts/utilities/simple_mf_data_extraction.py'
    },
    {
        'source': 'mf_after_submit.html',
        'destination': 'data/debug/mf_after_submit.html'
    },
    {
        'source': 'verify_ultrafix_success.py',
        'destination': 'scripts/utilities/verify_ultrafix_success.py'
    },
    {
        'source': 'quick_test_improvements.py',
        'destination': 'scripts/utilities/quick_test_improvements.py'
    },
    {
        'source': 'test_mf_login.py',
        'destination': 'tests/integration/test_mf_login.py'
    },
    {
        'source': 'debug_before_click_MAFI-2025-0166.html',
        'destination': 'data/debug/debug_before_click_MAFI-2025-0166.html'
    },
    {
        'source': 'check_mf_test_status.py',
        'destination': 'scripts/utilities/check_mf_test_status.py'
    },
    {
        'source': 'test_mf_mor_with_email_verification.py',
        'destination': 'tests/integration/test_mf_mor_with_email_verification.py'
    },
    {
        'source': 'debug_take_action.py',
        'destination': 'scripts/debug/debug_take_action.py'
    },
    {
        'source': 'debug_referee_status.py',
        'destination': 'scripts/debug/debug_referee_status.py'
    },
    {
        'source': 'PROJECT_ROOT_OPTIMIZATION_ANALYSIS.md',
        'destination': 'docs/reference/PROJECT_ROOT_OPTIMIZATION_ANALYSIS.md'
    },
    {
        'source': 'simple_mf_data_20250719_183952.json',
        'destination': 'data/exports/legacy/simple_mf_data_20250719_183952.json'
    },
    {
        'source': 'patch_scholarone_extractor.py',
        'destination': 'scripts/utilities/patch_scholarone_extractor.py'
    },
    {
        'source': 'test_mf_mor_detailed.py',
        'destination': 'tests/integration/test_mf_mor_detailed.py'
    },
    {
        'source': 'quick_mf_test.py',
        'destination': 'scripts/utilities/quick_mf_test.py'
    },
    {
        'source': 'fix_scholarone_take_action.py',
        'destination': 'scripts/utilities/fix_scholarone_take_action.py'
    },
    {
        'source': 'test_mf_mor_actual_extraction.py',
        'destination': 'tests/integration/test_mf_mor_actual_extraction.py'
    },
    {
        'source': 'debug_take_action_MAFI-2025-0166.html',
        'destination': 'data/debug/debug_take_action_MAFI-2025-0166.html'
    },
    {
        'source': 'debug_take_action_only.py',
        'destination': 'scripts/debug/debug_take_action_only.py'
    },
    {
        'source': 'show_working_extraction.py',
        'destination': 'scripts/utilities/show_working_extraction.py'
    },
    {
        'source': 'MF_PARSING_IMPROVEMENTS_SUMMARY.md',
        'destination': 'docs/reference/MF_PARSING_IMPROVEMENTS_SUMMARY.md'
    },
    {
        'source': 'test_mf_direct.py',
        'destination': 'tests/integration/test_mf_direct.py'
    },
    {
        'source': 'extract_real_data_from_logs.py',
        'destination': 'scripts/utilities/extract_real_data_from_logs.py'
    },
    {
        'source': 'sifin_firefox_20250717_093942.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_093942.json'
    },
    {
        'source': 'analyze_sifin_manuscript_ids.py',
        'destination': 'scripts/utilities/analyze_sifin_manuscript_ids.py'
    },
    {
        'source': 'debug_sifin_gmail_search.py',
        'destination': 'scripts/debug/debug_sifin_gmail_search.py'
    },
    {
        'source': 'test_mor_verification.py',
        'destination': 'tests/integration/test_mor_verification.py'
    },
    {
        'source': 'sifin_enhanced_timeline_20250717_131315.json',
        'destination': 'data/exports/legacy/sifin_enhanced_timeline_20250717_131315.json'
    },
    {
        'source': 'test_mf_robust.py',
        'destination': 'tests/integration/test_mf_robust.py'
    },
    {
        'source': 'debug_take_action_MAFI-2024-0167.html',
        'destination': 'data/debug/debug_take_action_MAFI-2024-0167.html'
    },
    {
        'source': 'test_minimal_mf.py',
        'destination': 'tests/legacy/test_minimal_mf.py'
    },
    {
        'source': 'show_real_mf_data.py',
        'destination': 'scripts/utilities/show_real_mf_data.py'
    },
    {
        'source': 'debug_mf_navigation.py',
        'destination': 'scripts/debug/debug_mf_navigation.py'
    },
    {
        'source': 'test_extraction_quick.py',
        'destination': 'tests/integration/test_extraction_quick.py'
    },
    {
        'source': 'real_mf_extraction_summary.json',
        'destination': 'data/exports/legacy/real_mf_extraction_summary.json'
    },
    {
        'source': 'ULTRATHINK_SAFE_REFACTORING_STRATEGY.md',
        'destination': 'docs/reference/ULTRATHINK_SAFE_REFACTORING_STRATEGY.md'
    },
    {
        'source': 'take_action_test_page.html',
        'destination': 'data/debug/take_action_test_page.html'
    },
    {
        'source': 'sifin_firefox_20250717_083630.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_083630.json'
    },
    {
        'source': 'sifin_firefox_20250717_005036.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_005036.json'
    },
    {
        'source': 'test_timeline_consistency.py',
        'destination': 'tests/legacy/test_timeline_consistency.py'
    },
    {
        'source': 'page_text_sample.txt',
        'destination': 'data/exports/legacy/page_text_sample.txt'
    },
    {
        'source': 'test_mf_complete.py',
        'destination': 'tests/integration/test_mf_complete.py'
    },
    {
        'source': 'test_mf_simple.py',
        'destination': 'tests/integration/test_mf_simple.py'
    },
    {
        'source': 'mf_robust_results_20250719_100829.json',
        'destination': 'data/exports/legacy/mf_robust_results_20250719_100829.json'
    },
    {
        'source': 'show_complete_mf_data.py',
        'destination': 'scripts/utilities/show_complete_mf_data.py'
    },
    {
        'source': 'run_complete_extraction_with_validation.py',
        'destination': 'scripts/utilities/run_complete_extraction_with_validation.py'
    },
    {
        'source': 'sifin_extraction_20250716_181157.json',
        'destination': 'data/exports/legacy/sifin_extraction_20250716_181157.json'
    },
    {
        'source': 'debug_mf_navigation_visual.py',
        'destination': 'scripts/debug/debug_mf_navigation_visual.py'
    },
    {
        'source': 'SESSION_COMPLETE_ULTRATHINK_SUMMARY.md',
        'destination': 'docs/reference/SESSION_COMPLETE_ULTRATHINK_SUMMARY.md'
    },
    {
        'source': 'debug_mor_login.py',
        'destination': 'scripts/debug/debug_mor_login.py'
    },
    {
        'source': 'fixed_mf_data_20250719_192659.json',
        'destination': 'data/exports/legacy/fixed_mf_data_20250719_192659.json'
    },
    {
        'source': 'mf_after_login.html',
        'destination': 'data/debug/mf_after_login.html'
    },
    {
        'source': 'SIFIN_SICON_EXTENSION_STRATEGY.md',
        'destination': 'docs/reference/SIFIN_SICON_EXTENSION_STRATEGY.md'
    },
    {
        'source': 'sifin_firefox_20250717_083332.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_083332.json'
    },
    {
        'source': 'sifin_firefox_20250717_091026.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_091026.json'
    },
    {
        'source': 'AUDIT_REPORT_MF_MOR_SYSTEMS.md',
        'destination': 'docs/reference/AUDIT_REPORT_MF_MOR_SYSTEMS.md'
    },
    {
        'source': 'debug_2fa_failed.html',
        'destination': 'data/debug/debug_2fa_failed.html'
    },
    {
        'source': 'mf_post_login.html',
        'destination': 'data/debug/mf_post_login.html'
    },
    {
        'source': 'sifin_extraction_20250716_234224.json',
        'destination': 'data/exports/legacy/sifin_extraction_20250716_234224.json'
    },
    {
        'source': 'mf_ae_dashboard.png',
        'destination': 'data/debug/mf_ae_dashboard.png'
    },
    {
        'source': 'debug_mf_mor_manuscript_extraction.py',
        'destination': 'scripts/debug/debug_mf_mor_manuscript_extraction.py'
    },
    {
        'source': 'mf_improved_parsing_results_20250719_182737.json',
        'destination': 'data/exports/legacy/mf_improved_parsing_results_20250719_182737.json'
    },
    {
        'source': 'sifin_email_timeline_20250717_120648.json',
        'destination': 'data/exports/legacy/sifin_email_timeline_20250717_120648.json'
    },
    {
        'source': 'test_sifin_timeline_consistency.py',
        'destination': 'tests/integration/test_sifin_timeline_consistency.py'
    },
    {
        'source': 'sifin_firefox_20250717_085907.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_085907.json'
    },
    {
        'source': 'SIFIN_GMAIL_SEARCH_DEBUG_REPORT.md',
        'destination': 'docs/reference/SIFIN_GMAIL_SEARCH_DEBUG_REPORT.md'
    },
    {
        'source': 'sifin_firefox_20250717_084245.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_084245.json'
    },
    {
        'source': 'debug_login_state.py',
        'destination': 'scripts/debug/debug_login_state.py'
    },
    {
        'source': 'sifin_gmail_debug_M147228_20250717_092302.json',
        'destination': 'data/exports/legacy/sifin_gmail_debug_M147228_20250717_092302.json'
    },
    {
        'source': 'fix_take_action_bulletproof.py',
        'destination': 'scripts/utilities/fix_take_action_bulletproof.py'
    },
    {
        'source': 'sifin_firefox_20250717_004850.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_004850.json'
    },
    {
        'source': 'test_mf_with_2fa.py',
        'destination': 'tests/integration/test_mf_with_2fa.py'
    },
    {
        'source': 'sifin_firefox_20250717_083851.json',
        'destination': 'data/exports/legacy/sifin_firefox_20250717_083851.json'
    },
    {
        'source': 'test_improved_mf_parsing.py',
        'destination': 'tests/integration/test_improved_mf_parsing.py'
    },
    {
        'source': 'check_mf_access.py',
        'destination': 'scripts/utilities/check_mf_access.py'
    },
    {
        'source': 'verify_mf_improvements.py',
        'destination': 'scripts/utilities/verify_mf_improvements.py'
    },
]

def execute_migrations():
    """Execute all migrations."""
    success = 0
    failed = 0
    
    print("Executing migrations...")
    print("-" * 60)
    
    for m in MIGRATIONS:
        src = PROJECT_ROOT / m['source']
        dst = PROJECT_ROOT / m['destination']
        
        try:
            # Create destination directory
            dst.parent.mkdir(parents=True, exist_ok=True)
            
            # Move file
            shutil.move(str(src), str(dst))
            print(f"✅ {m['source']} → {m['destination']}")
            success += 1
        except Exception as e:
            print(f"❌ {m['source']}: {e}")
            failed += 1
            
    print("-" * 60)
    print(f"Complete: {success} moved, {failed} failed")
    
    return failed == 0

if __name__ == "__main__":
    import sys
    success = execute_migrations()
    sys.exit(0 if success else 1)
