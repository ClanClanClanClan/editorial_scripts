"""Verify basic setup is working."""


def test_imports():
    """Test that core imports work."""


def test_environment():
    """Test environment setup."""
    import os

    assert os.getenv("ENVIRONMENT", "development") == "development"


def test_project_structure():
    """Test project directories exist."""
    from pathlib import Path

    required_dirs = [
        "src/foundation",
        "src/domain",
        "src/application",
        "src/infrastructure",
        "src/presentation",
        "tests/unit",
        "tests/integration",
        "tests/e2e",
    ]

    for dir_path in required_dirs:
        assert Path(dir_path).is_dir(), f"Missing directory: {dir_path}"
