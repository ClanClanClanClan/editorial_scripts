#!/usr/bin/env python3
"""Show the working extraction with debug output"""

import os
import sys
import logging
from pathlib import Path
from dotenv import load_dotenv

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

# Enable detailed logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

from editorial_assistant.extractors.scholarone import ScholarOneExtractor

print("🎯 SHOWING MF EXTRACTION WITH FULL DEBUG OUTPUT")
print("=" * 60)

# Create extractor with visible browser and debug logging
extractor = ScholarOneExtractor('MF', headless=False)
extractor.logger.setLevel(logging.DEBUG)

print("\n📍 Starting extraction...")
print("Watch the logs to see:")
print("  - Login process")
print("  - Navigation to AE Center")
print("  - Finding manuscripts")
print("  - TAKE ACTION CLICKING")
print("  - Referee extraction\n")

try:
    result = extractor.extract()
    
    print(f"\n✅ EXTRACTION COMPLETE")
    print(f"Found {len(result.manuscripts)} manuscripts")
    
    for ms in result.manuscripts:
        print(f"\n📄 {ms.manuscript_id}")
        print(f"   Title: {ms.title[:80] if ms.title else 'N/A'}...")
        print(f"   Referees: {len(ms.referees)}")
        
        if ms.referees:
            for ref in ms.referees[:3]:
                print(f"     - {ref.name} ({ref.status})")
            if len(ms.referees) > 3:
                print(f"     ... and {len(ms.referees) - 3} more")
                
except Exception as e:
    print(f"\n❌ Error: {e}")
    import traceback
    traceback.print_exc()
    
    # Check for debug files
    import glob
    debug_files = glob.glob("debug_take_action_*.html")
    if debug_files:
        print(f"\n📁 Debug files created:")
        for f in debug_files:
            print(f"   - {f}")