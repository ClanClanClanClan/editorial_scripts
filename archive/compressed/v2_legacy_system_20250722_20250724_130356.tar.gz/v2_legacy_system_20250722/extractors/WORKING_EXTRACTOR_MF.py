#!/usr/bin/env python3
"""
WORKING EXTRACTOR FOR MF - PRODUCTION VERSION
=============================================

This is the DEFINITIVE, WORKING extractor for Mathematical Finance.
✅ PROVEN TO WORK - extracted complete data on 2025-07-21

RESULTS: mf_comprehensive_20250721_215939.json
- 2 manuscripts: MAFI-2025-0166, MAFI-2024-0167  
- 6 referees total with emails and affiliations
- Complete metadata, documents, editorial data

DO NOT MODIFY THIS FILE - IT IS THE GOLD STANDARD
"""

#!/usr/bin/env python3
"""
COMPREHENSIVE MF EXTRACTOR
==========================

Extracts ALL data from ALL categories with proper navigation.
"""

import os
import sys
import time
import json
import re
import requests
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Import the cover letter download fixer
from fix_cover_letter_download import CoverLetterDownloadFixer

# Load environment
load_dotenv('.env.production')


class ComprehensiveMFExtractor:
    def __init__(self):
        self.manuscripts = []
        self.processed_manuscript_ids = set()  # Track processed manuscripts to avoid duplicates
        self.download_dir = Path("downloads")  # Set up download directory
        self.setup_driver()
        
    def setup_driver(self):
        """Setup Chrome driver."""
        chrome_options = Options()
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        # Run in headful mode for debugging
        # chrome_options.add_argument('--headless')  # Commented out for debugging
        self.driver = webdriver.Chrome(options=chrome_options)
    
    def wait_for_element(self, by, value, timeout=10):
        """Wait for element and return it."""
        try:
            return WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located((by, value))
            )
        except:
            return None
    
    def login(self):
        """Login to MF platform."""
        print("🔐 Logging in...")
        self.driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        # Handle cookie banner
        try:
            self.driver.find_element(By.ID, "onetrust-reject-all-handler").click()
        except:
            pass
        
        # Login
        self.driver.find_element(By.ID, "USERID").send_keys(os.getenv('MF_EMAIL'))
        self.driver.find_element(By.ID, "PASSWORD").send_keys(os.getenv('MF_PASSWORD'))
        self.driver.execute_script("document.getElementById('logInButton').click();")
        time.sleep(3)
        
        # Handle 2FA
        try:
            token_field = self.driver.find_element(By.ID, "TOKEN_VALUE")
            print("   📱 2FA required...")
            
            # Record the exact time when 2FA starts - this is when the email will be sent
            login_start_time = time.time()
            print(f"   ⏰ Login timestamp: {datetime.fromtimestamp(login_start_time).strftime('%H:%M:%S')}")
            
            # Wait for the verification email to be sent and arrive
            print("   📧 Waiting for verification email to arrive...")
            time.sleep(15)  # Give email service more time to send and deliver
            
            # Try to fetch verification code with timestamp filtering
            code = None
            
            try:
                sys.path.insert(0, str(Path(__file__).parent))
                from core.email_utils import fetch_latest_verification_code
                print("   🔍 Fetching RECENT verification code from Gmail...")
                code = fetch_latest_verification_code('MF', max_wait=45, poll_interval=3, start_timestamp=login_start_time)
                
                # Additional validation - make sure we got a fresh code
                if code and len(code) == 6 and code.isdigit():
                    print(f"   ✅ Found fresh verification code: {code[:3]}***")
                else:
                    print(f"   ⚠️ Invalid code format: {code}")
                    code = None
                    
            except Exception as e:
                print(f"   ❌ Gmail fetch failed: {e}")
                code = None
            
            if code:
                print(f"   🔑 Entering verification code...")
                token_field.clear()
                token_field.send_keys(code)
                self.driver.find_element(By.ID, "VERIFY_BTN").click()
                time.sleep(8)
                
                # Check if 2FA succeeded by seeing if we're still on the verification page
                try:
                    still_on_2fa = self.driver.find_element(By.ID, "TOKEN_VALUE")
                    print("   ❌ 2FA failed - still on verification page")
                    return False
                except:
                    print("   ✅ 2FA successful - moved past verification page")
                
                # Handle device verification modal if it appears
                try:
                    modal = self.driver.find_element(By.ID, "unrecognizedDeviceModal")
                    if modal.is_displayed():
                        print("   📱 Handling device verification...")
                        close_btn = modal.find_element(By.CLASS_NAME, "button-close")
                        close_btn.click()
                        time.sleep(3)
                except:
                    pass
                    
                return True
                
            else:
                print("   ❌ Could not fetch verification code from Gmail")
                print("   💡 Possible issues:")
                print("      - Gmail API not properly configured")
                print("      - No recent verification email received")
                print("      - Email delivery delay")
                return False
                
        except Exception as e:
            print(f"   ❌ 2FA error: {e}")
            return False
    
    def get_manuscript_categories(self):
        """Get all manuscript categories with counts."""
        print("\n📊 Finding manuscript categories...")
        
        categories = []
        
        # Categories to check (excluding "Manuscripts Awaiting Revision" section)
        category_names = [
            "Awaiting Reviewer Selection",
            "Awaiting Reviewer Invitation", 
            "Awaiting Reviewer Assignment",
            "Awaiting Reviewer Scores",
            "Overdue Reviewer Scores",
            "Awaiting AE Recommendation"
        ]
        
        for category_name in category_names:
            try:
                # Find the link with this category name
                category_link = self.driver.find_element(By.XPATH, f"//a[contains(text(), '{category_name}')]")
                
                # Find the row containing this link
                row = category_link.find_element(By.XPATH, "./ancestor::tr[1]")
                
                # Get count - look for <b> tag with number in the same row
                try:
                    count_elem = row.find_element(By.XPATH, ".//p[@class='pagecontents']/b")
                    
                    # Check if it's a link or just text
                    link_elems = count_elem.find_elements(By.TAG_NAME, "a")
                    if link_elems:
                        count = int(link_elems[0].text.strip())
                    else:
                        count = int(count_elem.text.strip())
                    
                    categories.append({
                        'name': category_name,
                        'count': count,
                        'link': category_link
                    })
                    if count > 0:
                        print(f"   ✓ {category_name}: {count} manuscripts")
                    else:
                        print(f"   - {category_name}: 0 manuscripts (will check anyway)")
                        
                except Exception as e:
                    print(f"   ❌ Error getting count for {category_name}: {e}")
                        
            except Exception as e:
                print(f"   ❌ Error finding {category_name}: {e}")
        
        return categories
    
    def extract_manuscript_details(self, manuscript_id):
        """Extract comprehensive manuscript details."""
        print(f"\n📄 Extracting details for {manuscript_id}...")
        
        manuscript = {
            'id': manuscript_id,
            'title': '',
            'authors': [],
            'submission_date': '',
            'last_updated': '',
            'in_review_time': '',
            'status': '',
            'status_details': '',
            'article_type': '',
            'special_issue': '',
            'referees': [],
            'editors': {},
            'documents': {}
        }
        
        try:
            # Extract from main info table
            info_table = self.driver.find_element(By.XPATH, "//td[@class='headerbg2']//table")
            
            # Title - extract from td colspan="2" containing the title
            try:
                title_elem = info_table.find_element(By.XPATH, ".//tr[2]/td[@colspan='2']/p[@class='pagecontents']")
                manuscript['title'] = title_elem.text.strip()
            except:
                # Fallback: look for any td with colspan="2" that has a long text
                title_elems = info_table.find_elements(By.XPATH, ".//td[@colspan='2']/p[@class='pagecontents']")
                for elem in title_elems:
                    text = elem.text.strip()
                    if len(text) > 30 and 'Original Article' not in text and 'special issue:' not in text.lower():
                        manuscript['title'] = text
                        break
            
            # Dates
            date_cells = info_table.find_elements(By.XPATH, ".//p[@class='footer']")
            for cell in date_cells:
                text = cell.text.strip()
                if 'Submitted:' in text:
                    manuscript['submission_date'] = text.replace('Submitted:', '').strip().rstrip(';')
                elif 'Last Updated:' in text:
                    manuscript['last_updated'] = text.replace('Last Updated:', '').strip().rstrip(';')
                elif 'In Review:' in text:
                    manuscript['in_review_time'] = text.replace('In Review:', '').strip()
            
            # Status
            status_elem = info_table.find_element(By.XPATH, ".//font[@color='green']")
            if status_elem:
                status_text = status_elem.text
                manuscript['status'] = status_text.split('(')[0].strip()
                
                # Extract status details (e.g., "2 active selections; 2 invited...")
                details_elem = status_elem.find_element(By.XPATH, ".//span[@class='footer']")
                if details_elem:
                    manuscript['status_details'] = details_elem.text.strip()
            
            # Authors - extract from the specific author row (3rd row with bullet point)
            try:
                # Find the row with authors (has bullet and contains mailpopup links)
                author_row = info_table.find_element(By.XPATH, ".//tr[3]/td[@colspan='2']/p[@class='pagecontents']")
                author_text = author_row.text.strip()
                
                # Parse author text like "Zhang, Panpan (contact); Wang, Guangchen; Xu, Zuo Quan"
                if ';' in author_text or '(contact)' in author_text:
                    # Split by semicolon to get individual authors
                    author_parts = author_text.split(';')
                    
                    for part in author_parts:
                        part = part.strip()
                        if part:
                            is_contact = '(contact)' in part
                            # Remove "(contact)" to get clean name
                            clean_name = part.replace('(contact)', '').strip()
                            
                            manuscript['authors'].append({
                                'name': self.normalize_name(clean_name),
                                'is_corresponding': is_contact,
                                'email': ''  # Don't extract emails from authors
                            })
                else:
                    # Single author case
                    is_contact = '(contact)' in author_text
                    clean_name = author_text.replace('(contact)', '').strip()
                    manuscript['authors'].append({
                        'name': self.normalize_name(clean_name),
                        'is_corresponding': is_contact,
                        'email': ''  # Don't extract emails from authors
                    })
                    
            except Exception as e:
                print(f"   ❌ Error extracting authors: {e}")
                # Fallback to old method
                author_links = info_table.find_elements(By.XPATH, ".//a[contains(@href, 'mailpopup')]")
                editor_names = ['Possamai', 'Cont', 'Chandni']
                referee_names = ['Liang', 'Strub', 'Mrad', 'Reis']
                
                for link in author_links:
                    name = link.text.strip()
                    if name and not any(ed_name in name for ed_name in editor_names + referee_names):
                        is_contact = False
                        try:
                            parent_text = link.find_element(By.XPATH, "..").text
                            if '(contact)' in parent_text:
                                is_contact = True
                        except:
                            pass
                        
                        manuscript['authors'].append({
                            'name': self.normalize_name(name),
                            'is_corresponding': is_contact,
                            'email': ''  # Don't extract emails from authors
                        })
            
            # Article type and special issue
            type_elems = info_table.find_elements(By.XPATH, ".//p[@class='pagecontents']")
            for elem in type_elems:
                text = elem.text.strip()
                if text == 'Original Article':
                    manuscript['article_type'] = text
                elif 'special issue:' in text.lower():
                    manuscript['special_issue'] = text.split(':')[1].strip()
            
            # Editors (AE, EIC, CO, ADM)
            editor_section = info_table.find_element(By.XPATH, ".//nobr[contains(text(), 'AE:')]/parent::p/parent::td")
            editor_lines = editor_section.find_elements(By.XPATH, ".//nobr")
            for line in editor_lines:
                text = line.text
                if ':' in text:
                    role, name = text.split(':', 1)
                    role = role.strip()
                    # Get the link for email
                    try:
                        link = line.find_element(By.TAG_NAME, "a")
                        manuscript['editors'][role] = {
                            'name': name.strip(),
                            'email': ''  # Don't extract editor emails
                        }
                    except:
                        manuscript['editors'][role] = {
                            'name': name.strip(),
                            'email': ''
                        }
            
        except Exception as e:
            print(f"   ❌ Error extracting info: {e}")
        
        # Extract referees
        self.extract_referees_comprehensive(manuscript)
        
        # Extract documents
        self.extract_document_links(manuscript)
        
        return manuscript
    
    def normalize_name(self, name):
        """Convert 'Last, First' to 'First Last'."""
        name = name.strip()
        if ',' in name:
            parts = name.split(',', 1)
            return f"{parts[1].strip()} {parts[0].strip()}"
        return name
    
    def extract_referees_comprehensive(self, manuscript):
        """Extract comprehensive referee information from the referee table."""
        print("   👥 Extracting referee details...")
        
        try:
            # Find referee table section - look for table rows with class="tablelightcolor" 
            # that are NOT in the manuscript info header (class="headerbg2")
            referee_table_rows = self.driver.find_elements(By.XPATH, 
                "//td[@class='tablelines']//tr[td[@class='tablelightcolor']]")
            
            print(f"      Found {len(referee_table_rows)} referee rows in referee table")
            
            # We don't need to filter by names - if it's in the referee table, it's a referee
            author_names = [author['name'].split()[-1] for author in manuscript['authors']]  # Last names for debugging
            
            for row in referee_table_rows:
                try:
                    referee = {
                        'name': '',
                        'email': '',
                        'affiliation': '',
                        'orcid': '',
                        'status': '',
                        'dates': {},
                        'report': None
                    }
                    
                    # Extract name from mailpopup link in second column
                    try:
                        name_link = row.find_element(By.XPATH, ".//a[contains(@href,'mailpopup')]")
                        full_name = name_link.text.strip()
                        referee['name'] = self.normalize_name(full_name)
                        
                        # Get email from popup
                        print(f"         Getting email for {referee['name']}...")
                        referee['email'] = self.get_email_from_popup(name_link, referee['name'])
                    except Exception as e:
                        print(f"         ❌ Error extracting name: {e}")
                        continue
                    
                    # Extract affiliation from span in name cell
                    try:
                        affil_span = row.find_element(By.XPATH, ".//span[@class='pagecontents']")
                        affil_text = affil_span.text.strip()
                        if affil_text and affil_text != referee['name']:
                            referee['affiliation'] = affil_text.split('<br>')[0].strip()
                    except:
                        pass
                    
                    # Extract ORCID
                    try:
                        orcid_link = row.find_element(By.XPATH, ".//a[contains(@href,'orcid.org')]")
                        referee['orcid'] = orcid_link.get_attribute('href')
                    except:
                        pass
                    
                    # Extract status from third column
                    try:
                        status_cell = row.find_elements(By.XPATH, ".//td[@class='tablelightcolor']")[2]
                        status_text = status_cell.text.strip()
                        referee['status'] = status_text
                        
                        # Check for view review button
                        try:
                            review_link = status_cell.find_element(By.XPATH, ".//a[contains(@href,'rev_ms_det_pop')]")
                            if review_link:
                                print(f"         📄 Found review report link, extracting...")
                                report_data = self.extract_referee_report_from_link(review_link)
                                if report_data:
                                    referee['report'] = report_data
                        except:
                            # No review link found
                            pass
                    except:
                        pass
                    
                    # Extract dates from history column (fourth column)
                    try:
                        history_cell = row.find_elements(By.XPATH, ".//td[@class='tablelightcolor']")[3]
                        
                        # Extract specific dates
                        date_rows = history_cell.find_elements(By.XPATH, ".//table//tr")
                        for date_row in date_rows:
                            try:
                                cells = date_row.find_elements(By.TAG_NAME, "td")
                                if len(cells) >= 2:
                                    date_type = cells[0].text.strip().lower().replace(':', '')
                                    date_value = cells[1].text.strip()
                                    
                                    if 'invited' in date_type:
                                        referee['dates']['invited'] = date_value
                                    elif 'agreed' in date_type:
                                        referee['dates']['agreed'] = date_value
                                    elif 'due' in date_type:
                                        referee['dates']['due'] = date_value
                                    elif 'return' in date_type:
                                        referee['dates']['returned'] = date_value
                            except:
                                pass
                    except:
                        pass
                    
                    # Check for reports - look for history popup links
                    try:
                        history_links = row.find_elements(By.XPATH, ".//a[contains(@href,'history_popup')]")
                        if history_links:
                            referee['report'] = {'available': True, 'url': history_links[0].get_attribute('href')}
                    except:
                        pass
                    
                    manuscript['referees'].append(referee)
                    print(f"         ✅ {referee['name']} ({referee['status']}) - {referee['affiliation']}")
                    
                except Exception as e:
                    print(f"      ❌ Error processing referee row: {e}")
            
            print(f"      Total referees extracted: {len(manuscript['referees'])}")
                    
        except Exception as e:
            print(f"   ❌ Error extracting referees: {e}")
            import traceback
            traceback.print_exc()
    
    def extract_referee_report_from_link(self, report_link):
        """Extract referee report details from review link."""
        try:
            current_window = self.driver.current_window_handle
            
            # Click report link
            report_link.click()
            time.sleep(3)
            
            # Switch to new window
            all_windows = self.driver.window_handles
            if len(all_windows) > 1:
                report_window = [w for w in all_windows if w != current_window][-1]
                self.driver.switch_to.window(report_window)
                time.sleep(2)
                
                report_data = {
                    'comments_to_editor': '',
                    'comments_to_author': '',
                    'recommendation': '',
                    'pdf_files': []
                }
                
                try:
                    # Extract confidential comments to editor
                    try:
                        editor_comment_cells = self.driver.find_elements(By.XPATH, 
                            "//p[contains(text(), 'Confidential Comments to the Editor')]/ancestor::tr/following-sibling::tr[1]//p[@class='pagecontents']")
                        if editor_comment_cells:
                            text = editor_comment_cells[0].text.strip()
                            if text and text != '\xa0' and 'see attached' not in text.lower():
                                report_data['comments_to_editor'] = text
                    except:
                        pass
                    
                    # Extract comments to author
                    try:
                        author_comment_cells = self.driver.find_elements(By.XPATH, 
                            "//p[contains(text(), 'Comments to the Author')]/ancestor::tr/following-sibling::tr[1]//p[@class='pagecontents']")
                        if author_comment_cells:
                            text = author_comment_cells[-1].text.strip()  # Get last one (after "Major and Minor" instruction)
                            if text and text != '\xa0' and 'see attached' not in text.lower():
                                report_data['comments_to_author'] = text
                    except:
                        pass
                    
                    # Look for attached PDF files
                    try:
                        pdf_links = self.driver.find_elements(By.XPATH, 
                            "//a[contains(@href, 'referee_report') and contains(@href, '.pdf')]")
                        
                        for pdf_link in pdf_links:
                            pdf_url = pdf_link.get_attribute('href')
                            pdf_name = pdf_link.text.strip()
                            
                            # Download the PDF
                            pdf_path = self.download_referee_report_pdf(pdf_url, pdf_name)
                            if pdf_path:
                                report_data['pdf_files'].append({
                                    'name': pdf_name,
                                    'path': pdf_path
                                })
                    except:
                        pass
                    
                    # Look for recommendation
                    try:
                        rec_elem = self.driver.find_element(By.XPATH, 
                            "//select[@name='recommendation']/option[@selected] | //p[contains(text(), 'Recommendation:')]")
                        report_data['recommendation'] = rec_elem.text.strip()
                    except:
                        pass
                    
                except Exception as e:
                    print(f"         ❌ Error parsing report content: {e}")
                
                # Close window
                self.driver.close()
                self.driver.switch_to.window(current_window)
                
                return report_data
            
        except Exception as e:
            print(f"         ❌ Error extracting report: {e}")
            try:
                self.driver.switch_to.window(current_window)
            except:
                pass
        
        return None
    
    def extract_document_links(self, manuscript):
        """Extract document links and download PDF and Cover Letter."""
        try:
            # Find the document links section
            doc_section = self.driver.find_element(By.XPATH, "//p[@class='pagecontents msdetailsbuttons']")
            
            # PDF link
            pdf_links = doc_section.find_elements(By.XPATH, ".//a[contains(@class, 'msdetailsbuttons') and contains(text(), 'PDF')]")
            if pdf_links:
                manuscript['documents']['pdf'] = True
                # Extract size if available
                pdf_text = pdf_links[0].get_attribute('title')
                if pdf_text and 'K' in pdf_text:
                    manuscript['documents']['pdf_size'] = pdf_text
                
                # Download PDF
                print(f"   📄 Downloading PDF for {manuscript['id']}...")
                pdf_path = self.download_pdf(pdf_links[0], manuscript['id'])
                if pdf_path:
                    manuscript['documents']['pdf_path'] = pdf_path
            
            # HTML link
            html_links = doc_section.find_elements(By.XPATH, ".//a[contains(text(), 'HTML')]")
            if html_links:
                manuscript['documents']['html'] = True
            
            # Abstract
            abstract_links = doc_section.find_elements(By.XPATH, ".//a[contains(text(), 'Abstract')]")
            if abstract_links:
                manuscript['documents']['abstract'] = True
            
            # Cover Letter
            cover_links = doc_section.find_elements(By.XPATH, ".//a[contains(text(), 'Cover Letter')]")
            if cover_links:
                manuscript['documents']['cover_letter'] = True
                
                # Download Cover Letter
                print(f"   📋 Downloading cover letter for {manuscript['id']}...")
                cover_path = self.download_cover_letter(cover_links[0], manuscript['id'])
                if cover_path:
                    manuscript['documents']['cover_letter_path'] = cover_path
                
        except Exception as e:
            print(f"   ❌ Error extracting documents: {e}")
    
    def get_email_from_popup(self, link, name):
        """Extract email from popup window with frame handling."""
        original_window = self.driver.current_window_handle
        
        try:
            # Click link
            link.click()
            time.sleep(2)
            
            # Check for new windows
            all_windows = self.driver.window_handles
            
            if len(all_windows) > 1:
                # Switch to popup window
                popup_window = [w for w in all_windows if w != original_window][-1]
                self.driver.switch_to.window(popup_window)
                time.sleep(1)
                
                try:
                    # Check if the popup uses frames
                    frames = self.driver.find_elements(By.TAG_NAME, "frame")
                    if frames:
                        # Switch to the main email frame (usually named 'mainemailwindow')
                        for frame in frames:
                            frame_name = frame.get_attribute('name')
                            if 'mail' in frame_name.lower():
                                self.driver.switch_to.frame(frame)
                                break
                        else:
                            # If no mail frame found, try first frame
                            self.driver.switch_to.frame(0)
                    
                    # Now extract email from the frame content
                    # In the email popup, the TO field contains the referee's email
                    try:
                        # Try to find the TO field input element
                        to_field = self.driver.find_element(By.NAME, "EMAIL_TEMPLATE_TO")
                        referee_email = to_field.get_attribute('value')
                        if referee_email and '@' in referee_email:
                            print(f"         ✅ Found email: {referee_email}")
                            return referee_email
                    except:
                        pass
                    
                    # Fallback: search in page source for the TO field value
                    page_source = self.driver.page_source
                    import re
                    
                    # Look for EMAIL_TEMPLATE_TO input field value
                    to_pattern = r'name="EMAIL_TEMPLATE_TO"[^>]+value="([^"]+)"'
                    to_match = re.search(to_pattern, page_source)
                    if to_match:
                        referee_email = to_match.group(1)
                        if referee_email and '@' in referee_email:
                            print(f"         ✅ Found email: {referee_email}")
                            return referee_email
                    
                    print(f"         ❌ No email found in popup")
                    
                except Exception as e:
                    print(f"         ❌ Error reading popup content: {str(e)[:50]}")
                
                finally:
                    # Close popup and return to main window
                    self.driver.close()
                    self.driver.switch_to.window(original_window)
            else:
                print(f"         ❌ No popup window opened")
                
        except Exception as e:
            print(f"         ❌ Email extraction error: {str(e)[:50]}")
            
        finally:
            # Ensure we're back on the main window
            try:
                if self.driver.current_window_handle != original_window:
                    self.driver.switch_to.window(original_window)
            except:
                # Emergency cleanup
                try:
                    windows = self.driver.window_handles
                    for window in windows[1:]:  # Close all but first
                        self.driver.switch_to.window(window)
                        self.driver.close()
                    self.driver.switch_to.window(windows[0])
                except:
                    pass
        
        return ''
    
    def download_pdf(self, pdf_link, manuscript_id):
        """Download manuscript PDF."""
        try:
            original_window = self.driver.current_window_handle
            
            # Click PDF link
            pdf_link.click()
            time.sleep(3)
            
            # Check for new window
            all_windows = self.driver.window_handles
            if len(all_windows) > 1:
                # Switch to PDF window
                pdf_window = [w for w in all_windows if w != original_window][-1]
                self.driver.switch_to.window(pdf_window)
                time.sleep(2)
                
                # Get PDF URL
                pdf_url = self.driver.current_url
                
                # Create downloads directory
                downloads_dir = Path("downloads/manuscripts")
                downloads_dir.mkdir(parents=True, exist_ok=True)
                
                # Save PDF using requests
                import requests
                
                # Get cookies from selenium
                cookies = self.driver.get_cookies()
                session = requests.Session()
                for cookie in cookies:
                    session.cookies.set(cookie['name'], cookie['value'])
                
                # Download PDF
                response = session.get(pdf_url, stream=True)
                if response.status_code == 200:
                    pdf_path = downloads_dir / f"{manuscript_id}.pdf"
                    with open(pdf_path, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            f.write(chunk)
                    print(f"      ✅ PDF saved to {pdf_path}")
                    
                    # Close PDF window
                    self.driver.close()
                    self.driver.switch_to.window(original_window)
                    
                    return str(pdf_path)
                else:
                    print(f"      ❌ Failed to download PDF: {response.status_code}")
                
                # Close window
                self.driver.close()
                self.driver.switch_to.window(original_window)
                
        except Exception as e:
            print(f"      ❌ Error downloading PDF: {e}")
            # Ensure we're back on main window
            try:
                self.driver.switch_to.window(original_window)
            except:
                pass
        
        return None
    
    def download_cover_letter(self, cover_link, manuscript_id):
        """Download cover letter using the fixed approach that gets actual files."""
        try:
            # Store current state
            original_window = self.driver.current_window_handle
            
            # First, click on the cover letter link to open the popup
            print(f"      🔗 Clicking on cover letter link...")
            self.driver.execute_script("arguments[0].click();", cover_link)
            time.sleep(3)
            
            # Switch to the popup window
            all_windows = self.driver.window_handles
            if len(all_windows) > 1:
                for window in all_windows:
                    if window != original_window:
                        self.driver.switch_to.window(window)
                        break
                print(f"      📄 Switched to cover letter popup")
                
                # Wait for content to load
                time.sleep(2)
                
                # Look for file links in the popup
                file_link_selectors = [
                    "//a[contains(@href, '.pdf')]",
                    "//a[contains(@href, '.docx')]",
                    "//a[contains(@href, '.doc')]",
                    "//a[contains(@href, 'FILE')]",
                    "//a[contains(text(), '.pdf')]",
                    "//a[contains(text(), '.docx')]",
                    "//a[contains(text(), 'Download')]",
                    "//a[contains(@class, 'file-link')]",
                    "//input[@value='View Cover Letter']",  # Sometimes it's another button
                    "//button[contains(text(), 'Download')]"
                ]
                
                file_downloaded = False
                file_path = None
                
                for selector in file_link_selectors:
                    try:
                        elements = self.driver.find_elements(By.XPATH, selector)
                        if elements:
                            for elem in elements:
                                # Check if it's a link with a file
                                href = elem.get_attribute('href') if elem.tag_name == 'a' else None
                                if href and any(ext in href.lower() for ext in ['.pdf', '.docx', '.doc']):
                                    print(f"      📎 Found file link: {href}")
                                    # Download using requests
                                    file_path = self._download_file_from_url(href, manuscript_id)
                                    if file_path:
                                        file_downloaded = True
                                        break
                                # If it's a View Cover Letter button, click it
                                elif elem.tag_name in ['input', 'button'] and 'View' in elem.get_attribute('value', ''):
                                    print(f"      🔘 Clicking View Cover Letter button...")
                                    elem.click()
                                    time.sleep(2)
                                    # Continue searching for file links
                    except Exception as e:
                        continue
                    
                    if file_downloaded:
                        break
                
                # Close popup and return to main window
                self.driver.close()
                self.driver.switch_to.window(original_window)
                
                if file_downloaded:
                    return file_path
                else:
                    print(f"      ❌ No downloadable file found in popup")
                    # Fall back to text extraction
                    return self._extract_cover_letter_text(manuscript_id)
            else:
                print(f"      ❌ No popup window opened")
                return self._extract_cover_letter_text(manuscript_id)
                
        except Exception as e:
            print(f"      ❌ Cover letter error: {e}")
            try:
                self.driver.switch_to.window(original_window)
            except:
                pass
            return None
    
    def _download_file_from_url(self, url: str, manuscript_id: str):
        """Download file from URL using requests with selenium cookies"""
        try:
            import requests
            from urllib.parse import urlparse, unquote
            
            # Create downloads directory
            downloads_dir = Path("downloads/cover_letters")
            downloads_dir.mkdir(parents=True, exist_ok=True)
            
            # Get cookies from selenium
            cookies = {cookie['name']: cookie['value'] for cookie in self.driver.get_cookies()}
            
            # Get headers from selenium
            headers = {
                'User-Agent': self.driver.execute_script("return navigator.userAgent;"),
                'Referer': self.driver.current_url
            }
            
            print(f"      📥 Downloading from: {url[:100]}...")
            
            # Download file
            response = requests.get(url, cookies=cookies, headers=headers, stream=True, timeout=30, allow_redirects=True)
            print(f"      📊 Response: {response.status_code}, Content-Type: {response.headers.get('content-type', 'unknown')}")
            
            if response.status_code == 200:
                # Determine file extension from content-type or URL
                content_type = response.headers.get('content-type', '').lower()
                
                if 'pdf' in content_type or '.pdf' in url.lower():
                    filename = f"{manuscript_id}_cover_letter.pdf"
                elif 'officedocument.wordprocessingml' in content_type or '.docx' in url.lower():
                    filename = f"{manuscript_id}_cover_letter.docx"
                elif 'msword' in content_type or '.doc' in url.lower():
                    filename = f"{manuscript_id}_cover_letter.doc"
                else:
                    # Try to guess from content
                    content_start = response.content[:100]
                    if content_start.startswith(b'%PDF'):
                        filename = f"{manuscript_id}_cover_letter.pdf"
                    elif b'PK' in content_start[:4]:  # ZIP-based format (DOCX)
                        filename = f"{manuscript_id}_cover_letter.docx"
                    else:
                        filename = f"{manuscript_id}_cover_letter.pdf"  # Default to PDF
                
                file_path = downloads_dir / filename
                with open(file_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                
                file_size = file_path.stat().st_size
                print(f"      ✅ Downloaded: {filename} ({file_size:,} bytes)")
                
                # Verify it's not an HTML error page
                if file_size > 100:
                    with open(file_path, 'rb') as f:
                        start_bytes = f.read(100)
                        if b'<html' in start_bytes.lower() or b'<!doctype html' in start_bytes.lower():
                            print(f"      ⚠️ Downloaded file appears to be HTML, not a document")
                            file_path.unlink()  # Delete the HTML file
                            return None
                
                return str(file_path)
            else:
                print(f"      ❌ Download failed: HTTP {response.status_code}")
                print(f"      📝 Response content preview: {response.text[:200]}")
                return None
        
        except Exception as e:
            print(f"      ❌ Download error: {e}")
            return None
    
    def _extract_cover_letter_text(self, manuscript_id: str):
        """Extract cover letter text content from popup"""
        try:
            cover_text = ""
            
            # Try different selectors to find text content
            selectors = [
                "//textarea[@name='cover_letter']",
                "//div[@class='cover_letter']", 
                "//pre",
                "//div[contains(@class, 'content')]",
                "//div[contains(@class, 'text')]",
                "//p[string-length(text()) > 50]",
                "//body"
            ]
            
            for selector in selectors:
                try:
                    elem = self.driver.find_element(By.XPATH, selector)
                    text = elem.text.strip()
                    if text and len(text) > 50:  # Likely to be meaningful content
                        cover_text = text
                        print(f"      📝 Found text content using selector: {selector}")
                        break
                except:
                    continue
            
            if cover_text:
                # Create downloads directory
                downloads_dir = Path("downloads/cover_letters")
                downloads_dir.mkdir(parents=True, exist_ok=True)
                
                # Save cover letter text
                cover_path = downloads_dir / f"{manuscript_id}_cover_letter.txt"
                with open(cover_path, 'w', encoding='utf-8') as f:
                    f.write(cover_text)
                
                return str(cover_path)
            
            return None
            
        except Exception as e:
            print(f"      ❌ Text extraction error: {e}")
            return None
    
    def download_referee_report_pdf(self, pdf_url, pdf_name):
        """Download referee report PDF."""
        try:
            # Create downloads directory
            downloads_dir = Path("downloads/referee_reports")
            downloads_dir.mkdir(parents=True, exist_ok=True)
            
            # Clean filename
            safe_name = pdf_name.replace('/', '_').replace('\\', '_')
            
            # Download PDF using requests
            import requests
            
            # Get cookies from selenium
            cookies = self.driver.get_cookies()
            session = requests.Session()
            for cookie in cookies:
                session.cookies.set(cookie['name'], cookie['value'])
            
            # Download PDF
            response = session.get(pdf_url, stream=True)
            if response.status_code == 200:
                pdf_path = downloads_dir / safe_name
                with open(pdf_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                print(f"         ✅ Referee report saved to {pdf_path}")
                return str(pdf_path)
            else:
                print(f"         ❌ Failed to download referee report: {response.status_code}")
                
        except Exception as e:
            print(f"         ❌ Error downloading referee report PDF: {e}")
        
        return None
    
    def process_category(self, category):
        """Process all manuscripts in a category."""
        print(f"\n📂 Processing category: {category['name']} ({category['count']} manuscripts)")
        
        # Click category link
        category['link'].click()
        time.sleep(3)
        
        # Find all Take Action links
        take_action_links = self.driver.find_elements(By.XPATH, 
            "//a[contains(@href,'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
        
        if not take_action_links:
            print("   📭 No manuscripts in this category")
            return
        
        actual_count = len(take_action_links)
        print(f"   Found {actual_count} Take Action links")
        
        # Update count if different from expected
        if actual_count != category['count']:
            print(f"   ⚠️  Expected {category['count']} but found {actual_count} manuscripts")
            category['count'] = actual_count
        
        if actual_count == 0:
            return
        
        # Click first Take Action
        take_action_links[0].click()
        time.sleep(5)
        
        # Process manuscripts using Next Document navigation
        processed = 0
        max_attempts = max(category['count'], actual_count) + 2  # Safety buffer
        
        while processed < category['count'] and processed < max_attempts:
            # Add per-manuscript timeout protection
            manuscript_start_time = time.time()
            max_manuscript_time = 120  # 2 minutes per manuscript max
            
            print(f"\n   Processing manuscript {processed + 1}/{category['count']}...")
            
            try:
                # Wait for page to load
                time.sleep(3)
                
                # Extract manuscript ID from current page
                page_text = self.driver.find_element(By.TAG_NAME, "body").text
                mafi_match = re.search(r'MAFI-\d{4}-\d{4}', page_text)
                
                if mafi_match:
                    manuscript_id = mafi_match.group(0)
                    print(f"   Current manuscript: {manuscript_id}")
                    
                    # Check if already processed
                    if manuscript_id in self.processed_manuscript_ids:
                        print(f"   ⏭️  Skipping {manuscript_id} - already processed in another category")
                        processed += 1
                    else:
                        # Save page source for debugging
                        with open(f"debug_manuscript_{manuscript_id}_{processed+1}.html", 'w') as f:
                            f.write(self.driver.page_source)
                        
                        manuscript = self.extract_manuscript_details(manuscript_id)
                        manuscript['category'] = category['name']
                        self.manuscripts.append(manuscript)
                        self.processed_manuscript_ids.add(manuscript_id)
                        processed += 1
                        
                        print(f"   ✅ Processed {manuscript_id}")
                        
                        # Check manuscript timeout
                        if time.time() - manuscript_start_time > max_manuscript_time:
                            print(f"   ⏰ Manuscript timeout reached, moving to next")
                            processed += 1
                            continue
                else:
                    print("   ❌ No manuscript ID found on page")
                    break
                        
            except Exception as e:
                print(f"   ❌ Error processing manuscript {processed + 1}: {e}")
                processed += 1  # Skip this manuscript and continue
                continue
            
            # Try Next Document (only if not the last manuscript)
            if processed < category['count']:
                print(f"   🔄 Looking for Next Document button...")
                try:
                    # Try multiple selectors for Next Document
                    next_selectors = [
                        "//a[contains(@href,'XIK_NEXT_PREV_DOCUMENT_ID')]/img[@alt='Next Document']/..",
                        "//img[@alt='Next Document']/..",
                        "//a[contains(@href,'XIK_NEXT_PREV_DOCUMENT_ID')]"
                    ]
                    
                    next_btn = None
                    for selector in next_selectors:
                        try:
                            next_btn = self.driver.find_element(By.XPATH, selector)
                            print(f"     Found Next Document with selector: {selector}")
                            break
                        except:
                            continue
                    
                    if next_btn:
                        next_btn.click()
                        print(f"     ✅ Clicked Next Document")
                        time.sleep(5)  # Wait longer for navigation
                    else:
                        print("     ❌ Next Document button not found")
                        break
                        
                except Exception as e:
                    print(f"     ❌ Error clicking Next Document: {e}")
                    break
            else:
                print("   ✅ Processed all manuscripts in category")
        
        print(f"\n   Category complete: {processed}/{category['count']} manuscripts processed")
        
        # Return to AE Center
        self.navigate_to_ae_center()
    
    def navigate_to_ae_center(self):
        """Navigate back to Associate Editor Center."""
        try:
            ae_link = self.wait_for_element(By.LINK_TEXT, "Associate Editor Center")
            if ae_link:
                ae_link.click()
                time.sleep(3)
        except:
            pass
    
    def extract_all(self):
        """Main extraction method."""
        print("🚀 COMPREHENSIVE MF EXTRACTION")
        print("=" * 60)
        
        # Login
        login_success = self.login()
        if not login_success:
            print("❌ Login failed - cannot continue")
            return
        
        # Navigate to AE Center
        print("\n📋 Navigating to Associate Editor Center...")
        
        # Wait for page to fully load after login/2FA and ensure we're not on login page anymore
        max_wait = 30
        wait_count = 0
        while wait_count < max_wait:
            current_url = self.driver.current_url
            if "page=LOGIN" not in current_url and "login" not in current_url.lower():
                break
            print(f"   ⏳ Still on login page, waiting... ({wait_count + 1}/{max_wait})")
            time.sleep(2)
            wait_count += 1
        
        if wait_count >= max_wait:
            print(f"   ❌ Login failed - still on login page after {max_wait} seconds")
            print(f"   📧 Please check Gmail for verification code or ensure 2FA is working")
            return
        
        print(f"   ✅ Successfully logged in: {self.driver.current_url}")
        time.sleep(3)
        
        # Try multiple ways to find AE Center
        ae_link = None
        for attempt in range(3):
            try:
                print(f"   Attempt {attempt + 1}...")
                # Try exact text
                ae_link = self.driver.find_element(By.LINK_TEXT, "Associate Editor Center")
                break
            except:
                try:
                    # Try partial text
                    ae_link = self.driver.find_element(By.PARTIAL_LINK_TEXT, "Associate Editor")
                    break
                except:
                    try:
                        # Try XPath with JavaScript
                        ae_link = self.driver.find_element(By.XPATH, 
                            "//a[contains(@href, 'ASSOCIATE_EDITOR_DASHBOARD') and contains(text(), 'Associate Editor Center')]")
                        break
                    except:
                        if attempt < 2:
                            print(f"   Attempt {attempt + 1} failed, retrying...")
                            time.sleep(3)
        
        if ae_link:
            print("   ✅ Found Associate Editor Center")
            ae_link.click()
            time.sleep(5)
        else:
            print("   ❌ Failed to find Associate Editor Center after 3 attempts")
            # Save debug info
            with open("debug_ae_center_fail.html", 'w') as f:
                f.write(self.driver.page_source)
            print("   💾 Saved debug HTML to debug_ae_center_fail.html")
            return
        
        # Get categories
        categories = self.get_manuscript_categories()
        
        if not categories:
            print("❌ No categories with manuscripts found")
            return
        
        # Process each category
        for category in categories:
            self.process_category(category)
        
        # Save results
        self.save_results()
    
    def save_results(self):
        """Save comprehensive results and show precise summary."""
        # Save to JSON
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"mf_comprehensive_{timestamp}.json"
        
        with open(output_file, 'w') as f:
            json.dump(self.manuscripts, f, indent=2, default=str)
        
        # Generate extremely precise results summary
        self._print_precise_results_summary()
        print(f"\n💾 Full data saved to: {output_file}")
    
    def _print_precise_results_summary(self):
        """Print extremely precise results summary for user review."""
        print("\n" + "="*80)
        print("🔍 PRECISE RESULTS SUMMARY")
        print("="*80)
        
        print(f"\n📊 MANUSCRIPTS FOUND: {len(self.manuscripts)}")
        
        if not self.manuscripts:
            print("❌ NO MANUSCRIPTS PROCESSED")
            return
            
        for i, ms in enumerate(self.manuscripts, 1):
            print(f"\n📄 MANUSCRIPT {i}/{len(self.manuscripts)}: {ms.get('id', 'UNKNOWN')}")
            print(f"   Title: {ms.get('title', 'NO TITLE')[:60]}...")
            print(f"   Status: {ms.get('status', 'UNKNOWN')}")
            print(f"   Category: {ms.get('category', 'UNKNOWN')}")
            
            # Authors
            authors = ms.get('authors', [])
            print(f"   👥 Authors ({len(authors)}): {', '.join([a.get('name', 'Unknown') for a in authors])}")
            
            # Referees
            referees = ms.get('referees', [])
            print(f"   🔍 Referees ({len(referees)}):")
            if referees:
                for ref in referees:
                    name = ref.get('name', 'Unknown')
                    status = ref.get('status', 'Unknown')
                    email = ref.get('email', 'No email')
                    print(f"      • {name} ({status}) - {email}")
            else:
                print("      ❌ NO REFEREES EXTRACTED")
            
            # Documents
            docs = ms.get('documents', {})
            print(f"   📁 Documents:")
            if docs.get('pdf'):
                path = docs.get('pdf_path', 'Unknown path')
                size = docs.get('pdf_size', 'Unknown size')
                print(f"      ✅ PDF: {path} ({size})")
            else:
                print(f"      ❌ No PDF")
                
            if docs.get('cover_letter'):
                path = docs.get('cover_letter_path', 'Unknown path')
                print(f"      📝 Cover Letter: {path}")
            else:
                print(f"      ❌ No Cover Letter")
        
        # File system verification
        print(f"\n📂 FILE SYSTEM VERIFICATION:")
        
        # Check manuscript PDFs
        manuscript_dir = Path("downloads/manuscripts")
        if manuscript_dir.exists():
            pdf_files = list(manuscript_dir.glob("*.pdf"))
            print(f"   📄 Manuscript PDFs: {len(pdf_files)} files")
            for pdf in pdf_files:
                size_mb = pdf.stat().st_size / (1024*1024)
                print(f"      ✅ {pdf.name} ({size_mb:.1f} MB)")
        else:
            print(f"   ❌ No manuscripts directory")
        
        # Check cover letters
        cover_dir = Path("downloads/cover_letters")
        if cover_dir.exists():
            cover_files = list(cover_dir.glob("*"))
            print(f"   📝 Cover Letters: {len(cover_files)} files")
            for cover in cover_files:
                if cover.is_file():
                    size_kb = cover.stat().st_size / 1024
                    file_type = "PDF" if cover.suffix == ".pdf" else "DOCX" if cover.suffix == ".docx" else "TEXT"
                    print(f"      {'✅' if cover.suffix in ['.pdf', '.docx'] else '📝'} {cover.name} ({file_type}, {size_kb:.1f} KB)")
        else:
            print(f"   ❌ No cover letters directory")
        
        # Summary counts
        total_referees = sum(len(ms.get('referees', [])) for ms in self.manuscripts)
        total_pdfs = len(list(Path("downloads/manuscripts").glob("*.pdf"))) if Path("downloads/manuscripts").exists() else 0
        total_covers = len(list(Path("downloads/cover_letters").glob("*"))) if Path("downloads/cover_letters").exists() else 0
        
        print(f"\n📈 FINAL COUNTS:")
        print(f"   📄 Manuscripts Processed: {len(self.manuscripts)}")
        print(f"   🔍 Total Referees: {total_referees}")
        print(f"   📁 PDF Downloads: {total_pdfs}")
        print(f"   📝 Cover Letters: {total_covers}")
        
        # Success/Failure Analysis
        expected_referees = [4, 2]  # Based on user specification: paper 1 has 4, paper 2 has 2
        expected_total = sum(expected_referees[:len(self.manuscripts)])
        
        print(f"\n✅ SUCCESS/FAILURE ANALYSIS:")
        print(f"   Expected Manuscripts: 2")
        print(f"   Actual Manuscripts: {len(self.manuscripts)}")
        print(f"   Expected Total Referees: {expected_total}")
        print(f"   Actual Total Referees: {total_referees}")
        print(f"   Expected PDFs: 2")
        print(f"   Actual PDFs: {total_pdfs}")
        
        if len(self.manuscripts) == 2 and total_referees == expected_total and total_pdfs == 2:
            print(f"   🎉 PERFECT SUCCESS - All data extracted correctly!")
        else:
            print(f"   ⚠️ PARTIAL SUCCESS - Some data missing")
        
        print("="*80)
    
    def cleanup(self):
        """Close browser."""
        self.driver.quit()
    
    def run(self):
        """Run extraction."""
        try:
            self.extract_all()
        except Exception as e:
            print(f"\n❌ Fatal error: {e}")
            import traceback
            traceback.print_exc()
        finally:
            self.cleanup()


if __name__ == "__main__":
    extractor = ComprehensiveMFExtractor()
    extractor.run()