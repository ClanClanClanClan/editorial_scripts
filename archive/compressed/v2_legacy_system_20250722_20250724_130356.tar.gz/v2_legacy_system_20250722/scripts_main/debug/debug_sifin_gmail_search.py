#!/usr/bin/env python3
"""
Debug SIFIN Gmail Email Search
Comprehensive testing to understand why Gmail searches return 0 results for SIFIN manuscripts
"""

import os
import re
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional

# Gmail API imports
try:
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow  
    from google.auth.transport.requests import Request
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
    GMAIL_AVAILABLE = True
except ImportError:
    GMAIL_AVAILABLE = False
    print("❌ Gmail API libraries not available")

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SIFINGmailDebugger:
    """Debug Gmail search for SIFIN manuscripts"""
    
    SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']
    
    def __init__(self):
        self.service = None
        self.credentials = None
        
    def setup_service(self) -> bool:
        """Setup Gmail service with existing credentials"""
        if not GMAIL_AVAILABLE:
            logger.error("Gmail API libraries not available")
            return False
            
        try:
            # Check for existing credentials
            creds = self._load_credentials()
            if not creds:
                logger.error("No Gmail credentials found")
                return False
                
            # Build service
            self.service = build('gmail', 'v1', credentials=creds)
            logger.info("✅ Gmail service initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to setup Gmail service: {e}")
            return False
    
    def _load_credentials(self) -> Optional[Credentials]:
        """Load Gmail credentials from various locations"""
        # Check common credential locations
        credential_paths = [
            "config/gmail_token.json",
            "scripts/setup/token.json",
            "token.json",
            "gmail_token.json",
            os.path.expanduser("~/.config/editorial_scripts/gmail_token.json"),
            os.path.expanduser("~/.gmail_token.json")
        ]
        
        for path in credential_paths:
            if os.path.exists(path):
                try:
                    # Load token data
                    with open(path, 'r') as f:
                        token_data = json.load(f)
                    
                    # Load client credentials from gmail_credentials.json
                    client_id = None
                    client_secret = None
                    
                    # Try to load client credentials
                    creds_path = "config/gmail_credentials.json"
                    if os.path.exists(creds_path):
                        try:
                            with open(creds_path, 'r') as f:
                                creds_data = json.load(f)
                                client_id = creds_data.get('installed', {}).get('client_id')
                                client_secret = creds_data.get('installed', {}).get('client_secret')
                        except Exception as e:
                            logger.warning(f"Failed to load client credentials: {e}")
                    
                    # Create credentials from token data
                    creds = Credentials(
                        token=token_data.get('access_token'),
                        refresh_token=token_data.get('refresh_token'),
                        token_uri='https://oauth2.googleapis.com/token',
                        client_id=client_id or token_data.get('client_id'),
                        client_secret=client_secret or token_data.get('client_secret'),
                        scopes=self.SCOPES
                    )
                    
                    # Check if credentials are valid and refresh if needed
                    if creds.expired:
                        logger.info("Token expired, attempting to refresh...")
                        try:
                            creds.refresh(Request())
                            logger.info("Token refreshed successfully")
                        except Exception as e:
                            logger.warning(f"Failed to refresh token: {e}")
                            continue
                    
                    logger.info(f"Loaded credentials from: {path}")
                    return creds
                    
                except Exception as e:
                    logger.warning(f"Failed to load credentials from {path}: {e}")
                    continue
        
        # Try to load from credentials.json if available
        credentials_paths = [
            "config/gmail_credentials.json",
            "scripts/setup/credentials.json",
            "credentials.json"
        ]
        
        for path in credentials_paths:
            if os.path.exists(path):
                try:
                    flow = InstalledAppFlow.from_client_secrets_file(path, self.SCOPES)
                    creds = flow.run_local_server(port=0)
                    
                    # Save for future use
                    with open("config/gmail_token.json", 'w') as token:
                        token.write(creds.to_json())
                    
                    logger.info(f"Created new token from: {path}")
                    return creds
                except Exception as e:
                    logger.warning(f"Failed to create credentials from {path}: {e}")
                    continue
        
        return None
    
    def test_manuscript_search(self, manuscript_id: str) -> Dict:
        """Test different search patterns for a manuscript"""
        if not self.service:
            return {"error": "Gmail service not initialized"}
        
        print(f"\n{'='*60}")
        print(f"TESTING GMAIL SEARCH FOR MANUSCRIPT: {manuscript_id}")
        print(f"{'='*60}")
        
        # Test different search patterns
        search_patterns = [
            # Original patterns from user
            f'subject:{manuscript_id}',
            f'subject:SIFIN {manuscript_id}',
            f'subject:"SIAM Journal" {manuscript_id}',
            f'subject:"Financial Mathematics" {manuscript_id}',
            f'body:{manuscript_id}',
            f'(subject:referee OR subject:reviewer) {manuscript_id}',
            f'(subject:invitation OR subject:reminder) {manuscript_id}',
            f'(subject:accepted OR subject:declined) {manuscript_id}',
            f'(subject:overdue OR subject:late) {manuscript_id}',
            
            # Additional SIFIN-specific patterns
            f'from:sifin.siam.org {manuscript_id}',
            f'from:@siam.org {manuscript_id}',
            f'subject:SIFIN subject:{manuscript_id}',
            f'subject:"SIAM Journal on Financial Mathematics" {manuscript_id}',
            f'subject:"Financial Mathematics" subject:{manuscript_id}',
            
            # Without manuscript ID to see if domain emails exist
            f'from:sifin.siam.org',
            f'from:@siam.org subject:SIFIN',
            f'subject:"SIAM Journal on Financial Mathematics"',
            f'subject:"Financial Mathematics"',
            
            # Pattern variations
            f'{manuscript_id}',  # Just the manuscript ID
            f'subject:"{manuscript_id}"',  # Quoted manuscript ID
            manuscript_id.replace('M', ''),  # Without M prefix
            f'subject:{manuscript_id.replace("M", "")}',  # Without M prefix in subject
            
            # Different manuscript ID formats that might exist
            f'subject:M{manuscript_id[1:]}',  # Ensure M prefix
            f'subject:#{manuscript_id}',  # With hash prefix
            f'subject:MS{manuscript_id[1:]}',  # MS prefix instead of M
            f'subject:SIFIN{manuscript_id[1:]}',  # SIFIN prefix
            
            # Time-based searches (last 2 years)
            f'after:2023/01/01 {manuscript_id}',
            f'after:2024/01/01 {manuscript_id}',
            f'after:2025/01/01 {manuscript_id}',
        ]
        
        results = {}
        total_found = 0
        
        for i, pattern in enumerate(search_patterns, 1):
            print(f"\n{i:2d}. Testing: {pattern}")
            
            try:
                response = self.service.users().messages().list(
                    userId='me',
                    q=pattern,
                    maxResults=50
                ).execute()
                
                messages = response.get('messages', [])
                count = len(messages)
                total_found += count
                
                print(f"    Result: {count} messages found")
                
                # Store results
                results[pattern] = {
                    'count': count,
                    'messages': messages[:5] if messages else []  # Store first 5 message IDs
                }
                
                # If we found messages, get some details
                if messages:
                    print(f"    First few message IDs: {[msg['id'] for msg in messages[:3]]}")
                    
                    # Get details of first message
                    try:
                        first_msg = self.service.users().messages().get(
                            userId='me',
                            id=messages[0]['id'],
                            format='metadata'
                        ).execute()
                        
                        headers = {h['name']: h['value'] for h in first_msg.get('payload', {}).get('headers', [])}
                        print(f"    First message subject: {headers.get('Subject', 'N/A')}")
                        print(f"    First message from: {headers.get('From', 'N/A')}")
                        print(f"    First message date: {headers.get('Date', 'N/A')}")
                        
                    except Exception as e:
                        print(f"    Error getting message details: {e}")
                
            except Exception as e:
                print(f"    Error: {e}")
                results[pattern] = {'error': str(e)}
        
        # Summary
        print(f"\n{'='*60}")
        print(f"SEARCH SUMMARY FOR {manuscript_id}")
        print(f"{'='*60}")
        print(f"Total messages found across all patterns: {total_found}")
        
        successful_patterns = [p for p, r in results.items() if 'error' not in r and r.get('count', 0) > 0]
        print(f"Successful patterns: {len(successful_patterns)}")
        
        if successful_patterns:
            print(f"\nPatterns that found emails:")
            for pattern in successful_patterns:
                print(f"  - {pattern}: {results[pattern]['count']} messages")
        else:
            print("\n❌ No patterns found any emails")
            
        return {
            'manuscript_id': manuscript_id,
            'total_found': total_found,
            'successful_patterns': len(successful_patterns),
            'results': results,
            'timestamp': datetime.now().isoformat()
        }
    
    def analyze_sifin_domain_emails(self) -> Dict:
        """Analyze what emails exist from SIFIN domains"""
        if not self.service:
            return {"error": "Gmail service not initialized"}
        
        print(f"\n{'='*60}")
        print("ANALYZING SIFIN DOMAIN EMAILS")
        print(f"{'='*60}")
        
        domain_queries = [
            'from:sifin.siam.org',
            'from:@siam.org',
            'subject:SIFIN',
            'subject:"SIAM Journal on Financial Mathematics"',
            'subject:"Financial Mathematics"',
            'from:sifin.siam.org after:2023/01/01',
            'from:sifin.siam.org after:2024/01/01',
            'from:sifin.siam.org after:2025/01/01',
        ]
        
        domain_results = {}
        
        for query in domain_queries:
            print(f"\nTesting domain query: {query}")
            
            try:
                response = self.service.users().messages().list(
                    userId='me',
                    q=query,
                    maxResults=20
                ).execute()
                
                messages = response.get('messages', [])
                count = len(messages)
                
                print(f"  Found {count} messages")
                
                domain_results[query] = {
                    'count': count,
                    'messages': messages
                }
                
                # Get sample subjects
                if messages:
                    sample_subjects = []
                    for msg in messages[:5]:
                        try:
                            msg_data = self.service.users().messages().get(
                                userId='me',
                                id=msg['id'],
                                format='metadata'
                            ).execute()
                            
                            headers = {h['name']: h['value'] for h in msg_data.get('payload', {}).get('headers', [])}
                            subject = headers.get('Subject', 'N/A')
                            sample_subjects.append(subject)
                            
                        except Exception as e:
                            print(f"  Error getting message: {e}")
                    
                    print(f"  Sample subjects:")
                    for subject in sample_subjects:
                        print(f"    - {subject}")
                        
            except Exception as e:
                print(f"  Error: {e}")
                domain_results[query] = {'error': str(e)}
        
        return domain_results
    
    def test_manuscript_id_variations(self, base_id: str) -> Dict:
        """Test different manuscript ID format variations"""
        if not self.service:
            return {"error": "Gmail service not initialized"}
        
        print(f"\n{'='*60}")
        print(f"TESTING MANUSCRIPT ID VARIATIONS FOR: {base_id}")
        print(f"{'='*60}")
        
        # Generate ID variations
        variations = [
            base_id,  # Original
            base_id.replace('M', ''),  # Without M
            f'#{base_id}',  # With hash
            f'MS{base_id[1:]}',  # MS prefix
            f'SIFIN{base_id[1:]}',  # SIFIN prefix
            base_id.replace('M', 'manuscript '),  # Spelled out
            base_id.replace('M', 'Ms '),  # Ms prefix
            base_id.replace('M', 'MS '),  # MS prefix with space
        ]
        
        variation_results = {}
        
        for variation in variations:
            print(f"\nTesting variation: {variation}")
            
            # Test both subject and body searches
            queries = [
                f'subject:{variation}',
                f'body:{variation}',
                f'{variation}',
                f'subject:"{variation}"',
                f'body:"{variation}"',
            ]
            
            for query in queries:
                try:
                    response = self.service.users().messages().list(
                        userId='me',
                        q=query,
                        maxResults=10
                    ).execute()
                    
                    messages = response.get('messages', [])
                    count = len(messages)
                    
                    if count > 0:
                        print(f"  {query}: {count} messages found")
                        variation_results[f"{variation}||{query}"] = {
                            'count': count,
                            'messages': messages
                        }
                    
                except Exception as e:
                    print(f"  Error with {query}: {e}")
        
        return variation_results
    
    def comprehensive_debug(self, manuscript_id: str) -> Dict:
        """Run comprehensive debug for a manuscript"""
        if not self.setup_service():
            return {"error": "Failed to setup Gmail service"}
        
        debug_results = {
            'manuscript_id': manuscript_id,
            'timestamp': datetime.now().isoformat(),
            'gmail_service_status': 'OK'
        }
        
        # Test 1: Basic manuscript search
        print("\n🔍 PHASE 1: Basic Manuscript Search")
        debug_results['manuscript_search'] = self.test_manuscript_search(manuscript_id)
        
        # Test 2: Domain analysis
        print("\n🔍 PHASE 2: Domain Analysis")
        debug_results['domain_analysis'] = self.analyze_sifin_domain_emails()
        
        # Test 3: ID variations
        print("\n🔍 PHASE 3: ID Variations")
        debug_results['id_variations'] = self.test_manuscript_id_variations(manuscript_id)
        
        # Generate comprehensive report
        self._generate_report(debug_results)
        
        return debug_results
    
    def _generate_report(self, debug_results: Dict):
        """Generate a comprehensive debug report"""
        print(f"\n{'='*80}")
        print("COMPREHENSIVE DEBUG REPORT")
        print(f"{'='*80}")
        
        manuscript_id = debug_results['manuscript_id']
        
        # Check if any searches found results
        manuscript_search = debug_results.get('manuscript_search', {})
        domain_analysis = debug_results.get('domain_analysis', {})
        id_variations = debug_results.get('id_variations', {})
        
        total_found = manuscript_search.get('total_found', 0)
        successful_patterns = manuscript_search.get('successful_patterns', 0)
        
        print(f"Manuscript ID: {manuscript_id}")
        print(f"Total emails found: {total_found}")
        print(f"Successful search patterns: {successful_patterns}")
        
        # Domain analysis summary
        domain_totals = sum(r.get('count', 0) for r in domain_analysis.values() if 'error' not in r)
        print(f"Total SIFIN domain emails: {domain_totals}")
        
        # ID variations summary
        variation_totals = sum(r.get('count', 0) for r in id_variations.values() if 'error' not in r)
        print(f"Total variation matches: {variation_totals}")
        
        # Conclusions
        print(f"\n{'='*40}")
        print("CONCLUSIONS & RECOMMENDATIONS")
        print(f"{'='*40}")
        
        if total_found == 0:
            print("❌ PRIMARY ISSUE: No emails found for this manuscript ID")
            
            if domain_totals > 0:
                print("✅ SIFIN domain emails exist in Gmail")
                print("📝 RECOMMENDATION: The manuscript ID format may be incorrect")
                print("   or the manuscript may not have generated any emails yet")
            else:
                print("❌ No SIFIN domain emails found in Gmail")
                print("📝 RECOMMENDATION: Check if:")
                print("   - Gmail API has correct permissions")
                print("   - The correct Gmail account is being searched")
                print("   - SIFIN emails are being received at this address")
        else:
            print("✅ SUCCESS: Found emails for this manuscript")
            print("📝 The search queries are working correctly")
        
        # Save detailed results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"sifin_gmail_debug_{manuscript_id}_{timestamp}.json"
        
        with open(output_file, 'w') as f:
            json.dump(debug_results, f, indent=2)
        
        print(f"\n📄 Detailed results saved to: {output_file}")


def main():
    """Main debug function"""
    print("🔍 SIFIN Gmail Search Debugger")
    print("=" * 50)
    
    # Test with the manuscript ID from the recent extraction
    test_manuscript_id = "M147228"  # From the recent SIFIN extraction
    
    debugger = SIFINGmailDebugger()
    results = debugger.comprehensive_debug(test_manuscript_id)
    
    print("\n✅ Debug complete!")
    return results


if __name__ == "__main__":
    main()