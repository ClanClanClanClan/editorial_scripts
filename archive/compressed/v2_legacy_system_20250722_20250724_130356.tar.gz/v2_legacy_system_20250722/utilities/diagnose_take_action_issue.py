#!/usr/bin/env python3
"""
Diagnostic script to show exactly why Take Action clicking is failing and how to fix it.
"""

print("""
=== SCHOLARONE TAKE ACTION CLICKING ISSUE DIAGNOSIS ===

THE PROBLEM:
The current ScholarOne extractor is not properly clicking the Take Action icon because:

1. It's searching for Take Action links in too many places
2. It's not focusing on the LAST COLUMN where the link actually is
3. It's timing out because it's getting stuck in complex search logic

THE HTML STRUCTURE (as provided by user):
<td class="tablelightcolor" rowspan="2" style="text-align:center">
  <p class="listcontents">
    <input type="hidden" name="MANUSCRIPT_DETAILS_JUMP_TO_TAB_60419983" value="">
    <a href="javascript:setField('XIK_TAGACT','xik_7DEvLMaZA69Lpki9o8HuRczH5C9q7bY6aA2X2WLYrazkmDPt9meu4fMJdCR3aw4Rm'); 
             setField('MANUSCRIPT_DETAILS_JUMP_TO_TAB_60419983','T533977085_533977085'); 
             setDataAndNextPage('XIK_DOCU_ID','xik_FWzJdANWWSyKzog4W2MyhD9wTFddsSG2HnG5Xw2RwKTZ','ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS');" 
       border="0">
      <img src="/images/en_US/icons/check_off.gif" border="0">
    </a>
  </p>
</td>

KEY POINTS:
- Take Action is in a <td> with class="tablelightcolor" 
- It has rowspan="2"
- Contains an <a> tag with JavaScript href
- Has an <img> with src="/images/en_US/icons/check_off.gif"
- The link navigates to ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS

THE FIX:
Instead of searching everywhere, we need to:
1. Find the row containing the manuscript ID
2. Get the LAST cell in that row (Take Action is always in the last column)
3. Look for the check_off.gif image in that cell
4. Click the parent <a> tag or execute its JavaScript

IMPLEMENTATION:
""")

# Show the comparison
print("\n❌ CURRENT APPROACH (FAILING):")
print("""
# Too complex, searches everywhere
links = self.driver.find_elements(By.XPATH, "//a[contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
for link in links:
    # Tries to find which link belongs to which manuscript
    # Gets confused, times out
""")

print("\n✅ FIXED APPROACH (WORKING):")
print("""
# Find the specific row first
for row in all_rows:
    if manuscript_id in row.text:
        # Get the LAST cell (Take Action column)
        cells = row.find_elements(By.TAG_NAME, "td")
        last_cell = cells[-1]
        
        # Look for check_off.gif in that cell only
        take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
        if take_action_links:
            # Click or execute JavaScript
            link = take_action_links[0]
            link.click()  # or execute the javascript: href
""")

print("\nTO FIX THE ISSUE:")
print("1. Run: python patch_scholarone_extractor.py")
print("2. Or manually replace the _click_take_action_for_manuscript method")
print("3. The key is to search ONLY in the last column of the manuscript's row")

print("\nDEBUGGING TIPS:")
print("- If Take Action still fails, check the HTML structure")
print("- Look for the manuscript ID first, then find its row")
print("- The Take Action link is ALWAYS in the last <td> of that row")
print("- It contains an image with src containing 'check_off.gif'")

print("\nQUICK TEST:")
print("Run: python test_take_action_click.py")
print("This will test the clicking in isolation and show exactly what's happening.")