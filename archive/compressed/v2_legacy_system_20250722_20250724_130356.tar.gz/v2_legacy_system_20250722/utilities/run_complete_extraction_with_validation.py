#!/usr/bin/env python3
"""
Run Complete Journal Extraction with Email Timeline Validation

This script runs the complete extraction for all implemented journals,
integrating web data with email timelines and validating for contradictions.
"""

import os
import sys
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

# Import the complete extractors
from editorial_assistant.extractors.sicon_complete import SICONCompleteExtractor
from editorial_assistant.extractors.sifin_complete import SIFINCompleteExtractor
from editorial_assistant.core.data_models import JournalConfig

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('complete_extraction.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class CompleteExtractionRunner:
    """Runs complete extraction with timeline validation for all journals."""
    
    def __init__(self):
        self.results = {}
        self.validation_summary = {}
        
    def run_all_extractions(self, validate_timeline: bool = True) -> Dict[str, Any]:
        """Run extraction for all implemented journals."""
        
        # Define journal configurations
        journals = {
            "SICON": {
                "config": JournalConfig(
                    code="SICON",
                    name="SIAM Journal on Control and Optimization",
                    url="https://sicon.siam.org/cgi-bin/main.plex",
                    platform="siam_orcid",
                    credentials={
                        "username_env": "ORCID_EMAIL",
                        "password_env": "ORCID_PASSWORD"
                    }
                ),
                "extractor_class": SICONCompleteExtractor
            },
            "SIFIN": {
                "config": JournalConfig(
                    code="SIFIN", 
                    name="SIAM Journal on Financial Mathematics",
                    url="https://sifin.siam.org/cgi-bin/main.plex",
                    platform="siam_orcid",
                    credentials={
                        "username_env": "ORCID_EMAIL",
                        "password_env": "ORCID_PASSWORD"
                    }
                ),
                "extractor_class": SIFINCompleteExtractor
            }
        }
        
        # Run extraction for each journal
        for journal_code, journal_info in journals.items():
            logger.info(f"\n{'='*60}")
            logger.info(f"Starting extraction for {journal_code}")
            logger.info(f"{'='*60}")
            
            try:
                # Create extractor instance
                extractor = journal_info["extractor_class"](
                    journal_info["config"],
                    validate_timeline=validate_timeline
                )
                
                # Run extraction
                manuscripts = extractor.extract_data()
                
                # Store results
                self.results[journal_code] = {
                    "success": True,
                    "manuscripts": manuscripts,
                    "count": len(manuscripts),
                    "extraction_time": datetime.now().isoformat()
                }
                
                # Analyze validation results
                self._analyze_validation_results(journal_code, manuscripts)
                
                logger.info(f"✅ {journal_code} extraction complete: {len(manuscripts)} manuscripts")
                
            except Exception as e:
                logger.error(f"❌ {journal_code} extraction failed: {e}")
                self.results[journal_code] = {
                    "success": False,
                    "error": str(e),
                    "extraction_time": datetime.now().isoformat()
                }
        
        # Generate summary report
        return self._generate_summary_report()
    
    def _analyze_validation_results(self, journal_code: str, manuscripts: List[Dict]) -> None:
        """Analyze validation results for a journal."""
        
        total_manuscripts = len(manuscripts)
        total_issues = 0
        critical_issues = 0
        manuscripts_with_issues = 0
        
        issue_types = {}
        
        for ms in manuscripts:
            issues = ms.get('validation_issues', [])
            if issues:
                manuscripts_with_issues += 1
                
            for issue in issues:
                total_issues += 1
                if issue['severity'] == 'critical':
                    critical_issues += 1
                
                # Count by issue type
                issue_type = issue.get('issue_type', 'unknown')
                issue_types[issue_type] = issue_types.get(issue_type, 0) + 1
        
        self.validation_summary[journal_code] = {
            'total_manuscripts': total_manuscripts,
            'manuscripts_with_issues': manuscripts_with_issues,
            'total_issues': total_issues,
            'critical_issues': critical_issues,
            'issue_types': issue_types,
            'validation_rate': (total_manuscripts - manuscripts_with_issues) / total_manuscripts if total_manuscripts > 0 else 0
        }
    
    def _generate_summary_report(self) -> Dict[str, Any]:
        """Generate a comprehensive summary report."""
        
        report = {
            'extraction_timestamp': datetime.now().isoformat(),
            'journals_processed': len(self.results),
            'successful_extractions': sum(1 for r in self.results.values() if r['success']),
            'failed_extractions': sum(1 for r in self.results.values() if not r['success']),
            'total_manuscripts': sum(r.get('count', 0) for r in self.results.values() if r['success']),
            'validation_summary': self.validation_summary,
            'journal_results': self.results
        }
        
        # Calculate overall validation statistics
        total_critical_issues = sum(v['critical_issues'] for v in self.validation_summary.values())
        total_all_issues = sum(v['total_issues'] for v in self.validation_summary.values())
        
        report['overall_validation'] = {
            'total_issues': total_all_issues,
            'critical_issues': total_critical_issues,
            'has_critical_issues': total_critical_issues > 0
        }
        
        return report
    
    def print_summary(self, report: Dict[str, Any]) -> None:
        """Print a formatted summary of the extraction results."""
        
        print("\n" + "="*80)
        print("COMPLETE EXTRACTION SUMMARY WITH TIMELINE VALIDATION")
        print("="*80)
        print(f"Timestamp: {report['extraction_timestamp']}")
        print(f"\nJournals Processed: {report['journals_processed']}")
        print(f"  ✅ Successful: {report['successful_extractions']}")
        print(f"  ❌ Failed: {report['failed_extractions']}")
        print(f"\nTotal Manuscripts Extracted: {report['total_manuscripts']}")
        
        # Validation summary
        print("\n" + "-"*80)
        print("TIMELINE VALIDATION SUMMARY")
        print("-"*80)
        
        if report['overall_validation']['has_critical_issues']:
            print(f"\n⚠️  CRITICAL ISSUES FOUND!")
            print(f"   Total critical issues: {report['overall_validation']['critical_issues']}")
            print(f"   Total all issues: {report['overall_validation']['total_issues']}")
        else:
            print("\n✅ NO CRITICAL TIMELINE ISSUES FOUND")
            print(f"   Total minor issues: {report['overall_validation']['total_issues']}")
        
        # Per-journal validation details
        print("\nPer-Journal Validation Results:")
        for journal, validation in report['validation_summary'].items():
            print(f"\n{journal}:")
            print(f"  Manuscripts: {validation['total_manuscripts']}")
            print(f"  Clean manuscripts: {validation['total_manuscripts'] - validation['manuscripts_with_issues']}")
            print(f"  Validation rate: {validation['validation_rate']:.1%}")
            
            if validation['critical_issues'] > 0:
                print(f"  ⚠️  Critical issues: {validation['critical_issues']}")
            
            if validation['issue_types']:
                print("  Issue breakdown:")
                for issue_type, count in validation['issue_types'].items():
                    print(f"    - {issue_type}: {count}")
        
        # Failed extractions
        if report['failed_extractions'] > 0:
            print("\n" + "-"*80)
            print("FAILED EXTRACTIONS")
            print("-"*80)
            for journal, result in report['journal_results'].items():
                if not result['success']:
                    print(f"\n{journal}: {result['error']}")
    
    def save_results(self, report: Dict[str, Any]) -> str:
        """Save extraction results to files."""
        
        # Create output directory
        output_dir = Path(f"extraction_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        output_dir.mkdir(exist_ok=True)
        
        # Save summary report
        summary_file = output_dir / "extraction_summary.json"
        with open(summary_file, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        # Save individual journal results
        for journal, result in report['journal_results'].items():
            if result['success']:
                journal_file = output_dir / f"{journal}_manuscripts.json"
                with open(journal_file, 'w') as f:
                    json.dump(result['manuscripts'], f, indent=2, default=str)
                
                # Save validation issues separately
                issues_file = output_dir / f"{journal}_validation_issues.json"
                issues = []
                for ms in result['manuscripts']:
                    if ms.get('validation_issues'):
                        issues.append({
                            'manuscript_id': ms.get('id'),
                            'issues': ms['validation_issues']
                        })
                
                if issues:
                    with open(issues_file, 'w') as f:
                        json.dump(issues, f, indent=2)
        
        print(f"\n📁 Results saved to: {output_dir}")
        return str(output_dir)


def main():
    """Run complete extraction with validation."""
    
    # Check for required environment variables
    required_env = ['ORCID_EMAIL', 'ORCID_PASSWORD']
    missing_env = [var for var in required_env if not os.getenv(var)]
    
    if missing_env:
        print(f"❌ Missing required environment variables: {', '.join(missing_env)}")
        print("\nPlease set:")
        for var in missing_env:
            print(f"  export {var}='your_value'")
        return
    
    # Run extraction
    runner = CompleteExtractionRunner()
    report = runner.run_all_extractions(validate_timeline=True)
    
    # Print summary
    runner.print_summary(report)
    
    # Save results
    output_dir = runner.save_results(report)
    
    # Return success/failure based on critical issues
    if report['overall_validation']['has_critical_issues']:
        print("\n❌ EXTRACTION COMPLETED WITH CRITICAL TIMELINE ISSUES")
        print("   These must be resolved to ensure data integrity!")
        return False
    else:
        print("\n✅ EXTRACTION COMPLETED SUCCESSFULLY")
        return True


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)