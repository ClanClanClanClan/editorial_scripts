#!/usr/bin/env python3
"""
SIFIN Firefox Extractor - July 16, 2025
ULTRATHINK APPROACH 3: Use Firefox instead of Chrome to bypass Cloudflare
"""

import os
import sys
import time
import logging
import json
import re
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from bs4 import BeautifulSoup

# Gmail API imports
try:
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
    GMAIL_AVAILABLE = True
except ImportError:
    GMAIL_AVAILABLE = False

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SIFINFirefoxExtractor:
    """SIFIN extractor using Firefox to bypass Chrome-specific Cloudflare blocking"""
    
    def __init__(self):
        self.driver = None
        self.manuscripts = []
        self.gmail_service = None
        self.manuscript_patterns = {
            'sifin_subject': r'SIFIN.*[Mm]anuscript\s+(M\d+)',
            'siam_subject': r'SIAM.*[Ff]inancial.*[Mm]anuscript\s+(M\d+)',
            'manuscript_id': r'M\d+',
            'referee_invitation': r'(?:referee|reviewer)\s+invitation',
            'referee_response': r'(?:accepted|declined|agreed|unable).*(?:review|referee)',
            'reminder': r'reminder.*(?:review|referee)',
            'overdue': r'overdue.*(?:review|referee)',
        }
        
    def setup_gmail_service(self) -> bool:
        """Setup Gmail API service for email crosschecking"""
        if not GMAIL_AVAILABLE:
            logger.warning("Gmail API not available - skipping email crosscheck")
            return False
            
        try:
            # Look for token file
            token_paths = [
                "/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/config/token.json",
                "config/token.json",
                "/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/config/gmail_token.json",
                "config/gmail_token.json",
                "scripts/setup/token.json",
                "token.json",
                os.path.expanduser("~/.config/editorial_scripts/gmail_token.json")
            ]
            
            token_path = None
            for path in token_paths:
                if os.path.exists(path):
                    token_path = path
                    break
                    
            if not token_path:
                logger.warning("Gmail token not found. Skipping email crosscheck.")
                return False
                
            # Load credentials
            creds = Credentials.from_authorized_user_file(token_path)
            self.gmail_service = build('gmail', 'v1', credentials=creds)
            
            logger.info("✅ Gmail service initialized for email crosscheck")
            return True
            
        except Exception as e:
            logger.warning(f"Failed to setup Gmail service: {e}")
            return False
        
    def setup_firefox_driver(self, headless=True):
        """Setup Firefox driver"""
        options = FirefoxOptions()
        if headless:
            options.add_argument('--headless')
        options.add_argument('--width=1920')
        options.add_argument('--height=1080')
        
        # Set user agent to look like regular Firefox
        options.set_preference("general.useragent.override", 
                              "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:120.0) Gecko/20100101 Firefox/120.0")
        
        try:
            self.driver = webdriver.Firefox(options=options)
            self.driver.set_window_size(1920, 1080)
            logger.info(f"✅ Firefox driver setup complete (headless={headless})")
            return True
        except Exception as e:
            logger.error(f"❌ Firefox setup failed: {e}")
            logger.info("Trying with system Firefox...")
            
            # Try with explicit service
            try:
                service = FirefoxService()
                self.driver = webdriver.Firefox(service=service, options=options)
                logger.info("✅ Firefox driver setup complete (with service)")
                return True
            except Exception as e2:
                logger.error(f"❌ Firefox setup failed again: {e2}")
                return False
        
    def navigate_to_sifin(self):
        """Navigate to SIFIN using Firefox"""
        logger.info("📍 Step 1: Navigating to SIFIN with Firefox...")
        
        self.driver.get("https://sifin.siam.org/cgi-bin/main.plex")
        time.sleep(5)
        
        title = self.driver.title
        logger.info(f"Firefox loaded page: {title}")
        
        # Check if Cloudflare is bypassed
        if "Just a moment" in title:
            logger.warning("⚠️ Cloudflare still detected with Firefox, waiting...")
            time.sleep(15)
            title = self.driver.title
            logger.info(f"After wait: {title}")
        else:
            logger.info("✅ Firefox bypassed Cloudflare!")
        
        # Handle privacy modal immediately after page load
        try:
            # Wait a bit for the modal to appear
            time.sleep(2)
            continue_button = self.driver.find_element(By.ID, "continue-btn")
            if continue_button and continue_button.is_displayed():
                logger.info("🍪 Found privacy notification modal on page load, clicking Continue...")
                continue_button.click()
                time.sleep(2)
                logger.info("✅ Privacy modal dismissed on page load")
        except Exception as e:
            logger.debug(f"No privacy modal on initial load: {e}")
        
        return "SIAM Journal on Financial Mathematics" in title or "sifin" in title.lower()
        
    def remove_cookie_banners(self):
        """Remove cookie banners with JavaScript - same as SICON"""
        try:
            js_remove_banners = """
            const selectors = [
                '#cookie-policy-layer-bg',
                '#cookie-policy-layer', 
                '.cc_banner-wrapper',
                '#onetrust-banner-sdk',
                '.onetrust-pc-dark-filter',
                '[id*="cookie"]',
                '[class*="cookie"]',
                '[id*="banner"]',
                '[class*="banner"]'
            ];
            
            selectors.forEach(sel => {
                document.querySelectorAll(sel).forEach(el => {
                    el.style.display = 'none';
                    el.remove();
                });
            });
            
            // Also try to find and click accept buttons
            const buttonTexts = ['Accept', 'Accept All', 'Accept Cookies', 'Got it', 'OK', 'Continue'];
            buttonTexts.forEach(text => {
                document.querySelectorAll('button, input[type="button"]').forEach(btn => {
                    if (btn.innerText && btn.innerText.toLowerCase().includes(text.toLowerCase())) {
                        btn.click();
                    }
                });
            });
            """
            
            self.driver.execute_script(js_remove_banners)
            time.sleep(1)
            logger.info("✅ Firefox removed cookie banners")
            
        except Exception as e:
            logger.debug(f"Firefox cookie removal failed: {e}")

    def find_orcid_button_firefox(self):
        """Find ORCID button using Firefox"""
        logger.info("📍 Step 2: Finding ORCID button with Firefox...")
        
        # First, handle the privacy notification modal
        try:
            # Look for the Continue button in the privacy modal
            continue_button = self.driver.find_element(By.ID, "continue-btn")
            if continue_button and continue_button.is_displayed():
                logger.info("🍪 Found privacy notification modal, clicking Continue...")
                continue_button.click()
                time.sleep(2)
                logger.info("✅ Privacy modal dismissed")
        except Exception as e:
            logger.debug(f"No privacy modal found or already dismissed: {e}")
        
        # Remove cookie banners
        self.remove_cookie_banners()
        time.sleep(3)
        
        # Try different selectors
        selectors = [
            "a[href*='orcid']",
            "a[href*='sso_site_redirect']",
            "img[src*='orcid']",
            "a[title*='ORCID']"
        ]
        
        for i, selector in enumerate(selectors, 1):
            try:
                logger.info(f"  Trying Firefox selector {i}: {selector}")
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                
                for element in elements:
                    if element.is_displayed():
                        logger.info(f"✅ Firefox found ORCID element with selector {i}")
                        
                        # If it's an image, get parent
                        if element.tag_name == 'img':
                            element = element.find_element(By.XPATH, "..")
                        
                        href = element.get_attribute("href")
                        logger.info(f"   ORCID link: {href}")
                        
                        return element
                        
            except Exception as e:
                logger.debug(f"  Firefox selector {i} failed: {e}")
                
        return None
        
    def authenticate_orcid_firefox(self):
        """Perform ORCID authentication with Firefox"""
        logger.info("📍 Step 3: ORCID authentication with Firefox...")
        
        # Get credentials
        orcid_user = os.environ.get('ORCID_EMAIL')
        orcid_pass = os.environ.get('ORCID_PASSWORD')
        
        if not orcid_user or not orcid_pass:
            raise Exception("ORCID credentials not found")
        
        # Wait for ORCID page
        try:
            WebDriverWait(self.driver, 15).until(
                lambda driver: "orcid.org" in driver.current_url
            )
            logger.info("✅ Firefox reached ORCID login page")
        except TimeoutException:
            logger.warning("⚠️ Firefox not on ORCID page, current URL: {self.driver.current_url}")
        
        # Handle ORCID cookie/privacy modal FIRST, before trying to find form fields
        time.sleep(3)  # Give time for modal to appear
        
        # Check and log what buttons are present on the page
        logger.info("📄 Page elements check:")
        try:
            all_buttons = self.driver.find_elements(By.TAG_NAME, "button")
            logger.info(f"   Found {len(all_buttons)} buttons")
            for i, btn in enumerate(all_buttons[:5]):  # Log first 5 buttons
                btn_text = btn.text.strip()
                btn_visible = btn.is_displayed()
                if btn_text:
                    logger.info(f"   Button {i+1}: '{btn_text}' (displayed: {btn_visible})")
        except:
            pass
        
        # Look for and handle cookie consent - SAME AS SICON
        try:
            # First, try the JavaScript approach like SICON
            js_accept_cookies = """
            const buttonTexts = ['Accept All Cookies', 'Accept all cookies', 'Accept', 'Accept Cookies', 'Got it', 'OK', 'Continue'];
            let found = false;
            buttonTexts.forEach(text => {
                document.querySelectorAll('button').forEach(btn => {
                    if (btn.innerText && btn.innerText.toLowerCase().includes(text.toLowerCase())) {
                        btn.click();
                        found = true;
                    }
                });
            });
            return found;
            """
            
            cookie_found = self.driver.execute_script(js_accept_cookies)
            if cookie_found:
                logger.info("✅ ORCID cookie modal dismissed via JavaScript")
                time.sleep(2)
            else:
                # Try XPath selectors as backup
                cookie_buttons = [
                    "//button[contains(text(), 'Accept All Cookies')]",
                    "//button[contains(text(), 'Accept all cookies')]",
                    "//button[contains(text(), 'Accept')]",
                    "//button[@class='btn btn-primary']",
                    "//button[contains(@class, 'accept')]"
                ]
                
                for selector in cookie_buttons:
                    try:
                        accept_button = self.driver.find_element(By.XPATH, selector)
                        if accept_button and accept_button.is_displayed():
                            logger.info(f"🍪 Found ORCID cookie button: {selector}, clicking...")
                            self.driver.execute_script("arguments[0].click();", accept_button)
                            time.sleep(2)
                            logger.info("✅ ORCID cookie modal dismissed")
                            break
                    except:
                        continue
                        
        except Exception as e:
            logger.info(f"Cookie handling check complete: {e}")
        
        # NOW try to fill username - wait for it to be visible
        try:
            username_field = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "username-input"))
            )
            username_field.clear()
            username_field.send_keys(orcid_user)
            logger.info("✅ Firefox entered username")
        except TimeoutException:
            try:
                username_field = self.driver.find_element(By.ID, "userId")
                username_field.clear()
                username_field.send_keys(orcid_user)
                logger.info("✅ Firefox entered username (alternative)")
            except NoSuchElementException:
                logger.error("❌ Firefox could not find username field")
                return False
        
        # Fill password
        try:
            password_field = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "password"))
            )
            password_field.clear()
            password_field.send_keys(orcid_pass)
            logger.info("✅ Firefox entered password")
        except TimeoutException:
            logger.error("❌ Firefox could not find password field")
            return False
        
        # Submit
        try:
            sign_in_button = self.driver.find_element(By.ID, "signin-button")
            sign_in_button.click()
            logger.info("✅ Firefox submitted login")
        except NoSuchElementException:
            try:
                sign_in_button = self.driver.find_element(By.XPATH, "//button[contains(text(), 'Sign in')]")
                sign_in_button.click()
                logger.info("✅ Firefox submitted login (alternative)")
            except NoSuchElementException:
                logger.error("❌ Firefox could not find sign in button")
                return False
        
        # Wait for redirect and log what we see
        logger.info("⏳ Waiting after login submission...")
        time.sleep(5)
        
        current_url = self.driver.current_url
        page_title = self.driver.title
        logger.info(f"Firefox after login URL: {current_url}")
        logger.info(f"Firefox after login title: {page_title}")
        
        # Check page source for authorization elements
        page_source = self.driver.page_source
        if "authorize" in page_source.lower():
            logger.info("🔐 Found 'authorize' in page source - authorization required")
        if "already authorized" in page_source.lower():
            logger.info("✅ Found 'already authorized' in page source")
        
        # Check if we need to complete the redirect manually
        if "orcid.org" in current_url:
            logger.info("⚠️ Still on ORCID page, checking for authorization elements...")
            
            # Let's see what's on the page
            logger.info("📄 Page elements check:")
            buttons = self.driver.find_elements(By.TAG_NAME, "button")
            logger.info(f"   Found {len(buttons)} buttons")
            for i, btn in enumerate(buttons[:5]):  # Show first 5 buttons
                logger.info(f"   Button {i+1}: '{btn.text}' (displayed: {btn.is_displayed()})")
            
            links = self.driver.find_elements(By.TAG_NAME, "a")
            auth_links = [link for link in links if "auth" in link.text.lower()]
            logger.info(f"   Found {len(auth_links)} authorization-related links")
            for link in auth_links[:3]:
                logger.info(f"   Auth link: '{link.text}'")
            
            time.sleep(5)
            current_url = self.driver.current_url
            logger.info(f"After additional wait: {current_url}")
            
            # If still on ORCID, try to find and click continue/authorize button
            if "orcid.org" in current_url:
                try:
                    # Check if we're on the authorization page specifically
                    if "oauth/authorize" in current_url or "Oauth" in self.driver.title:
                        logger.info("🔐 On ORCID OAuth authorization page")
                        
                        # Look for the authorization form - this is the most reliable method
                        try:
                            # Try to find the authorization form by its action
                            forms = self.driver.find_elements(By.TAG_NAME, "form")
                            for form in forms:
                                action = form.get_attribute("action")
                                if action and ("oauth" in action or "authorize" in action or "token" in action):
                                    logger.info(f"🔐 Found OAuth form with action: {action}")
                                    
                                    # Look for submit button in this form
                                    submit_inputs = form.find_elements(By.XPATH, ".//input[@type='submit']")
                                    submit_buttons = form.find_elements(By.XPATH, ".//button[@type='submit']")
                                    
                                    if submit_inputs:
                                        logger.info("🔐 Found submit input in OAuth form")
                                        self.driver.execute_script("arguments[0].click();", submit_inputs[0])
                                        time.sleep(5)
                                        break
                                    elif submit_buttons:
                                        logger.info("🔐 Found submit button in OAuth form")
                                        self.driver.execute_script("arguments[0].click();", submit_buttons[0])
                                        time.sleep(5)
                                        break
                                    else:
                                        # If no submit button, try to submit the form directly
                                        logger.info("🔐 No submit button found, submitting form directly")
                                        self.driver.execute_script("arguments[0].submit();", form)
                                        time.sleep(5)
                                        break
                        except Exception as e:
                            logger.debug(f"Form submission failed: {e}")
                    
                    # Fallback: Look for various authorization button types
                    button_selectors = [
                        "//button[contains(text(), 'Authorize')]",
                        "//button[contains(text(), 'Continue')]", 
                        "//button[contains(text(), 'Allow')]",
                        "//input[@type='submit'][contains(@value, 'Authorize')]",
                        "//input[@type='submit'][contains(@value, 'Continue')]",
                        "//input[@type='submit']",  # Any submit button
                        "//button[@type='submit']",  # Any submit button
                        "//a[contains(text(), 'Authorize')]",
                        "//a[contains(text(), 'Continue')]",
                        "#authorize",
                        "#continue-button",
                        ".btn-primary"
                    ]
                    
                    for selector in button_selectors:
                        try:
                            if selector.startswith("//"):
                                buttons = self.driver.find_elements(By.XPATH, selector)
                            else:
                                buttons = self.driver.find_elements(By.CSS_SELECTOR, selector)
                                
                            if buttons:
                                for button in buttons:
                                    if button.is_displayed():
                                        logger.info(f"🔘 Found authorization button with selector: {selector}")
                                        self.driver.execute_script("arguments[0].click();", button)
                                        time.sleep(5)
                                        current_url = self.driver.current_url
                                        logger.info(f"After authorization click: {current_url}")
                                        break
                                break
                        except Exception as e:
                            logger.debug(f"Button selector {selector} failed: {e}")
                    
                    # Check if we're now redirected
                    time.sleep(3)
                    current_url = self.driver.current_url
                    logger.info(f"Final URL after authorization attempts: {current_url}")
                    
                    # If still on ORCID after trying buttons, try manual redirect
                    if "orcid.org" in current_url:
                        logger.info("🔄 Still on ORCID after authorization attempts, trying to navigate directly to SIFIN...")
                        self.driver.get("https://sifin.siam.org/cgi-bin/main.plex")
                        time.sleep(3)
                        current_url = self.driver.current_url
                        logger.info(f"After direct navigation: {current_url}")
                        
                except Exception as e:
                    logger.debug(f"Authorization attempt failed: {e}")
        
        if "sifin.siam.org" in current_url:
            logger.info("✅ Firefox successfully returned to SIFIN")
            return True
        else:
            logger.warning(f"⚠️ Firefox unexpected URL after login: {current_url}")
            return True  # Proceed anyway
        
    def extract_manuscripts_firefox(self):
        """Extract SIFIN manuscripts using Firefox"""
        logger.info("📍 Step 4: Extracting manuscripts with Firefox...")
        
        manuscripts = []
        
        try:
            # Wait for page to load
            time.sleep(3)
            
            # Debug: Check current page content
            logger.info(f"🔍 Current URL: {self.driver.current_url}")
            logger.info(f"🔍 Page title: {self.driver.title}")
            
            # Check if we're logged in by looking for manuscript links or dashboard elements
            page_source = self.driver.page_source
            if "login" in page_source.lower() or "sign in" in page_source.lower():
                logger.warning("⚠️ Appears we're not fully logged in")
            
            # Look for editorial roles or dashboard indicators
            if "associate editor" in page_source.lower() or "editorial" in page_source.lower():
                logger.info("✅ Found editorial role indicators")
            else:
                logger.warning("⚠️ No editorial role indicators found")
                
            # Save page source for debugging
            with open("sifin_debug_page.html", "w") as f:
                f.write(page_source)
            logger.info("💾 Saved page source to sifin_debug_page.html")
            
            # Check for SIAM editorial interface elements
            if 'role="assoc_ed"' in page_source:
                logger.info("✅ Found Associate Editor role section")
            else:
                logger.warning("⚠️ No Associate Editor role section found")
                
            if "Associate Editor Tasks" in page_source:
                logger.info("✅ Found Associate Editor Tasks section")
            else:
                logger.warning("⚠️ No Associate Editor Tasks section found")
                
            # Look for the specific editorial table structure
            editorial_table_found = False
            if 'tbody class="desktop-section" role="assoc_ed"' in page_source:
                editorial_table_found = True
                logger.info("✅ Found editorial table with role='assoc_ed'")
            elif 'tbody role="assoc_ed"' in page_source:
                editorial_table_found = True
                logger.info("✅ Found editorial table with role='assoc_ed' (alternative)")
            else:
                logger.warning("⚠️ No editorial table found with role='assoc_ed'")
            
            # Look for task links specifically in the Associate Editor section
            task_links = []
            
            # First try to find the editorial table
            try:
                editorial_sections = self.driver.find_elements(By.CSS_SELECTOR, 'tbody[role="assoc_ed"]')
                logger.info(f"🔍 Found {len(editorial_sections)} editorial sections")
                
                for section in editorial_sections:
                    section_task_links = section.find_elements(By.CSS_SELECTOR, "a.ndt_task_link")
                    logger.info(f"🔍 Found {len(section_task_links)} task links in editorial section")
                    task_links.extend(section_task_links)
                    
            except Exception as e:
                logger.debug(f"Editorial section search failed: {e}")
            
            # If no task links found in editorial sections, try global search
            if len(task_links) == 0:
                logger.info("🔍 No task links in editorial sections, trying global search...")
                task_links = self.driver.find_elements(By.CSS_SELECTOR, "a.ndt_task_link")
                logger.info(f"🔍 Global search found {len(task_links)} task links")
            
            # If still no task links, try alternative selectors
            if len(task_links) == 0:
                logger.info("🔍 No ndt_task_link found, trying alternative selectors...")
                
                # Try other common manuscript link patterns
                alternative_selectors = [
                    "a[href*='view_ms']",
                    "a[href*='manuscript']", 
                    "a[href*='M1']",
                    "a[contains(text(), '#')]",
                    ".manuscript-link",
                    "td a"
                ]
                
                for selector in alternative_selectors:
                    try:
                        alt_links = self.driver.find_elements(By.CSS_SELECTOR, selector)
                        logger.info(f"   Selector '{selector}': {len(alt_links)} links")
                        if len(alt_links) > 0:
                            # Show sample links
                            for i, link in enumerate(alt_links[:3]):
                                text = link.text.strip()
                                href = link.get_attribute("href")
                                logger.info(f"     Sample {i+1}: '{text}' -> {href}")
                    except Exception as e:
                        logger.debug(f"   Selector '{selector}' failed: {e}")
                
                # Try to find any links that look like manuscripts
                all_links = self.driver.find_elements(By.TAG_NAME, "a")
                logger.info(f"🔍 Total links on page: {len(all_links)}")
                
                potential_manuscript_links = []
                for link in all_links:
                    text = link.text.strip()
                    href = link.get_attribute("href") or ""
                    if any(pattern in text for pattern in ["M1", "#", "manuscript"]) or "view_ms" in href:
                        potential_manuscript_links.append(link)
                        
                logger.info(f"🔍 Potential manuscript links found: {len(potential_manuscript_links)}")
                
                # Use potential links as task_links if found
                if len(potential_manuscript_links) > 0:
                    task_links = potential_manuscript_links
            
            manuscript_links = []
            for link in task_links:
                text = link.text.strip()
                if text.startswith("#") and " - " in text:
                    href = link.get_attribute("href")
                    if href:
                        manuscript_id = text.split()[0].replace('#', '')
                        manuscript_links.append({
                            'url': href,
                            'text': text,
                            'id': manuscript_id
                        })
                        logger.info(f"📄 Firefox found manuscript: {text}")
            
            logger.info(f"✅ Firefox found {len(manuscript_links)} manuscripts")
            
            # Extract details for each manuscript
            for i, manuscript in enumerate(manuscript_links, 1):
                try:
                    logger.info(f"📄 Firefox processing {manuscript['id']} ({i}/{len(manuscript_links)})...")
                    
                    # Navigate to manuscript
                    self.driver.get(manuscript['url'])
                    time.sleep(3)
                    
                    # Extract data
                    manuscript_data = self.extract_manuscript_data_firefox(manuscript['id'])
                    
                    if manuscript_data:
                        # Look up missing affiliations
                        logger.info(f"🔍 Looking up missing affiliations for {manuscript['id']}...")
                        manuscript_data['Referees'] = self.lookup_missing_affiliations(manuscript_data.get('Referees', []))
                        
                        # Crosscheck with emails if Gmail service is available
                        if self.gmail_service:
                            logger.info(f"📧 Crosschecking {manuscript['id']} with emails...")
                            manuscript_data = self.crosscheck_manuscript_with_emails(manuscript_data, manuscript['id'])
                        
                        manuscripts.append(manuscript_data)
                        logger.info(f"✅ Firefox extracted data for {manuscript['id']}")
                        
                        # Log details
                        logger.info(f"   Title: {manuscript_data.get('Title', 'N/A')[:50]}...")
                        logger.info(f"   Stage: {manuscript_data.get('Current Stage', 'N/A')}")
                        logger.info(f"   Referees: {len(manuscript_data.get('Referees', []))}")
                        logger.info(f"   PDFs: {len(manuscript_data.get('PDFs', []))}")
                        
                        # Log email crosscheck results if available
                        if 'email_crosscheck' in manuscript_data:
                            emails_found = manuscript_data['email_crosscheck']['total_emails_found']
                            logger.info(f"   📧 Email crosscheck: {emails_found} emails found")
                    
                except Exception as e:
                    logger.error(f"❌ Firefox error processing {manuscript['id']}: {e}")
                    continue
                    
        except Exception as e:
            logger.error(f"❌ Firefox error extracting manuscripts: {e}")
            
        return manuscripts
        
    def extract_manuscript_data_firefox(self, manuscript_id):
        """Extract manuscript data with Firefox"""
        try:
            soup = BeautifulSoup(self.driver.page_source, "html.parser")
            
            manuscript_data = {
                "Manuscript #": manuscript_id,
                "Title": "",
                "Submitted": "",
                "Current Stage": "",
                "Corresponding Author": "",
                "Abstract": "",
                "Keywords": "",
                "Referees": [],
                "PDFs": [],
                "Comments": []
            }
            
            # Use the manuscript ID passed in from the link text
            # Don't override with URL parameters as they contain different internal IDs
            
            # Look for manuscript details table
            table = soup.find("table", id="ms_details_expanded")
            if table:
                logger.info(f"✅ Firefox found manuscript details table")
                
                for row in table.find_all("tr"):
                    th = row.find("th")
                    td = row.find("td")
                    
                    if th and td:
                        label = th.get_text(strip=True)
                        value = td.get_text(strip=True)
                        
                        if label == "Title":
                            manuscript_data["Title"] = value
                        elif label == "Submission Date":
                            manuscript_data["Submitted"] = value
                        elif label == "Current Stage":
                            manuscript_data["Current Stage"] = value
                        elif label == "Corresponding Author":
                            manuscript_data["Corresponding Author"] = value
                        elif label == "Abstract":
                            manuscript_data["Abstract"] = value
                        elif label == "Keywords":
                            manuscript_data["Keywords"] = value
                        elif label == "Referees":
                            # Extract accepted referees with full profile data
                            referees = self.extract_referees_with_profiles(td, "Accepted")
                            manuscript_data["Referees"].extend(referees)
                        elif "Potential Referees" in label:
                            # Extract potential referees with full profile data
                            referees = self.extract_referees_with_profiles(td, "Potential")
                            manuscript_data["Referees"].extend(referees)
            
            # Extract PDFs with detailed classification
            manuscript_data["PDFs"] = self.extract_pdf_links_detailed(soup)
            if manuscript_data["PDFs"]:
                logger.info(f"   PDFs: {len(manuscript_data['PDFs'])} files")
                for pdf in manuscript_data["PDFs"]:
                    logger.info(f"     - {pdf['type']}: {pdf['url']}")
            
            # Extract referee comments by navigating to review page
            manuscript_data["referee_comments"] = self.extract_referee_comments_detailed(soup)
            if manuscript_data["referee_comments"]:
                logger.info(f"   Referee Comments: {len(manuscript_data['referee_comments'])} comments found")
            
            return manuscript_data
            
        except Exception as e:
            logger.error(f"❌ Firefox error extracting manuscript data: {e}")
            return None
    
    def extract_referees_with_profiles(self, td_element, referee_type):
        """Extract referee information and navigate to profiles for emails/affiliations"""
        referees = []
        
        try:
            for ref_link in td_element.find_all("a"):
                ref_name = ref_link.get_text(strip=True)
                ref_url = ref_link.get("href", "")
                
                if ref_name and ref_url:
                    # Construct full URL
                    if not ref_url.startswith("http"):
                        if ref_url.startswith("cgi-bin/"):
                            ref_url = f"https://sifin.siam.org/{ref_url}"
                        else:
                            ref_url = f"https://sifin.siam.org/cgi-bin/{ref_url.lstrip('/')}"
                    
                    # Get profile details (email, affiliation)
                    profile_details = self.get_referee_profile_details(ref_url)
                    
                    referee_data = {
                        "Referee Name": ref_name,
                        "Referee URL": ref_url,
                        "Status": referee_type,
                        "Referee Email": profile_details.get("email", ""),
                        "Affiliation": profile_details.get("affiliation", "")
                    }
                    
                    referees.append(referee_data)
                    logger.info(f"   ✅ Extracted referee: {ref_name} ({profile_details.get('email', 'no email')})")
                    
        except Exception as e:
            logger.error(f"❌ Error extracting referees: {e}")
            
        return referees
    
    def get_referee_profile_details(self, profile_url):
        """Navigate to referee profile page to extract email and affiliation"""
        try:
            logger.info(f"🔍 Navigating to referee profile: {profile_url}")
            
            # Navigate to profile page
            self.driver.get(profile_url)
            time.sleep(2)
            
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            details = {}
            
            # Look for email addresses (mailto links)
            email_links = soup.find_all('a', href=lambda x: x and 'mailto:' in x)
            if email_links:
                details['email'] = email_links[0].get('href').replace('mailto:', '')
                logger.info(f"   📧 Found email: {details['email']}")
            
            # Look for affiliation and email in table cells
            for td in soup.find_all('td'):
                text = td.get_text(strip=True)
                if '@' in text and '.' in text and 'email' not in details:
                    # Found email in text
                    email_match = re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text)
                    if email_match:
                        details['email'] = email_match.group()
                        logger.info(f"   📧 Found email in text: {details['email']}")
                elif any(keyword in text for keyword in ['University', 'Institute', 'College', 'School', 'Department']):
                    if 'affiliation' not in details or len(text) > len(details.get('affiliation', '')):
                        # Clean the affiliation text
                        cleaned_affiliation = self.clean_affiliation_text(text)
                        details['affiliation'] = cleaned_affiliation
                        logger.info(f"   🏛️ Found affiliation: {cleaned_affiliation[:50]}...")
            
            # Look for full name in headers
            for tag in soup.find_all(['h1', 'h2', 'h3', 'title']):
                text = tag.get_text(strip=True)
                if text and len(text.split()) >= 2 and not text.startswith('SIAM'):
                    details['full_name'] = text
                    break
            
            return details
            
        except Exception as e:
            logger.warning(f"Could not get profile details from {profile_url}: {e}")
            return {}
    
    def extract_pdf_links_detailed(self, soup):
        """Extract PDF download links with detailed classification (same as SICON)"""
        pdfs = []
        seen_base_urls = set()  # Track seen URLs to avoid duplicates
        
        # Look for PDF links in ordered lists (ol) or direct links
        for link in soup.find_all('a'):
            href = link.get('href', '')
            text = link.get_text(strip=True)
            
            # Look for PDF links
            if '.pdf' in href and ('sifin.siam.org' in href or href.startswith('/')):
                full_url = href if href.startswith('http') else f"https://sifin.siam.org{href}"
                
                # Create base URL for deduplication (remove _sc suffix)
                base_url = full_url.replace('_sc.pdf', '.pdf')
                
                # Skip if we've already seen this base URL
                if base_url in seen_base_urls:
                    continue
                seen_base_urls.add(base_url)
                
                pdf_data = {
                    'url': full_url,
                    'type': 'Unknown PDF',
                    'size': ''
                }
                
                # Determine PDF type from context (same logic as SICON)
                if 'art_file' in href:
                    pdf_data['type'] = 'Article File'
                elif 'reviewer_attachment' in href:
                    pdf_data['type'] = 'Referee Review Attachment'
                elif 'cover_letter' in href:
                    pdf_data['type'] = 'Cover Letter'
                elif 'attachment' in href:
                    pdf_data['type'] = 'Additional Attachment'
                
                # Extract size from text
                if 'KB' in text or 'MB' in text:
                    import re
                    size_match = re.search(r'\(([^)]+[KM]B)\)', text)
                    if size_match:
                        pdf_data['size'] = size_match.group(1)
                
                pdfs.append(pdf_data)
                logger.info(f"   📄 Found PDF: {pdf_data['type']} - {full_url}")
        
        return pdfs
    
    def extract_referee_comments_detailed(self, soup):
        """Extract referee comments by navigating to Associate Editor Recommendation page"""
        try:
            # Find the Associate Editor Recommendation link
            ae_link = None
            for link in soup.find_all('a'):
                href = link.get('href', '')
                text = link.get_text(strip=True)
                if 'display_me_review' in href and 'Associate Editor Recommendation' in text:
                    ae_link = href
                    break
            
            if not ae_link:
                logger.info("   📝 No Associate Editor Recommendation link found")
                return []
            
            # Construct full URL
            if not ae_link.startswith('http'):
                if ae_link.startswith('cgi-bin/'):
                    ae_link = "https://sifin.siam.org/" + ae_link
                else:
                    ae_link = "https://sifin.siam.org/cgi-bin/" + ae_link.lstrip('/')
            
            logger.info(f"   📝 Navigating to comments page: {ae_link}")
            
            # Navigate to comments page
            self.driver.get(ae_link)
            time.sleep(2)
            
            comment_soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            # Look for the comments table with Referee, Note, Comment columns
            comments = []
            seen_comments = set()  # Track seen comments to avoid duplicates
            
            for table in comment_soup.find_all('table'):
                # Check if this is the comments table
                headers = table.find_all('th')
                if len(headers) >= 3:
                    header_texts = [th.get_text(strip=True) for th in headers]
                    if 'Referee' in header_texts and 'Comment' in header_texts:
                        logger.info("   📝 Found referee comments table")
                        # This is the comments table
                        for row in table.find_all('tr')[1:]:  # Skip header row
                            cells = row.find_all('td')
                            if len(cells) >= 3:
                                referee = cells[0].get_text(strip=True)
                                note = cells[1].get_text(strip=True)
                                comment = cells[2].get_text(strip=True)
                                
                                # Create unique identifier for this comment
                                comment_id = f"{referee}|{note}|{comment[:100]}"
                                
                                # Filter out system-generated entries and empty/pointer comments
                                is_system_entry = any([
                                    'Attach File' in referee,
                                    'Review Attachment' in referee and not comment,
                                    note == '' and 'Review Attachment' in comment,
                                    'Return to the author' in referee or 'Publish after' in referee or 'Reject outright' in referee,
                                    comment == 'No Comment',
                                    comment == '' and note in ['Remarks to the Author', 'Confidential Message to Review Editor'],
                                    comment.lower().strip() in ['please see pdf', 'see pdf', 'see attached', 'see attachment', 'please see attached']
                                ])
                                
                                if referee and not is_system_entry and comment and comment.strip() and comment_id not in seen_comments:
                                    seen_comments.add(comment_id)
                                    comments.append({
                                        'referee': referee,
                                        'note_type': note,
                                        'comment': comment
                                    })
                                    logger.info(f"   📝 Extracted comment from {referee}: {comment[:50]}...")
            
            return comments
            
        except Exception as e:
            logger.warning(f"Could not extract referee comments: {e}")
            return []
    
    def crosscheck_manuscript_with_emails(self, manuscript_data, manuscript_id):
        """Crosscheck manuscript with Gmail emails"""
        if not self.gmail_service:
            return manuscript_data
            
        # Get the displayed manuscript ID from the current page URL
        # This is the ID that appears in emails (e.g., M174160)
        display_manuscript_id = manuscript_id  # Use the correct manuscript ID from the link text
        
        internal_manuscript_id = manuscript_data.get('Manuscript #', '')
        if not internal_manuscript_id:
            # Try to extract manuscript ID from title or other fields
            title = manuscript_data.get('Title', '')
            id_match = re.search(r'M\d+', title)
            if id_match:
                internal_manuscript_id = id_match.group()
            else:
                logger.warning("No manuscript ID found - skipping email crosscheck")
                return manuscript_data
        
        # Use the display ID for email search (this is the correct ID from the link text)
        search_id = display_manuscript_id
        
        logger.info(f"📧 Crosschecking emails for manuscript {search_id} (internal: {internal_manuscript_id})")
        
        # Get all referee emails for this manuscript
        referee_emails = self.fetch_manuscript_emails(search_id)
        
        # Enhance referee data with email timeline
        enhanced_referees = self.enhance_referees_with_emails(manuscript_data, referee_emails)
        
        # Add email crosscheck data
        manuscript_data['email_crosscheck'] = {
            'total_emails_found': len(referee_emails),
            'crosscheck_date': datetime.now().isoformat(),
            'enhanced_referees': enhanced_referees,
            'timeline_reconstruction': self.reconstruct_timeline(referee_emails),
            'search_manuscript_id': search_id
        }
        
        return manuscript_data
    
    def extract_display_manuscript_id(self):
        """Extract the manuscript ID that appears in emails from the current page"""
        try:
            # The display ID is usually in the page URL or title
            current_url = self.driver.current_url
            
            # Look for ms_id parameter in URL
            ms_id_match = re.search(r'ms_id=(\d+)', current_url)
            if ms_id_match:
                internal_id = ms_id_match.group(1)
                display_id = f"M{internal_id}"
                logger.info(f"📧 Found display manuscript ID: {display_id}")
                return display_id
            
            # Also check page source for the displayed manuscript ID
            page_source = self.driver.page_source
            soup = BeautifulSoup(page_source, 'html.parser')
            
            # Look for manuscript ID in task links or headings
            for link in soup.find_all('a', class_='ndt_task_link'):
                text = link.get_text(strip=True)
                if text.startswith('# M') and ' - ' in text:
                    id_match = re.search(r'# (M\d+)', text)
                    if id_match:
                        display_id = id_match.group(1)
                        logger.info(f"📧 Found display manuscript ID from task link: {display_id}")
                        return display_id
            
            return None
            
        except Exception as e:
            logger.warning(f"Could not extract display manuscript ID: {e}")
            return None
    
    def fetch_manuscript_emails(self, manuscript_id: str):
        """Fetch all emails related to a specific manuscript"""
        if not self.gmail_service:
            return []
            
        try:
            # Build comprehensive search queries for SIFIN based on actual email patterns
            queries = [
                # Direct manuscript ID searches
                f'subject:{manuscript_id}',
                f'body:{manuscript_id}',
                f'from:sifin.siam.org {manuscript_id}',
                f'to:sifin.siam.org {manuscript_id}',
                
                # SIFIN specific patterns
                f'subject:SIFIN {manuscript_id}',
                f'subject:"SIFIN {manuscript_id}"',
                f'subject:"SIFIN {manuscript_id} --"',
                f'subject:"SIFIN {manuscript_id} -"',
                
                # SIAM Journal patterns
                f'subject:"SIAM Journal" {manuscript_id}',
                f'subject:"SIAM J. Financial Mathematics" {manuscript_id}',
                f'subject:"Financial Mathematics" {manuscript_id}',
                f'subject:"Financial Mathematics manuscript #{manuscript_id}"',
                
                # Referee-specific patterns
                f'subject:referee {manuscript_id}',
                f'subject:reviewer {manuscript_id}',
                f'subject:"referee report" {manuscript_id}',
                f'subject:"Review you requested" {manuscript_id}',
                f'subject:"referee invitation" {manuscript_id}',
                
                # Action-specific patterns
                f'subject:invitation {manuscript_id}',
                f'subject:reminder {manuscript_id}',
                f'subject:"follow-up" {manuscript_id}',
                f'subject:overdue {manuscript_id}',
                f'subject:late {manuscript_id}',
                f'subject:accepted {manuscript_id}',
                f'subject:declined {manuscript_id}',
                
                # Domain-specific searches
                f'from:sifin.siam.org subject:{manuscript_id}',
                f'from:siam.org subject:{manuscript_id}',
                f'from:*siam.org* {manuscript_id}',
                
                # Broad searches for comprehensive coverage
                f'(subject:sifin OR subject:siam OR from:siam.org) {manuscript_id}',
                f'(subject:financial OR subject:mathematics) {manuscript_id}',
            ]
            
            all_emails = []
            seen_ids = set()
            
            for query in queries:
                logger.info(f"  Searching: {query}")
                
                try:
                    response = self.gmail_service.users().messages().list(
                        userId='me',
                        q=query,
                        maxResults=100
                    ).execute()
                    
                    messages = response.get('messages', [])
                    logger.info(f"    Found {len(messages)} messages")
                    
                    # Stop searching if we've found enough emails
                    if len(messages) > 0:
                        logger.info(f"    ✅ Query '{query}' found {len(messages)} messages")
                    
                    for msg in messages:
                        if msg['id'] in seen_ids:
                            continue
                            
                        try:
                            full_msg = self.gmail_service.users().messages().get(
                                userId='me',
                                id=msg['id'],
                                format='full'
                            ).execute()
                            
                            email_data = self.parse_email_message(full_msg)
                            if email_data and self.is_manuscript_relevant(email_data, manuscript_id):
                                all_emails.append(email_data)
                                seen_ids.add(msg['id'])
                                
                        except Exception as e:
                            logger.warning(f"Error fetching message {msg['id']}: {e}")
                            
                except Exception as e:
                    logger.error(f"Error with query '{query}': {e}")
                    
            # Sort emails by date
            all_emails.sort(key=lambda x: x.get('date', ''), reverse=True)
            
            logger.info(f"📧 Found {len(all_emails)} relevant emails for {manuscript_id}")
            return all_emails
            
        except Exception as e:
            logger.error(f"Error fetching emails for {manuscript_id}: {e}")
            return []
    
    def parse_email_message(self, message):
        """Parse Gmail message into structured format"""
        try:
            headers = {}
            payload = message.get('payload', {})
            
            # Extract headers
            for header in payload.get('headers', []):
                name = header.get('name', '').lower()
                if name in ['subject', 'from', 'to', 'date', 'cc', 'bcc']:
                    headers[name] = header.get('value', '')
            
            # Extract body
            body = self.extract_email_body(payload)
            
            # Parse date
            date_str = headers.get('date', '')
            parsed_date = self.parse_email_date(date_str)
            
            return {
                'id': message.get('id'),
                'thread_id': message.get('threadId'),
                'subject': headers.get('subject', ''),
                'from': headers.get('from', ''),
                'to': headers.get('to', ''),
                'cc': headers.get('cc', ''),
                'date': parsed_date,
                'body': body,
                'raw_date': date_str
            }
            
        except Exception as e:
            logger.warning(f"Error parsing email: {e}")
            return None
    
    def extract_email_body(self, payload):
        """Extract body text from email payload"""
        body = ''
        
        if 'parts' in payload:
            for part in payload['parts']:
                if part.get('mimeType') == 'text/plain':
                    data = part.get('body', {}).get('data', '')
                    if data:
                        import base64
                        try:
                            body = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                            break
                        except:
                            pass
        else:
            data = payload.get('body', {}).get('data', '')
            if data:
                import base64
                try:
                    body = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                except:
                    pass
        
        return body
    
    def parse_email_date(self, date_str):
        """Parse email date to ISO format"""
        if not date_str:
            return ''
            
        try:
            from email.utils import parsedate_to_datetime
            dt = parsedate_to_datetime(date_str)
            return dt.isoformat()
        except:
            return date_str
    
    def is_manuscript_relevant(self, email, manuscript_id):
        """Check if email is relevant to manuscript"""
        subject = email.get('subject', '').lower()
        body = email.get('body', '').lower()
        
        # Must contain manuscript ID
        if manuscript_id.lower() not in subject and manuscript_id.lower() not in body:
            return False
            
        # Must be SIFIN/SIAM related
        sifin_indicators = ['sifin', 'siam', 'financial', 'mathematics', 'referee', 'reviewer']
        return any(indicator in subject or indicator in body for indicator in sifin_indicators)
    
    def enhance_referees_with_emails(self, manuscript_data, emails):
        """Enhance referee data with email exchanges"""
        enhanced_referees = []
        
        for referee in manuscript_data.get('Referees', []):
            enhanced_ref = referee.copy()
            
            # Find emails for this referee
            referee_emails = self.find_referee_emails(referee, emails)
            
            # Analyze email timeline
            timeline = self.analyze_referee_timeline(referee_emails)
            
            # Add timeline data
            enhanced_ref['email_timeline'] = timeline
            enhanced_ref['email_count'] = len(referee_emails)
            
            enhanced_referees.append(enhanced_ref)
        
        return enhanced_referees
    
    def find_referee_emails(self, referee, emails):
        """Find emails related to specific referee"""
        referee_name = referee.get('Referee Name', '').lower()
        referee_email = referee.get('Referee Email', '').lower()
        
        referee_emails = []
        
        for email in emails:
            if self.email_involves_referee(email, referee_name, referee_email):
                referee_emails.append(email)
        
        return referee_emails
    
    def email_involves_referee(self, email, referee_name, referee_email):
        """Check if email involves specific referee"""
        to_field = email.get('to', '').lower()
        from_field = email.get('from', '').lower()
        cc_field = email.get('cc', '').lower()
        body = email.get('body', '').lower()
        
        # Check email address
        if referee_email and (
            referee_email in to_field or 
            referee_email in from_field or 
            referee_email in cc_field
        ):
            return True
        
        # Check name (be careful with partial matches)
        if referee_name and len(referee_name) > 5:
            name_parts = referee_name.split()
            if len(name_parts) >= 2:
                last_name = name_parts[-1]
                if (last_name in to_field or last_name in from_field or 
                    last_name in cc_field or last_name in body):
                    return True
        
        return False
    
    def analyze_referee_timeline(self, referee_emails):
        """Analyze referee email timeline"""
        timeline = {
            'invitation_date': None,
            'response_date': None,
            'reminder_dates': [],
            'overdue_mentions': [],
            'email_types': []
        }
        
        for email in referee_emails:
            subject = email.get('subject', '').lower()
            body = email.get('body', '').lower()
            date = email.get('date', '')
            
            # Categorize email type
            email_type = self.categorize_email_type(subject, body)
            timeline['email_types'].append({
                'date': date,
                'type': email_type,
                'subject': email.get('subject', '')
            })
            
            # Extract specific dates
            if email_type == 'invitation':
                if not timeline['invitation_date'] or date < timeline['invitation_date']:
                    timeline['invitation_date'] = date
            elif email_type == 'response':
                if not timeline['response_date'] or date < timeline['response_date']:
                    timeline['response_date'] = date
            elif email_type == 'reminder':
                timeline['reminder_dates'].append(date)
            elif email_type == 'overdue':
                timeline['overdue_mentions'].append(date)
        
        return timeline
    
    def categorize_email_type(self, subject, body):
        """Categorize email type based on content"""
        text = f"{subject} {body}".lower()
        
        if any(word in text for word in ['invitation', 'invite', 'request to review']):
            return 'invitation'
        elif any(word in text for word in ['accepted', 'agreed', 'willing to review']):
            return 'acceptance'
        elif any(word in text for word in ['declined', 'unable', 'cannot review']):
            return 'decline'
        elif any(word in text for word in ['reminder', 'follow-up', 'pending']):
            return 'reminder'
        elif any(word in text for word in ['overdue', 'late', 'delayed']):
            return 'overdue'
        elif any(word in text for word in ['report', 'review submitted']):
            return 'report_submission'
        else:
            return 'other'
    
    def reconstruct_timeline(self, emails):
        """Reconstruct complete manuscript timeline from emails"""
        timeline = {
            'manuscript_timeline': [],
            'referee_interactions': {},
            'editorial_actions': []
        }
        
        for email in emails:
            date = email.get('date', '')
            subject = email.get('subject', '')
            email_type = self.categorize_email_type(subject, email.get('body', ''))
            
            timeline['manuscript_timeline'].append({
                'date': date,
                'type': email_type,
                'subject': subject,
                'from': email.get('from', ''),
                'to': email.get('to', '')
            })
        
        # Sort by date
        timeline['manuscript_timeline'].sort(key=lambda x: x['date'])
        
        return timeline
    
    def clean_affiliation_text(self, affiliation_text):
        """Clean and parse affiliation text to extract institution name"""
        if not affiliation_text:
            return ""
            
        # Remove common HTML-like artifacts
        cleaned = re.sub(r'(GeneralInformationAddressHistoryNotesKeywords|Loading\.\.\.|Primary Work|Secondary Email Address:|ORCID:|Please enter a search term:|Search Type|Running query\.\.\.)', '', affiliation_text)
        
        # Find university/institution names
        institution_patterns = [
            r'([A-Z][a-z]+\s+(?:University|Institute|College|School)(?:\s+of\s+[A-Z][a-z]+)?)',
            r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+(?:University|Institute|College|School))',
            r'(University\s+of\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
            r'([A-Z][a-z]+\s+(?:Technological|Technical|Normal|National)\s+University)',
        ]
        
        for pattern in institution_patterns:
            match = re.search(pattern, cleaned)
            if match:
                institution = match.group(1).strip()
                if len(institution) > 5:  # Avoid very short matches
                    return institution
        
        # If no pattern match, try to extract the first meaningful institution-like text
        words = cleaned.split()
        for i, word in enumerate(words):
            if word in ['University', 'Institute', 'College', 'School'] and i > 0:
                # Take up to 3 words before the institution type
                start_idx = max(0, i-3)
                institution = ' '.join(words[start_idx:i+1])
                if len(institution) > 5:
                    return institution
        
        return cleaned[:100] if cleaned else ""  # Return first 100 chars if no clean extraction
    
    def lookup_missing_affiliations(self, referees):
        """Look up missing affiliations for referees online"""
        for referee in referees:
            if not referee.get('Affiliation', '').strip():
                name = referee.get('Referee Name', '')
                email = referee.get('Referee Email', '')
                
                # Try to extract affiliation from email domain
                if email and '@' in email:
                    domain = email.split('@')[1].lower()
                    affiliation = self.extract_affiliation_from_domain(domain)
                    if affiliation:
                        referee['Affiliation'] = affiliation
                        logger.info(f"   🔍 Found affiliation from email domain: {affiliation}")
                        continue
                
                # Try to search for the person online (simplified approach)
                if name and len(name) > 5:
                    # Remove referee number from name
                    clean_name = re.sub(r'\s+#\d+$', '', name)
                    affiliation = self.search_affiliation_online(clean_name, email)
                    if affiliation:
                        referee['Affiliation'] = affiliation
                        logger.info(f"   🔍 Found affiliation online: {affiliation}")
        
        return referees
    
    def extract_affiliation_from_domain(self, domain):
        """Extract likely affiliation from email domain"""
        # Common academic domain patterns
        domain_mappings = {
            'ntu.edu.sg': 'Nanyang Technological University',
            'imperial.ac.uk': 'Imperial College London',
            'ucf.edu': 'University of Central Florida',
            'uni-mannheim.de': 'University of Mannheim',
            'uni-stuttgart.de': 'University of Stuttgart',
            'uni-trier.de': 'University of Trier',
            'utoronto.ca': 'University of Toronto',
            'nenu.edu.cn': 'Northeast Normal University',
            'usc.edu': 'University of Southern California',
            'cwi.nl': 'Centrum Wiskunde & Informatica',
            'enpc.fr': 'École des Ponts ParisTech',
            'cermics.enpc.fr': 'École des Ponts ParisTech'
        }
        
        # Check exact domain match first
        if domain in domain_mappings:
            return domain_mappings[domain]
        
        # Try to extract university name from domain
        if '.edu' in domain or '.ac.' in domain:
            # Remove common prefixes/suffixes
            clean_domain = domain.replace('.edu', '').replace('.ac.uk', '').replace('.ac.', '')
            
            # Common university name patterns
            if 'mit' in clean_domain:
                return 'MIT'
            elif 'stanford' in clean_domain:
                return 'Stanford University'
            elif 'harvard' in clean_domain:
                return 'Harvard University'
            elif 'cambridge' in clean_domain:
                return 'University of Cambridge'
            elif 'oxford' in clean_domain:
                return 'University of Oxford'
            elif 'polytechnique' in clean_domain:
                return 'École Polytechnique'
            
            # Generic university pattern
            parts = clean_domain.split('.')
            if len(parts) > 0:
                main_part = parts[0]
                if len(main_part) > 2:
                    return f"{main_part.title()} University"
        
        return None
    
    def search_affiliation_online(self, name, email):
        """Search for person's affiliation online (simplified approach)"""
        # This is a simplified implementation
        # In a production system, you might use APIs like:
        # - Google Scholar API
        # - ORCID API
        # - CrossRef API
        # - LinkedIn API
        
        # For now, we'll use basic heuristics from the name and email
        if not name or not email:
            return None
        
        # If email domain gives us a clue, use it
        if '@' in email:
            domain = email.split('@')[1].lower()
            return self.extract_affiliation_from_domain(domain)
        
        return None
        
    def run_extraction(self):
        """Run the complete SIFIN Firefox extraction"""
        try:
            logger.info("🚀 SIFIN FIREFOX EXTRACTION")
            logger.info("==================================================")
            
            # Setup Gmail service for email crosschecking
            gmail_available = self.setup_gmail_service()
            if gmail_available:
                logger.info("✅ Gmail service ready for email crosschecking")
            else:
                logger.warning("⚠️ Gmail service not available - will skip email crosschecking")
            
            # Setup Firefox driver (headless mode for production)
            if not self.setup_firefox_driver(headless=True):
                logger.error("❌ Firefox setup failed")
                return []
            
            # Step 1: Navigate to SIFIN
            if not self.navigate_to_sifin():
                logger.error("❌ Firefox failed to navigate to SIFIN")
                return []
            
            # Step 2: Find ORCID button
            orcid_button = self.find_orcid_button_firefox()
            if not orcid_button:
                logger.error("❌ Firefox could not find ORCID button")
                return []
            
            # Click ORCID button using JavaScript (like SICON)
            try:
                self.driver.execute_script("arguments[0].click();", orcid_button)
                logger.info("✅ Firefox clicked ORCID button (JavaScript)")
                time.sleep(3)
            except Exception:
                # Fallback to regular click
                try:
                    orcid_button.click()
                    logger.info("✅ Firefox clicked ORCID button (regular)")
                    time.sleep(3)
                except Exception as e:
                    logger.error(f"❌ Firefox failed to click ORCID button: {e}")
                    return []
            
            # Step 3: Authenticate
            if not self.authenticate_orcid_firefox():
                logger.error("❌ Firefox ORCID authentication failed")
                return []
            
            # Step 4: Extract manuscripts
            manuscripts = self.extract_manuscripts_firefox()
            
            # Save results
            output_file = f"sifin_firefox_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(output_file, 'w') as f:
                json.dump(manuscripts, f, indent=2, default=str)
            
            # Summary with detailed breakdown
            total_referees = sum(len(ms.get("Referees", [])) for ms in manuscripts)
            total_pdfs = sum(len(ms.get("PDFs", [])) for ms in manuscripts)
            total_comments = sum(len(ms.get("referee_comments", [])) for ms in manuscripts)
            
            # Count PDF types
            pdf_types = {}
            for ms in manuscripts:
                for pdf in ms.get("PDFs", []):
                    pdf_type = pdf.get("type", "Unknown")
                    pdf_types[pdf_type] = pdf_types.get(pdf_type, 0) + 1
            
            logger.info("\\n📊 FIREFOX EXTRACTION RESULTS:")
            logger.info(f"    Manuscripts: {len(manuscripts)}")
            logger.info(f"    Total Referees: {total_referees}")
            logger.info(f"    Total PDFs: {total_pdfs}")
            for pdf_type, count in pdf_types.items():
                logger.info(f"      - {pdf_type}: {count}")
            logger.info(f"    Total Referee Comments: {total_comments}")
            logger.info(f"💾 Results saved to: {output_file}")
            
            return manuscripts
            
        except Exception as e:
            logger.error(f"❌ Firefox extraction failed: {e}")
            import traceback
            traceback.print_exc()
            return []
            
        finally:
            if self.driver:
                self.driver.quit()
                logger.info("🖥️ Firefox browser closed")

def main():
    """Main execution"""
    extractor = SIFINFirefoxExtractor()
    
    # Check credentials
    if not os.environ.get('ORCID_EMAIL') or not os.environ.get('ORCID_PASSWORD'):
        logger.error("❌ Missing ORCID credentials")
        sys.exit(1)
    
    # Run extraction
    results = extractor.run_extraction()
    
    if results:
        logger.info("✅ FIREFOX EXTRACTION SUCCESSFUL!")
        
        # Print detailed results
        for i, ms in enumerate(results, 1):
            logger.info(f"\\nManuscript {i}: {ms.get('Manuscript #', '')}")
            logger.info(f"  Title: {ms.get('Title', 'N/A')[:60]}...")
            logger.info(f"  Status: {ms.get('Current Stage', 'N/A')}")
            logger.info(f"  Submitted: {ms.get('Submitted', 'N/A')}")
            logger.info(f"  Referees: {len(ms.get('Referees', []))}")
            
            for j, ref in enumerate(ms.get('Referees', [])[:3], 1):
                logger.info(f"    Referee {j}: {ref.get('Referee Name', '')} - {ref.get('Status', '')}")
    else:
        logger.error("❌ FIREFOX EXTRACTION FAILED!")
        sys.exit(1)

if __name__ == "__main__":
    main()