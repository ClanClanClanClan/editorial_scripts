#!/usr/bin/env python3
"""
ScholarOne platform tests for MF and MOR extractors.
Tests platform-specific features and differences.
"""

import unittest
import sys
from pathlib import Path
from unittest.mock import Mock, patch

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))


class TestScholarOnePlatform(unittest.TestCase):
    """Test ScholarOne platform-specific functionality."""
    
    def setUp(self):
        """Set up test environment."""
        from editorial_assistant.extractors.mf_extractor import MFExtractor
        from editorial_assistant.extractors.mor_extractor import MORExtractor
        
        self.mf_extractor = MFExtractor()
        self.mor_extractor = MORExtractor()
    
    def test_mf_vs_mor_category_differences(self):
        """Test that MF has 6 categories while MOR has 7."""
        
        # MF should have 6 categories
        self.assertEqual(len(self.mf_extractor.categories), 6)
        
        # MOR should have 7 categories (includes "Overdue" categories)
        self.assertEqual(len(self.mor_extractor.categories), 7)
        
        # Verify MOR has overdue categories that MF doesn't
        mor_categories = self.mor_extractor.categories
        overdue_categories = [cat for cat in mor_categories if "Overdue" in cat]
        self.assertGreater(len(overdue_categories), 0, "MOR should have Overdue categories")
    
    def test_url_differences(self):
        """Test that MF and MOR have different URLs."""
        
        self.assertIn("mafi", self.mf_extractor.journal_url)
        self.assertIn("mor", self.mor_extractor.journal_url)
        self.assertNotEqual(self.mf_extractor.journal_url, self.mor_extractor.journal_url)
    
    def test_shared_platform_features(self):
        """Test features that should be the same across ScholarOne journals."""
        
        # Both should use ScholarOne authentication
        self.assertTrue(hasattr(self.mf_extractor, 'login'))
        self.assertTrue(hasattr(self.mor_extractor, 'login'))
        
        # Both should have same popup timing
        self.assertEqual(self.mf_extractor.popup_wait_time, 6)
        self.assertEqual(self.mor_extractor.popup_wait_time, 6)
        
        # Both should have same navigation timing  
        self.assertEqual(self.mf_extractor.page_navigation_wait, 5)
        self.assertEqual(self.mor_extractor.page_navigation_wait, 5)
        
        # Both should have extract_all_data method
        self.assertTrue(hasattr(self.mf_extractor, 'extract_all_data'))
        self.assertTrue(hasattr(self.mor_extractor, 'extract_all_data'))
    
    def test_staff_exclusions_different(self):
        """Test that MF and MOR may have different staff exclusions."""
        
        # Both should have staff exclusions defined
        self.assertIsInstance(self.mf_extractor.staff_to_exclude, list)
        self.assertIsInstance(self.mor_extractor.staff_to_exclude, list)
        
        # Should not be empty
        self.assertGreater(len(self.mf_extractor.staff_to_exclude), 0)
        self.assertGreater(len(self.mor_extractor.staff_to_exclude), 0)
    
    def test_inheritance_structure(self):
        """Test that both inherit from ScholarOneExtractor."""
        
        from editorial_assistant.extractors.scholarone import ScholarOneExtractor
        
        self.assertIsInstance(self.mf_extractor, ScholarOneExtractor)
        self.assertIsInstance(self.mor_extractor, ScholarOneExtractor)
    
    def test_authentication_methods_exist(self):
        """Test that authentication-related methods exist."""
        
        auth_methods = ['login', '_is_logged_in', '_needs_2fa', '_handle_2fa']
        
        for method in auth_methods:
            self.assertTrue(hasattr(self.mf_extractor, method), f"MF missing {method}")
            self.assertTrue(hasattr(self.mor_extractor, method), f"MOR missing {method}")
    
    def test_extraction_methods_exist(self):
        """Test that extraction-related methods exist."""
        
        extraction_methods = [
            'extract_manuscripts_for_category',
            'extract_referee_data_for_manuscript', 
            '_execute_take_action',
            '_extract_referees_from_popup'
        ]
        
        for method in extraction_methods:
            self.assertTrue(hasattr(self.mf_extractor, method), f"MF missing {method}")
            self.assertTrue(hasattr(self.mor_extractor, method), f"MOR missing {method}")
    
    def test_parsing_methods_exist(self):
        """Test that parsing-related methods exist."""
        
        parsing_methods = [
            '_parse_authors',
            '_should_exclude_referee',
            '_extract_email_from_row',
            '_deduplicate_referees'
        ]
        
        for method in parsing_methods:
            self.assertTrue(hasattr(self.mf_extractor, method), f"MF missing {method}")
            self.assertTrue(hasattr(self.mor_extractor, method), f"MOR missing {method}")


class TestScholarOneCompatibility(unittest.TestCase):
    """Test backward compatibility of ScholarOne extractors."""
    
    def test_mf_backward_compatibility(self):
        """Test MF backward compatibility function."""
        from editorial_assistant.extractors.mf_extractor import extract_mf_data
        
        # Should be callable
        self.assertTrue(callable(extract_mf_data))
        
        # Should accept expected parameters
        import inspect
        sig = inspect.signature(extract_mf_data)
        params = list(sig.parameters.keys())
        
        expected_params = ['username', 'password', 'headless']
        for param in expected_params:
            self.assertIn(param, params, f"MF missing parameter: {param}")
    
    def test_mor_backward_compatibility(self):
        """Test MOR backward compatibility function."""
        from editorial_assistant.extractors.mor_extractor import extract_mor_data
        
        # Should be callable
        self.assertTrue(callable(extract_mor_data))
        
        # Should accept expected parameters
        import inspect
        sig = inspect.signature(extract_mor_data)
        params = list(sig.parameters.keys())
        
        expected_params = ['username', 'password', 'headless']
        for param in expected_params:
            self.assertIn(param, params, f"MOR missing parameter: {param}")
    
    @patch('os.environ.get')
    def test_credential_handling(self, mock_env_get):
        """Test that credential environment variables are handled correctly."""
        
        # Mock environment variables
        def mock_get_env(key, default=None):
            env_vars = {
                'SCHOLARONE_USERNAME': 'test_user',
                'SCHOLARONE_PASSWORD': 'test_pass',
                'MF_USERNAME': 'mf_user',
                'MF_PASSWORD': 'mf_pass',
                'MOR_USERNAME': 'mor_user', 
                'MOR_PASSWORD': 'mor_pass'
            }
            return env_vars.get(key, default)
        
        mock_env_get.side_effect = mock_get_env
        
        # Test that extractors can access credentials
        from editorial_assistant.extractors.mf_extractor import MFExtractor
        from editorial_assistant.extractors.mor_extractor import MORExtractor
        
        mf = MFExtractor()
        mor = MORExtractor()
        
        # Should initialize without credential errors
        self.assertIsNotNone(mf)
        self.assertIsNotNone(mor)


class TestScholarOneErrorHandling(unittest.TestCase):
    """Test error handling in ScholarOne extractors."""
    
    def test_missing_config_handling(self):
        """Test graceful handling of missing configuration."""
        
        # Should still initialize even with missing config elements
        try:
            from editorial_assistant.extractors.mf_extractor import MFExtractor
            from editorial_assistant.extractors.mor_extractor import MORExtractor
            
            mf = MFExtractor()
            mor = MORExtractor()
            
            self.assertIsNotNone(mf)
            self.assertIsNotNone(mor)
            
        except Exception as e:
            self.fail(f"Extractors should handle missing config gracefully: {e}")
    
    def test_invalid_journal_code_handling(self):
        """Test handling of invalid journal codes."""
        
        from editorial_assistant.extractors.mf_extractor import MFExtractor
        from editorial_assistant.extractors.mor_extractor import MORExtractor
        from editorial_assistant.core.exceptions import ConfigurationError
        
        # Should raise ConfigurationError for invalid journal codes (this is correct behavior)
        with self.assertRaises(ConfigurationError):
            MFExtractor('INVALID_CODE')
            
        with self.assertRaises(ConfigurationError):
            MORExtractor('INVALID_CODE')


if __name__ == '__main__':
    unittest.main(verbosity=2)