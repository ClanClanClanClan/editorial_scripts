#!/usr/bin/env python3
"""Debug ONLY Take Action clicking - nothing else"""

import os
import sys
import time
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from dotenv import load_dotenv

load_dotenv('.env.production')

def debug_take_action_only():
    """Test ONLY the Take Action clicking part"""
    
    print("🎯 DEBUG: TAKE ACTION ONLY TEST")
    print("=" * 60)
    
    # Chrome setup
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        print("\n📋 MANUAL SETUP REQUIRED:")
        print("1. Navigate to: https://mc.manuscriptcentral.com/mafi")
        print("2. Login manually")
        print("3. Go to Associate Editor Center")
        print("4. Click on 'Awaiting Reviewer Scores' or similar")
        print("5. Make sure you see the manuscript table with MAFI-* IDs")
        
        input("\nPress ENTER when you see the manuscript table...")
        
        print("\n🔍 ANALYZING PAGE...")
        
        # Get current URL for reference
        current_url = driver.current_url
        print(f"Current URL: {current_url}")
        
        # Find all rows
        all_rows = driver.find_elements(By.TAG_NAME, "tr")
        print(f"Total rows found: {len(all_rows)}")
        
        # Find manuscript rows
        manuscript_rows = []
        for i, row in enumerate(all_rows):
            row_text = row.text
            if 'MAFI-' in row_text and 'Manuscript ID' not in row_text:
                manuscript_rows.append((i, row))
                print(f"\n📄 Found manuscript row {i}: {row_text[:100]}...")
        
        print(f"\nTotal manuscript rows: {len(manuscript_rows)}")
        
        if not manuscript_rows:
            print("❌ No manuscript rows found!")
            return
        
        # Test first manuscript
        row_index, first_row = manuscript_rows[0]
        print(f"\n🎯 TESTING FIRST MANUSCRIPT (row {row_index})...")
        
        # Extract manuscript ID
        import re
        ms_id_match = re.search(r'MAFI-\d{4}-\d{4}', first_row.text)
        manuscript_id = ms_id_match.group(0) if ms_id_match else "Unknown"
        print(f"Manuscript ID: {manuscript_id}")
        
        # Get cells
        cells = first_row.find_elements(By.TAG_NAME, "td")
        print(f"Number of cells: {len(cells)}")
        
        if not cells:
            print("❌ No cells found!")
            return
        
        # Check last cell
        last_cell = cells[-1]
        print(f"Last cell HTML: {last_cell.get_attribute('innerHTML')[:200]}...")
        
        # Look for Take Action
        take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
        print(f"Take Action links with check_off.gif: {len(take_action_links)}")
        
        if not take_action_links:
            # Try alternate search
            all_links = last_cell.find_elements(By.TAG_NAME, "a")
            print(f"All links in last cell: {len(all_links)}")
            for link in all_links:
                href = link.get_attribute('href')
                print(f"  Link: {href}")
                if 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS' in (href or ''):
                    take_action_links = [link]
                    break
        
        if not take_action_links:
            print("❌ No Take Action found!")
            return
        
        # Click Take Action
        link = take_action_links[0]
        href = link.get_attribute('href')
        print(f"\n🚀 CLICKING TAKE ACTION...")
        print(f"href: {href}")
        
        old_url = driver.current_url
        
        if href and 'javascript:' in href:
            js_code = href.replace('javascript:', '')
            print(f"Executing JavaScript: {js_code[:100]}...")
            driver.execute_script(js_code)
        else:
            print("Using direct click...")
            link.click()
        
        # Wait and check
        time.sleep(5)
        new_url = driver.current_url
        
        print(f"\n📊 RESULTS:")
        print(f"Old URL: {old_url}")
        print(f"New URL: {new_url}")
        print(f"Navigation occurred: {old_url != new_url}")
        
        # Check page content
        page_text = driver.find_element(By.TAG_NAME, "body").text
        print(f"Page contains 'Referee': {'Referee' in page_text}")
        print(f"Page contains 'Reviewer': {'Reviewer' in page_text}")
        
        if 'Referee' in page_text or 'Reviewer' in page_text:
            print("\n✅ SUCCESS! Take Action worked!")
            referee_count = page_text.count('@')
            print(f"Approximate referee count: {referee_count}")
        else:
            print("\n❌ FAILED! Not on referee page")
            print("Page preview:")
            print(page_text[:500])
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        print("\nBrowser will remain open for 30 seconds...")
        time.sleep(30)
        driver.quit()

if __name__ == "__main__":
    debug_take_action_only()