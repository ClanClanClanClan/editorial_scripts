#!/usr/bin/env python3
"""
Unified Timeline Manager - Cross-platform timeline coordination

This module provides unified timeline management across all journal platforms,
integrating web-extracted data with email timeline information.

Phase 3: System Integration - Timeline Integration System
"""

from typing import Dict, List, Optional, Any, Union, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum
import logging
import re
from pathlib import Path

from ..core.unified_config import get_config_manager
from ..core.platform_extractor import UnifiedManuscript, UnifiedReferee, PlatformType
from ..core.exceptions import ConfigurationError, ExtractionError


class TimelineEventType(Enum):
    """Types of timeline events."""
    SUBMISSION = "submission"
    INVITATION_SENT = "invitation_sent"
    REMINDER_SENT = "reminder_sent"
    RESPONSE_RECEIVED = "response_received"
    REVIEW_SUBMITTED = "review_submitted"
    REVIEW_DUE = "review_due"
    DECISION_MADE = "decision_made"
    REVISION_REQUESTED = "revision_requested"
    MANUSCRIPT_WITHDRAWN = "manuscript_withdrawn"


class TimelineEventSource(Enum):
    """Sources of timeline events."""
    WEB_INTERFACE = "web"
    GMAIL_EMAIL = "gmail"
    SYSTEM_GENERATED = "system"
    USER_INPUT = "user"


@dataclass
class TimelineEvent:
    """Unified timeline event across all platforms."""
    
    # Core identification
    event_id: str
    manuscript_id: str
    event_type: TimelineEventType
    event_date: datetime
    
    # Event details
    source: TimelineEventSource
    platform_type: PlatformType
    description: str
    
    # Participants
    participants: List[str] = None  # Email addresses
    referee_email: Optional[str] = None
    
    # Event metadata
    raw_data: Dict[str, Any] = None
    confidence_score: float = 1.0  # 0.0 to 1.0
    
    # Validation
    is_validated: bool = False
    validation_notes: str = ""
    
    def __post_init__(self):
        """Initialize default values."""
        if self.participants is None:
            self.participants = []
        if self.raw_data is None:
            self.raw_data = {}


@dataclass
class ManuscriptTimeline:
    """Complete timeline for a manuscript across all sources."""
    
    manuscript_id: str
    platform_type: PlatformType
    journal_code: str
    
    # Timeline events
    events: List[TimelineEvent]
    
    # Timeline metadata
    first_event_date: Optional[datetime] = None
    last_event_date: Optional[datetime] = None
    total_events: int = 0
    
    # Validation status
    is_complete: bool = False
    validation_score: float = 0.0
    issues: List[str] = None
    
    def __post_init__(self):
        """Calculate timeline metadata."""
        if self.events:
            self.total_events = len(self.events)
            dates = [e.event_date for e in self.events if e.event_date]
            if dates:
                self.first_event_date = min(dates)
                self.last_event_date = max(dates)
        
        if self.issues is None:
            self.issues = []


class TimelineManager:
    """
    Unified timeline manager for cross-platform coordination.
    
    This class integrates timeline data from multiple sources:
    - Web interface extractions
    - Gmail email analysis  
    - System-generated events
    - User inputs
    """
    
    def __init__(self):
        """Initialize the timeline manager."""
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Configuration
        config_manager = get_config_manager()
        self.enable_gmail_integration = config_manager.is_feature_enabled('gmail_timeline_integration')
        self.enable_validation = config_manager.is_feature_enabled('timeline_validation')
        self.enable_event_inference = config_manager.is_feature_enabled('timeline_event_inference')
        
        # Timeline storage
        self._timelines: Dict[str, ManuscriptTimeline] = {}
        self._event_processors = {}
        
        # Gmail integration
        self._gmail_integration = None
        if self.enable_gmail_integration:
            try:
                from .gmail_integration import GmailTimelineIntegration
                self._gmail_integration = GmailTimelineIntegration()
                self.logger.info("Gmail timeline integration enabled")
            except ImportError:
                self.logger.warning("Gmail integration not available")
                self.enable_gmail_integration = False
        
        # Event processors for different platforms
        self._initialize_event_processors()
        
        self.logger.info(f"Timeline Manager initialized - Gmail: {self.enable_gmail_integration}, "
                        f"Validation: {self.enable_validation}, Inference: {self.enable_event_inference}")
    
    def _initialize_event_processors(self):
        """Initialize platform-specific event processors."""
        
        # ScholarOne event patterns
        self._event_processors[PlatformType.SCHOLARONE] = {
            'invitation_patterns': [
                r'invitation.*review',
                r'reviewer.*assignment',
                r'review.*request'
            ],
            'reminder_patterns': [
                r'reminder.*review',
                r'overdue.*review', 
                r'follow.*up.*review'
            ],
            'response_patterns': [
                r'accepted.*review',
                r'declined.*review',
                r'review.*response'
            ]
        }
        
        # SIAM event patterns
        self._event_processors[PlatformType.SIAM] = {
            'invitation_patterns': [
                r'invitation.*referee',
                r'referee.*request',
                r'review.*invitation'
            ],
            'reminder_patterns': [
                r'reminder.*referee',
                r'overdue.*referee',
                r'follow.*up.*referee'  
            ],
            'response_patterns': [
                r'accepted.*referee',
                r'declined.*referee',
                r'referee.*response'
            ]
        }
    
    def create_timeline(self, manuscript: UnifiedManuscript, 
                       web_referees: List[UnifiedReferee] = None) -> ManuscriptTimeline:
        """
        Create a unified timeline for a manuscript.
        
        Args:
            manuscript: Unified manuscript object
            web_referees: Referees extracted from web interface
            
        Returns:
            ManuscriptTimeline: Complete timeline with all events
        """
        timeline_id = f"{manuscript.journal_code}_{manuscript.manuscript_id}"
        
        self.logger.info(f"Creating timeline for manuscript {manuscript.manuscript_id}")
        
        # Initialize timeline
        timeline = ManuscriptTimeline(
            manuscript_id=manuscript.manuscript_id,
            platform_type=manuscript.platform_type,
            journal_code=manuscript.journal_code,
            events=[]
        )
        
        try:
            # Step 1: Extract events from web data
            web_events = self._extract_web_events(manuscript, web_referees or [])
            timeline.events.extend(web_events)
            
            # Step 2: Extract events from Gmail (if enabled)
            if self.enable_gmail_integration and self._gmail_integration:
                gmail_events = self._extract_gmail_events(manuscript, web_referees or [])
                timeline.events.extend(gmail_events)
            
            # Step 3: Generate inferred events (if enabled)
            if self.enable_event_inference:
                inferred_events = self._generate_inferred_events(timeline)
                timeline.events.extend(inferred_events)
            
            # Step 4: Sort and deduplicate events
            timeline.events = self._process_timeline_events(timeline.events)
            
            # Step 5: Validate timeline (if enabled)
            if self.enable_validation:
                self._validate_timeline(timeline)
            
            # Store timeline
            self._timelines[timeline_id] = timeline
            
            self.logger.info(f"Timeline created for {manuscript.manuscript_id}: {len(timeline.events)} events")
            return timeline
            
        except Exception as e:
            self.logger.error(f"Failed to create timeline for {manuscript.manuscript_id}: {e}")
            raise ExtractionError(f"Timeline creation failed: {e}") from e
    
    def _extract_web_events(self, manuscript: UnifiedManuscript, 
                           referees: List[UnifiedReferee]) -> List[TimelineEvent]:
        """Extract timeline events from web interface data."""
        events = []
        
        try:
            # Extract submission event from manuscript data
            if manuscript.submission_date:
                submission_event = TimelineEvent(
                    event_id=f"sub_{manuscript.manuscript_id}",
                    manuscript_id=manuscript.manuscript_id,
                    event_type=TimelineEventType.SUBMISSION,
                    event_date=manuscript.submission_date,
                    source=TimelineEventSource.WEB_INTERFACE,
                    platform_type=manuscript.platform_type,
                    description=f"Manuscript {manuscript.manuscript_id} submitted",
                    raw_data={'source': 'manuscript_data'}
                )
                events.append(submission_event)
            
            # Extract referee events
            for referee in referees:
                # Invitation events
                if referee.invitation_date:
                    invitation_event = TimelineEvent(
                        event_id=f"inv_{manuscript.manuscript_id}_{referee.email}",
                        manuscript_id=manuscript.manuscript_id,
                        event_type=TimelineEventType.INVITATION_SENT,
                        event_date=referee.invitation_date,
                        source=TimelineEventSource.WEB_INTERFACE,
                        platform_type=manuscript.platform_type,
                        description=f"Review invitation sent to {referee.name}",
                        referee_email=referee.email,
                        participants=[referee.email],
                        raw_data={'referee_data': referee.platform_data}
                    )
                    events.append(invitation_event)
                
                # Response events
                if referee.response_date:
                    response_event = TimelineEvent(
                        event_id=f"resp_{manuscript.manuscript_id}_{referee.email}",
                        manuscript_id=manuscript.manuscript_id,
                        event_type=TimelineEventType.RESPONSE_RECEIVED,
                        event_date=referee.response_date,
                        source=TimelineEventSource.WEB_INTERFACE,
                        platform_type=manuscript.platform_type,
                        description=f"Response received from {referee.name}",
                        referee_email=referee.email,
                        participants=[referee.email],
                        raw_data={'referee_data': referee.platform_data}
                    )
                    events.append(response_event)
                
                # Due date events (as system-generated)
                if referee.due_date:
                    due_event = TimelineEvent(
                        event_id=f"due_{manuscript.manuscript_id}_{referee.email}",
                        manuscript_id=manuscript.manuscript_id,
                        event_type=TimelineEventType.REVIEW_DUE,
                        event_date=referee.due_date,
                        source=TimelineEventSource.SYSTEM_GENERATED,
                        platform_type=manuscript.platform_type,
                        description=f"Review due from {referee.name}",
                        referee_email=referee.email,
                        participants=[referee.email],
                        raw_data={'referee_data': referee.platform_data}
                    )
                    events.append(due_event)
            
            self.logger.debug(f"Extracted {len(events)} events from web data")
            return events
            
        except Exception as e:
            self.logger.error(f"Failed to extract web events: {e}")
            return []
    
    def _extract_gmail_events(self, manuscript: UnifiedManuscript,
                             referees: List[UnifiedReferee]) -> List[TimelineEvent]:
        """Extract timeline events from Gmail integration."""
        if not self._gmail_integration:
            return []
        
        try:
            self.logger.debug(f"Extracting Gmail events for manuscript {manuscript.manuscript_id}")
            
            # Get referee email addresses for filtering
            referee_emails = [r.email for r in referees if r.email]
            
            # Extract Gmail events
            gmail_events = self._gmail_integration.extract_timeline_events(
                manuscript_id=manuscript.manuscript_id,
                journal_code=manuscript.journal_code,
                referee_emails=referee_emails,
                platform_type=manuscript.platform_type
            )
            
            self.logger.debug(f"Extracted {len(gmail_events)} events from Gmail")
            return gmail_events
            
        except Exception as e:
            self.logger.error(f"Failed to extract Gmail events: {e}")
            return []
    
    def _generate_inferred_events(self, timeline: ManuscriptTimeline) -> List[TimelineEvent]:
        """Generate inferred events based on existing timeline."""
        inferred_events = []
        
        try:
            # Look for patterns that suggest missing events
            invitation_events = [e for e in timeline.events if e.event_type == TimelineEventType.INVITATION_SENT]
            response_events = [e for e in timeline.events if e.event_type == TimelineEventType.RESPONSE_RECEIVED]
            
            # Infer reminders for overdue reviews
            for invitation in invitation_events:
                # Look for corresponding response
                response = next((r for r in response_events if r.referee_email == invitation.referee_email), None)
                
                if response:
                    # If response came more than 2 weeks after invitation, infer reminder
                    if (response.event_date - invitation.event_date).days > 14:
                        reminder_date = invitation.event_date + timedelta(days=10)
                        
                        reminder_event = TimelineEvent(
                            event_id=f"inferred_rem_{timeline.manuscript_id}_{invitation.referee_email}",
                            manuscript_id=timeline.manuscript_id,
                            event_type=TimelineEventType.REMINDER_SENT,
                            event_date=reminder_date,
                            source=TimelineEventSource.SYSTEM_GENERATED,
                            platform_type=timeline.platform_type,
                            description=f"Inferred reminder sent to {invitation.referee_email}",
                            referee_email=invitation.referee_email,
                            participants=[invitation.referee_email],
                            confidence_score=0.7,  # Lower confidence for inferred events
                            raw_data={'inferred': True, 'based_on': 'response_delay'}
                        )
                        inferred_events.append(reminder_event)
            
            self.logger.debug(f"Generated {len(inferred_events)} inferred events")
            return inferred_events
            
        except Exception as e:
            self.logger.error(f"Failed to generate inferred events: {e}")
            return []
    
    def _process_timeline_events(self, events: List[TimelineEvent]) -> List[TimelineEvent]:
        """Sort and deduplicate timeline events."""
        
        # Remove duplicates based on event_id
        unique_events = {}
        for event in events:
            if event.event_id not in unique_events:
                unique_events[event.event_id] = event
            else:
                # Keep event with higher confidence score
                if event.confidence_score > unique_events[event.event_id].confidence_score:
                    unique_events[event.event_id] = event
        
        # Sort by date
        sorted_events = sorted(unique_events.values(), key=lambda e: e.event_date)
        
        return sorted_events
    
    def _validate_timeline(self, timeline: ManuscriptTimeline):
        """Validate timeline for consistency and completeness."""
        
        issues = []
        
        # Check for basic timeline consistency
        if timeline.events:
            # Check date ordering
            for i in range(1, len(timeline.events)):
                if timeline.events[i].event_date < timeline.events[i-1].event_date:
                    issues.append(f"Timeline ordering issue at event {i}")
            
            # Check for reasonable time gaps
            for i in range(1, len(timeline.events)):
                gap = timeline.events[i].event_date - timeline.events[i-1].event_date
                if gap.days > 365:  # More than a year gap
                    issues.append(f"Large time gap ({gap.days} days) between events {i-1} and {i}")
        
        # Check for missing expected events
        invitation_events = [e for e in timeline.events if e.event_type == TimelineEventType.INVITATION_SENT]
        submission_events = [e for e in timeline.events if e.event_type == TimelineEventType.SUBMISSION]
        
        if invitation_events and not submission_events:
            issues.append("Invitations found but no submission event")
        
        # Calculate validation score
        total_checks = 4  # Number of validation checks
        passed_checks = total_checks - len(issues)
        timeline.validation_score = max(0.0, passed_checks / total_checks)
        
        # Mark as complete if score is high enough
        timeline.is_complete = timeline.validation_score >= 0.8
        
        timeline.issues = issues
        
        if issues:
            self.logger.warning(f"Timeline validation issues for {timeline.manuscript_id}: {issues}")
        else:
            self.logger.debug(f"Timeline validation passed for {timeline.manuscript_id}")
    
    def get_timeline(self, manuscript_id: str, journal_code: str = None) -> Optional[ManuscriptTimeline]:
        """Get timeline for a specific manuscript."""
        
        # Try with journal code first
        if journal_code:
            timeline_id = f"{journal_code}_{manuscript_id}"
            if timeline_id in self._timelines:
                return self._timelines[timeline_id]
        
        # Search through all timelines
        for timeline in self._timelines.values():
            if timeline.manuscript_id == manuscript_id:
                return timeline
        
        return None
    
    def get_timeline_summary(self, manuscript_id: str, journal_code: str = None) -> Dict[str, Any]:
        """Get summary statistics for a timeline."""
        
        timeline = self.get_timeline(manuscript_id, journal_code)
        if not timeline:
            return {'error': 'Timeline not found'}
        
        # Count events by type
        event_counts = {}
        for event in timeline.events:
            event_type = event.event_type.value
            event_counts[event_type] = event_counts.get(event_type, 0) + 1
        
        # Count events by source
        source_counts = {}
        for event in timeline.events:
            source = event.source.value
            source_counts[source] = source_counts.get(source, 0) + 1
        
        return {
            'manuscript_id': timeline.manuscript_id,
            'platform_type': timeline.platform_type.value,
            'total_events': timeline.total_events,
            'first_event': timeline.first_event_date.isoformat() if timeline.first_event_date else None,
            'last_event': timeline.last_event_date.isoformat() if timeline.last_event_date else None,
            'is_complete': timeline.is_complete,
            'validation_score': timeline.validation_score,
            'event_counts': event_counts,
            'source_counts': source_counts,
            'issues': timeline.issues
        }
    
    def export_timeline(self, manuscript_id: str, journal_code: str = None, 
                       format: str = 'dict') -> Union[Dict[str, Any], str]:
        """Export timeline in specified format."""
        
        timeline = self.get_timeline(manuscript_id, journal_code)
        if not timeline:
            raise ValueError(f"Timeline not found for manuscript {manuscript_id}")
        
        if format == 'dict':
            return {
                'timeline_metadata': {
                    'manuscript_id': timeline.manuscript_id,
                    'platform_type': timeline.platform_type.value,
                    'journal_code': timeline.journal_code,
                    'total_events': timeline.total_events,
                    'validation_score': timeline.validation_score,
                    'is_complete': timeline.is_complete
                },
                'events': [
                    {
                        'event_id': event.event_id,
                        'event_type': event.event_type.value,
                        'event_date': event.event_date.isoformat(),
                        'source': event.source.value,
                        'description': event.description,
                        'referee_email': event.referee_email,
                        'participants': event.participants,
                        'confidence_score': event.confidence_score,
                        'raw_data': event.raw_data
                    }
                    for event in timeline.events
                ]
            }
        
        elif format == 'csv':
            import csv
            import io
            
            output = io.StringIO()
            writer = csv.writer(output)
            
            # Header
            writer.writerow(['event_date', 'event_type', 'description', 'source', 'referee_email', 'confidence'])
            
            # Events
            for event in timeline.events:
                writer.writerow([
                    event.event_date.isoformat(),
                    event.event_type.value,
                    event.description,
                    event.source.value,
                    event.referee_email or '',
                    event.confidence_score
                ])
            
            return output.getvalue()
        
        else:
            raise ValueError(f"Unsupported format: {format}")
    
    def clear_timeline(self, manuscript_id: str, journal_code: str = None):
        """Clear timeline for a manuscript."""
        
        if journal_code:
            timeline_id = f"{journal_code}_{manuscript_id}"
            if timeline_id in self._timelines:
                del self._timelines[timeline_id]
                self.logger.info(f"Cleared timeline for {timeline_id}")
                return
        
        # Search and remove
        to_remove = []
        for timeline_id, timeline in self._timelines.items():
            if timeline.manuscript_id == manuscript_id:
                to_remove.append(timeline_id)
        
        for timeline_id in to_remove:
            del self._timelines[timeline_id]
            self.logger.info(f"Cleared timeline for {timeline_id}")
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Get performance metrics for the timeline manager."""
        
        total_timelines = len(self._timelines)
        if total_timelines == 0:
            return {'message': 'No timelines processed yet'}
        
        # Calculate metrics
        total_events = sum(t.total_events for t in self._timelines.values())
        avg_events_per_timeline = total_events / total_timelines
        
        validation_scores = [t.validation_score for t in self._timelines.values()]
        avg_validation_score = sum(validation_scores) / len(validation_scores)
        
        complete_timelines = sum(1 for t in self._timelines.values() if t.is_complete)
        completeness_rate = complete_timelines / total_timelines
        
        return {
            'total_timelines': total_timelines,
            'total_events': total_events,
            'avg_events_per_timeline': avg_events_per_timeline,
            'avg_validation_score': avg_validation_score,
            'completeness_rate': completeness_rate,
            'complete_timelines': complete_timelines,
            'gmail_integration_enabled': self.enable_gmail_integration,
            'validation_enabled': self.enable_validation,
            'inference_enabled': self.enable_event_inference
        }