#!/usr/bin/env python3
"""
SIFIN Adapter for Generic Referee Tracker
Demonstrates how to integrate the generic referee tracking system with existing SIFIN email parser
"""

import sys
import os
import json
import re
from datetime import datetime, timezone
from typing import List, Dict, Optional
from dataclasses import dataclass

# Add path to import existing SIFIN parser
sys.path.append('/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/scripts/sifin')

from referee_email_tracker import (
    GenericRefereeTracker, EmailEvent, RefereeProfile, RefereeState
)

try:
    from parse_sifin_emails import SIFINEmailParser
except ImportError:
    print("Warning: Could not import SIFINEmailParser. Running in standalone mode.")
    SIFINEmailParser = None

class SIFINAdapter:
    """Adapter to integrate SIFIN email parser with generic referee tracker"""
    
    def __init__(self):
        self.referee_tracker = GenericRefereeTracker()
        self.sifin_parser = SIFINEmailParser() if SIFINEmailParser else None
        
        # SIFIN-specific pattern enhancements
        self.enhance_sifin_patterns()
    
    def enhance_sifin_patterns(self):
        """Add SIFIN-specific patterns to the generic tracker"""
        sifin_patterns = {
            'invitation': [
                r'SIFIN.*invitation.*referee',
                r'SIFIN.*[Ii]nvitation.*[Mm]anuscript\s+(M\d+)',
                r'SIFIN.*[Rr]eview.*[Rr]equest.*[Mm]anuscript\s+(M\d+)',
                r'SIFIN.*[Rr]eferee.*[Ii]nvitation.*[Mm]anuscript\s+(M\d+)',
            ],
            'reminder': [
                r'SIFIN\s+(M\d+)\s+--\s+.*[Oo]verdue',
                r'SIFIN\s+(M\d+)\s+-\s+[Ff]ollow-up.*[Mm]essage',
                r'SIFIN\s+(M\d+)\s+--\s+.*[Rr]eview.*[Tt]hree-[Mm]onth.*[Mm]ark',
                r'SIFIN\s+(M\d+)\s+--\s+.*[Rr]eview.*[Rr]equested.*[Oo]verdue',
                r'SIFIN\s+(M\d+)\s+--\s+.*[Rr]eminder',
                r'SIFIN\s+(M\d+)\s+-\s+.*[Rr]eminder',
            ],
            'submission': [
                r'SIFIN.*[Rr]eport.*[Rr]eceived.*[Mm]anuscript\s+(M\d+)',
                r'SIFIN\s+(M\d+).*[Rr]eport.*[Rr]eceived',
                r'SIAM.*[Ff]inancial.*[Mm]athematics.*[Mm]anuscript\s+#(M\d+).*[Rr]eport.*[Rr]eceived',
                # Enhanced patterns for referee name capture
                r'([A-Z][a-z]+(?:\s+[A-Z][a-z]*)*\s+[A-Z][a-z]+)\s+has\s+submitted\s+a\s+report',
                r'([A-Z][a-z]+(?:\s+[A-Z][a-z]*)*\s+[A-Z][a-z]+)\s+has\s+submitted\s+(?:a\s+)?(?:referee\s+)?report',
            ],
            'acceptance': [
                r'SIFIN.*[Rr]eferee\s+(accepted|agreed).*[Mm]anuscript\s+(M\d+)',
                r'SIFIN\s+(M\d+).*[Rr]eferee\s+(accepted|agreed)',
                r'([A-Z][a-z]+(?:\s+[A-Z][a-z]*)*\s+[A-Z][a-z]+)\s+has\s+accepted\s+to\s+review',
                r'([A-Z][a-z]+(?:\s+[A-Z][a-z]*)*\s+[A-Z][a-z]+)\s+has\s+agreed\s+to\s+review',
            ],
            'decline': [
                r'SIFIN.*[Rr]eferee\s+(declined|refused).*[Mm]anuscript\s+(M\d+)',
                r'SIFIN\s+(M\d+).*[Rr]eferee\s+(declined|refused)',
                r'([A-Z][a-z]+(?:\s+[A-Z][a-z]*)*\s+[A-Z][a-z]+)\s+has\s+declined\s+to\s+review',
                r'([A-Z][a-z]+(?:\s+[A-Z][a-z]*)*\s+[A-Z][a-z]+)\s+(?:is\s+)?unable\s+to\s+review',
            ]
        }
        
        # Add SIFIN patterns to generic tracker
        for event_type, patterns in sifin_patterns.items():
            self.referee_tracker.pattern_matcher.patterns[event_type].extend(patterns)
    
    def convert_sifin_email_to_generic(self, gmail_message: Dict) -> Optional[EmailEvent]:
        """Convert SIFIN Gmail message to generic EmailEvent"""
        try:
            # Extract headers
            headers = {}
            payload = gmail_message.get('payload', {})
            
            for header in payload.get('headers', []):
                name = header.get('name', '').lower()
                if name in ['subject', 'from', 'to', 'date', 'cc', 'bcc']:
                    headers[name] = header.get('value', '')
            
            # Extract body
            body = self._extract_email_body(payload)
            
            # Parse addresses
            to_addresses = self._parse_email_addresses(headers.get('to', ''))
            cc_addresses = self._parse_email_addresses(headers.get('cc', ''))
            
            # Parse date
            date_str = headers.get('date', '')
            try:
                from email.utils import parsedate_to_datetime
                email_date = parsedate_to_datetime(date_str)
                if email_date.tzinfo is None:
                    email_date = email_date.replace(tzinfo=timezone.utc)
            except:
                email_date = datetime.now(timezone.utc)
            
            # Extract manuscript ID
            manuscript_id = self._extract_manuscript_id(headers.get('subject', ''), body)
            
            if not manuscript_id:
                return None
            
            # Create EmailEvent
            return EmailEvent(
                message_id=gmail_message.get('id', ''),
                thread_id=gmail_message.get('threadId', ''),
                date=email_date,
                subject=headers.get('subject', ''),
                from_address=headers.get('from', ''),
                to_addresses=to_addresses,
                cc_addresses=cc_addresses,
                body=body,
                event_type='unknown',  # Will be determined by pattern matcher
                manuscript_id=manuscript_id
            )
            
        except Exception as e:
            print(f"Error converting email: {e}")
            return None
    
    def _extract_email_body(self, payload: Dict) -> str:
        """Extract body text from email payload"""
        body = ""
        
        def extract_text_recursive(part):
            nonlocal body
            if 'parts' in part:
                for subpart in part['parts']:
                    extract_text_recursive(subpart)
            elif part.get('mimeType') == 'text/plain':
                data = part.get('body', {}).get('data', '')
                if data:
                    import base64
                    try:
                        decoded = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                        body += decoded + "\n"
                    except:
                        pass
        
        extract_text_recursive(payload)
        return body
    
    def _parse_email_addresses(self, address_string: str) -> List[str]:
        """Parse email addresses from header string"""
        if not address_string:
            return []
        
        import re
        # Simple regex to extract email addresses
        emails = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', address_string)
        return emails
    
    def _extract_manuscript_id(self, subject: str, body: str) -> Optional[str]:
        """Extract manuscript ID from subject or body"""
        text = f"{subject} {body}"
        
        # SIFIN patterns for manuscript ID
        patterns = [
            r'SIFIN\s+(M\d+)',
            r'[Mm]anuscript\s+#?(M\d+)',
            r'(M\d{6})',  # 6-digit manuscript IDs
            r'(M\d{5})',  # 5-digit manuscript IDs
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1)
        
        return None
    
    def process_sifin_emails(self, manuscript_ids: List[str]) -> Dict:
        """Process SIFIN emails using the generic tracker"""
        if not self.sifin_parser:
            print("SIFIN parser not available")
            return {}
        
        print(f"🔍 Processing SIFIN emails for manuscripts: {manuscript_ids}")
        
        # Setup Gmail service
        if not self.sifin_parser.setup_gmail_service():
            print("❌ Failed to setup Gmail service")
            return {}
        
        # Fetch emails
        all_emails = []
        for manuscript_id in manuscript_ids:
            emails = self._fetch_manuscript_emails(manuscript_id)
            all_emails.extend(emails)
        
        print(f"📧 Found {len(all_emails)} emails total")
        
        # Convert to generic format and process
        processed_emails = []
        for gmail_msg in all_emails:
            email_event = self.convert_sifin_email_to_generic(gmail_msg)
            if email_event:
                # Process with generic tracker
                processed_email = self.referee_tracker.process_email(email_event)
                processed_emails.append(processed_email)
        
        # Finalize processing
        self.referee_tracker.finalize_processing()
        
        print(f"✅ Processed {len(processed_emails)} emails")
        
        # Generate analytics for each manuscript
        results = {}
        for manuscript_id in manuscript_ids:
            analytics = self.referee_tracker.generate_analytics(manuscript_id)
            timeline = self.referee_tracker.get_referee_timeline(manuscript_id)
            
            results[manuscript_id] = {
                'analytics': analytics,
                'timeline': timeline,
                'attribution_stats': self._calculate_attribution_stats(timeline)
            }
        
        return results
    
    def _fetch_manuscript_emails(self, manuscript_id: str) -> List[Dict]:
        """Fetch emails for a specific manuscript"""
        queries = [
            f'from:sifin.siam.org {manuscript_id}',
            f'subject:SIFIN {manuscript_id}',
            f'subject:"{manuscript_id}"',
        ]
        
        all_emails = []
        seen_ids = set()
        
        for query in queries:
            try:
                response = self.sifin_parser.gmail_service.users().messages().list(
                    userId='me',
                    q=query,
                    maxResults=50
                ).execute()
                
                messages = response.get('messages', [])
                
                for msg in messages:
                    if msg['id'] in seen_ids:
                        continue
                    seen_ids.add(msg['id'])
                    
                    full_msg = self.sifin_parser.gmail_service.users().messages().get(
                        userId='me',
                        id=msg['id'],
                        format='full'
                    ).execute()
                    
                    all_emails.append(full_msg)
                    
            except Exception as e:
                print(f"Error with query '{query}': {e}")
        
        return all_emails
    
    def _calculate_attribution_stats(self, timeline: Dict) -> Dict:
        """Calculate attribution statistics"""
        total_emails = sum(len(emails) for emails in timeline.values())
        attributed_emails = sum(
            len([e for e in emails if e.attribution]) 
            for emails in timeline.values()
        )
        
        return {
            'total_emails': total_emails,
            'attributed_emails': attributed_emails,
            'attribution_rate': attributed_emails / total_emails if total_emails > 0 else 0.0,
            'referee_coverage': len(timeline)
        }
    
    def generate_enhanced_report(self, results: Dict) -> str:
        """Generate enhanced report with referee attribution"""
        report = []
        report.append("📊 SIFIN Enhanced Referee Attribution Report")
        report.append("=" * 60)
        
        for manuscript_id, data in results.items():
            analytics = data['analytics']
            timeline = data['timeline']
            stats = data['attribution_stats']
            
            report.append(f"\n📄 Manuscript {manuscript_id}")
            report.append(f"   Timeline Coverage: {analytics['timeline_coverage']:.1%}")
            report.append(f"   Attribution Rate: {stats['attribution_rate']:.1%}")
            report.append(f"   Referees Identified: {stats['referee_coverage']}")
            report.append(f"   Total Emails: {stats['total_emails']}")
            report.append("")
            
            # Referee-specific details
            for referee_id, referee_data in analytics['referees'].items():
                report.append(f"   👤 {referee_data['name']} ({referee_data['email']})")
                report.append(f"      State: {referee_data['state']}")
                report.append(f"      Timeline Events: {referee_data['timeline_events']}")
                
                if referee_data['invitation_date']:
                    report.append(f"      📨 Invited: {referee_data['invitation_date']}")
                if referee_data['response_date']:
                    report.append(f"      📧 Response: {referee_data['response_date']}")
                if referee_data['submission_date']:
                    report.append(f"      📝 Submitted: {referee_data['submission_date']}")
                if referee_data['reminder_count'] > 0:
                    report.append(f"      🔔 Reminders: {referee_data['reminder_count']}")
                
                report.append("")
        
        return "\n".join(report)
    
    def save_results(self, results: Dict, filename: str = None) -> str:
        """Save results to JSON file"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"sifin_enhanced_attribution_{timestamp}.json"
        
        # Convert to serializable format
        serializable_results = {}
        for manuscript_id, data in results.items():
            # Convert EmailEvent objects to dicts
            timeline_data = {}
            for referee_id, emails in data['timeline'].items():
                timeline_data[referee_id] = []
                for email in emails:
                    email_dict = {
                        'message_id': email.message_id,
                        'date': email.date.isoformat(),
                        'subject': email.subject,
                        'event_type': email.event_type,
                        'attribution': {
                            'referee_id': email.attribution.referee_id,
                            'confidence': email.attribution.confidence,
                            'evidence': email.attribution.evidence,
                            'method': email.attribution.attribution_method
                        } if email.attribution else None
                    }
                    timeline_data[referee_id].append(email_dict)
            
            serializable_results[manuscript_id] = {
                'analytics': data['analytics'],
                'timeline': timeline_data,
                'attribution_stats': data['attribution_stats']
            }
        
        with open(filename, 'w') as f:
            json.dump(serializable_results, f, indent=2)
        
        print(f"📄 Enhanced attribution results saved to: {filename}")
        return filename

def main():
    """Test the SIFIN adapter with generic referee tracker"""
    adapter = SIFINAdapter()
    
    # Test with known SIFIN manuscript IDs
    manuscript_ids = ["M174160", "M174727", "M175988", "M176140"]
    
    print("🚀 Testing SIFIN Adapter with Generic Referee Tracker")
    print("=" * 60)
    
    # Process emails
    results = adapter.process_sifin_emails(manuscript_ids)
    
    if results:
        # Generate report
        report = adapter.generate_enhanced_report(results)
        print(report)
        
        # Save results
        filename = adapter.save_results(results)
        
        print(f"\n🎉 SIFIN Enhanced Attribution Complete!")
        print(f"📊 Results saved to: {filename}")
        
    else:
        print("❌ No results generated")

if __name__ == "__main__":
    main()