#!/usr/bin/env python3
"""
Auto-generated file migration script.
Generated: 2025-07-20T04:19:21.260936
"""

import os
import shutil
from pathlib import Path

# Migration data
MIGRATIONS = [
    {
        "source": "TEST_RESULTS_ANALYSIS.md",
        "destination": "docs/reference/",
        "size": 7712,
        "type": ".md"
    },
    {
        "source": "sifin_gmail_debug_M147228_20250717_093253.json",
        "destination": "data/exports/legacy/",
        "size": 18989,
        "type": ".json"
    },
    {
        "source": "sifin_extraction_20250716_181436.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "sifin_debug_page.html",
        "destination": "data/debug/",
        "size": 30528,
        "type": ".html"
    },
    {
        "source": "mor_post_login.html",
        "destination": "data/debug/",
        "size": 203011,
        "type": ".html"
    },
    {
        "source": "ULTRATHINK_REFACTORING_PLAN.md",
        "destination": "docs/reference/",
        "size": 15848,
        "type": ".md"
    },
    {
        "source": "sifin_firefox_20250717_000735.json",
        "destination": "data/exports/legacy/",
        "size": 12958,
        "type": ".json"
    },
    {
        "source": "IMPLEMENTATION_AUDIT_SUMMARY.md",
        "destination": "docs/reference/",
        "size": 4387,
        "type": ".md"
    },
    {
        "source": "SICON_SIFIN_VERIFICATION_REPORT.md",
        "destination": "docs/reference/",
        "size": 4433,
        "type": ".md"
    },
    {
        "source": "sifin_firefox_20250717_005218.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "sifin_extraction_20250716_232130.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "sicon_extraction_20250716_234739.json",
        "destination": "data/exports/legacy/",
        "size": 17238,
        "type": ".json"
    },
    {
        "source": "sicon_extraction_20250716_233443.json",
        "destination": "data/exports/legacy/",
        "size": 17237,
        "type": ".json"
    },
    {
        "source": "sifin_enhanced_timeline_20250717_131623.json",
        "destination": "data/exports/legacy/",
        "size": 24178,
        "type": ".json"
    },
    {
        "source": "mor_after_login.html",
        "destination": "data/debug/",
        "size": 208580,
        "type": ".html"
    },
    {
        "source": "sifin_email_timeline_20250717_130703.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "sifin_firefox_20250717_091706.json",
        "destination": "data/exports/legacy/",
        "size": 24508,
        "type": ".json"
    },
    {
        "source": "sifin_email_timeline_20250717_121935.json",
        "destination": "data/exports/legacy/",
        "size": 1424,
        "type": ".json"
    },
    {
        "source": "sifin_firefox_20250717_005310.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "sifin_extraction_20250716_181708.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "sifin_email_timeline_20250717_120559.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "sifin_firefox_20250717_094617.json",
        "destination": "data/exports/legacy/",
        "size": 14112,
        "type": ".json"
    },
    {
        "source": "mf_login_debug.html",
        "destination": "data/debug/",
        "size": 39,
        "type": ".html"
    },
    {
        "source": "sifin_firefox_20250717_091326.json",
        "destination": "data/exports/legacy/",
        "size": 14140,
        "type": ".json"
    },
    {
        "source": "sifin_firefox_20250717_080433.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "complete_mf_everything_20250719_200156.json",
        "destination": "data/exports/legacy/",
        "size": 4693,
        "type": ".json"
    },
    {
        "source": "sifin_email_timeline_20250717_131210.json",
        "destination": "data/exports/legacy/",
        "size": 2122,
        "type": ".json"
    },
    {
        "source": "mf_ae_dashboard.html",
        "destination": "data/debug/",
        "size": 225633,
        "type": ".html"
    },
    {
        "source": "mf_verification_page.html",
        "destination": "data/debug/",
        "size": 204638,
        "type": ".html"
    },
    {
        "source": "sifin_firefox_20250717_082843.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "manuscript_details_page.html",
        "destination": "data/debug/",
        "size": 437492,
        "type": ".html"
    },
    {
        "source": "sifin_manuscript_analysis_20250717_092431.json",
        "destination": "data/exports/legacy/",
        "size": 2356,
        "type": ".json"
    },
    {
        "source": "mor_after_submit.html",
        "destination": "data/debug/",
        "size": 200988,
        "type": ".html"
    },
    {
        "source": "mf_debug_page.html",
        "destination": "data/debug/",
        "size": 213189,
        "type": ".html"
    },
    {
        "source": "ULTRATHINK_SOLUTION_SUMMARY.md",
        "destination": "docs/reference/",
        "size": 7180,
        "type": ".md"
    },
    {
        "source": "mf_login_page.html",
        "destination": "data/debug/",
        "size": 213239,
        "type": ".html"
    },
    {
        "source": "sicon_extraction_20250716_235712.json",
        "destination": "data/exports/legacy/",
        "size": 17235,
        "type": ".json"
    },
    {
        "source": "sifin_firefox_20250717_080127.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "mf_initial_page.html",
        "destination": "data/debug/",
        "size": 213009,
        "type": ".html"
    },
    {
        "source": "sifin_email_timeline_20250717_130907.json",
        "destination": "data/exports/legacy/",
        "size": 1424,
        "type": ".json"
    },
    {
        "source": "sifin_email_timeline_20250717_120854.json",
        "destination": "data/exports/legacy/",
        "size": 1424,
        "type": ".json"
    },
    {
        "source": "EXECUTIVE_ACTION_PLAN.md",
        "destination": "docs/reference/",
        "size": 5898,
        "type": ".md"
    },
    {
        "source": "mor_login_page.html",
        "destination": "data/debug/",
        "size": 37217,
        "type": ".html"
    },
    {
        "source": "sifin_firefox_20250717_090112.json",
        "destination": "data/exports/legacy/",
        "size": 22743,
        "type": ".json"
    },
    {
        "source": "sifin_firefox_20250717_094413.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "mor_debug_page.html",
        "destination": "data/debug/",
        "size": 202123,
        "type": ".html"
    },
    {
        "source": "mf_2fa_page.html",
        "destination": "data/debug/",
        "size": 203879,
        "type": ".html"
    },
    {
        "source": "MF_TAKE_ACTION_WORKING_SUMMARY.md",
        "destination": "docs/reference/",
        "size": 1876,
        "type": ".md"
    },
    {
        "source": "mor_ae_dashboard.html",
        "destination": "data/debug/",
        "size": 228650,
        "type": ".html"
    },
    {
        "source": "sifin_enhanced_timeline_20250717_121451.json",
        "destination": "data/exports/legacy/",
        "size": 21850,
        "type": ".json"
    },
    {
        "source": "mor_2fa_page.html",
        "destination": "data/debug/",
        "size": 200988,
        "type": ".html"
    },
    {
        "source": "COMPREHENSIVE_AUDIT_AND_CONTINUATION_SUMMARY.md",
        "destination": "docs/reference/",
        "size": 10265,
        "type": ".md"
    },
    {
        "source": "sifin_gmail_solution_20250717_092615.json",
        "destination": "data/exports/legacy/",
        "size": 4472,
        "type": ".json"
    },
    {
        "source": "mf_after_submit.html",
        "destination": "data/debug/",
        "size": 203879,
        "type": ".html"
    },
    {
        "source": "debug_before_click_MAFI-2025-0166.html",
        "destination": "data/debug/",
        "size": 215602,
        "type": ".html"
    },
    {
        "source": "PROJECT_ROOT_OPTIMIZATION_ANALYSIS.md",
        "destination": "docs/reference/",
        "size": 22718,
        "type": ".md"
    },
    {
        "source": "simple_mf_data_20250719_183952.json",
        "destination": "data/exports/legacy/",
        "size": 1584,
        "type": ".json"
    },
    {
        "source": "journal_implementation_report_20250717_225553.json",
        "destination": "data/exports/legacy/",
        "size": 5984,
        "type": ".json"
    },
    {
        "source": "debug_take_action_MAFI-2025-0166.html",
        "destination": "data/debug/",
        "size": 212001,
        "type": ".html"
    },
    {
        "source": "MF_PARSING_IMPROVEMENTS_SUMMARY.md",
        "destination": "docs/reference/",
        "size": 4702,
        "type": ".md"
    },
    {
        "source": "sifin_firefox_20250717_093942.json",
        "destination": "data/exports/legacy/",
        "size": 24664,
        "type": ".json"
    },
    {
        "source": "sifin_enhanced_timeline_20250717_131315.json",
        "destination": "data/exports/legacy/",
        "size": 23038,
        "type": ".json"
    },
    {
        "source": "debug_take_action_MAFI-2024-0167.html",
        "destination": "data/debug/",
        "size": 212003,
        "type": ".html"
    },
    {
        "source": "real_mf_extraction_summary.json",
        "destination": "data/exports/legacy/",
        "size": 1657,
        "type": ".json"
    },
    {
        "source": "take_action_test_page.html",
        "destination": "data/debug/",
        "size": 213278,
        "type": ".html"
    },
    {
        "source": "sifin_firefox_20250717_083630.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "sifin_firefox_20250717_005036.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "mf_robust_results_20250719_100829.json",
        "destination": "data/exports/legacy/",
        "size": 105,
        "type": ".json"
    },
    {
        "source": "sifin_extraction_20250716_181157.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "SESSION_COMPLETE_ULTRATHINK_SUMMARY.md",
        "destination": "docs/reference/",
        "size": 8304,
        "type": ".md"
    },
    {
        "source": "fixed_mf_data_20250719_192659.json",
        "destination": "data/exports/legacy/",
        "size": 1230,
        "type": ".json"
    },
    {
        "source": "mf_after_login.html",
        "destination": "data/debug/",
        "size": 207130,
        "type": ".html"
    },
    {
        "source": "sifin_firefox_20250717_083332.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "sifin_firefox_20250717_091026.json",
        "destination": "data/exports/legacy/",
        "size": 14075,
        "type": ".json"
    },
    {
        "source": "debug_2fa_failed.html",
        "destination": "data/debug/",
        "size": 204141,
        "type": ".html"
    },
    {
        "source": "mf_post_login.html",
        "destination": "data/debug/",
        "size": 206144,
        "type": ".html"
    },
    {
        "source": "sifin_extraction_20250716_234224.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "mf_improved_parsing_results_20250719_182737.json",
        "destination": "data/exports/legacy/",
        "size": 1576390,
        "type": ".json"
    },
    {
        "source": "sifin_email_timeline_20250717_120648.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "sifin_firefox_20250717_085907.json",
        "destination": "data/exports/legacy/",
        "size": 22742,
        "type": ".json"
    },
    {
        "source": "SIFIN_GMAIL_SEARCH_DEBUG_REPORT.md",
        "destination": "docs/reference/",
        "size": 6173,
        "type": ".md"
    },
    {
        "source": "sifin_firefox_20250717_084245.json",
        "destination": "data/exports/legacy/",
        "size": 22736,
        "type": ".json"
    },
    {
        "source": "sifin_gmail_debug_M147228_20250717_092302.json",
        "destination": "data/exports/legacy/",
        "size": 18989,
        "type": ".json"
    },
    {
        "source": "sifin_firefox_20250717_004850.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    },
    {
        "source": "sifin_firefox_20250717_083851.json",
        "destination": "data/exports/legacy/",
        "size": 2,
        "type": ".json"
    }
]

def migrate_files():
    """Execute file migrations."""
    project_root = Path(__file__).parent.parent.parent
    
    success_count = 0
    error_count = 0
    
    print("Starting file migration...")
    print("-" * 50)
    
    for migration in MIGRATIONS:
        src = project_root / migration['source']
        dst_dir = project_root / migration['destination']
        dst = dst_dir / src.name
        
        try:
            # Ensure destination directory exists
            dst_dir.mkdir(parents=True, exist_ok=True)
            
            # Move file
            shutil.move(str(src), str(dst))
            print(f"✅ Moved: {migration['source']} → {migration['destination']}")
            success_count += 1
        except Exception as e:
            print(f"❌ Failed: {migration['source']}: {e}")
            error_count += 1
    
    print("-" * 50)
    print(f"Migration complete: {success_count} success, {error_count} errors")
    
    return error_count == 0

if __name__ == "__main__":
    import sys
    success = migrate_files()
    sys.exit(0 if success else 1)
