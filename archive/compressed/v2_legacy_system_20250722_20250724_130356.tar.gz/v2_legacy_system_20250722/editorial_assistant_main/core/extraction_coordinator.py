#!/usr/bin/env python3
"""
Extraction Coordinator - Unified interface for all journal extractors.

This module provides the single entry point for all editorial extraction operations,
coordinating between different platforms and providing unified data access.

Phase 3: System Integration - Unified Extraction Coordinator
"""

from typing import Dict, List, Optional, Any, Union
from datetime import datetime
from dataclasses import dataclass
from enum import Enum
import logging

from .platform_extractor import PlatformExtractor, PlatformType
from ..core.exceptions import ConfigurationError, ExtractionError
from ..core.unified_config import get_config_manager
from .browser_pool import get_browser_pool
from .extraction_cache import get_extraction_cache
from .parallel_extraction import get_parallel_engine, ExtractionTask


class ExtractionMode(Enum):
    """Extraction modes for different use cases."""
    FULL = "full"                    # Complete extraction with all data
    MANUSCRIPTS_ONLY = "manuscripts" # Only manuscript metadata
    REFEREES_ONLY = "referees"       # Only referee information
    QUICK = "quick"                  # Minimal extraction for testing
    TIMELINE_ENHANCED = "timeline"   # Include email timeline integration


@dataclass
class ExtractionRequest:
    """Request specification for extraction operations."""
    
    # Target specification
    journal_codes: List[str]                    # Journals to extract from
    extraction_mode: ExtractionMode = ExtractionMode.FULL
    
    # Filtering options
    manuscript_limit: Optional[int] = None      # Max manuscripts per journal
    category_filter: Optional[List[str]] = None # Specific categories
    date_filter: Optional[Dict[str, str]] = None # Date range filtering
    
    # Feature flags
    enable_timeline: bool = False               # Enable timeline integration
    enable_caching: bool = True                 # Enable result caching
    enable_validation: bool = True              # Enable data validation
    
    # Output options
    output_format: str = "dict"                 # dict, json, csv
    include_raw_data: bool = False              # Include platform-specific data
    
    # Authentication
    credentials: Dict[str, Any] = None          # Platform credentials
    
    def __post_init__(self):
        """Initialize default values."""
        if self.credentials is None:
            self.credentials = {}


@dataclass
class ExtractionResult:
    """Result of extraction operations."""
    
    # Metadata
    request_id: str
    journal_codes: List[str]
    extraction_timestamp: datetime
    extraction_mode: ExtractionMode
    
    # Data
    manuscripts: List[Dict[str, Any]]
    referees: List[Dict[str, Any]]
    
    # Summary statistics
    summary: Dict[str, Any]
    
    # Status information
    success: bool
    errors: List[str] = None
    warnings: List[str] = None
    
    # Performance metrics
    execution_time: float = 0.0
    manuscripts_extracted: int = 0
    referees_extracted: int = 0
    
    def __post_init__(self):
        """Initialize default values."""
        if self.errors is None:
            self.errors = []
        if self.warnings is None:
            self.warnings = []
        
        # Update counts
        self.manuscripts_extracted = len(self.manuscripts)
        self.referees_extracted = len(self.referees)


class ExtractionCoordinator:
    """
    Unified coordinator for all journal extraction operations.
    
    This class provides a single interface for extracting data from all supported
    journal platforms, handling authentication, coordination, and result aggregation.
    """
    
    def __init__(self):
        """Initialize the extraction coordinator."""
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Registry of available extractors
        self._extractor_registry = {}
        self._platform_registry = {}
        
        # Coordinator configuration
        config_manager = get_config_manager()
        self.enable_parallel_extraction = config_manager.is_feature_enabled('parallel_extraction') if config_manager else False
        self.enable_result_caching = config_manager.is_feature_enabled('result_caching') if config_manager else True
        self.enable_performance_monitoring = config_manager.is_feature_enabled('performance_monitoring') if config_manager else True
        
        # Performance tracking
        self._extraction_history = []
        self._performance_metrics = {}
        
        # Performance optimization components
        self.cache = get_extraction_cache() if self.enable_result_caching else None
        self.browser_pool = get_browser_pool()
        
        # Journal priorities for parallel execution
        self._journal_priorities = {
            'MF': 10,    # Highest priority
            'MOR': 9,
            'SICON': 8,
            'SIFIN': 7
        }
        
        # Initialize extractor registry
        self._initialize_extractors()
        
        self.logger.info("Extraction Coordinator initialized - "
                        f"Registered extractors: {list(self._extractor_registry.keys())}")
    
    def _initialize_extractors(self):
        """Initialize and register all available extractors."""
        
        # Register consolidated extractors
        extractor_map = {
            'MF': ('editorial_assistant.extractors.mf_extractor', 'MFExtractor'),
            'MOR': ('editorial_assistant.extractors.mor_extractor', 'MORExtractor'),
            'SICON': ('editorial_assistant.extractors.sicon_consolidated', 'SICONConsolidatedExtractor'),
            'SIFIN': ('editorial_assistant.extractors.sifin_consolidated', 'SIFINConsolidatedExtractor')
        }
        
        for journal_code, (module_path, class_name) in extractor_map.items():
            try:
                # Register extractor info
                self._extractor_registry[journal_code] = {
                    'module_path': module_path,
                    'class_name': class_name,
                    'platform_type': self._get_platform_type(journal_code),
                    'available': True
                }
                
                self.logger.debug(f"Registered extractor for {journal_code}")
                
            except Exception as e:
                self.logger.warning(f"Failed to register extractor for {journal_code}: {e}")
                self._extractor_registry[journal_code] = {
                    'available': False,
                    'error': str(e)
                }
    
    def _get_platform_type(self, journal_code: str) -> PlatformType:
        """Determine platform type for a journal code."""
        platform_map = {
            'MF': PlatformType.SCHOLARONE,
            'MOR': PlatformType.SCHOLARONE,
            'SICON': PlatformType.SIAM,
            'SIFIN': PlatformType.SIAM
        }
        
        return platform_map.get(journal_code, PlatformType.UNKNOWN)
    
    def get_available_journals(self) -> List[str]:
        """Get list of available journal codes."""
        return [code for code, info in self._extractor_registry.items() if info.get('available', False)]
    
    def get_platform_info(self, journal_code: str) -> Dict[str, Any]:
        """Get platform information for a journal."""
        if journal_code not in self._extractor_registry:
            raise ConfigurationError(f"Unknown journal code: {journal_code}")
        
        info = self._extractor_registry[journal_code].copy()
        info['journal_code'] = journal_code
        return info
    
    def extract_data(self, request: ExtractionRequest) -> ExtractionResult:
        """
        Execute extraction request across specified journals.
        
        Args:
            request: ExtractionRequest specifying what to extract
            
        Returns:
            ExtractionResult: Aggregated results from all journals
        """
        start_time = datetime.now()
        request_id = f"req_{start_time.strftime('%Y%m%d_%H%M%S')}"
        
        self.logger.info(f"Starting extraction request {request_id} for journals: {request.journal_codes}")
        
        # Initialize result
        result = ExtractionResult(
            request_id=request_id,
            journal_codes=request.journal_codes,
            extraction_timestamp=start_time,
            extraction_mode=request.extraction_mode,
            manuscripts=[],
            referees=[],
            summary={}
        )
        
        try:
            # Validate request
            self._validate_request(request)
            
            # Execute extraction for each journal
            if self.enable_parallel_extraction and len(request.journal_codes) > 1:
                # Parallel extraction (future implementation)
                journal_results = self._extract_parallel(request)
            else:
                # Sequential extraction
                journal_results = self._extract_sequential(request)
            
            # Aggregate results
            self._aggregate_results(result, journal_results)
            
            # Post-processing
            if request.enable_validation:
                self._validate_results(result)
            
            # Calculate performance metrics
            end_time = datetime.now()
            result.execution_time = (end_time - start_time).total_seconds()
            result.success = True
            
            self.logger.info(f"Extraction request {request_id} completed successfully - "
                           f"{result.manuscripts_extracted} manuscripts, {result.referees_extracted} referees")
            
        except Exception as e:
            result.success = False
            result.errors.append(f"Extraction failed: {e}")
            self.logger.error(f"Extraction request {request_id} failed: {e}")
        
        # Update performance tracking
        if self.enable_performance_monitoring:
            self._update_performance_metrics(request, result)
        
        return result
    
    def _validate_request(self, request: ExtractionRequest):
        """Validate extraction request parameters."""
        
        # Check journal codes
        unknown_journals = [j for j in request.journal_codes if j not in self._extractor_registry]
        if unknown_journals:
            raise ConfigurationError(f"Unknown journal codes: {unknown_journals}")
        
        # Check availability
        unavailable_journals = [j for j in request.journal_codes 
                               if not self._extractor_registry[j].get('available', False)]
        if unavailable_journals:
            raise ConfigurationError(f"Unavailable journals: {unavailable_journals}")
        
        # Validate parameters
        if request.manuscript_limit is not None and request.manuscript_limit < 1:
            raise ConfigurationError("Manuscript limit must be positive")
    
    def _extract_sequential(self, request: ExtractionRequest) -> Dict[str, Dict[str, Any]]:
        """Execute sequential extraction for all journals."""
        
        results = {}
        
        for journal_code in request.journal_codes:
            try:
                self.logger.info(f"Extracting data from {journal_code}")
                
                # Create extractor instance
                extractor = self._create_extractor(journal_code)
                
                # Execute extraction based on mode
                journal_result = self._extract_from_journal(extractor, request)
                results[journal_code] = journal_result
                
                # Cleanup
                extractor.cleanup()
                
                self.logger.info(f"Completed extraction from {journal_code}")
                
            except Exception as e:
                self.logger.error(f"Failed to extract from {journal_code}: {e}")
                results[journal_code] = {
                    'success': False,
                    'error': str(e),
                    'manuscripts': [],
                    'referees': []
                }
        
        return results
    
    def _extract_parallel(self, request: ExtractionRequest) -> Dict[str, Dict[str, Any]]:
        """Execute parallel extraction for all journals."""
        self.logger.info(f"Starting parallel extraction for {len(request.journal_codes)} journals")
        
        # Get parallel engine
        engine = get_parallel_engine()
        
        # Create tasks for each journal
        tasks = []
        for journal_code in request.journal_codes:
            if journal_code not in self._extractor_registry:
                self.logger.warning(f"No extractor registered for {journal_code}")
                continue
            
            # Create extractor instance
            try:
                extractor = self._create_extractor(journal_code)
            except Exception as e:
                self.logger.error(f"Failed to create extractor for {journal_code}: {e}")
                continue
            
            # Prepare extraction parameters
            extraction_params = self._prepare_extraction_params(request)
            
            # Create task
            task = ExtractionTask(
                task_id=f"{request.request_id}_{journal_code}",
                journal_code=journal_code,
                extractor=extractor,
                extraction_params=extraction_params,
                extraction_mode=request.extraction_mode.value,  # Convert enum to string
                priority=self._get_journal_priority(journal_code)
            )
            tasks.append(task)
        
        # Execute tasks in parallel
        task_results = engine.execute_parallel(tasks)
        
        # Convert task results to expected format
        results = {}
        for task_id, task_result in task_results.items():
            journal_code = task_result.journal_code
            
            if task_result.success:
                results[journal_code] = task_result.data
            else:
                results[journal_code] = {
                    'success': False,
                    'error': task_result.error,
                    'manuscripts': [],
                    'referees': []
                }
        
        return results
    
    def _get_journal_priority(self, journal_code: str) -> int:
        """Get priority for a journal (higher number = higher priority)."""
        return self._journal_priorities.get(journal_code, 5)
    
    def _create_extractor(self, journal_code: str) -> PlatformExtractor:
        """Create an extractor instance for the specified journal."""
        
        extractor_info = self._extractor_registry[journal_code]
        
        try:
            # Dynamic import of extractor class
            import importlib
            module = importlib.import_module(extractor_info['module_path'])
            extractor_class = getattr(module, extractor_info['class_name'])
            
            # Create instance
            extractor = extractor_class(journal_code)
            
            return extractor
            
        except Exception as e:
            raise ExtractionError(f"Failed to create extractor for {journal_code}: {e}") from e
    
    def _extract_from_journal(self, extractor: PlatformExtractor, request: ExtractionRequest) -> Dict[str, Any]:
        """Extract data from a single journal using the specified extractor."""
        
        try:
            # Prepare extraction parameters
            extraction_params = {
                'credentials': request.credentials.get(extractor.journal_code, {}),
                'manuscript_filters': {
                    'limit': request.manuscript_limit,
                    'categories': request.category_filter
                }
            }
            
            # Execute based on extraction mode
            if request.extraction_mode == ExtractionMode.FULL:
                result = extractor.extract_all_data(**extraction_params)
                
            elif request.extraction_mode == ExtractionMode.MANUSCRIPTS_ONLY:
                extractor.authenticate(**extraction_params['credentials'])
                manuscripts = extractor.extract_manuscripts(**extraction_params['manuscript_filters'])
                result = {
                    'manuscripts': [extractor._manuscript_to_dict(m) for m in manuscripts],
                    'referees': []
                }
                
            elif request.extraction_mode == ExtractionMode.QUICK:
                # Quick mode - limited extraction for testing
                extraction_params['manuscript_filters']['limit'] = min(
                    request.manuscript_limit or 5, 5
                )
                result = extractor.extract_all_data(**extraction_params)
                
            else:
                raise ConfigurationError(f"Unsupported extraction mode: {request.extraction_mode}")
            
            result['success'] = True
            return result
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'manuscripts': [],
                'referees': []
            }
    
    def _aggregate_results(self, result: ExtractionResult, journal_results: Dict[str, Dict[str, Any]]):
        """Aggregate results from all journals into unified result."""
        
        total_manuscripts = 0
        total_referees = 0
        successful_journals = []
        failed_journals = []
        
        for journal_code, journal_result in journal_results.items():
            if journal_result.get('success', False):
                # Add manuscripts
                manuscripts = journal_result.get('manuscripts', [])
                result.manuscripts.extend(manuscripts)
                total_manuscripts += len(manuscripts)
                
                # Add referees
                referees = journal_result.get('referees', [])
                result.referees.extend(referees)
                total_referees += len(referees)
                
                successful_journals.append(journal_code)
                
            else:
                error = journal_result.get('error', 'Unknown error')
                result.errors.append(f"{journal_code}: {error}")
                failed_journals.append(journal_code)
        
        # Build summary
        result.summary = {
            'successful_journals': successful_journals,
            'failed_journals': failed_journals,
            'total_manuscripts': total_manuscripts,
            'total_referees': total_referees,
            'unique_referees': len(set(r.get('email', '') for r in result.referees if r.get('email'))),
            'journals_processed': len(journal_results),
            'success_rate': len(successful_journals) / len(journal_results) if journal_results else 0
        }
    
    def _validate_results(self, result: ExtractionResult):
        """Validate extraction results for consistency and completeness."""
        
        # Basic validation
        if not result.manuscripts and not result.referees:
            result.warnings.append("No data extracted from any journal")
        
        # Data consistency checks
        manuscript_ids = set(m.get('manuscript_id', '') for m in result.manuscripts)
        referee_manuscript_ids = set(r.get('manuscript_id', '') for r in result.referees)
        
        orphaned_referees = referee_manuscript_ids - manuscript_ids
        if orphaned_referees:
            result.warnings.append(f"Found referees for unknown manuscripts: {len(orphaned_referees)} orphaned")
    
    def _update_performance_metrics(self, request: ExtractionRequest, result: ExtractionResult):
        """Update performance tracking metrics."""
        
        metrics = {
            'timestamp': result.extraction_timestamp,
            'journals': request.journal_codes,
            'mode': request.extraction_mode.value,
            'execution_time': result.execution_time,
            'manuscripts_extracted': result.manuscripts_extracted,
            'referees_extracted': result.referees_extracted,
            'success': result.success,
            'success_rate': result.summary.get('success_rate', 0)
        }
        
        self._extraction_history.append(metrics)
        
        # Keep only recent history (last 100 extractions)
        if len(self._extraction_history) > 100:
            self._extraction_history = self._extraction_history[-100:]
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get performance summary from extraction history."""
        
        if not self._extraction_history:
            return {'message': 'No extraction history available'}
        
        recent_extractions = self._extraction_history[-20:]  # Last 20
        
        total_time = sum(e['execution_time'] for e in recent_extractions)
        avg_time = total_time / len(recent_extractions)
        
        total_manuscripts = sum(e['manuscripts_extracted'] for e in recent_extractions)
        total_referees = sum(e['referees_extracted'] for e in recent_extractions)
        
        success_rate = sum(1 for e in recent_extractions if e['success']) / len(recent_extractions)
        
        return {
            'recent_extractions': len(recent_extractions),
            'average_execution_time': avg_time,
            'total_manuscripts_extracted': total_manuscripts,
            'total_referees_extracted': total_referees,
            'success_rate': success_rate,
            'available_journals': self.get_available_journals()
        }


# Convenience functions for backward compatibility
def extract_all_journals(**kwargs) -> ExtractionResult:
    """Extract data from all available journals."""
    coordinator = ExtractionCoordinator()
    
    request = ExtractionRequest(
        journal_codes=coordinator.get_available_journals(),
        **kwargs
    )
    
    return coordinator.extract_data(request)


def extract_journal(journal_code: str, **kwargs) -> ExtractionResult:
    """Extract data from a specific journal."""
    coordinator = ExtractionCoordinator()
    
    request = ExtractionRequest(
        journal_codes=[journal_code],
        **kwargs
    )
    
    return coordinator.extract_data(request)