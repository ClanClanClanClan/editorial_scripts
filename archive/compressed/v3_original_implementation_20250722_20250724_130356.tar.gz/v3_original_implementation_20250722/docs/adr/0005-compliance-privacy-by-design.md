# ADR-0005: Compliance and Privacy by Design

## Status
Accepted

## Context
Editorial Scripts v3.0 processes personal data of researchers, editors, and reviewers across EU and international jurisdictions. The system handles:
- Author personal details, affiliations, and ORCID identifiers
- Editor and reviewer personal information and decisions
- Manuscript content with potential personal references
- Peer review data with attribution and confidentiality requirements
- Communication records and behavioral analytics

The v3.0 specifications mandate compliance with:
- **GDPR** (EU General Data Protection Regulation 2016/679)
- **EU AI Act** (Regulation 2024/1689) for AI risk management
- **SLSA-3** for supply chain security
- **WCAG 2.2 AA** for accessibility

Regulatory violations carry severe penalties (up to 4% global revenue) and reputational damage in academic communities.

## Decision
We will implement **Privacy by Design** and **Compliance by Design** as architectural principles with the following strategy:

### 1. GDPR Compliance Architecture

#### Data Minimization and Purpose Limitation
```python
# Domain model with lawful basis tracking
class PersonalData(Entity):
    value: Any
    lawful_basis: LawfulBasis  # consent, contract, legitimate_interest, etc.
    purpose: Purpose           # submission_processing, peer_review, etc.
    retention_until: datetime
    processing_activity: ProcessingActivity
```

#### Data Subject Rights Implementation
```python
# DSAR (Data Subject Access Request) API
@dataclass
class DSARRequest:
    data_subject_email: str
    request_type: DSARType  # access, rectification, erasure, portability
    verification_token: str
    requested_at: datetime

# Automated right to be forgotten
class PersonalDataEraser:
    async def cascade_delete(self, data_subject_id: UUID) -> EraseResult:
        # Soft delete with anonymization cascade
        # Preserve aggregate statistics while removing PII
```

#### Row-Level Security by Journal/Organization
```sql
-- Multi-tenant data isolation
ALTER TABLE manuscript ENABLE ROW LEVEL SECURITY;
CREATE POLICY journal_isolation ON manuscript
    FOR ALL TO application
    USING (journal_id = current_setting('app.current_journal_id')::uuid);

-- Editor access control  
CREATE POLICY editor_manuscript_access ON manuscript
    FOR ALL TO editor_role
    USING (
        journal_id IN (
            SELECT journal_id FROM editor_assignment 
            WHERE editor_id = current_user_id()
        )
    );
```

#### Pseudonymization and Anonymization
```python
# Reversible pseudonymization for analytics
class PseudonymizationService:
    def pseudonymize(self, pii: str, context: str) -> str:
        # HMAC-based, deterministic within context
        return hmac.new(self._key, f"{context}:{pii}", sha256).hexdigest()
    
    def anonymize_for_retention(self, entity: Entity) -> Entity:
        # Irreversible anonymization for long-term storage
        return entity.replace_pii_with_synthetic()
```

### 2. EU AI Act Compliance (High-Risk AI Systems)

#### AI Risk Classification and Management
```python
@dataclass
class AISystemRisk:
    system_id: str
    risk_level: RiskLevel  # MINIMAL, LIMITED, HIGH, UNACCEPTABLE
    impact_assessment: ImpactAssessment
    mitigation_measures: List[MitigationMeasure]
    human_oversight_level: HumanOversightLevel
    
# High-risk systems: reviewer recommendations, acceptance predictions
class HighRiskAISystem:
    def __init__(self):
        self.risk_management_system = RiskManagementSystem()
        self.quality_management_system = QualityManagementSystem()
        self.human_oversight = HumanOversightSystem()
```

#### Algorithmic Transparency and Explainability
```python
# Explainable AI for editorial decisions
class DecisionExplanation:
    prediction: float
    confidence_interval: Tuple[float, float]
    feature_importance: Dict[str, float]
    similar_cases: List[ManuscriptId]
    human_review_trigger: bool
    
def explain_reviewer_recommendation(manuscript: Manuscript) -> DecisionExplanation:
    # SHAP/LIME explanations for reviewer matching algorithm
    # Must be understandable to editors without ML background
```

#### Bias Monitoring and Fairness
```python
# Automated bias detection
class FairnessMonitor:
    async def check_equal_opportunity(self, predictions: List[Prediction]) -> FairnessReport:
        # Monitor for gender, geographic, seniority bias
        # Δ equal-opportunity < 5pp across protected characteristics
        
    async def drift_detection(self) -> DriftAlert:
        # Nightly statistical tests for model degradation
        # Alert if fairness metrics degrade beyond threshold
```

### 3. Data Governance and Audit Trail

#### Comprehensive Audit Logging
```python
@dataclass 
class AuditEvent:
    event_id: UUID
    timestamp: datetime
    actor: ActorId  # user, system, api_key
    action: AuditAction  # CREATE, READ, UPDATE, DELETE, EXPORT
    resource_type: str
    resource_id: Optional[str]
    lawful_basis: Optional[LawfulBasis]
    data_subject_id: Optional[UUID]
    ip_address: Optional[str]
    user_agent: Optional[str]
    
# Immutable audit trail in separate database
class AuditService:
    async def log_data_access(self, access: DataAccess) -> None:
        # Every PII access logged with lawful basis
        # Tamper-evident logging with cryptographic checksums
```

#### Data Processing Register
```yaml
# GDPR Article 30 - Records of Processing Activities
processing_activities:
  - name: "Manuscript Submission Processing"
    controller: "Editorial Scripts Ltd"
    lawful_basis: "contract"  # Article 6(1)(b)
    categories_of_data: ["contact_details", "academic_affiliations"]
    retention_period: "7_years_after_publication"
    international_transfers: false
    
  - name: "Peer Review Matching"
    controller: "Editorial Scripts Ltd" 
    lawful_basis: "legitimate_interests"  # Article 6(1)(f)
    legitimate_interests_assessment: "LIA-2024-001"
    categories_of_data: ["research_expertise", "publication_history"]
```

### 4. Technical Implementation

#### Database Schema for Compliance
```sql
-- Lawful basis tracking at column level
CREATE TABLE manuscript_author (
    author_id UUID,
    name TEXT NOT NULL,
    name_lawful_basis lawful_basis_enum NOT NULL,
    email CITEXT,
    email_lawful_basis lawful_basis_enum,
    consent_timestamp TIMESTAMPTZ,
    consent_version TEXT,
    retention_until TIMESTAMPTZ NOT NULL
);

-- Soft delete with anonymization
CREATE TABLE deleted_personal_data (
    original_table TEXT NOT NULL,
    original_id UUID NOT NULL, 
    deletion_reason deletion_reason_enum NOT NULL,
    deleted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    anonymized_data JSONB  -- statistical summary only
);
```

#### API Design for Privacy
```python
# Privacy-first API design
class ManuscriptAPI:
    @require_lawful_basis(LawfulBasis.CONTRACT)
    @audit_data_access(ResourceType.MANUSCRIPT)
    @rate_limit_per_data_subject(requests=10, period=3600)
    async def get_manuscript(
        self, 
        manuscript_id: UUID,
        requesting_user: User
    ) -> PrivacyFilteredManuscript:
        # Automatic PII filtering based on role and purpose
```

#### Consent Management
```python
class ConsentService:
    async def record_consent(
        self, 
        data_subject: DataSubject,
        purposes: List[Purpose],
        consent_mechanism: ConsentMechanism  # explicit, implicit, contract
    ) -> ConsentRecord:
        # Granular consent with versioning and withdrawal support
        
    async def withdraw_consent(self, data_subject: DataSubject, purpose: Purpose):
        # Cascade consent withdrawal to all dependent processing
```

## Consequences

### Positive
- **Legal compliance** - Avoids regulatory fines and sanctions
- **Trust and reputation** - Academic community confidence
- **Global market access** - Compliance enables worldwide deployment  
- **Data quality** - Privacy by design improves data governance
- **Competitive advantage** - Privacy as a differentiator
- **Future-proof** - Prepared for emerging regulations

### Negative
- **Development complexity** - Additional layers and validations
- **Performance overhead** - Audit logging, encryption, access controls
- **Operational burden** - DSAR handling, consent management
- **Storage costs** - Audit trails, consent records, backups
- **User friction** - Consent flows, data access restrictions

### Risk Mitigation
- **Legal review** - Regular compliance audits with data protection lawyers
- **Automated testing** - Compliance gates in CI/CD pipeline
- **Staff training** - Privacy awareness for all team members
- **Incident response** - Breach notification procedures and templates
- **Vendor assessment** - Third-party processors must meet same standards

### Monitoring and Compliance Gates

#### CI/CD Compliance Checks
```bash
# Automated compliance verification
pytest tests/compliance/test_gdpr_compliance.py
pytest tests/compliance/test_ai_act_compliance.py
bandit -r src/ --severity-level medium  # Privacy-related security
```

#### Runtime Monitoring
```python
# Compliance metrics in production
gdpr_consent_rate = Gauge('gdpr_consent_rate_percent', 'Percentage of users with valid consent')
dsar_response_time = Histogram('dsar_response_time_hours', 'Time to fulfill data subject requests')
ai_fairness_score = Gauge('ai_fairness_equal_opportunity', 'Equal opportunity score across demographics')
```

## Implementation Phases

**Phase 1 (Weeks 3-6):** Core GDPR compliance - lawful basis, audit trail, RLS
**Phase 2 (Weeks 46-48):** Full GDPR implementation - DSAR API, retention policies  
**Phase 3 (Weeks 46-48):** EU AI Act compliance - risk management, explainability
**Phase 4 (Ongoing):** Compliance monitoring and continuous improvement

## References
- [GDPR Official Text](https://eur-lex.europa.eu/eli/reg/2016/679/oj)
- [EU AI Act Official Text](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32024R1689)
- [Privacy by Design Principles](https://www.ipc.on.ca/wp-content/uploads/Resources/7foundationalprinciples.pdf)
- [EDPB Guidelines on Consent](https://edpb.europa.eu/our-work-tools/our-documents/guidelines/guidelines-052020-consent-under-regulation-2016679_en)
- [ISO 27001 Privacy Controls](https://www.iso.org/standard/54534.html)