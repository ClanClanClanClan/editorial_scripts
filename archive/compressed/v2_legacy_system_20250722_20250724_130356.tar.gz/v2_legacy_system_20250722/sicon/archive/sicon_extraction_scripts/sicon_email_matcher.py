#!/usr/bin/env python3
"""
SICON-specific email matcher for referee timeline
To be integrated with core/email_utils.py
"""

import re
from datetime import datetime
from typing import Dict, List, Optional, Tuple

def robust_match_email_for_referee_sicon(ref_name: str, ms_id: str, status: str, 
                                       flagged_emails: List[Dict], 
                                       starred_emails: List[Dict] = None) -> Tuple[Optional[Dict], Optional[Dict]]:
    """
    SICON-specific email matching for referee timeline data
    
    Args:
        ref_name: Referee name (e.g., "Samuel Daudin")
        ms_id: Manuscript ID (e.g., "M172838")
        status: Referee status (accepted/declined)
        flagged_emails: List of flagged emails
        starred_emails: List of starred emails (optional)
        
    Returns:
        Tuple of (acceptance_email_info, contact_email_info)
        Each info dict contains: {'date': str, 'to': str, 'subject': str, 'body': str}
    """
    # Combine all emails
    all_emails = list(flagged_emails)
    if starred_emails:
        all_emails.extend(starred_emails)
    
    # Normalize referee name for matching
    ref_name_lower = ref_name.lower().strip()
    ref_parts = ref_name_lower.split()
    last_name = ref_parts[-1] if ref_parts else ""
    first_name = ref_parts[0] if ref_parts else ""
    
    # Remove any # suffix from name (e.g., "Samuel daudin #1" -> "Samuel daudin")
    if '#' in ref_name_lower:
        ref_name_lower = re.sub(r'\s*#\d+', '', ref_name_lower).strip()
    
    # Initialize results
    invitation_email = None
    response_email = None
    best_invitation_score = 0
    best_response_score = 0
    
    for email in all_emails:
        subject = email.get('subject', '').lower()
        body = email.get('body', '').lower()
        to_field = email.get('to', '').lower()
        
        # Check if this email is about the right manuscript
        if ms_id.lower() not in subject and ms_id.lower() not in body[:1000]:
            continue
        
        # Score this email
        score = 0
        
        # Name matching
        if ref_name_lower in to_field:
            score += 20
        elif last_name in to_field:
            score += 15
            if first_name and first_name in to_field:
                score += 5
        elif last_name in body[:500]:  # Check early in body (e.g., "Dear Dr. Daudin")
            score += 10
        
        # Check for invitation patterns
        invitation_patterns = [
            'referee invitation',
            'invitation to review',
            'invited to review',
            'review invitation',
            'would you be willing to review',
            'invite you to serve as a referee',
            'request you to review'
        ]
        
        is_invitation = any(pattern in subject or pattern in body[:500] for pattern in invitation_patterns)
        
        # Check for response patterns
        response_patterns = [
            'accepted to review',
            'declined to review',
            'agreed to review',
            'willing to review',
            'unable to review',
            'cannot review',
            'referee response'
        ]
        
        is_response = any(pattern in subject or pattern in body[:500] for pattern in response_patterns)
        
        # SICON-specific patterns
        if 'sicon:' in subject:
            score += 10
        
        # Assign to appropriate category
        if is_invitation and score > best_invitation_score:
            best_invitation_score = score
            invitation_email = email
        elif is_response and score > best_response_score:
            best_response_score = score
            response_email = email
    
    # Convert to info format
    invitation_info = _extract_email_info(invitation_email, ref_name) if invitation_email else None
    response_info = _extract_email_info(response_email, ref_name) if response_email else None
    
    # For SICON, we return (acceptance_info, contact_info)
    # where contact_info is the invitation email
    return response_info, invitation_info


def _extract_email_info(email: Dict, ref_name: str) -> Dict:
    """Extract standardized email info from email dict"""
    if not email:
        return None
    
    # Extract referee email from 'to' field
    to_field = email.get('to', '')
    referee_email = ''
    
    # Try to extract email address
    email_match = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', to_field)
    if email_match:
        referee_email = email_match.group(0)
    
    # Parse date to standard format
    date_str = email.get('date', '')
    try:
        # Try to parse various date formats
        if 'T' in date_str:  # ISO format
            parsed_date = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
        else:
            # Try other common formats
            for fmt in ['%a, %d %b %Y %H:%M:%S %z', '%Y-%m-%d %H:%M:%S']:
                try:
                    parsed_date = datetime.strptime(date_str, fmt)
                    break
                except:
                    continue
            else:
                parsed_date = None
        
        if parsed_date:
            date_str = parsed_date.isoformat()
    except:
        pass  # Keep original date string
    
    return {
        'date': date_str,
        'to': referee_email,
        'subject': email.get('subject', ''),
        'body': email.get('body', '')[:500] + '...' if len(email.get('body', '')) > 500 else email.get('body', '')
    }


def find_sicon_referee_emails(referee_name: str, manuscript_id: str, 
                            all_emails: List[Dict]) -> Dict[str, List[Dict]]:
    """
    Find all SICON emails related to a specific referee and manuscript
    
    Returns dict with lists of categorized emails:
    - invitations: Initial invitation emails
    - responses: Accept/decline emails  
    - reminders: Reminder emails
    - reports: Report submission emails
    """
    results = {
        'invitations': [],
        'responses': [],
        'reminders': [],
        'reports': []
    }
    
    # Normalize search terms
    name_lower = referee_name.lower().strip()
    if '#' in name_lower:
        name_lower = re.sub(r'\s*#\d+', '', name_lower).strip()
    
    name_parts = name_lower.split()
    last_name = name_parts[-1] if name_parts else ""
    
    for email in all_emails:
        subject = email.get('subject', '').lower()
        body = email.get('body', '').lower()
        to_field = email.get('to', '').lower()
        
        # Must be about this manuscript
        if manuscript_id.lower() not in subject and manuscript_id.lower() not in body[:1000]:
            continue
        
        # Must be related to this referee
        is_referee_email = (
            name_lower in to_field or
            last_name in to_field or
            last_name in body[:500] or
            name_lower in body[:500]
        )
        
        if not is_referee_email:
            continue
        
        # Categorize email
        if any(kw in subject or kw in body[:500] for kw in 
               ['invitation', 'invite', 'request to review', 'invited to review']):
            results['invitations'].append(email)
        elif any(kw in subject or kw in body[:500] for kw in 
                ['accepted', 'declined', 'agreed', 'unable', 'cannot review']):
            results['responses'].append(email)
        elif any(kw in subject or kw in body[:500] for kw in 
                ['reminder', 'overdue', 'follow-up', 'pending review']):
            results['reminders'].append(email)
        elif any(kw in subject or kw in body[:500] for kw in 
                ['report submitted', 'review submitted', 'completed review']):
            results['reports'].append(email)
    
    return results


# For testing and integration
if __name__ == "__main__":
    # Test the matcher
    test_email = {
        'subject': 'SICON: Referee invitation for manuscript M172838',
        'body': 'Dear Dr. Daudin, You are invited to review...',
        'to': '"Samuel Daudin" <samuel.daudin@university.edu>',
        'date': '2025-02-01T10:00:00Z'
    }
    
    # Test extraction
    acceptance, contact = robust_match_email_for_referee_sicon(
        "Samuel daudin #1", 
        "M172838",
        "accepted",
        [test_email]
    )
    
    print("Contact email:", contact)
    print("Acceptance email:", acceptance)