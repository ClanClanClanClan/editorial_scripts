#!/usr/bin/env python3
"""
Test script to verify that Take Action clicking is now working for ScholarOne journals.
"""

import sys
import os
import logging
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from editorial_assistant.extractors.scholarone import ScholarOneExtractor
from editorial_assistant.utils.browser_manager import BrowserManager

def test_take_action_clicking(journal_code='MF'):
    """Test Take Action clicking for a ScholarOne journal."""
    
    # Set up logging to see detailed output
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print(f"\n🧪 Testing Take Action clicking for {journal_code}...")
    print("=" * 60)
    
    # Create browser manager
    browser_manager = BrowserManager()
    driver = browser_manager.create_driver()
    
    try:
        # Create extractor
        extractor = ScholarOneExtractor(
            journal_code=journal_code,
            driver=driver,
            output_dir=Path('test_output')
        )
        
        # Login
        print(f"\n📝 Logging into {journal_code}...")
        extractor._login()
        print("✅ Login successful!")
        
        # Navigate to manuscripts
        print(f"\n📂 Navigating to manuscripts...")
        extractor._navigate_to_manuscripts()
        
        # Check if manuscripts were found
        if extractor.found_manuscripts:
            print(f"\n✅ Found {len(extractor.found_manuscripts)} manuscripts!")
            
            # Try processing the first manuscript
            if len(extractor.found_manuscripts) > 0:
                first_ms = extractor.found_manuscripts[0]
                print(f"\n🔍 Testing Take Action for manuscript: {first_ms['id']}")
                print(f"   Title: {first_ms.get('title', 'N/A')}")
                print(f"   Category URL stored: {'Yes' if first_ms.get('category_url') else 'No'}")
                
                # Extract manuscripts (which will process them)
                manuscripts = extractor._extract_manuscripts()
                
                if manuscripts and len(manuscripts) > 0:
                    print(f"\n✅ Successfully processed {len(manuscripts)} manuscripts!")
                    print("\n🎉 Take Action clicking is working properly!")
                else:
                    print("\n❌ No manuscripts were processed successfully")
            else:
                print("\n⚠️  No manuscripts found to test")
        else:
            print("\n⚠️  No manuscripts found in any category")
            
    except Exception as e:
        print(f"\n❌ Error during test: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Clean up
        print("\n🧹 Cleaning up...")
        driver.quit()
        print("✅ Test complete!")


if __name__ == "__main__":
    # Get journal code from command line or use default
    journal_code = sys.argv[1] if len(sys.argv) > 1 else 'MF'
    
    # Check for required environment variables
    email_var = f'{journal_code}_EMAIL'
    password_var = f'{journal_code}_PASSWORD'
    
    if not os.getenv(email_var) or not os.getenv(password_var):
        print(f"❌ Error: Missing credentials!")
        print(f"   Please set {email_var} and {password_var} environment variables")
        sys.exit(1)
    
    test_take_action_clicking(journal_code)