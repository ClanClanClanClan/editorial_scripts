# ADR-0003: PostgreSQL with Extensions Strategy

## Status
Accepted

## Context
Editorial Scripts v3.0 requires a robust, scalable database system with advanced capabilities for:
- UUID generation with timestamp ordering
- Full-text search across manuscripts and reviews  
- Vector similarity for author matching and manuscript classification
- Row-level security for multi-tenant compliance
- ACID transactions for data integrity

The v3.0 specifications mandate:
- PostgreSQL 16 as the primary database
- Specific extensions: pg_uuidv7, pgvector, pg_trgm
- UUIDv7 primary keys for all entities
- Performance targets: p95 response ≤ 30s
- Multi-tenant row-level security

Alternative databases (MySQL, MongoDB, etc.) lack the extension ecosystem and advanced features required.

## Decision
We will use **PostgreSQL 16** with the following essential extensions:

### 1. Core Extensions
```sql
CREATE EXTENSION IF NOT EXISTS "pgcrypto";      -- secure random generation
CREATE EXTENSION IF NOT EXISTS "pg_uuidv7";    -- timestamp-ordered UUIDs  
CREATE EXTENSION IF NOT EXISTS "citext";       -- case-insensitive text
CREATE EXTENSION IF NOT EXISTS "pg_trgm";      -- trigram similarity search
CREATE EXTENSION IF NOT EXISTS "vector";       -- pgvector for embeddings
```

### 2. Primary Key Strategy: UUIDv7
```sql
CREATE TABLE manuscript (
    manuscript_id UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
    -- timestamp-ordered, globally unique, sortable
);
```

**Benefits of UUIDv7:**
- **Timestamp ordering** - Natural chronological sort
- **Global uniqueness** - No ID conflicts across instances  
- **Performance** - Better index locality than UUID4
- **Future-proof** - Supports distributed systems

### 3. Full-Text Search: pg_trgm
```sql
CREATE INDEX manuscript_title_trgm ON manuscript USING GIN (title gin_trgm_ops);
-- Fuzzy matching, typo tolerance, multi-language support
```

### 4. Vector Similarity: pgvector
```sql
CREATE TABLE manuscript_embedding (
    manuscript_id UUID REFERENCES manuscript(manuscript_id),
    embedding vector(384),  -- sentence-transformers dimension
    created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX ON manuscript_embedding USING ivfflat (embedding vector_cosine_ops);
```

**Use cases:**
- Author-manuscript matching based on expertise
- Duplicate manuscript detection
- Reviewer recommendation by topic similarity
- Classification into journal categories

### 5. Row-Level Security (RLS)
```sql
ALTER TABLE manuscript ENABLE ROW LEVEL SECURITY;
CREATE POLICY manuscript_journal_isolation ON manuscript
    FOR ALL TO application
    USING (journal_id = current_setting('app.current_journal_id')::uuid);
```

## Implementation Strategy

### Extension Availability Checks
```python
async def verify_extensions():
    required = ['pg_uuidv7', 'vector', 'pg_trgm', 'citext']
    for ext in required:
        result = await conn.fetchval("SELECT 1 FROM pg_extension WHERE extname = $1", ext)
        if not result:
            raise DatabaseError(f"Required extension {ext} not available")
```

### Fallback for pg_uuidv7
```sql
-- Fallback if pg_uuidv7 not available (flagged by CI)
CREATE OR REPLACE FUNCTION uuid_generate_v7() RETURNS uuid AS $$
SELECT gen_random_uuid();  -- Not timestamp-ordered, but functional
$$ LANGUAGE SQL;
```

### Database Migrations
- Version-controlled SQL migrations in `migrations/`
- Extension installation in initial migration
- Index creation with `CONCURRENTLY` for zero-downtime
- Rollback procedures for each migration

## Performance Considerations

### Index Strategy
```sql
-- Core performance indexes
CREATE INDEX CONCURRENTLY manuscript_journal_created ON manuscript(journal_id, created_at);
CREATE INDEX CONCURRENTLY manuscript_status_idx ON manuscript(status) WHERE status != 'PUBLISHED';
CREATE INDEX CONCURRENTLY review_manuscript_idx ON review(manuscript_id) WHERE status = 'PENDING';
```

### Connection Pooling
- PgBouncer for connection multiplexing
- Separate pools for read/write operations
- Transaction-level pooling for short-lived connections

### Monitoring
- pg_stat_statements for query performance
- pg_stat_user_tables for table access patterns
- Custom metrics for UUIDv7 generation rate

## Consequences

### Positive
- **Rich functionality** - Advanced search, similarity, security
- **Performance** - Optimized for complex queries and large datasets  
- **Scalability** - Proven at enterprise scale
- **Compliance** - Built-in RLS for data isolation
- **Ecosystem** - Extensive tooling and monitoring
- **Future-proof** - UUIDv7 supports distributed architectures

### Negative
- **Complexity** - Multiple extensions to manage
- **Deployment overhead** - Must ensure extensions available
- **Vendor lock-in** - PostgreSQL-specific features
- **Memory usage** - Vector indexes consume significant RAM
- **Migration complexity** - Extension dependencies in migrations

### Risk Mitigation
- **Extension availability** - CI checks for required extensions
- **Cloud provider support** - Verify pgvector availability on RDS/CloudSQL
- **Fallback procedures** - Graceful degradation if extensions missing
- **Performance monitoring** - Early detection of slow queries
- **Backup strategy** - pg_dump includes extension dependencies

### Failure Scenarios
1. **Missing pg_uuidv7** - Use gen_random_uuid() fallback (detected by CI)
2. **pgvector unavailable** - Disable similarity features, log warning
3. **RLS performance** - Monitor and optimize policy queries
4. **Index bloat** - Automated reindexing procedures

## Dependencies
- PostgreSQL 16+ (required for JSON improvements)
- pg_uuidv7 extension (custom build if not available)
- pgvector (requires compilation with PostgreSQL headers)
- Sufficient shared_preload_libraries configuration

## References
- [PostgreSQL Extensions](https://www.postgresql.org/docs/16/external-extensions.html)
- [UUIDv7 Specification](https://datatracker.ietf.org/doc/draft-peabody-dispatch-new-uuid-format/)
- [pgvector Documentation](https://github.com/pgvector/pgvector)
- [PostgreSQL Row Level Security](https://www.postgresql.org/docs/16/ddl-rowsecurity.html)
- [pg_trgm Documentation](https://www.postgresql.org/docs/16/pgtrgm.html)