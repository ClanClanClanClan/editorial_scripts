#!/usr/bin/env python3
"""
Comprehensive integration tests for all consolidated extractors.
Tests MF, MOR, SICON, and SIFIN consolidated extractors.
"""

import unittest
import sys
import logging
from pathlib import Path
from unittest.mock import Mock, patch

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

# Configure logging for tests
logging.basicConfig(level=logging.WARNING)  # Reduce noise during testing


class TestConsolidatedExtractors(unittest.TestCase):
    """Test all consolidated extractors for functionality and consistency."""
    
    def setUp(self):
        """Set up test environment."""
        self.test_results = {}
    
    def tearDown(self):
        """Clean up after tests."""
        pass
    
    def test_mf_extractor_initialization(self):
        """Test MF consolidated extractor initialization."""
        from editorial_assistant.extractors.mf_extractor import MFExtractor
        
        extractor = MFExtractor()
        
        # Test basic properties
        self.assertEqual(extractor.journal_url, "https://mc.manuscriptcentral.com/mafi")
        self.assertEqual(len(extractor.categories), 6)  # MF has 6 categories
        self.assertEqual(extractor.popup_wait_time, 6)
        self.assertEqual(extractor.page_navigation_wait, 5)
        
        # Test methods exist
        self.assertTrue(hasattr(extractor, 'login'))
        self.assertTrue(hasattr(extractor, 'extract_all_data'))
        self.assertTrue(hasattr(extractor, 'navigate_to_ae_center'))
        
        # Test feature flags are disabled by default
        self.assertFalse(extractor.use_config_system)
        self.assertFalse(extractor.use_navigation_module)
        self.assertFalse(extractor.use_enhanced_timeline)
    
    def test_mor_extractor_initialization(self):
        """Test MOR consolidated extractor initialization."""
        from editorial_assistant.extractors.mor_extractor import MORExtractor
        
        extractor = MORExtractor()
        
        # Test basic properties
        self.assertEqual(extractor.journal_url, "https://mc.manuscriptcentral.com/mor")
        self.assertEqual(len(extractor.categories), 7)  # MOR has 7 categories (vs MF's 6)
        self.assertEqual(extractor.popup_wait_time, 6)
        self.assertEqual(extractor.page_navigation_wait, 5)
        
        # Test methods exist
        self.assertTrue(hasattr(extractor, 'login'))
        self.assertTrue(hasattr(extractor, 'extract_all_data'))
        self.assertTrue(hasattr(extractor, 'navigate_to_ae_center'))
        
        # Test feature flags are disabled by default
        self.assertFalse(extractor.use_config_system)
        self.assertFalse(extractor.use_navigation_module)
        self.assertFalse(extractor.use_enhanced_timeline)
    
    def test_sicon_extractor_initialization(self):
        """Test SICON consolidated extractor initialization."""
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
        
        extractor = SICONConsolidatedExtractor()
        
        # Test basic properties
        self.assertEqual(extractor.journal_url, "https://sicon.siam.org/cgi-bin/main.plex")
        self.assertEqual(extractor.popup_wait_time, 1)
        self.assertEqual(extractor.page_navigation_wait, 5)
        
        # Test methods exist
        self.assertTrue(hasattr(extractor, '_login'))
        self.assertTrue(hasattr(extractor, 'extract_data'))
        self.assertTrue(hasattr(extractor, '_navigate_to_ae_dashboard'))
        
        # Test feature flags are disabled by default
        self.assertFalse(extractor.use_config_system)
        self.assertFalse(extractor.use_navigation_module)
        self.assertFalse(extractor.use_enhanced_timeline)
    
    def test_sifin_extractor_initialization(self):
        """Test SIFIN consolidated extractor initialization."""
        from editorial_assistant.extractors.sifin_consolidated import SIFINConsolidatedExtractor
        
        extractor = SIFINConsolidatedExtractor()
        
        # Test basic properties
        self.assertEqual(extractor.journal_url, "http://sifin.siam.org/")
        self.assertEqual(extractor.popup_wait_time, 1)
        self.assertEqual(extractor.page_navigation_wait, 5)
        self.assertEqual(extractor.redirect_timeout, 30)
        
        # Test browser requirement
        self.assertEqual(extractor.browser_manager.browser_type, 'firefox')
        
        # Test methods exist
        self.assertTrue(hasattr(extractor, '_login'))
        self.assertTrue(hasattr(extractor, 'extract_data'))
        self.assertTrue(hasattr(extractor, '_remove_cookie_banner'))
        
        # Test feature flags are disabled by default
        self.assertFalse(extractor.use_config_system)
        self.assertFalse(extractor.use_navigation_module)
        self.assertFalse(extractor.use_enhanced_timeline)
    
    def test_backward_compatibility_functions(self):
        """Test all backward compatibility functions exist and work."""
        
        # Test MF backward compatibility
        from editorial_assistant.extractors.mf_extractor import extract_mf_data
        self.assertTrue(callable(extract_mf_data))
        
        # Test MOR backward compatibility
        from editorial_assistant.extractors.mor_extractor import extract_mor_data
        self.assertTrue(callable(extract_mor_data))
        
        # Test SICON backward compatibility
        from editorial_assistant.extractors.sicon_consolidated import extract_sicon_data
        self.assertTrue(callable(extract_sicon_data))
        
        # Test SIFIN backward compatibility
        from editorial_assistant.extractors.sifin_consolidated import extract_sifin_data
        self.assertTrue(callable(extract_sifin_data))
    
    def test_platform_differences_preserved(self):
        """Test that platform-specific differences are preserved."""
        
        # Import all extractors
        from editorial_assistant.extractors.mf_extractor import MFExtractor
        from editorial_assistant.extractors.mor_extractor import MORExtractor
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
        from editorial_assistant.extractors.sifin_consolidated import SIFINConsolidatedExtractor
        
        mf = MFExtractor()
        mor = MORExtractor()
        sicon = SICONConsolidatedExtractor()
        sifin = SIFINConsolidatedExtractor()
        
        # Test MF vs MOR differences (same platform, different journals)
        self.assertEqual(len(mf.categories), 6)  # MF has 6 categories
        self.assertEqual(len(mor.categories), 7)  # MOR has 7 categories
        self.assertIn("mafi", mf.journal_url)     # MF URL
        self.assertIn("mor", mor.journal_url)     # MOR URL
        
        # Test SICON vs SIFIN differences (same platform, different journals)
        self.assertIn("sicon", sicon.journal_url)  # SICON URL
        self.assertIn("sifin", sifin.journal_url)  # SIFIN URL
        self.assertEqual(sifin.browser_manager.browser_type, 'firefox')  # SIFIN requires Firefox
        
        # Test ScholarOne vs SIAM platform differences
        # ScholarOne (MF/MOR) has different method names than SIAM (SICON/SIFIN)
        self.assertTrue(hasattr(mf, 'login'))      # ScholarOne uses 'login'
        self.assertTrue(hasattr(mor, 'login'))     # ScholarOne uses 'login'
        self.assertTrue(hasattr(sicon, '_login'))  # SIAM uses '_login'
        self.assertTrue(hasattr(sifin, '_login'))  # SIAM uses '_login'
    
    def test_configuration_system_integration(self):
        """Test that configuration system is properly integrated."""
        
        from editorial_assistant.core.unified_config import get_config_manager
        config_manager = get_config_manager()
        
        # Test all journal configs load
        for journal in ['MF', 'MOR', 'SICON', 'SIFIN']:
            config = config_manager.get_journal_config(journal)
            self.assertIsNotNone(config, f"{journal} config should load")
            self.assertIsNotNone(config.url, f"{journal} config should have URL")
    
    def test_error_handling(self):
        """Test error handling in all extractors."""
        
        # Test each extractor handles missing config gracefully
        extractors = [
            ('MF', 'editorial_assistant.extractors.mf_extractor', 'MFExtractor'),
            ('MOR', 'editorial_assistant.extractors.mor_extractor', 'MORExtractor'),
            ('SICON', 'editorial_assistant.extractors.sicon_consolidated', 'SICONConsolidatedExtractor'),
            ('SIFIN', 'editorial_assistant.extractors.sifin_consolidated', 'SIFINConsolidatedExtractor')
        ]
        
        for name, module_name, class_name in extractors:
            with self.subTest(extractor=name):
                try:
                    module = __import__(module_name, fromlist=[class_name])
                    extractor_class = getattr(module, class_name)
                    extractor = extractor_class()
                    
                    # Should initialize without errors
                    self.assertIsNotNone(extractor)
                    
                except Exception as e:
                    self.fail(f"{name} extractor failed to initialize: {e}")
    
    def test_method_consistency(self):
        """Test that similar methods exist across platform families."""
        
        from editorial_assistant.extractors.mf_extractor import MFExtractor
        from editorial_assistant.extractors.mor_extractor import MORExtractor
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
        from editorial_assistant.extractors.sifin_consolidated import SIFINConsolidatedExtractor
        
        # ScholarOne extractors should have similar methods
        mf = MFExtractor()
        mor = MORExtractor()
        
        scholarone_methods = ['login', 'extract_all_data', 'navigate_to_ae_center']
        for method in scholarone_methods:
            self.assertTrue(hasattr(mf, method), f"MF missing {method}")
            self.assertTrue(hasattr(mor, method), f"MOR missing {method}")
        
        # SIAM extractors should have similar methods
        sicon = SICONConsolidatedExtractor()
        sifin = SIFINConsolidatedExtractor()
        
        siam_methods = ['_login', 'extract_data', '_navigate_to_ae_dashboard']
        for method in siam_methods:
            self.assertTrue(hasattr(sicon, method), f"SICON missing {method}")
            self.assertTrue(hasattr(sifin, method), f"SIFIN missing {method}")


class TestPerformance(unittest.TestCase):
    """Test performance of consolidated extractors."""
    
    def test_import_performance(self):
        """Test that imports are fast enough."""
        import time
        
        start_time = time.time()
        
        # Import all consolidated extractors
        from editorial_assistant.extractors.mf_extractor import MFExtractor
        from editorial_assistant.extractors.mor_extractor import MORExtractor
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
        from editorial_assistant.extractors.sifin_consolidated import SIFINConsolidatedExtractor
        
        import_time = time.time() - start_time
        
        # Should import in under 2 seconds
        self.assertLess(import_time, 2.0, f"Imports took {import_time:.3f}s, should be < 2.0s")
    
    def test_initialization_performance(self):
        """Test that initialization is fast enough."""
        import time
        
        from editorial_assistant.extractors.mf_extractor import MFExtractor
        from editorial_assistant.extractors.mor_extractor import MORExtractor
        from editorial_assistant.extractors.sicon_consolidated import SICONConsolidatedExtractor
        from editorial_assistant.extractors.sifin_consolidated import SIFINConsolidatedExtractor
        
        extractors = [MFExtractor, MORExtractor, SICONConsolidatedExtractor, SIFINConsolidatedExtractor]
        
        for extractor_class in extractors:
            with self.subTest(extractor=extractor_class.__name__):
                start_time = time.time()
                extractor = extractor_class()
                init_time = time.time() - start_time
                
                # Should initialize in under 1 second
                self.assertLess(init_time, 1.0, 
                    f"{extractor_class.__name__} took {init_time:.3f}s to initialize")


if __name__ == '__main__':
    # Run with verbose output
    unittest.main(verbosity=2)