"""Unit tests for foundation types."""

import pytest

from src.foundation.types import (
    Result,
    validate_email,
    validate_manuscript_id,
    validate_non_empty,
    validate_positive_int,
    validate_url,
)


class TestResult:
    """Test Result type."""

    def test_ok_result(self):
        """Test creating a successful result."""
        result = Result.ok(42)
        assert result.is_ok()
        assert not result.is_err()
        assert result.unwrap() == 42
        assert str(result) == "Ok(42)"

    def test_err_result(self):
        """Test creating an error result."""
        result = Result.err("Something went wrong")
        assert not result.is_ok()
        assert result.is_err()
        assert result.unwrap_err() == "Something went wrong"
        assert str(result) == "Err('Something went wrong')"

    def test_unwrap_error_on_err(self):
        """Test unwrap raises on error result."""
        result = Result.err("Error")
        with pytest.raises(ValueError, match="Called unwrap on an error result"):
            result.unwrap()

    def test_unwrap_err_on_ok(self):
        """Test unwrap_err raises on success result."""
        result = Result.ok(42)
        with pytest.raises(ValueError, match="Called unwrap_err on a success result"):
            result.unwrap_err()

    def test_unwrap_or(self):
        """Test unwrap_or with default value."""
        ok_result = Result.ok(42)
        err_result = Result.err("Error")

        assert ok_result.unwrap_or(0) == 42
        assert err_result.unwrap_or(0) == 0

    def test_map(self):
        """Test mapping over success value."""
        result = Result.ok(10)
        mapped = result.map(lambda x: x * 2)
        assert mapped.is_ok()
        assert mapped.unwrap() == 20

        err_result = Result.err("Error")
        mapped_err = err_result.map(lambda x: x * 2)
        assert mapped_err.is_err()
        assert mapped_err.unwrap_err() == "Error"

    def test_map_err(self):
        """Test mapping over error value."""
        result = Result.err("error")
        mapped = result.map_err(str.upper)
        assert mapped.is_err()
        assert mapped.unwrap_err() == "ERROR"

        ok_result = Result.ok(42)
        mapped_ok = ok_result.map_err(str.upper)
        assert mapped_ok.is_ok()
        assert mapped_ok.unwrap() == 42


class TestValidators:
    """Test custom validators."""

    def test_validate_non_empty(self):
        """Test non-empty string validation."""
        assert validate_non_empty("  hello  ") == "hello"
        assert validate_non_empty("test") == "test"

        with pytest.raises(ValueError, match="String cannot be empty"):
            validate_non_empty("")

        with pytest.raises(ValueError, match="String cannot be empty"):
            validate_non_empty("   ")

    def test_validate_email(self):
        """Test email validation."""
        assert validate_email("TEST@EXAMPLE.COM") == "test@example.com"
        assert validate_email("  user@domain.co.uk  ") == "user@domain.co.uk"
        assert validate_email("user+tag@example.com") == "user+tag@example.com"

        invalid_emails = [
            "notanemail",
            "@example.com",
            "user@",
            "user@.com",
            "user@domain",
            "user space@example.com",
        ]

        for email in invalid_emails:
            with pytest.raises(ValueError, match="Invalid email format"):
                validate_email(email)

    def test_validate_url(self):
        """Test URL validation."""
        valid_urls = [
            "http://example.com",
            "https://example.com",
            "https://www.example.com",
            "https://example.com/path/to/page",
            "https://example.com/path?query=value",
            "https://subdomain.example.com",
        ]

        for url in valid_urls:
            assert validate_url(url) == url.strip()

        invalid_urls = [
            "not a url",
            "ftp://example.com",
            "//example.com",
            "example.com",
            "http://",
        ]

        for url in invalid_urls:
            with pytest.raises(ValueError, match="Invalid URL format"):
                validate_url(url)

    def test_validate_manuscript_id(self):
        """Test manuscript ID validation."""
        valid_ids = [
            "SIAP-2023-0123",
            "MOR-D-23-00456",
            "TEST-2024-000001",
            "AB-2023-1234",
        ]

        for mid in valid_ids:
            assert validate_manuscript_id(mid) == mid.upper()

        # Test case conversion
        assert validate_manuscript_id("siap-2023-0123") == "SIAP-2023-0123"

        invalid_ids = [
            "123456",
            "TOOLONG-2023-0123",
            "AB-23-ABC",
            "AB_2023_0123",
            "",
        ]

        for mid in invalid_ids:
            with pytest.raises(ValueError, match="Invalid manuscript ID format"):
                validate_manuscript_id(mid)

    def test_validate_positive_int(self):
        """Test positive integer validation."""
        assert validate_positive_int(1) == 1
        assert validate_positive_int(100) == 100

        with pytest.raises(ValueError, match="Value must be positive"):
            validate_positive_int(0)

        with pytest.raises(ValueError, match="Value must be positive"):
            validate_positive_int(-1)
