#!/usr/bin/env python3
"""
Fixed version of the Take Action clicking method for ScholarOne extractor.
This can be integrated into the main ScholarOne extractor to fix the clicking issue.
"""

def _click_take_action_for_manuscript_FIXED(self, manuscript_id: str) -> bool:
    """
    Fixed version: Find and click Take Action link for a specific manuscript.
    
    Based on the exact HTML structure:
    - Take Action is in the LAST COLUMN of the table
    - Has an image with src="/images/en_US/icons/check_off.gif"
    - Has rowspan="2"
    - Contains JavaScript to navigate to manuscript details
    """
    try:
        self.logger.info(f"Looking for Take Action link for {manuscript_id}")
        
        # First, find ALL rows in ALL tables (don't filter too early)
        all_rows = self.driver.find_elements(By.TAG_NAME, "tr")
        self.logger.info(f"Found {len(all_rows)} total rows on page")
        
        manuscript_row_found = False
        
        for row_index, row in enumerate(all_rows):
            try:
                # Get row text to check for manuscript ID
                row_text = row.text.strip()
                
                # Skip empty rows
                if not row_text:
                    continue
                
                # Check if this row contains our manuscript ID
                if manuscript_id not in row_text:
                    continue
                
                self.logger.info(f"Found {manuscript_id} in row {row_index}")
                manuscript_row_found = True
                
                # Get all cells in this row
                cells = row.find_elements(By.TAG_NAME, "td")
                if not cells:
                    self.logger.warning(f"No cells found in row {row_index}")
                    continue
                
                self.logger.info(f"Row has {len(cells)} cells")
                
                # THE KEY: Check the LAST cell (Take Action is always in the last column)
                last_cell = cells[-1]
                last_cell_html = last_cell.get_attribute('innerHTML')
                
                self.logger.debug(f"Last cell HTML preview: {last_cell_html[:200]}...")
                
                # Method 1: Look for the check_off.gif image in the last cell
                take_action_imgs = last_cell.find_elements(By.XPATH, ".//img[contains(@src, '/images/en_US/icons/check_off.gif')]")
                
                if take_action_imgs:
                    self.logger.info("✅ Found check_off.gif image in last cell")
                    
                    # Find the parent anchor tag
                    for img in take_action_imgs:
                        try:
                            # Get the parent <a> tag
                            parent_link = img.find_element(By.XPATH, "./ancestor::a[1]")
                            
                            if parent_link:
                                self.logger.info("Found Take Action link (parent of check_off.gif)")
                                
                                # Get href for debugging
                                href = parent_link.get_attribute('href')
                                self.logger.info(f"Take Action href: {href[:150]}...")
                                
                                # Try direct click first
                                try:
                                    parent_link.click()
                                    self._wait_for_page_load()
                                    
                                    # Verify navigation worked
                                    new_url = self.driver.current_url
                                    new_page_text = self.driver.find_element(By.TAG_NAME, "body").text
                                    
                                    if "Manuscript Details" in new_page_text or "Reviewer" in new_page_text:
                                        self.logger.info(f"✅ Successfully clicked Take Action for {manuscript_id}")
                                        return True
                                    else:
                                        self.logger.warning("Click executed but page didn't change as expected")
                                        
                                except Exception as click_e:
                                    self.logger.warning(f"Direct click failed: {click_e}")
                                    
                                    # Fallback: Execute JavaScript
                                    if href and 'javascript:' in href:
                                        js_code = href.replace('javascript:', '')
                                        self.logger.info("Executing JavaScript from href...")
                                        
                                        try:
                                            self.driver.execute_script(js_code)
                                            self._wait_for_page_load()
                                            
                                            # Verify navigation
                                            new_page_text = self.driver.find_element(By.TAG_NAME, "body").text
                                            if "Manuscript Details" in new_page_text or "Reviewer" in new_page_text:
                                                self.logger.info(f"✅ Successfully executed Take Action JavaScript for {manuscript_id}")
                                                return True
                                                
                                        except Exception as js_e:
                                            self.logger.error(f"JavaScript execution failed: {js_e}")
                                            
                        except Exception as e:
                            self.logger.debug(f"Error finding parent link: {e}")
                            continue
                
                # Method 2: Look for any anchor in last cell with ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS
                if not take_action_imgs:  # Only try this if method 1 didn't work
                    detail_links = last_cell.find_elements(By.XPATH, ".//a[contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
                    
                    if detail_links:
                        link = detail_links[0]
                        self.logger.info("Found ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS link in last cell")
                        
                        href = link.get_attribute('href')
                        if href and 'javascript:' in href:
                            js_code = href.replace('javascript:', '')
                            try:
                                self.driver.execute_script(js_code)
                                self._wait_for_page_load()
                                
                                # Verify navigation
                                new_page_text = self.driver.find_element(By.TAG_NAME, "body").text
                                if "Manuscript Details" in new_page_text or "Reviewer" in new_page_text:
                                    self.logger.info(f"✅ Successfully executed manuscript details JavaScript for {manuscript_id}")
                                    return True
                                    
                            except Exception as js_e:
                                self.logger.error(f"JavaScript execution failed: {js_e}")
                                
            except Exception as e:
                self.logger.debug(f"Error processing row {row_index}: {e}")
                continue
        
        # If we found the manuscript but couldn't click Take Action
        if manuscript_row_found:
            self.logger.error(f"❌ Found {manuscript_id} but could not find/click Take Action in last column")
        else:
            self.logger.error(f"❌ Could not find {manuscript_id} in any table row")
        
        # Save debug information
        try:
            debug_file = f"{self.journal.code.lower()}_no_take_action_{manuscript_id}.html"
            with open(debug_file, 'w') as f:
                f.write(self.driver.page_source)
            self.logger.error(f"Saved debug HTML to {debug_file}")
            
            # Also save a screenshot
            screenshot_file = f"{self.journal.code.lower()}_no_take_action_{manuscript_id}.png"
            self.driver.save_screenshot(screenshot_file)
            self.logger.error(f"Saved screenshot to {screenshot_file}")
            
            # Log some diagnostic info
            self.logger.error("Diagnostic info:")
            self.logger.error(f"  Current URL: {self.driver.current_url}")
            self.logger.error(f"  Page title: {self.driver.title}")
            
        except Exception as debug_e:
            self.logger.error(f"Failed to save debug info: {debug_e}")
        
        return False
        
    except Exception as e:
        self.logger.error(f"Error in _click_take_action_for_manuscript: {e}")
        import traceback
        self.logger.error(traceback.format_exc())
        return False


# Also provide a simpler integration test
def test_take_action_integration():
    """Test the fixed Take Action clicking in isolation."""
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    import time
    import re
    
    print("\n=== Testing Fixed Take Action Click ===")
    
    # This would be called from within the ScholarOne extractor
    # after navigating to a category page with manuscripts
    
    # Example usage:
    # 1. Find all manuscript IDs on the page
    # 2. For each ID, call the fixed click method
    # 3. Extract data, then navigate back
    
    print("""
To integrate this fix into ScholarOne extractor:

1. Replace the _click_take_action_for_manuscript method with _click_take_action_for_manuscript_FIXED

2. The key improvements:
   - Focuses on finding Take Action in the LAST COLUMN only
   - Looks specifically for the check_off.gif image
   - Better error handling and debugging output
   - Verifies that navigation actually happened

3. This should resolve the timeout issues by:
   - Being more targeted in searching for the link
   - Not trying too many different approaches
   - Providing clear debug output when it fails
""")


if __name__ == "__main__":
    test_take_action_integration()