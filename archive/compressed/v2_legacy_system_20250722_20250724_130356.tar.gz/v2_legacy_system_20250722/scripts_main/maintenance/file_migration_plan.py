#!/usr/bin/env python3
"""
Generate file migration plan for Phase 1 refactoring.
This script analyzes current files and shows where they should be moved.
"""

import os
import json
from pathlib import Path
from datetime import datetime

def get_migration_rules():
    """Define rules for where files should be moved."""
    return {
        # Debug scripts to scripts/debug
        'debug_*.py': 'scripts/debug/',
        
        # Test files to proper test directories
        'test_mf_*.py': 'tests/integration/',
        'test_mor_*.py': 'tests/integration/',
        'test_sicon_*.py': 'tests/integration/',
        'test_sifin_*.py': 'tests/integration/',
        'test_take_action_*.py': 'tests/integration/',
        'test_referee_*.py': 'tests/integration/',
        'test_gmail_*.py': 'tests/integration/',
        'test_*.py': 'tests/legacy/',  # Other tests to legacy for now
        
        # Quick utilities to scripts/utilities
        'quick_*.py': 'scripts/utilities/',
        'show_*.py': 'scripts/utilities/',
        
        # Extraction scripts to scripts/utilities
        'extract_*.py': 'scripts/utilities/',
        'run_*.py': 'scripts/utilities/',
        
        # Analysis scripts
        'analyze_*.py': 'scripts/utilities/',
        
        # Fix/patch scripts
        'fix_*.py': 'scripts/utilities/',
        'patch_*.py': 'scripts/utilities/',
        
        # Validation scripts
        'validate_*.py': 'scripts/utilities/',
        'verify_*.py': 'scripts/utilities/',
        
        # HTML debug files
        '*.html': 'data/debug/',
        
        # JSON extraction results
        '*_extraction_*.json': 'data/exports/legacy/',
        '*_results_*.json': 'data/exports/legacy/',
        '*_firefox_*.json': 'data/exports/legacy/',
        '*_timeline_*.json': 'data/exports/legacy/',
        '*.json': 'data/exports/legacy/',  # Catch-all for other JSON
        
        # Documentation to proper docs folders
        '*_SUMMARY.md': 'docs/reference/',
        '*_PLAN.md': 'docs/reference/',
        '*_REPORT.md': 'docs/reference/',
        '*_ANALYSIS.md': 'docs/reference/',
        
        # Main extractors (special handling)
        'ultrathink_perfect_mf_final.py': 'KEEP_FOR_NOW',
        'ultrathink_perfect_mor_enhanced.py': 'KEEP_FOR_NOW',
    }

def analyze_files(project_root):
    """Analyze all files in root directory and plan migrations."""
    
    # Get migration rules
    rules = get_migration_rules()
    
    # Files to migrate
    migrations = []
    
    # Files to keep in root
    keep_files = [
        'README.md',
        'Makefile',
        'pyproject.toml',
        'pytest.ini',
        'requirements.txt',
        'alembic.ini',
        '.gitignore',
        'run_extraction.py',  # Main entry point
    ]
    
    # Scan root directory only (not subdirectories)
    for item in project_root.iterdir():
        if item.is_file() and not item.name.startswith('.'):
            # Check if should keep
            if item.name in keep_files:
                continue
            
            # Check if it's a backup
            if 'backup' in item.name or item.suffix == '.gz':
                continue
                
            # Find matching rule
            destination = None
            for pattern, dest in rules.items():
                if pattern.startswith('*') and pattern.endswith('*'):
                    # Contains pattern
                    if pattern[1:-1] in item.name:
                        destination = dest
                        break
                elif pattern.startswith('*'):
                    # Ends with pattern
                    if item.name.endswith(pattern[1:]):
                        destination = dest
                        break
                elif pattern.endswith('*'):
                    # Starts with pattern
                    if item.name.startswith(pattern[:-1]):
                        destination = dest
                        break
                elif item.name == pattern:
                    # Exact match
                    destination = dest
                    break
            
            if destination and destination != 'KEEP_FOR_NOW':
                migrations.append({
                    'source': str(item.relative_to(project_root)),
                    'destination': destination,
                    'size': item.stat().st_size,
                    'type': item.suffix
                })
    
    return migrations

def generate_migration_script(migrations, project_root):
    """Generate the actual migration script."""
    
    script_content = '''#!/usr/bin/env python3
"""
Auto-generated file migration script.
Generated: {timestamp}
"""

import os
import shutil
from pathlib import Path

# Migration data
MIGRATIONS = {migrations}

def migrate_files():
    """Execute file migrations."""
    project_root = Path(__file__).parent.parent.parent
    
    success_count = 0
    error_count = 0
    
    print("Starting file migration...")
    print("-" * 50)
    
    for migration in MIGRATIONS:
        src = project_root / migration['source']
        dst_dir = project_root / migration['destination']
        dst = dst_dir / src.name
        
        try:
            # Ensure destination directory exists
            dst_dir.mkdir(parents=True, exist_ok=True)
            
            # Move file
            shutil.move(str(src), str(dst))
            print(f"✅ Moved: {{migration['source']}} → {{migration['destination']}}")
            success_count += 1
        except Exception as e:
            print(f"❌ Failed: {{migration['source']}}: {{e}}")
            error_count += 1
    
    print("-" * 50)
    print(f"Migration complete: {{success_count}} success, {{error_count}} errors")
    
    return error_count == 0

if __name__ == "__main__":
    import sys
    success = migrate_files()
    sys.exit(0 if success else 1)
'''.format(
        timestamp=datetime.now().isoformat(),
        migrations=json.dumps(migrations, indent=4)
    )
    
    return script_content

def main():
    """Generate migration plan and script."""
    
    # Get project root
    project_root = Path(__file__).parent.parent.parent
    
    print("Analyzing files for migration...")
    print(f"Project root: {project_root}")
    print("-" * 50)
    
    # Analyze files
    migrations = analyze_files(project_root)
    
    # Group by destination
    by_destination = {}
    for m in migrations:
        dest = m['destination']
        if dest not in by_destination:
            by_destination[dest] = []
        by_destination[dest].append(m)
    
    # Display plan
    total_size = 0
    total_files = len(migrations)
    
    print(f"\nMigration Plan: {total_files} files to move")
    print("=" * 70)
    
    for dest, files in sorted(by_destination.items()):
        dest_size = sum(f['size'] for f in files)
        total_size += dest_size
        print(f"\n→ {dest} ({len(files)} files, {dest_size/1024/1024:.1f}MB)")
        
        # Show first 5 files as examples
        for f in files[:5]:
            print(f"  - {f['source']}")
        if len(files) > 5:
            print(f"  ... and {len(files)-5} more files")
    
    print("\n" + "=" * 70)
    print(f"Total: {total_files} files, {total_size/1024/1024:.1f}MB")
    
    # Generate migration script
    script_content = generate_migration_script(migrations, project_root)
    script_path = project_root / "scripts" / "maintenance" / "migrate_files.py"
    
    script_path.write_text(script_content)
    os.chmod(script_path, 0o755)
    
    print(f"\n✅ Migration script generated: {script_path}")
    print("\nNext steps:")
    print("1. Review the migration plan above")
    print("2. Run: python3 scripts/maintenance/migrate_files.py")
    print("3. Run: python3 scripts/maintenance/validate_structure.py")

if __name__ == "__main__":
    main()