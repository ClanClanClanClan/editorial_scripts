#!/usr/bin/env python3
"""
Unified Configuration System for Editorial Assistant.
Single source of truth for all configuration management.
"""

import os
import yaml
import json
from pathlib import Path
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)


@dataclass
class JournalConfiguration:
    """Configuration for a single journal."""
    code: str
    name: str
    platform: str
    url: str
    authentication: Dict[str, Any] = field(default_factory=dict)
    extraction: Dict[str, Any] = field(default_factory=dict)
    timings: Dict[str, int] = field(default_factory=dict)
    features: Dict[str, bool] = field(default_factory=dict)
    
    def get_timing(self, key: str, default: int = 5) -> int:
        """Get timing value with fallback."""
        return self.timings.get(key, default)
    
    def is_feature_enabled(self, feature: str) -> bool:
        """Check if a feature is enabled."""
        return self.features.get(feature, False)
    
    def get_categories(self) -> List[str]:
        """Get manuscript categories for this journal."""
        return self.extraction.get('categories', [])


class UnifiedConfigurationManager:
    """
    Unified configuration management system.
    Provides single source of truth for all configuration.
    """
    
    def __init__(self, environment: str = "development"):
        """
        Initialize configuration manager.
        
        Args:
            environment: Environment name (development, testing, production)
        """
        self.environment = environment
        self.project_root = self._find_project_root()
        self.config_dir = self.project_root / "config"
        
        # Load configurations
        self._global_config = self._load_global_config()
        self._journal_configs = self._load_journal_configs()
        self._environment_config = self._load_environment_config()
        self._credentials = self._load_credentials()
        
        # Apply environment overrides
        self._apply_environment_overrides()
        
        logger.info(f"Configuration loaded for environment: {environment}")
        
    def _find_project_root(self) -> Path:
        """Find the project root directory."""
        current = Path(__file__).parent
        
        # Go up until we find the root markers
        while current != current.parent:
            if (current / "editorial_assistant").exists() and (current / "config").exists():
                return current
            current = current.parent
            
        # Fallback to current working directory
        return Path.cwd()
        
    def _load_global_config(self) -> Dict[str, Any]:
        """Load global configuration settings."""
        settings_path = self.config_dir / "settings.yaml"
        
        if settings_path.exists():
            with open(settings_path, 'r') as f:
                return yaml.safe_load(f) or {}
        
        # Default settings if file doesn't exist
        return {
            'browser': {
                'headless': True,
                'timeout': 30,
                'download_dir': str(self.project_root / 'downloads')
            },
            'extraction': {
                'retry_attempts': 3,
                'cache_enabled': True,
                'cache_ttl_hours': 6
            },
            'logging': {
                'level': 'INFO',
                'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            }
        }
        
    def _load_journal_configs(self) -> Dict[str, JournalConfiguration]:
        """Load all journal configurations."""
        journals = {}
        
        # Load from main journals.yaml
        main_config_path = self.config_dir / "journals.yaml"
        if main_config_path.exists():
            with open(main_config_path, 'r') as f:
                data = yaml.safe_load(f) or {}
                # Handle dict format where keys are journal codes
                journals_data = data.get('journals', {})
                if isinstance(journals_data, dict):
                    for code, journal_data in journals_data.items():
                        config_data = {
                            'code': code,
                            'name': journal_data.get('name', code),
                            'platform': journal_data.get('platform', 'unknown'),
                            'url': journal_data.get('url', ''),
                            'authentication': journal_data.get('authentication', {}),
                            'extraction': journal_data.get('extraction', {
                                'categories': journal_data.get('categories', [])
                            }),
                            'timings': journal_data.get('timings', {}),
                            'features': journal_data.get('features', {})
                        }
                        journals[code] = JournalConfiguration(**config_data)
        
        # Load individual journal configs from journals/ directory
        journals_dir = self.config_dir / "journals"
        if journals_dir.exists():
            for yaml_file in journals_dir.glob("*.yaml"):
                try:
                    with open(yaml_file, 'r') as f:
                        data = yaml.safe_load(f) or {}
                        
                    # Extract journal code from filename or content
                    code = yaml_file.stem.upper()
                    if 'journal' in data:
                        code = data['journal'].get('code', code)
                        
                    # Create configuration object
                    config_data = {
                        'code': code,
                        'name': data.get('journal', {}).get('name', code),
                        'platform': data.get('journal', {}).get('platform', 'unknown'),
                        'url': data.get('journal', {}).get('url', ''),
                        'authentication': data.get('authentication', {}),
                        'extraction': data.get('extraction', {}),
                        'timings': data.get('timings', {}),
                        'features': data.get('features', {})
                    }
                    
                    # Handle categories separately for backward compatibility
                    if 'categories' in data:
                        config_data['extraction']['categories'] = data['categories']
                        
                    journals[code] = JournalConfiguration(**config_data)
                    
                except Exception as e:
                    logger.error(f"Failed to load journal config {yaml_file}: {e}")
                    
        return journals
        
    def _load_environment_config(self) -> Dict[str, Any]:
        """Load environment-specific configuration."""
        env_path = self.config_dir / "environments" / f"{self.environment}.yaml"
        
        if env_path.exists():
            with open(env_path, 'r') as f:
                return yaml.safe_load(f) or {}
                
        return {}
        
    def _load_credentials(self) -> Dict[str, Any]:
        """Load credentials safely."""
        credentials = {}
        
        # Try multiple credential sources
        credential_files = [
            self.config_dir / "credentials.yaml",
            self.config_dir / "credentials.json",
            self.config_dir / ".credentials"  # Hidden file
        ]
        
        for cred_file in credential_files:
            if cred_file.exists():
                try:
                    if cred_file.suffix == '.yaml':
                        with open(cred_file, 'r') as f:
                            credentials.update(yaml.safe_load(f) or {})
                    elif cred_file.suffix == '.json':
                        with open(cred_file, 'r') as f:
                            credentials.update(json.load(f))
                except Exception as e:
                    logger.error(f"Failed to load credentials from {cred_file}: {e}")
                    
        # Also check environment variables
        env_mappings = {
            'SCHOLARONE_USERNAME': 'scholarone.username',
            'SCHOLARONE_PASSWORD': 'scholarone.password',
            'ORCID_EMAIL': 'orcid.email',
            'ORCID_PASSWORD': 'orcid.password',
            'GMAIL_CREDENTIALS': 'gmail.credentials_path'
        }
        
        for env_key, config_key in env_mappings.items():
            if env_key in os.environ:
                # Navigate nested keys
                parts = config_key.split('.')
                current = credentials
                for part in parts[:-1]:
                    if part not in current:
                        current[part] = {}
                    current = current[part]
                current[parts[-1]] = os.environ[env_key]
                
        return credentials
        
    def _apply_environment_overrides(self):
        """Apply environment-specific overrides to configurations."""
        if not self._environment_config:
            return
            
        # Apply global overrides
        if 'global' in self._environment_config:
            self._merge_configs(self._global_config, self._environment_config['global'])
            
        # Apply journal-specific overrides
        if 'journals' in self._environment_config:
            for code, overrides in self._environment_config['journals'].items():
                if code in self._journal_configs:
                    journal_dict = self._journal_configs[code].__dict__
                    self._merge_configs(journal_dict, overrides)
                    self._journal_configs[code] = JournalConfiguration(**journal_dict)
                    
    def _merge_configs(self, base: Dict[str, Any], override: Dict[str, Any]):
        """Recursively merge override configuration into base."""
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._merge_configs(base[key], value)
            else:
                base[key] = value
                
    # Public API Methods
    
    def get_journal_config(self, journal_code: str) -> Optional[JournalConfiguration]:
        """
        Get configuration for a specific journal.
        
        Args:
            journal_code: Journal code (e.g., 'MF', 'MOR', 'SICON')
            
        Returns:
            JournalConfiguration object or None if not found
        """
        return self._journal_configs.get(journal_code.upper())
        
    def get_all_journal_codes(self) -> List[str]:
        """Get list of all configured journal codes."""
        return list(self._journal_configs.keys())
        
    def get_global_setting(self, key: str, default: Any = None) -> Any:
        """
        Get a global configuration setting.
        
        Args:
            key: Dot-separated key path (e.g., 'browser.headless')
            default: Default value if key not found
            
        Returns:
            Configuration value or default
        """
        parts = key.split('.')
        current = self._global_config
        
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return default
                
        return current
        
    def get_credential(self, key: str, default: str = "") -> str:
        """
        Get a credential value.
        
        Args:
            key: Dot-separated credential key
            default: Default value if not found
            
        Returns:
            Credential value or default
        """
        parts = key.split('.')
        current = self._credentials
        
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return default
                
        return str(current)
        
    def is_feature_enabled(self, feature: str, journal_code: Optional[str] = None) -> bool:
        """
        Check if a feature is enabled globally or for a specific journal.
        
        Args:
            feature: Feature name
            journal_code: Optional journal code for journal-specific features
            
        Returns:
            True if feature is enabled
        """
        # Check journal-specific first
        if journal_code:
            journal_config = self.get_journal_config(journal_code)
            if journal_config:
                return journal_config.is_feature_enabled(feature)
                
        # Fall back to global
        return self.get_global_setting(f'features.{feature}', False)
        
    def get_browser_config(self) -> Dict[str, Any]:
        """Get browser configuration."""
        return {
            'headless': self.get_global_setting('browser.headless', True),
            'timeout': self.get_global_setting('browser.timeout', 30),
            'download_dir': self.get_global_setting('browser.download_dir'),
            'options': self.get_global_setting('browser.options', {})
        }
        
    def save_journal_config(self, journal_code: str, config: JournalConfiguration):
        """
        Save or update a journal configuration.
        
        Args:
            journal_code: Journal code
            config: JournalConfiguration object
        """
        # Update in memory
        self._journal_configs[journal_code] = config
        
        # Save to file
        file_path = self.config_dir / "journals" / f"{journal_code.lower()}.yaml"
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Convert to dict for YAML
        config_dict = {
            'journal': {
                'code': config.code,
                'name': config.name,
                'platform': config.platform,
                'url': config.url
            },
            'authentication': config.authentication,
            'extraction': config.extraction,
            'timings': config.timings,
            'features': config.features
        }
        
        with open(file_path, 'w') as f:
            yaml.dump(config_dict, f, default_flow_style=False, sort_keys=False)
            
        logger.info(f"Saved configuration for journal: {journal_code}")
        

# Singleton instance
_config_manager: Optional[UnifiedConfigurationManager] = None


def get_config_manager(environment: Optional[str] = None) -> UnifiedConfigurationManager:
    """
    Get the singleton configuration manager instance.
    
    Args:
        environment: Environment name (only used on first call)
        
    Returns:
        UnifiedConfigurationManager instance
    """
    global _config_manager
    
    if _config_manager is None:
        env = environment or os.getenv('EDITORIAL_ENV', 'development')
        _config_manager = UnifiedConfigurationManager(env)
        
    return _config_manager


if __name__ == "__main__":
    # Test the configuration system
    config = get_config_manager()
    
    print("Configured Journals:")
    for code in config.get_all_journal_codes():
        journal = config.get_journal_config(code)
        print(f"  - {code}: {journal.name} ({journal.platform})")
        
    print("\nGlobal Settings:")
    print(f"  - Browser Headless: {config.get_global_setting('browser.headless')}")
    print(f"  - Cache Enabled: {config.get_global_setting('extraction.cache_enabled')}")
    
    print("\nFeature Flags:")
    print(f"  - Use Config System (MF): {config.is_feature_enabled('use_config_system', 'MF')}")
    print(f"  - Use Navigation Module (MF): {config.is_feature_enabled('use_navigation_module', 'MF')}")