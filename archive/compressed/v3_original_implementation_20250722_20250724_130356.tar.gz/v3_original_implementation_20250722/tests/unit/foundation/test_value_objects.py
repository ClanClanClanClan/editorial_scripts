"""Unit tests for foundation value objects."""

from datetime import UTC, datetime

import pendulum
import pytest

from src.foundation.value_objects import (
    Address,
    DateRange,
    EmailAddress,
    FullName,
    Institution,
    TimeRange,
    Timestamp,
)


class TestEmailAddress:
    """Test EmailAddress value object."""

    def test_create_email_address(self):
        """Test creating an email address."""
        email = EmailAddress(value="test@example.com")
        assert str(email) == "test@example.com"
        assert email.domain() == "example.com"
        assert email.local_part() == "test"

    def test_from_string(self):
        """Test creating from string."""
        email = EmailAddress.from_string("user@domain.com")
        assert email.value == "user@domain.com"

    def test_immutability(self):
        """Test that EmailAddress is immutable."""
        from pydantic import ValidationError

        email = EmailAddress(value="test@example.com")
        with pytest.raises(ValidationError):
            email.value = "other@example.com"


class TestFullName:
    """Test FullName value object."""

    def test_create_full_name(self):
        """Test creating a full name."""
        name = FullName(
            first_name="John",
            last_name="Doe",
            middle_name="Robert",
            suffix="Jr.",
        )
        assert str(name) == "John Robert Doe Jr."
        assert name.formal_name() == "Doe, John R., Jr."
        assert name.initials() == "JRD"

    def test_without_middle_name(self):
        """Test full name without middle name."""
        name = FullName(first_name="Jane", last_name="Smith")
        assert str(name) == "Jane Smith"
        assert name.formal_name() == "Smith, Jane"
        assert name.initials() == "JS"

    def test_immutability(self):
        """Test that FullName is immutable."""
        from pydantic import ValidationError

        name = FullName(first_name="John", last_name="Doe")
        with pytest.raises(ValidationError):
            name.first_name = "Jane"


class TestInstitution:
    """Test Institution value object."""

    def test_create_institution(self):
        """Test creating an institution."""
        inst = Institution(
            name="MIT",
            department="Computer Science",
            country="USA",
        )
        assert str(inst) == "Computer Science, MIT, USA"

    def test_without_department(self):
        """Test institution without department."""
        inst = Institution(name="Stanford University", country="USA")
        assert str(inst) == "Stanford University, USA"

    def test_minimal_institution(self):
        """Test institution with only name."""
        inst = Institution(name="Harvard")
        assert str(inst) == "Harvard"


class TestAddress:
    """Test Address value object."""

    def test_create_address(self):
        """Test creating an address."""
        addr = Address(
            street1="123 Main St",
            street2="Apt 4B",
            city="Boston",
            state_province="MA",
            postal_code="02101",
            country="USA",
        )

        expected_multiline = "123 Main St\nApt 4B\nBoston, MA, 02101\nUSA"
        assert str(addr) == expected_multiline

        expected_single = "123 Main St, Apt 4B, Boston, MA, 02101, USA"
        assert addr.single_line() == expected_single

    def test_minimal_address(self):
        """Test address with minimal fields."""
        addr = Address(
            street1="123 Main St",
            city="Boston",
            country="USA",
        )
        assert str(addr) == "123 Main St\nBoston\nUSA"


class TestTimestamp:
    """Test Timestamp value object."""

    def test_create_timestamp(self):
        """Test creating a timestamp."""
        ts = Timestamp()
        assert ts.value.tzinfo is not None
        assert isinstance(ts.to_pendulum(), pendulum.DateTime)

    def test_now(self):
        """Test creating current timestamp."""
        ts = Timestamp.now()
        assert ts.value.tzinfo is not None
        assert (pendulum.now() - ts.to_pendulum()).total_seconds() < 1

    def test_from_datetime(self):
        """Test creating from datetime."""
        dt = datetime(2024, 1, 1, 12, 0, 0, tzinfo=UTC)
        ts = Timestamp.from_datetime(dt)
        assert ts.value == dt

    def test_ensure_timezone(self):
        """Test timezone is added if missing."""
        dt = datetime(2024, 1, 1, 12, 0, 0)  # No timezone
        ts = Timestamp(value=dt)
        assert ts.value.tzinfo is not None

    def test_format(self):
        """Test formatting timestamp."""
        dt = datetime(2024, 1, 1, 12, 0, 0, tzinfo=UTC)
        ts = Timestamp.from_datetime(dt)
        assert ts.format() == "2024-01-01 12:00:00"
        assert ts.format("MMMM D, YYYY") == "January 1, 2024"

    def test_add_subtract_days(self):
        """Test adding and subtracting days."""
        dt = datetime(2024, 1, 1, tzinfo=UTC)
        ts = Timestamp.from_datetime(dt)

        future = ts.add_days(5)
        assert future.value.day == 6

        past = ts.subtract_days(5)
        assert past.value.month == 12
        assert past.value.year == 2023


class TestDateRange:
    """Test DateRange value object."""

    def test_create_date_range(self):
        """Test creating a date range."""
        start = Timestamp.from_datetime(datetime(2024, 1, 1, tzinfo=UTC))
        end = Timestamp.from_datetime(datetime(2024, 1, 10, tzinfo=UTC))

        range_ = DateRange(start=start, end=end)
        assert range_.duration_days() == 9

    def test_end_before_start_validation(self):
        """Test validation that end is after start."""
        start = Timestamp.from_datetime(datetime(2024, 1, 10, tzinfo=UTC))
        end = Timestamp.from_datetime(datetime(2024, 1, 1, tzinfo=UTC))

        with pytest.raises(ValueError, match="End date must be after start date"):
            DateRange(start=start, end=end)

    def test_contains(self):
        """Test checking if timestamp is in range."""
        start = Timestamp.from_datetime(datetime(2024, 1, 1, tzinfo=UTC))
        end = Timestamp.from_datetime(datetime(2024, 1, 10, tzinfo=UTC))
        range_ = DateRange(start=start, end=end)

        # Inside range
        inside = Timestamp.from_datetime(datetime(2024, 1, 5, tzinfo=UTC))
        assert range_.contains(inside)

        # At boundaries
        assert range_.contains(start)
        assert range_.contains(end)

        # Outside range
        before = Timestamp.from_datetime(datetime(2023, 12, 31, tzinfo=UTC))
        after = Timestamp.from_datetime(datetime(2024, 1, 11, tzinfo=UTC))
        assert not range_.contains(before)
        assert not range_.contains(after)

    def test_overlaps(self):
        """Test checking if ranges overlap."""
        # Range 1: Jan 1-10
        range1 = DateRange(
            start=Timestamp.from_datetime(datetime(2024, 1, 1, tzinfo=UTC)),
            end=Timestamp.from_datetime(datetime(2024, 1, 10, tzinfo=UTC)),
        )

        # Range 2: Jan 5-15 (overlaps)
        range2 = DateRange(
            start=Timestamp.from_datetime(datetime(2024, 1, 5, tzinfo=UTC)),
            end=Timestamp.from_datetime(datetime(2024, 1, 15, tzinfo=UTC)),
        )
        assert range1.overlaps(range2)
        assert range2.overlaps(range1)

        # Range 3: Jan 15-20 (no overlap)
        range3 = DateRange(
            start=Timestamp.from_datetime(datetime(2024, 1, 15, tzinfo=UTC)),
            end=Timestamp.from_datetime(datetime(2024, 1, 20, tzinfo=UTC)),
        )
        assert not range1.overlaps(range3)
        assert not range3.overlaps(range1)


class TestTimeRange:
    """Test TimeRange value object."""

    def test_create_closed_range(self):
        """Test creating a closed time range."""
        start = Timestamp.from_datetime(
            datetime(2024, 1, 1, 10, 0, 0, tzinfo=UTC)
        )
        end = Timestamp.from_datetime(
            datetime(2024, 1, 1, 11, 30, 0, tzinfo=UTC)
        )

        range_ = TimeRange(start=start, end=end)
        assert not range_.is_open()
        assert range_.duration_seconds() == 5400  # 1.5 hours

    def test_create_open_range(self):
        """Test creating an open time range."""
        start = Timestamp.now()
        range_ = TimeRange(start=start)

        assert range_.is_open()
        assert range_.duration_seconds() is None

    def test_close_range(self):
        """Test closing an open range."""
        start = Timestamp.from_datetime(
            datetime(2024, 1, 1, 10, 0, 0, tzinfo=UTC)
        )
        open_range = TimeRange(start=start)

        end = Timestamp.from_datetime(
            datetime(2024, 1, 1, 11, 0, 0, tzinfo=UTC)
        )
        closed_range = open_range.close(end)

        assert not closed_range.is_open()
        assert closed_range.duration_seconds() == 3600

        # Original range unchanged
        assert open_range.is_open()
