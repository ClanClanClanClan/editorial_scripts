#!/usr/bin/env python3
"""
Test MOR connection with same fixes as MF
"""

import os
import sys
import time
import logging
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from editorial_assistant.core.browser_manager import BrowserManager
from core.email_utils import fetch_latest_verification_code

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_mor_connection():
    """Test MOR connection with device verification."""
    logger.info("🧪 Testing MOR connection")
    
    # Load production config
    with open('.env.production', 'r') as f:
        for line in f:
            if '=' in line and not line.startswith('#'):
                key, value = line.strip().split('=', 1)
                os.environ[key] = value
    
    try:
        # Create browser
        browser_manager = BrowserManager(headless=False)
        driver = browser_manager.create_driver()
        
        # Navigate to MOR
        logger.info("📍 Navigating to MOR")
        driver.get("https://mc.manuscriptcentral.com/mathor")
        time.sleep(3)
        
        # Accept cookies
        try:
            accept_btn = driver.find_element("id", "onetrust-accept-btn-handler")
            if accept_btn.is_displayed():
                accept_btn.click()
                time.sleep(1)
        except:
            pass
        
        # Login
        logger.info("📍 Logging in to MOR")
        user = os.environ.get('MOR_EMAIL')
        password = os.environ.get('MOR_PASSWORD')
        
        logger.info(f"   Using email: {user}")
        
        user_box = driver.find_element("id", "USERID")
        pw_box = driver.find_element("id", "PASSWORD")
        
        user_box.clear()
        user_box.send_keys(user)
        pw_box.clear()
        pw_box.send_keys(password)
        
        login_btn = driver.find_element("id", "logInButton")
        login_btn.click()
        time.sleep(10)
        
        # Handle device verification if needed
        if "UNRECOGNIZED_DEVICE" in driver.page_source:
            logger.info("📍 Handling device verification...")
            verification_input = driver.find_element("id", "TOKEN_VALUE")
            verification_code = fetch_latest_verification_code(journal="MOR", max_wait=300, poll_interval=10)
            
            if verification_code:
                logger.info(f"✅ Got verification code: {verification_code}")
                verification_input.clear()
                verification_input.send_keys(verification_code)
                verification_input.send_keys("\\n")
                time.sleep(10)
                logger.info("✅ Device verification completed")
            else:
                logger.error("❌ No verification code found")
                return False
        
        # Check for successful login
        current_url = driver.current_url
        page_source = driver.page_source
        
        logger.info(f"Current URL: {current_url}")
        
        # Look for Associate Editor Center
        if "Associate Editor Center" in page_source:
            logger.info("✅ MOR CONNECTION SUCCESSFUL!")
            logger.info("✅ Found Associate Editor Center - ready for manuscript extraction")
            
            # Try to click Associate Editor Center
            try:
                ae_link = driver.find_element("link text", "Associate Editor Center")
                logger.info("📍 Clicking Associate Editor Center...")
                ae_link.click()
                time.sleep(5)
                
                # Check for manuscript dashboard
                if "manuscript" in driver.page_source.lower():
                    logger.info("✅ Successfully accessed manuscript dashboard")
                    return True
                else:
                    logger.warning("❌ Could not access manuscript dashboard")
                    return False
                    
            except Exception as e:
                logger.error(f"❌ Error accessing Associate Editor Center: {e}")
                return False
        else:
            logger.error("❌ MOR connection failed - no Associate Editor Center found")
            return False
        
    except Exception as e:
        logger.error(f"❌ Error testing MOR connection: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    success = test_mor_connection()
    if success:
        print("✅ MOR CONNECTION TEST PASSED")
    else:
        print("❌ MOR CONNECTION TEST FAILED")