#!/usr/bin/env python3
"""Simple test to verify SICON/SIFIN extractors are working"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

# Add to path
sys.path.insert(0, str(Path(__file__).parent))

# Load credentials
load_dotenv('.env.production')

def test_journal_extraction(journal_code):
    """Test extraction for a specific journal"""
    
    from editorial_assistant.core.data_models import JournalConfig
    
    # Journal configurations
    configs = {
        'SICON': JournalConfig(
            code="SICON",
            name="SIAM Journal on Control and Optimization",
            url="https://sicon.siam.org/cgi-bin/main.plex",
            platform="siam_orcid",
            credentials={
                "username_env": "ORCID_EMAIL",
                "password_env": "ORCID_PASSWORD"
            }
        ),
        'SIFIN': JournalConfig(
            code="SIFIN",
            name="SIAM Journal on Financial Mathematics",
            url="https://sifin.siam.org/cgi-bin/main.plex",
            platform="siam_orcid",
            credentials={
                "username_env": "ORCID_EMAIL",
                "password_env": "ORCID_PASSWORD"
            }
        )
    }
    
    config = configs[journal_code]
    
    # Import the appropriate extractor
    if journal_code == 'SICON':
        from editorial_assistant.extractors.sicon import SICONExtractor
        ExtractorClass = SICONExtractor
    else:
        from editorial_assistant.extractors.sifin import SIFINExtractor
        ExtractorClass = SIFINExtractor
    
    print(f"\n{'='*60}")
    print(f"Testing {journal_code} Extraction")
    print(f"{'='*60}")
    
    try:
        print(f"Creating {journal_code} extractor...")
        extractor = ExtractorClass(config)
        
        print(f"Starting extraction (this may take a minute)...")
        manuscripts = extractor.extract_data()
        
        print(f"\n✅ {journal_code} Extraction Results:")
        print(f"   Total manuscripts: {len(manuscripts)}")
        
        # Count referees
        total_referees = 0
        for ms in manuscripts:
            total_referees += len(ms.get('referees', []))
            total_referees += len(ms.get('declined_referees', []))
        
        print(f"   Total referees: {total_referees}")
        
        # Show sample
        if manuscripts:
            sample = manuscripts[0]
            print(f"\n   Sample manuscript:")
            print(f"   - ID: {sample.get('id', 'N/A')}")
            print(f"   - Title: {sample.get('title', 'N/A')[:50]}...")
            print(f"   - Status: {sample.get('status', 'N/A')}")
            print(f"   - Referees: {len(sample.get('referees', []))}")
        
        # Save results
        output_file = f"{journal_code.lower()}_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(output_file, 'w') as f:
            json.dump(manuscripts, f, indent=2, default=str)
        print(f"\n   Results saved to: {output_file}")
        
        return True, len(manuscripts)
        
    except Exception as e:
        print(f"\n❌ {journal_code} extraction failed: {e}")
        import traceback
        traceback.print_exc()
        return False, 0

def main():
    """Test both SICON and SIFIN"""
    
    print("SICON/SIFIN FUNCTIONALITY TEST")
    print("="*60)
    
    # Check environment
    if not os.getenv('ORCID_EMAIL') or not os.getenv('ORCID_PASSWORD'):
        print("❌ Missing ORCID credentials")
        print("   Please set ORCID_EMAIL and ORCID_PASSWORD")
        return False
    
    print(f"✅ Using credentials for: {os.getenv('ORCID_EMAIL')}")
    
    results = {}
    
    # Test each journal
    for journal in ['SICON', 'SIFIN']:
        success, count = test_journal_extraction(journal)
        results[journal] = {
            'success': success,
            'manuscripts': count
        }
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    
    all_success = all(r['success'] for r in results.values())
    
    for journal, result in results.items():
        status = "✅ PASSED" if result['success'] else "❌ FAILED"
        print(f"{journal}: {status} ({result['manuscripts']} manuscripts)")
    
    print("\n" + "="*60)
    if all_success:
        print("✅ ALL TESTS PASSED - SICON and SIFIN are working!")
    else:
        print("❌ SOME TESTS FAILED - Please check the errors above")
    
    return all_success

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)