#!/usr/bin/env python3
"""Debug referee cell structure"""

import os
import sys
import time
from pathlib import Path
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

def debug_referee_cells():
    """Debug the exact cell structure of referee rows"""
    
    print("🔍 DEBUGGING REFEREE CELL STRUCTURE")
    print("=" * 50)
    
    # Chrome setup
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        # Quick login (we know this works)
        print("1. Quick login...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        try:
            reject_btn = driver.find_element(By.ID, "onetrust-reject-all-handler")
            reject_btn.click()
        except:
            pass
        
        email_field = driver.find_element(By.ID, "USERID")
        email_field.send_keys(os.getenv('MF_EMAIL'))
        password_field = driver.find_element(By.ID, "PASSWORD")
        password_field.send_keys(os.getenv('MF_PASSWORD'))
        login_btn = driver.find_element(By.ID, "logInButton")
        driver.execute_script("arguments[0].click();", login_btn)
        time.sleep(3)
        
        # Handle 2FA
        try:
            code_input = driver.find_element(By.ID, "TOKEN_VALUE")
            from core.email_utils import fetch_latest_verification_code
            time.sleep(5)
            verification_code = fetch_latest_verification_code('MF', max_wait=60, poll_interval=3)
            if verification_code:
                code_input.clear()
                code_input.send_keys(verification_code)
                try:
                    remember_checkbox = driver.find_element(By.ID, "REMEMBER_THIS_DEVICE")
                    if not remember_checkbox.is_selected():
                        remember_checkbox.click()
                except:
                    pass
                verify_btn = driver.find_element(By.ID, "VERIFY_BTN")
                verify_btn.click()
                time.sleep(15)
        except:
            pass
        
        # Navigate and click Take Action (we know this works)
        print("2. Navigating and clicking Take Action...")
        ae_link = driver.find_element(By.LINK_TEXT, "Associate Editor Center")
        ae_link.click()
        time.sleep(5)
        
        category_link = driver.find_element(By.LINK_TEXT, "Awaiting Reviewer Scores")
        category_link.click()
        time.sleep(5)
        
        # Find and click Take Action
        all_rows = driver.find_elements(By.TAG_NAME, "tr")
        for row in all_rows:
            if 'MAFI-' in row.text:
                cells = row.find_elements(By.TAG_NAME, "td")
                if cells:
                    last_cell = cells[-1]
                    take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
                    if take_action_links:
                        href = take_action_links[0].get_attribute('href')
                        if href and 'javascript:' in href:
                            js_code = href.replace('javascript:', '')
                            driver.execute_script(js_code)
                            time.sleep(5)
                            print("✅ Take Action clicked successfully")
                            break
        
        # Now debug the referee cell structure
        print("3. DEBUGGING REFEREE CELL STRUCTURE...")
        print("-" * 50)
        
        # Find rows with referee names
        tablelightcolor_rows = driver.find_elements(By.XPATH, "//tr[td[contains(@class, 'tablelightcolor')]]")
        print(f"Found {len(tablelightcolor_rows)} tablelightcolor rows")
        
        referee_names = ['Liang', 'Mrad', 'Dos Reis', 'Strub']
        
        for i, row in enumerate(tablelightcolor_rows):
            row_text = row.text
            if any(name in row_text for name in referee_names):
                print(f"\n🎯 REFEREE ROW {i+1}: {referee_names[0] if 'Liang' in row_text else referee_names[1] if 'Mrad' in row_text else referee_names[2] if 'Dos Reis' in row_text else referee_names[3] if 'Strub' in row_text else 'Unknown'}")
                print(f"Row text: {row_text[:100]}...")
                
                cells = row.find_elements(By.TAG_NAME, "td")
                print(f"Total cells: {len(cells)}")
                
                for j, cell in enumerate(cells):
                    cell_text = cell.text.strip()
                    cell_html = cell.get_attribute('innerHTML')
                    
                    if cell_text or j < 10:  # Show first 10 cells or non-empty cells
                        print(f"  Cell {j}: '{cell_text}' (HTML: {cell_html[:100]}...)")
                        
                        # Look for specific elements
                        links = cell.find_elements(By.TAG_NAME, "a")
                        if links:
                            print(f"    Links in cell {j}:")
                            for k, link in enumerate(links):
                                href = link.get_attribute('href')
                                link_text = link.text
                                print(f"      Link {k+1}: '{link_text}' -> {href}")
                        
                        spans = cell.find_elements(By.TAG_NAME, "span")
                        if spans:
                            print(f"    Spans in cell {j}:")
                            for k, span in enumerate(spans):
                                span_text = span.text
                                span_class = span.get_attribute('class')
                                print(f"      Span {k+1} (class='{span_class}'): '{span_text}'")
                
                print("-" * 40)
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        driver.quit()

if __name__ == "__main__":
    debug_referee_cells()