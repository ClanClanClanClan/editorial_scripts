#!/usr/bin/env python3
"""Test basic SICON extraction functionality"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Add to path
sys.path.insert(0, str(Path(__file__).parent))

# Load credentials
load_dotenv('.env.production')

from editorial_assistant.core.data_models import JournalConfig
from editorial_assistant.extractors.sicon import SICONExtractor

def test_basic_sicon():
    """Test basic SICON extraction without email validation"""
    
    print("="*60)
    print("BASIC SICON EXTRACTION TEST")
    print("="*60)
    
    # Check environment
    if not os.getenv('ORCID_EMAIL') or not os.getenv('ORCID_PASSWORD'):
        print("❌ Missing ORCID credentials in environment")
        return False
    
    print(f"✅ Credentials loaded for: {os.getenv('ORCID_EMAIL')}")
    
    # Create SICON config
    config = JournalConfig(
        code="SICON",
        name="SIAM Journal on Control and Optimization",
        url="https://sicon.siam.org/cgi-bin/main.plex",
        platform="siam_orcid",
        credentials={
            "username_env": "ORCID_EMAIL",
            "password_env": "ORCID_PASSWORD"
        }
    )
    
    # Test extraction
    try:
        print("\nCreating SICON extractor...")
        extractor = SICONExtractor(config)
        
        print("Running extraction...")
        manuscripts = extractor.extract_data()
        
        print(f"\n✅ Extraction successful!")
        print(f"   Manuscripts found: {len(manuscripts)}")
        
        # Show sample data
        if manuscripts:
            print("\nSample manuscript:")
            sample = manuscripts[0]
            print(f"   ID: {sample.get('id', 'N/A')}")
            print(f"   Title: {sample.get('title', 'N/A')[:50]}...")
            print(f"   Referees: {len(sample.get('referees', []))}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Extraction failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_basic_sicon()
    sys.exit(0 if success else 1)