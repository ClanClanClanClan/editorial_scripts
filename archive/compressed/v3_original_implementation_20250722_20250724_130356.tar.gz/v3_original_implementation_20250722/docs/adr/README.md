# Architecture Decision Records (ADRs)

This directory contains Architecture Decision Records for Editorial Scripts v3.0, documenting significant architectural and design decisions made during the development process.

## Index of ADRs

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| [ADR-0001](0001-pristine-plus-architecture.md) | Pristine-Plus Architecture | Accepted | Bootstrap Phase |
| [ADR-0002](0002-optimistic-locking.md) | Optimistic Locking Strategy | Accepted | Bootstrap Phase |
| [ADR-0003](0003-postgresql-extensions-strategy.md) | PostgreSQL with Extensions Strategy | Accepted | Domain Canon Phase |
| [ADR-0004](0004-mutation-testing-strategy.md) | Mutation Testing Strategy | Accepted | Domain Canon Phase |
| [ADR-0005](0005-compliance-privacy-by-design.md) | Compliance and Privacy by Design | Accepted | Domain Canon Phase |

## ADR Template

For new ADRs, use the following template structure:

```markdown
# ADR-XXXX: [Title]

## Status
[Proposed | Accepted | Rejected | Deprecated | Superseded]

## Context
[Describe the forces at play, including technological, political, social, and local to the project]

## Decision
[Describe the architectural decision and provide rationale]

## Consequences
[Describe the resulting context, after applying the decision. All consequences should be listed, not just the "positive" ones]

## References
[Links to external resources]
```

## Process

1. **Proposal**: Create a new ADR in `Proposed` status
2. **Review**: Technical team reviews and discusses
3. **Decision**: Mark as `Accepted`, `Rejected`, or request modifications
4. **Implementation**: Update status to `Accepted` when implemented
5. **Evolution**: Mark as `Deprecated` or `Superseded` when replaced

All ADRs are living documents and may be updated as the system evolves.