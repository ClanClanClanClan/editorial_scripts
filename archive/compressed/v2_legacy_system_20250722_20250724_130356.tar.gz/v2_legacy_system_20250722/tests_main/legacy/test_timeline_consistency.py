#!/usr/bin/env python3
"""
Test Timeline Consistency for All Journals

This script specifically tests timeline consistency between web and email data
to ensure there are no contradictions.
"""

import os
import json
from datetime import datetime
from pathlib import Path

from run_complete_extraction_with_validation import CompleteExtractionRunner


def test_timeline_consistency():
    """Run timeline consistency tests for all journals."""
    
    print("="*80)
    print("TIMELINE CONSISTENCY TEST")
    print("="*80)
    print("This test verifies that web data and email data are consistent")
    print("and that there are no contradictions in referee timelines.")
    print("="*80)
    
    # Check environment
    required_env = ['ORCID_EMAIL', 'ORCID_PASSWORD']
    missing_env = [var for var in required_env if not os.getenv(var)]
    
    if missing_env:
        print(f"\n❌ Missing required environment variables: {', '.join(missing_env)}")
        return False
    
    # Run extraction with validation
    runner = CompleteExtractionRunner()
    report = runner.run_all_extractions(validate_timeline=True)
    
    # Analyze results
    print("\n" + "="*80)
    print("TIMELINE CONSISTENCY TEST RESULTS")
    print("="*80)
    
    all_passed = True
    
    for journal, validation in report['validation_summary'].items():
        print(f"\n{journal}:")
        
        if validation['critical_issues'] == 0:
            print("  ✅ PASSED - No critical timeline inconsistencies")
        else:
            print(f"  ❌ FAILED - {validation['critical_issues']} critical issues found")
            all_passed = False
            
            # Show issue breakdown
            if validation['issue_types']:
                print("  Issue types:")
                for issue_type, count in validation['issue_types'].items():
                    print(f"    - {issue_type}: {count}")
        
        # Show validation rate
        print(f"  Validation rate: {validation['validation_rate']:.1%}")
        print(f"  Manuscripts checked: {validation['total_manuscripts']}")
        print(f"  Manuscripts with issues: {validation['manuscripts_with_issues']}")
    
    # Overall result
    print("\n" + "="*80)
    if all_passed:
        print("✅ ALL TIMELINE CONSISTENCY TESTS PASSED")
        print("   Web and email data are consistent across all journals")
    else:
        print("❌ TIMELINE CONSISTENCY TESTS FAILED")
        print("   Critical contradictions found between web and email data")
        print("\n   Next steps:")
        print("   1. Review the validation issues in the output files")
        print("   2. Investigate why web and email data contradict")
        print("   3. Fix the extractors to handle these cases")
        print("   4. Re-run this test until all issues are resolved")
    
    # Save detailed test results
    test_results = {
        'test_timestamp': datetime.now().isoformat(),
        'test_passed': all_passed,
        'journals_tested': list(report['validation_summary'].keys()),
        'total_critical_issues': report['overall_validation']['critical_issues'],
        'validation_details': report['validation_summary']
    }
    
    results_file = f"timeline_consistency_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(results_file, 'w') as f:
        json.dump(test_results, f, indent=2)
    
    print(f"\n📄 Detailed test results saved to: {results_file}")
    
    return all_passed


if __name__ == "__main__":
    import sys
    passed = test_timeline_consistency()
    sys.exit(0 if passed else 1)