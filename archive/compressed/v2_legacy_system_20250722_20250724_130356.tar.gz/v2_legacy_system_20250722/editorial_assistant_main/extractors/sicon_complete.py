"""
SIAM Journal on Control and Optimization (SICON) Complete Extractor
With email timeline integration and validation

This is the production-ready version that:
1. Extracts manuscript data from the web
2. Integrates email timeline data
3. Validates for contradictions
4. Returns unified, validated data
"""

import os
import logging
import time
import json
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
from pathlib import Path
from bs4 import BeautifulSoup
import re

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

from editorial_assistant.core.data_models import JournalConfig
from editorial_assistant.extractors.base_platform_extractors import SIAMExtractor
from editorial_assistant.core.timeline_validator import TimelineValidator, ValidationIssue
from scripts.sicon.scripts.sicon.parse_sicon_emails import SICONEmailParser
from core.working_gmail_utils import get_gmail_service, search_messages, get_message_details

logger = logging.getLogger(__name__)


class SICONCompleteExtractor(SIAMExtractor):
    """
    Complete SICON extractor with email timeline integration and validation.
    
    This extractor:
    1. Follows the exact 8-step workflow for web extraction
    2. Fetches and parses SICON emails from Gmail
    3. Validates timeline consistency between sources
    4. Returns unified data with all contradictions resolved
    """
    
    def __init__(self, journal: JournalConfig, validate_timeline: bool = True):
        super().__init__(journal)
        self.site_prefix = "https://sicon.siam.org/"
        self.manuscripts = []
        self.referees = []
        self.validate_timeline = validate_timeline
        self.email_parser = SICONEmailParser()
        self.timeline_validator = TimelineValidator(tolerance_days=2)
        self.gmail_service = None
        
    def extract_data(self) -> List[Dict[str, Any]]:
        """
        Main extraction method that combines web and email data.
        
        Returns:
            List of manuscripts with validated timeline data
        """
        try:
            # Step 1: Web extraction
            logger.info("Starting SICON web extraction...")
            web_manuscripts = self._extract_from_web()
            logger.info(f"Extracted {len(web_manuscripts)} manuscripts from web")
            
            # Step 2: Email extraction (if validation enabled)
            if self.validate_timeline:
                logger.info("Starting SICON email extraction...")
                email_data = self._extract_from_emails()
                logger.info(f"Extracted {len(email_data)} emails")
                
                # Step 3: Integrate and validate
                logger.info("Integrating and validating timeline data...")
                validated_manuscripts = self._integrate_and_validate(web_manuscripts, email_data)
                
                # Step 4: Report any critical issues
                self._report_validation_issues(validated_manuscripts)
                
                return validated_manuscripts
            else:
                return web_manuscripts
                
        except Exception as e:
            logger.error(f"SICON extraction failed: {e}")
            raise
            
        finally:
            if self.driver:
                self.driver.quit()
    
    def _extract_from_web(self) -> List[Dict[str, Any]]:
        """Extract manuscripts from SICON website following exact workflow."""
        try:
            # Initialize browser
            if not self.driver:
                self.driver = self.browser_manager.create_driver()
            
            # Login to SICON
            self._login()
            
            # Extract manuscripts
            return self.extract_manuscripts()
            
        except Exception as e:
            logger.error(f"Web extraction failed: {e}")
            return []
    
    def _extract_from_emails(self, days_back: int = 180) -> List[Dict]:
        """Extract SICON emails from Gmail."""
        try:
            # Initialize Gmail service
            self.gmail_service = get_gmail_service()
            if not self.gmail_service:
                logger.warning("Gmail service not available - skipping email extraction")
                return []
            
            # Search queries for SICON emails
            queries = [
                f'subject:SICON newer_than:{days_back}d',
                f'from:sicon.siam.org newer_than:{days_back}d',
                f'subject:"SIAM Journal on Control" newer_than:{days_back}d',
                f'(subject:"referee invitation" OR subject:"reviewer invitation") SICON newer_than:{days_back}d',
                f'(subject:"accepted to review" OR subject:"declined to review") SICON newer_than:{days_back}d'
            ]
            
            all_emails = []
            seen_ids = set()
            
            for query in queries:
                logger.info(f"Searching Gmail: {query}")
                messages = search_messages(self.gmail_service, query)
                
                for msg in messages:
                    if msg['id'] not in seen_ids:
                        seen_ids.add(msg['id'])
                        details = get_message_details(self.gmail_service, msg['id'])
                        if details:
                            all_emails.append(details)
            
            logger.info(f"Found {len(all_emails)} SICON emails")
            return all_emails
            
        except Exception as e:
            logger.error(f"Email extraction failed: {e}")
            return []
    
    def _integrate_and_validate(self, web_manuscripts: List[Dict], emails: List[Dict]) -> List[Dict]:
        """
        Integrate web and email data, validating for contradictions.
        
        Args:
            web_manuscripts: Manuscripts from web scraping
            emails: Raw emails from Gmail
            
        Returns:
            List of manuscripts with integrated and validated timeline data
        """
        validated_manuscripts = []
        
        for manuscript in web_manuscripts:
            ms_id = manuscript.get('id', '')
            
            # Parse email timeline for this manuscript
            email_timeline = self.email_parser.parse_referee_emails(emails, manuscript_id=ms_id)
            
            # Get all referees
            all_referees = []
            all_referees.extend(manuscript.get('Declined Referees', []))
            all_referees.extend(manuscript.get('Referees', []))
            
            # Validate timeline
            validation_issues = self.timeline_validator.validate_manuscript_timeline(
                ms_id, all_referees, email_timeline
            )
            
            # Enhance referee data with email timeline
            enhanced_referees = self._enhance_referee_data(all_referees, email_timeline)
            
            # Update manuscript with validated data
            validated_manuscript = manuscript.copy()
            validated_manuscript['enhanced_referees'] = enhanced_referees
            validated_manuscript['email_timeline'] = email_timeline
            validated_manuscript['validation_issues'] = [issue.to_dict() for issue in validation_issues]
            validated_manuscript['has_critical_issues'] = any(
                issue.severity == 'critical' for issue in validation_issues
            )
            
            # Separate referees by status with enhanced data
            validated_manuscript['declined_referees'] = [
                ref for ref in enhanced_referees if ref['status'] == 'declined'
            ]
            validated_manuscript['accepted_referees'] = [
                ref for ref in enhanced_referees if ref['status'] in ['accepted', 'complete', 'overdue']
            ]
            
            validated_manuscripts.append(validated_manuscript)
        
        return validated_manuscripts
    
    def _enhance_referee_data(self, web_referees: List[Dict], email_timeline: Dict) -> List[Dict]:
        """
        Enhance web referee data with email timeline information.
        
        Args:
            web_referees: Referees from web scraping
            email_timeline: Parsed email timeline data
            
        Returns:
            List of referees with enhanced timeline data
        """
        enhanced_referees = []
        
        # Create email lookup maps
        email_invitations = {inv['referee_email'].lower(): inv for inv in email_timeline.get('invitations', [])}
        email_responses = {resp['referee_email'].lower(): resp for resp in email_timeline.get('responses', [])}
        
        for web_ref in web_referees:
            enhanced_ref = web_ref.copy()
            referee_email = web_ref.get('email', '').lower()
            
            # Add email timeline data if available
            if referee_email in email_invitations:
                invitation = email_invitations[referee_email]
                enhanced_ref['invitation_date'] = invitation.get('date')
                enhanced_ref['invitation_deadline'] = invitation.get('deadline')
                enhanced_ref['email_evidence'] = True
            else:
                enhanced_ref['email_evidence'] = False
                
            if referee_email in email_responses:
                response = email_responses[referee_email]
                enhanced_ref['response_date'] = response.get('date')
                enhanced_ref['email_decision'] = response.get('decision')
                
                # Calculate response time
                if enhanced_ref.get('invitation_date') and response.get('date'):
                    try:
                        inv_date = datetime.fromisoformat(enhanced_ref['invitation_date'].replace('Z', '+00:00'))
                        resp_date = datetime.fromisoformat(response['date'].replace('Z', '+00:00'))
                        enhanced_ref['response_time_days'] = (resp_date - inv_date).days
                    except:
                        pass
            
            # Flag any contradictions
            if enhanced_ref.get('email_decision') and enhanced_ref.get('status'):
                web_status = enhanced_ref['status'].lower()
                email_decision = enhanced_ref['email_decision'].lower()
                
                # Check for contradictions
                if (web_status == 'declined' and email_decision == 'accepted') or \
                   (web_status in ['accepted', 'complete'] and email_decision == 'declined'):
                    enhanced_ref['has_contradiction'] = True
                    enhanced_ref['contradiction_details'] = f"Web shows '{web_status}' but email shows '{email_decision}'"
                else:
                    enhanced_ref['has_contradiction'] = False
            
            enhanced_referees.append(enhanced_ref)
        
        # Add email-only referees (found in emails but not on web)
        for email, invitation in email_invitations.items():
            if not any(ref.get('email', '').lower() == email for ref in web_referees):
                email_only_ref = {
                    'name': invitation.get('referee_name', ''),
                    'email': invitation.get('referee_email', ''),
                    'status': 'email_only',
                    'invitation_date': invitation.get('date'),
                    'invitation_deadline': invitation.get('deadline'),
                    'email_evidence': True,
                    'web_evidence': False,
                    'warning': 'Found in emails but not on website'
                }
                
                # Check if they responded
                if email in email_responses:
                    response = email_responses[email]
                    email_only_ref['response_date'] = response.get('date')
                    email_only_ref['email_decision'] = response.get('decision')
                
                enhanced_referees.append(email_only_ref)
        
        return enhanced_referees
    
    def _report_validation_issues(self, manuscripts: List[Dict]) -> None:
        """Report critical validation issues that require attention."""
        total_issues = 0
        critical_issues = 0
        
        for ms in manuscripts:
            issues = ms.get('validation_issues', [])
            total_issues += len(issues)
            critical_issues += sum(1 for issue in issues if issue['severity'] == 'critical')
        
        if critical_issues > 0:
            logger.error(f"CRITICAL: Found {critical_issues} timeline contradictions that need resolution!")
            logger.error("These indicate data integrity issues between web and email sources.")
            
            # Show examples of critical issues
            for ms in manuscripts[:3]:  # First 3 manuscripts
                if ms.get('has_critical_issues'):
                    logger.error(f"\nManuscript {ms['id']}:")
                    for issue in ms['validation_issues']:
                        if issue['severity'] == 'critical':
                            logger.error(f"  - {issue['description']}")
        
        logger.info(f"Timeline validation complete: {total_issues} total issues, {critical_issues} critical")
    
    def _login(self) -> None:
        """Login to SICON using ORCID authentication."""
        # Use the existing login method from parent class
        super()._login()
    
    def extract_manuscripts(self) -> List[Dict[str, Any]]:
        """Extract manuscripts using the existing method."""
        # Use the existing method but ensure it returns data
        if hasattr(super(), 'extract_manuscripts'):
            return super().extract_manuscripts()
        else:
            # Implement the extraction logic here
            return self._extract_manuscripts_impl()
    
    def _extract_manuscripts_impl(self) -> List[Dict[str, Any]]:
        """Implementation of manuscript extraction following exact workflow."""
        try:
            manuscripts = []
            
            # Step 4: Navigate to manuscript folders
            self._handle_popups()
            task_links = self._navigate_manuscript_folders()
            
            if not task_links:
                logger.warning("No AE task links found")
                return []
            
            # Step 5: Extract manuscript IDs
            manuscript_urls = self._extract_manuscript_ids(task_links)
            
            if not manuscript_urls:
                logger.warning("No manuscript URLs found")
                return []
            
            # Step 6: Extract manuscript details
            self._extract_manuscript_details(manuscript_urls)
            
            return self.manuscripts
            
        except Exception as e:
            logger.error(f"Manuscript extraction failed: {e}")
            return []


# Convenience function for testing
def test_sicon_extraction(validate_timeline: bool = True):
    """Test SICON extraction with timeline validation."""
    from editorial_assistant.core.data_models import JournalConfig
    
    config = JournalConfig(
        code="SICON",
        name="SIAM Journal on Control and Optimization",
        url="https://sicon.siam.org/cgi-bin/main.plex",
        platform="siam_orcid",
        credentials={
            "username_env": "ORCID_EMAIL",
            "password_env": "ORCID_PASSWORD"
        }
    )
    
    extractor = SICONCompleteExtractor(config, validate_timeline=validate_timeline)
    manuscripts = extractor.extract_data()
    
    # Save results
    output_file = f"sicon_complete_extraction_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_file, 'w') as f:
        json.dump(manuscripts, f, indent=2, default=str)
    
    print(f"\nExtraction complete!")
    print(f"Total manuscripts: {len(manuscripts)}")
    
    # Summary of validation issues
    total_critical = sum(1 for ms in manuscripts if ms.get('has_critical_issues'))
    if total_critical > 0:
        print(f"\n⚠️  WARNING: {total_critical} manuscripts have critical timeline issues!")
    else:
        print("\n✅ No critical timeline issues found")
    
    print(f"\nResults saved to: {output_file}")
    
    return manuscripts


if __name__ == "__main__":
    test_sicon_extraction(validate_timeline=True)