#!/usr/bin/env python3
"""
Debug MOR login page to see what's happening
"""

import os
import sys
import time
import logging
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from editorial_assistant.core.browser_manager import BrowserManager
from core.email_utils import fetch_latest_verification_code

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def debug_mor_login():
    """Debug MOR login to see what's happening."""
    logger.info("🧪 Debugging MOR login")
    
    # Load production config
    with open('.env.production', 'r') as f:
        for line in f:
            if '=' in line and not line.startswith('#'):
                key, value = line.strip().split('=', 1)
                os.environ[key] = value
    
    try:
        # Create browser
        browser_manager = BrowserManager(headless=False)
        driver = browser_manager.create_driver()
        
        # Navigate to MOR
        logger.info("📍 Navigating to MOR")
        driver.get("https://mc.manuscriptcentral.com/mathor")
        time.sleep(3)
        
        # Accept cookies
        try:
            accept_btn = driver.find_element("id", "onetrust-accept-btn-handler")
            if accept_btn.is_displayed():
                accept_btn.click()
                time.sleep(1)
        except:
            pass
        
        # Login
        logger.info("📍 Logging in to MOR")
        user = os.environ.get('MOR_EMAIL')
        password = os.environ.get('MOR_PASSWORD')
        
        logger.info(f"   Using email: {user}")
        
        user_box = driver.find_element("id", "USERID")
        pw_box = driver.find_element("id", "PASSWORD")
        
        user_box.clear()
        user_box.send_keys(user)
        pw_box.clear()
        pw_box.send_keys(password)
        
        login_btn = driver.find_element("id", "logInButton")
        login_btn.click()
        time.sleep(10)
        
        # Check current state
        current_url = driver.current_url
        page_source = driver.page_source
        
        logger.info(f"Current URL: {current_url}")
        
        # Check for device verification
        if "UNRECOGNIZED_DEVICE" in page_source:
            logger.info("📍 Device verification needed")
            verification_input = driver.find_element("id", "TOKEN_VALUE")
            verification_code = fetch_latest_verification_code(journal="MOR", max_wait=300, poll_interval=10)
            
            if verification_code:
                logger.info(f"✅ Got verification code: {verification_code}")
                verification_input.clear()
                verification_input.send_keys(verification_code)
                verification_input.send_keys("\\n")
                time.sleep(10)
                
                # Check again after verification
                current_url = driver.current_url
                page_source = driver.page_source
                logger.info(f"After verification URL: {current_url}")
            else:
                logger.error("❌ No verification code found")
        
        # Check for login success indicators
        login_indicators = [
            "Associate Editor Center",
            "Author Center", 
            "Reviewer Center",
            "Logout",
            "Sign Out",
            "Welcome"
        ]
        
        found_indicators = []
        for indicator in login_indicators:
            if indicator in page_source:
                found_indicators.append(indicator)
        
        if found_indicators:
            logger.info(f"✅ Found login indicators: {found_indicators}")
        else:
            logger.error("❌ No login indicators found")
            
        # Check for error messages
        if "login" in current_url.lower():
            logger.error("❌ Still on login page")
        if "error" in page_source.lower():
            logger.error("❌ Error message found in page")
        if "invalid" in page_source.lower():
            logger.error("❌ Invalid credentials message found")
            
        # Show all links for debugging
        logger.info("📍 All available links:")
        links = driver.find_elements("tag name", "a")
        for i, link in enumerate(links):
            try:
                link_text = link.text.strip()
                href = link.get_attribute('href')
                if link_text and len(link_text) > 3:
                    logger.info(f"  Link {i+1}: '{link_text}' -> {href}")
            except:
                pass
        
        # Keep browser open for inspection
        input("Press Enter to close browser...")
        
    except Exception as e:
        logger.error(f"❌ Error debugging MOR login: {e}")
        import traceback
        traceback.print_exc()
    finally:
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    debug_mor_login()