#!/usr/bin/env python3
"""
Patch script to fix the Take Action clicking issue in ScholarOne extractor.
This script will update the ScholarOne extractor with the working click method.
"""

import sys
from pathlib import Path

def apply_patch():
    """Apply the fix to ScholarOne extractor."""
    
    # Read the current ScholarOne extractor
    extractor_path = Path("/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/editorial_assistant/extractors/scholarone.py")
    
    if not extractor_path.exists():
        print(f"❌ ScholarOne extractor not found at {extractor_path}")
        return False
    
    with open(extractor_path, 'r') as f:
        content = f.read()
    
    # The fixed method
    fixed_method = '''    def _click_take_action_for_manuscript(self, manuscript_id: str) -> bool:
        """
        Find and click Take Action link for a specific manuscript.
        
        FIXED VERSION: Focuses on the exact HTML structure where Take Action is in the LAST COLUMN.
        """
        try:
            self.logger.info(f"Looking for Take Action link for {manuscript_id}")
            
            # Find ALL table rows on the page
            all_rows = self.driver.find_elements(By.TAG_NAME, "tr")
            self.logger.info(f"Scanning {len(all_rows)} rows for {manuscript_id}")
            
            for row in all_rows:
                try:
                    row_text = row.text.strip()
                    
                    # Skip if this row doesn't contain our manuscript ID
                    if not row_text or manuscript_id not in row_text:
                        continue
                    
                    self.logger.info(f"Found row containing {manuscript_id}")
                    
                    # Get all cells in this row
                    cells = row.find_elements(By.TAG_NAME, "td")
                    if not cells:
                        continue
                    
                    # CRITICAL: Take Action is ALWAYS in the LAST cell
                    last_cell = cells[-1]
                    
                    # Look for the check_off.gif image in the last cell
                    take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
                    
                    if take_action_links:
                        link = take_action_links[0]
                        self.logger.info("✅ Found Take Action link with check_off.gif in last column")
                        
                        # Get href for debugging
                        href = link.get_attribute('href')
                        self.logger.debug(f"Take Action href: {href[:100]}...")
                        
                        # Try direct click
                        try:
                            link.click()
                            self._wait_for_page_load()
                            
                            # Verify we navigated to manuscript details
                            page_text = self.driver.find_element(By.TAG_NAME, "body").text
                            if "Manuscript Details" in page_text or "Reviewer" in page_text:
                                self.logger.info(f"✅ Successfully clicked Take Action for {manuscript_id}")
                                return True
                        except:
                            # Fallback to JavaScript execution
                            if href and 'javascript:' in href:
                                js_code = href.replace('javascript:', '')
                                self.driver.execute_script(js_code)
                                self._wait_for_page_load()
                                
                                page_text = self.driver.find_element(By.TAG_NAME, "body").text
                                if "Manuscript Details" in page_text or "Reviewer" in page_text:
                                    self.logger.info(f"✅ Successfully executed Take Action JavaScript for {manuscript_id}")
                                    return True
                    
                    # Alternative: Look for ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS link in last cell
                    detail_links = last_cell.find_elements(By.XPATH, ".//a[contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
                    if detail_links:
                        link = detail_links[0]
                        href = link.get_attribute('href')
                        if href and 'javascript:' in href:
                            js_code = href.replace('javascript:', '')
                            self.driver.execute_script(js_code)
                            self._wait_for_page_load()
                            
                            page_text = self.driver.find_element(By.TAG_NAME, "body").text
                            if "Manuscript Details" in page_text or "Reviewer" in page_text:
                                self.logger.info(f"✅ Successfully executed manuscript details JavaScript for {manuscript_id}")
                                return True
                            
                except Exception as e:
                    self.logger.debug(f"Error processing row: {e}")
                    continue
            
            self.logger.error(f"❌ Could not find Take Action link for {manuscript_id}")
            
            # Save debug info
            debug_file = f"{self.journal.code.lower()}_no_take_action_{manuscript_id}.html"
            with open(debug_file, 'w') as f:
                f.write(self.driver.page_source)
            self.logger.error(f"Saved debug HTML to {debug_file}")
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error clicking Take Action for {manuscript_id}: {e}")
            return False'''
    
    # Find the start of the current method
    method_start = content.find("    def _click_take_action_for_manuscript(self, manuscript_id: str) -> bool:")
    if method_start == -1:
        print("❌ Could not find _click_take_action_for_manuscript method")
        return False
    
    # Find the end of the method (next method definition or class end)
    method_end = content.find("\n    def ", method_start + 1)
    if method_end == -1:
        # Maybe it's the last method in the class
        method_end = content.find("\n\nclass", method_start + 1)
        if method_end == -1:
            method_end = len(content)
    
    # Replace the method
    new_content = content[:method_start] + fixed_method + content[method_end:]
    
    # Backup the original file
    backup_path = extractor_path.with_suffix('.py.backup')
    with open(backup_path, 'w') as f:
        f.write(content)
    print(f"✅ Backed up original to {backup_path}")
    
    # Write the patched version
    with open(extractor_path, 'w') as f:
        f.write(new_content)
    print(f"✅ Patched {extractor_path}")
    
    return True


def main():
    """Main function."""
    print("=== ScholarOne Take Action Fix Patch ===")
    print("\nThis will patch the ScholarOne extractor to fix the Take Action clicking issue.")
    
    response = input("\nProceed with patching? (y/n): ").strip().lower()
    if response != 'y':
        print("Patch cancelled")
        return
    
    if apply_patch():
        print("\n✅ Patch applied successfully!")
        print("\nThe fix:")
        print("1. Focuses ONLY on the last column where Take Action is located")
        print("2. Looks specifically for the check_off.gif image")
        print("3. Has better error handling and debugging")
        print("4. Verifies that navigation actually occurred")
        print("\nYou can now run the extraction and it should work properly.")
    else:
        print("\n❌ Patch failed!")


if __name__ == "__main__":
    main()