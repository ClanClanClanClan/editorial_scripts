#!/usr/bin/env python3
"""
Foolproof SIFIN Adapter
Uses the foolproof referee tracker for validated referee identification
"""

import sys
import os
import json
import re
from datetime import datetime, timezone
from typing import List, Dict, Optional

# Add path to import existing SIFIN parser
sys.path.append('/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/scripts/sifin')

from foolproof_referee_tracker import FoolproofRefereeTracker
from referee_email_tracker import EmailEvent

try:
    from parse_sifin_emails import SIFINEmailParser
except ImportError:
    print("Warning: Could not import SIFINEmailParser. Running in standalone mode.")
    SIFINEmailParser = None

class FoolproofSIFINAdapter:
    """Foolproof adapter for SIFIN with comprehensive validation"""
    
    def __init__(self):
        self.referee_tracker = FoolproofRefereeTracker()
        self.sifin_parser = SIFINEmailParser() if SIFINEmailParser else None
        
        # Enhanced SIFIN patterns
        self.enhance_sifin_patterns()
    
    def enhance_sifin_patterns(self):
        """Add SIFIN-specific patterns with validation"""
        sifin_patterns = {
            'invitation': [
                r'SIFIN.*invitation.*referee',
                r'SIFIN.*[Ii]nvitation.*[Mm]anuscript\s+(M\d+)',
                r'SIFIN.*[Rr]eview.*[Rr]equest.*[Mm]anuscript\s+(M\d+)',
                r'SIFIN.*[Rr]eferee.*[Ii]nvitation.*[Mm]anuscript\s+(M\d+)',
                r'[Ii]nvitation.*[Rr]eview.*[Mm]anuscript\s+(M\d+).*SIFIN',
                r'[Ww]ould\s+you\s+be\s+(?:willing|able)\s+to\s+(?:referee|review)',
            ],
            'reminder': [
                r'SIFIN\s+(M\d+)\s+--\s+.*[Oo]verdue',
                r'SIFIN\s+(M\d+)\s+-\s+[Ff]ollow-up.*[Mm]essage',
                r'SIFIN\s+(M\d+)\s+--\s+.*[Rr]eview.*[Tt]hree-[Mm]onth.*[Mm]ark',
                r'SIFIN\s+(M\d+)\s+--\s+.*[Rr]eview.*[Rr]equested.*[Oo]verdue',
                r'SIFIN\s+(M\d+)\s+--\s+.*[Rr]eminder',
                r'SIFIN\s+(M\d+)\s+-\s+.*[Rr]eminder',
            ],
            'submission': [
                r'SIFIN.*[Rr]eport.*[Rr]eceived.*[Mm]anuscript\s+(M\d+)',
                r'SIFIN\s+(M\d+).*[Rr]eport.*[Rr]eceived',
                r'SIAM.*[Ff]inancial.*[Mm]athematics.*[Mm]anuscript\s+#(M\d+).*[Rr]eport.*[Rr]eceived',
                # Enhanced patterns for referee name capture with validation
                r'([A-Z][a-z]{2,}\s+[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\s+has\s+submitted\s+a\s+report',
                r'([A-Z][a-z]{2,}\s+[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\s+has\s+submitted\s+(?:a\s+)?(?:referee\s+)?report',
            ],
            'acceptance': [
                r'SIFIN.*[Rr]eferee\s+(accepted|agreed).*[Mm]anuscript\s+(M\d+)',
                r'SIFIN\s+(M\d+).*[Rr]eferee\s+(accepted|agreed)',
                r'([A-Z][a-z]{2,}\s+[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\s+has\s+accepted\s+to\s+review',
                r'([A-Z][a-z]{2,}\s+[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\s+has\s+agreed\s+to\s+review',
            ],
            'decline': [
                r'SIFIN.*[Rr]eferee\s+(declined|refused).*[Mm]anuscript\s+(M\d+)',
                r'SIFIN\s+(M\d+).*[Rr]eferee\s+(declined|refused)',
                r'([A-Z][a-z]{2,}\s+[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\s+has\s+declined\s+to\s+review',
                r'([A-Z][a-z]{2,}\s+[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\s+(?:is\s+)?unable\s+to\s+review',
            ]
        }
        
        # Add patterns to foolproof tracker
        for event_type, patterns in sifin_patterns.items():
            self.referee_tracker.pattern_matcher.patterns[event_type].extend(patterns)
    
    def convert_sifin_email_to_generic(self, gmail_message: Dict) -> Optional[EmailEvent]:
        """Convert SIFIN Gmail message to generic EmailEvent with validation"""
        try:
            # Extract headers
            headers = {}
            payload = gmail_message.get('payload', {})
            
            for header in payload.get('headers', []):
                name = header.get('name', '').lower()
                if name in ['subject', 'from', 'to', 'date', 'cc', 'bcc']:
                    headers[name] = header.get('value', '')
            
            # Extract and clean body
            body = self._extract_email_body(payload)
            body = self._clean_email_body(body)
            
            # Parse addresses
            to_addresses = self._parse_email_addresses(headers.get('to', ''))
            cc_addresses = self._parse_email_addresses(headers.get('cc', ''))
            
            # Parse date
            date_str = headers.get('date', '')
            try:
                from email.utils import parsedate_to_datetime
                email_date = parsedate_to_datetime(date_str)
                if email_date.tzinfo is None:
                    email_date = email_date.replace(tzinfo=timezone.utc)
            except:
                email_date = datetime.now(timezone.utc)
            
            # Extract and validate manuscript ID
            manuscript_id = self._extract_manuscript_id(headers.get('subject', ''), body)
            
            if not manuscript_id:
                return None
            
            # Create EmailEvent
            return EmailEvent(
                message_id=gmail_message.get('id', ''),
                thread_id=gmail_message.get('threadId', ''),
                date=email_date,
                subject=headers.get('subject', ''),
                from_address=headers.get('from', ''),
                to_addresses=to_addresses,
                cc_addresses=cc_addresses,
                body=body,
                event_type='unknown',  # Will be determined by pattern matcher
                manuscript_id=manuscript_id
            )
            
        except Exception as e:
            print(f"Error converting email: {e}")
            return None
    
    def _extract_email_body(self, payload: Dict) -> str:
        """Extract body text from email payload"""
        body = ""
        
        def extract_text_recursive(part):
            nonlocal body
            if 'parts' in part:
                for subpart in part['parts']:
                    extract_text_recursive(subpart)
            elif part.get('mimeType') == 'text/plain':
                data = part.get('body', {}).get('data', '')
                if data:
                    import base64
                    try:
                        decoded = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                        body += decoded + "\n"
                    except:
                        pass
        
        extract_text_recursive(payload)
        return body
    
    def _clean_email_body(self, body: str) -> str:
        """Clean email body of noise and artifacts"""
        if not body:
            return ""
        
        # Remove email signatures
        body = re.sub(r'--\s*\n.*', '', body, flags=re.DOTALL)
        
        # Remove excessive whitespace
        body = re.sub(r'\n\s*\n', '\n\n', body)
        body = re.sub(r'\s+', ' ', body)
        
        # Remove email threading artifacts
        body = re.sub(r'On\s+.*wrote:', '', body, flags=re.IGNORECASE)
        body = re.sub(r'From:.*To:.*Subject:', '', body, flags=re.IGNORECASE)
        
        return body.strip()
    
    def _parse_email_addresses(self, address_string: str) -> List[str]:
        """Parse and validate email addresses"""
        if not address_string:
            return []
        
        # Extract email addresses
        emails = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', address_string)
        
        # Validate and filter
        valid_emails = []
        for email in emails:
            if self._is_valid_email(email):
                valid_emails.append(email.lower())
        
        return valid_emails
    
    def _is_valid_email(self, email: str) -> bool:
        """Validate email format and content"""
        if not email or '@' not in email:
            return False
        
        # Check basic format
        parts = email.split('@')
        if len(parts) != 2:
            return False
        
        username, domain = parts
        
        # Basic validation
        if len(username) < 1 or len(domain) < 3:
            return False
        
        if not domain.count('.') >= 1:
            return False
        
        return True
    
    def _extract_manuscript_id(self, subject: str, body: str) -> Optional[str]:
        """Extract and validate manuscript ID"""
        text = f"{subject} {body}"
        
        # SIFIN patterns for manuscript ID
        patterns = [
            r'SIFIN\s+(M\d+)',
            r'[Mm]anuscript\s+#?(M\d+)',
            r'(M\d{6})',  # 6-digit manuscript IDs
            r'(M\d{5})',  # 5-digit manuscript IDs
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                manuscript_id = match.group(1)
                if self._is_valid_manuscript_id(manuscript_id):
                    return manuscript_id
        
        return None
    
    def _is_valid_manuscript_id(self, manuscript_id: str) -> bool:
        """Validate manuscript ID format"""
        if not manuscript_id:
            return False
        
        # Must start with M and have digits
        if not re.match(r'^M\d{5,6}$', manuscript_id):
            return False
        
        # Check if it's a reasonable ID (not too old or too new)
        try:
            id_number = int(manuscript_id[1:])
            return 100000 <= id_number <= 999999
        except:
            return False
    
    def process_sifin_emails(self, manuscript_ids: List[str]) -> Dict:
        """Process SIFIN emails with foolproof validation"""
        if not self.sifin_parser:
            print("SIFIN parser not available")
            return {}
        
        print(f"🔍 Processing SIFIN emails with foolproof validation: {manuscript_ids}")
        
        # Setup Gmail service
        if not self.sifin_parser.setup_gmail_service():
            print("❌ Failed to setup Gmail service")
            return {}
        
        # Fetch emails
        all_emails = []
        for manuscript_id in manuscript_ids:
            emails = self._fetch_manuscript_emails(manuscript_id)
            all_emails.extend(emails)
        
        print(f"📧 Found {len(all_emails)} emails total")
        
        # Convert to generic format and process
        processed_emails = []
        for gmail_msg in all_emails:
            email_event = self.convert_sifin_email_to_generic(gmail_msg)
            if email_event:
                # Process with foolproof tracker
                processed_email = self.referee_tracker.process_email(email_event)
                processed_emails.append(processed_email)
        
        # Finalize with entity resolution and validation
        self.referee_tracker.finalize_processing()
        
        print(f"✅ Processed {len(processed_emails)} emails with validation")
        
        # Generate analytics for each manuscript
        results = {}
        for manuscript_id in manuscript_ids:
            analytics = self.referee_tracker.generate_analytics(manuscript_id)
            timeline = self.referee_tracker.get_referee_timeline(manuscript_id)
            report = self.referee_tracker.generate_foolproof_report(manuscript_id)
            
            results[manuscript_id] = {
                'analytics': analytics,
                'timeline': timeline,
                'foolproof_report': report,
                'attribution_stats': self._calculate_attribution_stats(analytics, timeline)
            }
        
        return results
    
    def _fetch_manuscript_emails(self, manuscript_id: str) -> List[Dict]:
        """Fetch emails for a specific manuscript"""
        queries = [
            f'from:sifin.siam.org {manuscript_id}',
            f'subject:SIFIN {manuscript_id}',
            f'subject:"{manuscript_id}"',
        ]
        
        all_emails = []
        seen_ids = set()
        
        for query in queries:
            try:
                response = self.sifin_parser.gmail_service.users().messages().list(
                    userId='me',
                    q=query,
                    maxResults=50
                ).execute()
                
                messages = response.get('messages', [])
                
                for msg in messages:
                    if msg['id'] in seen_ids:
                        continue
                    seen_ids.add(msg['id'])
                    
                    full_msg = self.sifin_parser.gmail_service.users().messages().get(
                        userId='me',
                        id=msg['id'],
                        format='full'
                    ).execute()
                    
                    all_emails.append(full_msg)
                    
            except Exception as e:
                print(f"Error with query '{query}': {e}")
        
        return all_emails
    
    def _calculate_attribution_stats(self, analytics: Dict, timeline: Dict) -> Dict:
        """Calculate attribution statistics"""
        total_emails = sum(len(emails) for emails in timeline.values())
        
        # Count referee emails (excluding editorial)
        referee_emails = 0
        for referee_id, emails in timeline.items():
            if referee_id in analytics['referees']:
                referee_emails += len(emails)
        
        # Count editorial emails
        editorial_emails = 0
        for referee_id, emails in timeline.items():
            if referee_id in analytics.get('editorial_contacts', {}):
                editorial_emails += len(emails)
        
        return {
            'total_emails': total_emails,
            'referee_emails': referee_emails,
            'editorial_emails': editorial_emails,
            'validated_referees': analytics['total_referees'],
            'editorial_contacts': analytics['total_editorial_contacts'],
            'referee_attribution_rate': referee_emails / total_emails if total_emails > 0 else 0.0,
            'editorial_attribution_rate': editorial_emails / total_emails if total_emails > 0 else 0.0
        }
    
    def save_foolproof_results(self, results: Dict, filename: str = None) -> str:
        """Save foolproof results to JSON file"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"sifin_foolproof_results_{timestamp}.json"
        
        # Convert to serializable format
        serializable_results = {}
        for manuscript_id, data in results.items():
            # Convert timeline data
            timeline_data = {}
            for referee_id, emails in data['timeline'].items():
                timeline_data[referee_id] = []
                for email in emails:
                    email_dict = {
                        'message_id': email.message_id,
                        'date': email.date.isoformat(),
                        'subject': email.subject,
                        'event_type': email.event_type,
                        'attribution': {
                            'referee_id': email.attribution.referee_id,
                            'confidence': email.attribution.confidence,
                            'evidence': email.attribution.evidence,
                            'method': email.attribution.attribution_method
                        } if email.attribution else None
                    }
                    timeline_data[referee_id].append(email_dict)
            
            serializable_results[manuscript_id] = {
                'analytics': data['analytics'],
                'timeline': timeline_data,
                'attribution_stats': data['attribution_stats'],
                'foolproof_report': data['foolproof_report']
            }
        
        with open(filename, 'w') as f:
            json.dump(serializable_results, f, indent=2)
        
        print(f"📄 Foolproof results saved to: {filename}")
        return filename

def main():
    """Test the foolproof SIFIN adapter"""
    adapter = FoolproofSIFINAdapter()
    
    # Test with known SIFIN manuscript IDs
    manuscript_ids = ["M174160", "M174727", "M175988", "M176140"]
    
    print("🚀 Testing Foolproof SIFIN Adapter")
    print("=" * 60)
    
    # Process emails
    results = adapter.process_sifin_emails(manuscript_ids)
    
    if results:
        # Display reports
        for manuscript_id, data in results.items():
            print(f"\n{data['foolproof_report']}")
            
            stats = data['attribution_stats']
            print(f"📊 Attribution Statistics:")
            print(f"   Total Emails: {stats['total_emails']}")
            print(f"   Referee Emails: {stats['referee_emails']}")
            print(f"   Editorial Emails: {stats['editorial_emails']}")
            print(f"   Validated Referees: {stats['validated_referees']}")
            print(f"   Referee Attribution Rate: {stats['referee_attribution_rate']:.1%}")
            print("=" * 60)
        
        # Save results
        filename = adapter.save_foolproof_results(results)
        
        print(f"\n🎉 Foolproof SIFIN Processing Complete!")
        print(f"📊 Results saved to: {filename}")
        
    else:
        print("❌ No results generated")

if __name__ == "__main__":
    main()