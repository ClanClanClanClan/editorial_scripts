#!/usr/bin/env python3
"""Test regex-based referee extraction"""

import os
import sys
import time
from pathlib import Path
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

def test_regex_extraction():
    """Test the regex-based referee extraction directly"""
    
    print("🎯 TESTING REGEX-BASED REFEREE EXTRACTION")
    print("=" * 50)
    
    # Chrome setup
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        # Quick login (we know this works)
        print("1. Quick login...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        try:
            reject_btn = driver.find_element(By.ID, "onetrust-reject-all-handler")
            reject_btn.click()
        except:
            pass
        
        email_field = driver.find_element(By.ID, "USERID")
        email_field.send_keys(os.getenv('MF_EMAIL'))
        password_field = driver.find_element(By.ID, "PASSWORD")
        password_field.send_keys(os.getenv('MF_PASSWORD'))
        login_btn = driver.find_element(By.ID, "logInButton")
        driver.execute_script("arguments[0].click();", login_btn)
        time.sleep(3)
        
        # Handle 2FA
        try:
            code_input = driver.find_element(By.ID, "TOKEN_VALUE")
            from core.email_utils import fetch_latest_verification_code
            time.sleep(5)
            verification_code = fetch_latest_verification_code('MF', max_wait=60, poll_interval=3)
            if verification_code:
                code_input.clear()
                code_input.send_keys(verification_code)
                try:
                    remember_checkbox = driver.find_element(By.ID, "REMEMBER_THIS_DEVICE")
                    if not remember_checkbox.is_selected():
                        remember_checkbox.click()
                except:
                    pass
                verify_btn = driver.find_element(By.ID, "VERIFY_BTN")
                verify_btn.click()
                time.sleep(15)
        except:
            pass
        
        # Navigate and click Take Action
        print("2. Navigating and clicking Take Action...")
        ae_link = driver.find_element(By.LINK_TEXT, "Associate Editor Center")
        ae_link.click()
        time.sleep(5)
        
        category_link = driver.find_element(By.LINK_TEXT, "Awaiting Reviewer Scores")
        category_link.click()
        time.sleep(5)
        
        # Find and click Take Action
        all_rows = driver.find_elements(By.TAG_NAME, "tr")
        for row in all_rows:
            if 'MAFI-' in row.text:
                cells = row.find_elements(By.TAG_NAME, "td")
                if cells:
                    last_cell = cells[-1]
                    take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
                    if take_action_links:
                        href = take_action_links[0].get_attribute('href')
                        if href and 'javascript:' in href:
                            js_code = href.replace('javascript:', '')
                            driver.execute_script(js_code)
                            time.sleep(5)
                            print("✅ Take Action clicked successfully")
                            break
        
        # Test regex extraction directly
        print("3. TESTING REGEX EXTRACTION...")
        print("-" * 50)
        
        page_text = driver.find_element(By.TAG_NAME, "body").text
        print(f"Page text length: {len(page_text)}")
        
        # Save a sample of the page text for debugging
        with open('page_text_sample.txt', 'w') as f:
            f.write(page_text[:5000])  # First 5000 characters
        print("Saved page text sample to page_text_sample.txt")
        
        # Test the exact regex pattern
        import re
        
        # Try different patterns
        patterns = [
            r'([A-Z][a-z]+,\s+[A-Z][a-z]+)\s+([^.]+?)\s+(?:https://orcid\.org/([0-9\-X]+))?\s*(Agreed|Declined|Unavailable|Pending|Invited)',
            r'([A-Z][a-z]+,\s+[A-Z][a-z\s]+)\s+University\s+([^.]+)\s+(Agreed|Declined|Unavailable|Pending)',
            r'(Liang,\s+Gechun|Mrad,\s+Mohamed|Dos Reis,\s+Goncalo|Strub,\s+Moris)\s+([^.]+?)\s+(Agreed|Declined|Unavailable|Pending)'
        ]
        
        for i, pattern in enumerate(patterns):
            print(f"\n🔍 Testing pattern {i+1}: {pattern}")
            matches = re.findall(pattern, page_text, re.MULTILINE | re.DOTALL)
            print(f"Found {len(matches)} matches")
            
            for j, match in enumerate(matches):
                print(f"  Match {j+1}: {match}")
        
        # Try a simpler approach - just look for the known names
        print(f"\n📝 SIMPLE NAME SEARCH:")
        referee_names = ['Liang, Gechun', 'Mrad, Mohamed', 'Dos Reis, Goncalo', 'Strub, Moris']
        
        for name in referee_names:
            if name in page_text:
                print(f"✅ Found: {name}")
                
                # Find the surrounding context
                name_pos = page_text.find(name)
                start = max(0, name_pos - 200)
                end = min(len(page_text), name_pos + 500)
                context = page_text[start:end]
                
                print(f"Context: ...{context}...")
                
                # Look for status words near the name
                status_words = ['Agreed', 'Declined', 'Unavailable', 'Pending', 'Invited']
                for status in status_words:
                    if status in context:
                        print(f"  Status: {status}")
                        break
                print("-" * 30)
            else:
                print(f"❌ Not found: {name}")
        
        # Test the new extraction method
        print(f"\n🧪 TESTING NEW EXTRACTION METHOD:")
        from editorial_assistant.extractors.scholarone import ScholarOneExtractor
        from editorial_assistant.core.data_models import Journal, Platform
        
        # Create a journal object
        journal = Journal(
            code='MF', 
            name='Mathematical Finance',
            platform=Platform.SCHOLARONE,
            url='https://mc.manuscriptcentral.com/mafi'
        )
        
        # Create extractor and set up driver
        extractor = ScholarOneExtractor(journal)
        extractor.driver = driver
        
        # Set up logging
        import logging
        logging.basicConfig(level=logging.INFO)
        extractor.logger = logging.getLogger('test_extractor')
        
        # Extract referees
        referees = extractor._extract_referees()
        
        print(f"\n📊 EXTRACTION RESULTS:")
        print(f"Total referees extracted: {len(referees)}")
        
        for i, referee in enumerate(referees):
            print(f"\n📄 Referee {i+1}:")
            print(f"   Name: {referee.name}")
            print(f"   Status: {referee.status}")
            print(f"   Institution: {referee.institution}")
            print(f"   ORCID: {referee.orcid}")
        
        if len(referees) > 0:
            print(f"\n🎉 SUCCESS! Extracted {len(referees)} referees using new method!")
        else:
            print(f"\n❌ No referees extracted - need further debugging")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        driver.quit()

if __name__ == "__main__":
    test_regex_extraction()