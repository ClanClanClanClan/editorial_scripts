# Editorial Scripts v3.0

A pristine-plus architecture implementation for editorial manuscript processing.

## Architecture

This project follows the pristine-plus architecture pattern with:

- **Foundation Layer**: Core types, value objects, and base classes
- **Domain Layer**: Business entities, value objects, and domain services
- **Application Layer**: Use cases and application services
- **Infrastructure Layer**: External integrations, repositories, and configuration
- **Presentation Layer**: API and CLI interfaces

## Project Structure

```
editorial_scripts_v3/
├── src/
│   ├── foundation/       # Core types and value objects
│   ├── domain/          # Business entities and logic
│   ├── application/     # Use cases
│   ├── infrastructure/  # External integrations
│   └── presentation/    # User interfaces
├── tests/
│   ├── unit/           # Unit tests
│   ├── integration/    # Integration tests
│   └── e2e/           # End-to-end tests
├── docs/               # Documentation
└── scripts/           # Utility scripts
```

## Setup

1. Install Poetry:
   ```bash
   curl -sSL https://install.python-poetry.org | python3 -
   ```

2. Install dependencies:
   ```bash
   make dev-install
   ```

3. Run tests:
   ```bash
   make test
   ```

## Development

### Running Tests

```bash
# Run all tests
make test

# Run unit tests only
make test-unit

# Run with coverage
make coverage
```

### Code Quality

```bash
# Run all linters
make lint

# Format code
make format

# Type checking
make type-check

# Security checks
make security-check
```

### Pre-commit Hooks

Pre-commit hooks are automatically installed with `make dev-install`. They run:
- Code formatting (black, isort)
- Linting (ruff)
- Type checking (mypy)
- Security checks (bandit)

## Key Design Principles

1. **Immutability**: All value objects are immutable using Pydantic's `frozen=True`
2. **Type Safety**: Strict typing with mypy and custom type validators
3. **Domain Isolation**: Domain entities don't depend on infrastructure
4. **Result Types**: Using Result[T, E] for error handling without exceptions
5. **Value Objects**: Rich domain modeling with validated value objects

## Core Components

### Foundation Layer

- `types.py`: Core type definitions with validation
- `value_objects.py`: Immutable value objects (EmailAddress, FullName, etc.)

### Domain Layer

- `entities/`: Core business entities (Manuscript, Author, Editor, etc.)
- `value_objects/`: Domain-specific value objects and enums

### Testing

- Comprehensive unit tests with pytest
- Fixtures using Faker for realistic test data
- Property-based testing with Hypothesis
- Coverage enforcement at 80%

## Make Commands

Run `make help` to see all available commands.

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines on how to contribute to this project.

## Third-Party Licenses

This project uses various third-party libraries. See [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md) for a complete list of licenses and compatibility analysis.

## Security

For security vulnerabilities, please follow responsible disclosure practices. Create a GitHub issue for non-sensitive bugs, or contact the maintainers directly for security-related issues.