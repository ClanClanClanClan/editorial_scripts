#!/usr/bin/env python3
"""
Get the actual manuscript details: titles, authors, PDFs, cover letters, referees
"""

import os
import sys
import time
import logging
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from editorial_assistant.extractors.scholarone import ScholarOneExtractor

# Set up logging to be less verbose
logging.basicConfig(level=logging.WARNING, format='%(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_actual_manuscript_details():
    """Get the actual manuscript details from the real website."""
    print("🎯 Getting ACTUAL manuscript details from MF website...")
    
    # Load production config
    try:
        with open('.env.production', 'r') as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    key, value = line.strip().split('=', 1)
                    os.environ[key] = value
    except FileNotFoundError:
        print("❌ No .env.production file found")
        return
    
    try:
        # Create extractor
        extractor = ScholarOneExtractor('MF')
        extractor.headless = True  # Run headless for speed
        
        # Get manuscripts
        print("🔄 Extracting manuscripts...")
        result = extractor.extract()
        
        if not result.manuscripts:
            print("❌ No manuscripts found")
            return
        
        print(f"\n📋 Found {len(result.manuscripts)} manuscripts")
        print("="*80)
        
        for i, manuscript in enumerate(result.manuscripts, 1):
            print(f"\n📄 MANUSCRIPT {i}")
            print("-" * 40)
            
            # Basic info
            print(f"ID: {manuscript.manuscript_id}")
            print(f"TITLE: {manuscript.title}")
            print(f"STATUS: {manuscript.status}")
            
            # Dates
            if hasattr(manuscript, 'submission_date') and manuscript.submission_date:
                print(f"SUBMITTED: {manuscript.submission_date}")
            if hasattr(manuscript, 'last_updated') and manuscript.last_updated:
                print(f"LAST UPDATED: {manuscript.last_updated}")
            if hasattr(manuscript, 'due_date') and manuscript.due_date:
                print(f"DUE DATE: {manuscript.due_date}")
            
            # Authors
            print(f"\nAUTHORS ({len(manuscript.authors)}):")
            for j, author in enumerate(manuscript.authors, 1):
                print(f"  {j}. {author.name}")
            
            # Documents
            print(f"\nDOCUMENTS:")
            if hasattr(manuscript, 'available_documents') and manuscript.available_documents:
                for doc_type, available in manuscript.available_documents.items():
                    status = "✅ Available" if available else "❌ Not available"
                    print(f"  {doc_type.upper()}: {status}")
            
            if hasattr(manuscript, 'pdf_path') and manuscript.pdf_path:
                print(f"  PDF PATH: {manuscript.pdf_path}")
            
            if hasattr(manuscript, 'cover_letter') and manuscript.cover_letter:
                print(f"  COVER LETTER: {len(manuscript.cover_letter)} characters")
                print(f"  COVER LETTER PREVIEW: {manuscript.cover_letter[:200]}...")
            
            # Referees
            print(f"\nREFEREES ({len(manuscript.referees)}):")
            if manuscript.referees:
                for j, referee in enumerate(manuscript.referees, 1):
                    print(f"  {j}. {referee.name}")
                    if referee.status:
                        print(f"     Status: {referee.status}")
                    if referee.institution:
                        print(f"     Institution: {referee.institution}")
                    if referee.email:
                        print(f"     Email: {referee.email}")
                    if referee.orcid:
                        print(f"     ORCID: {referee.orcid}")
            else:
                print("  No referees found")
            
            # Reviewer stats
            if hasattr(manuscript, 'reviewer_stats') and manuscript.reviewer_stats:
                stats = manuscript.reviewer_stats
                print(f"\nREVIEWER STATISTICS:")
                print(f"  Invited: {stats.get('invited', 0)}")
                print(f"  Agreed: {stats.get('agreed', 0)}")
                print(f"  Declined: {stats.get('declined', 0)}")
                print(f"  Returned: {stats.get('returned', 0)}")
            
            print("=" * 80)
        
        # Summary
        total_authors = sum(len(m.authors) for m in result.manuscripts)
        total_referees = sum(len(m.referees) for m in result.manuscripts)
        with_cover_letters = sum(1 for m in result.manuscripts if hasattr(m, 'cover_letter') and m.cover_letter)
        with_pdfs = sum(1 for m in result.manuscripts if hasattr(m, 'pdf_path') and m.pdf_path)
        
        print(f"\n📊 SUMMARY:")
        print(f"Total Manuscripts: {len(result.manuscripts)}")
        print(f"Total Authors: {total_authors}")
        print(f"Total Referees: {total_referees}")
        print(f"Manuscripts with Cover Letters: {with_cover_letters}")
        print(f"Manuscripts with PDFs: {with_pdfs}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    get_actual_manuscript_details()