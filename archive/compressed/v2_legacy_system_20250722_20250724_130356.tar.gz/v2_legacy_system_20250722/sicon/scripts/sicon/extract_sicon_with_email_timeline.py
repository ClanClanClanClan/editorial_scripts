#!/usr/bin/env python3
"""
SICON Extractor with Email Timeline Integration
Combines web extraction with email timeline parsing for complete referee data
"""

import os
import sys
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional

# Add parent directories to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from scripts.sicon.extract_sicon_exact_workflow import SICONExactExtractor
from scripts.sicon.parse_sicon_emails import SICONEmailParser, integrate_with_sicon_extractor

# Try to import Gmail utilities
try:
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    GMAIL_AVAILABLE = True
except ImportError:
    GMAIL_AVAILABLE = False
    print("⚠️ Gmail API not available. Install with: pip install google-auth google-auth-oauthlib google-api-python-client")

logger = logging.getLogger(__name__)

class SICONEmailTimelineExtractor:
    """Enhanced SICON extractor that includes email timeline data"""
    
    def __init__(self):
        self.web_extractor = SICONExactExtractor()
        self.email_parser = SICONEmailParser()
        self.gmail_service = None
        
    def setup_gmail_service(self):
        """Setup Gmail API service"""
        if not GMAIL_AVAILABLE:
            logger.warning("Gmail API libraries not available")
            return False
            
        try:
            # Check for token file
            token_path = Path(__file__).parent.parent / "setup" / "token.json"
            if not token_path.exists():
                # Try alternative locations
                alt_paths = [
                    Path.home() / ".config" / "editorial_scripts" / "gmail_token.json",
                    Path(__file__).parent.parent.parent / "credentials" / "gmail_token.json",
                ]
                for alt_path in alt_paths:
                    if alt_path.exists():
                        token_path = alt_path
                        break
                        
            if not token_path.exists():
                logger.error(f"Gmail token not found. Run setup_gmail_api.py first.")
                return False
                
            # Load credentials
            creds = Credentials.from_authorized_user_file(str(token_path))
            
            # Build service
            self.gmail_service = build('gmail', 'v1', credentials=creds)
            logger.info("✅ Gmail service initialized")
            return True
            
        except Exception as e:
            logger.error(f"Failed to setup Gmail service: {e}")
            return False
    
    def fetch_sicon_emails(self, days_back: int = 180) -> List[Dict]:
        """Fetch SICON-related emails from Gmail"""
        if not self.gmail_service:
            logger.warning("Gmail service not initialized")
            return []
            
        try:
            # Build search query
            after_date = datetime.now()
            after_date = after_date.replace(day=after_date.day - days_back)
            after_str = after_date.strftime('%Y/%m/%d')
            
            queries = [
                f'subject:SICON after:{after_str}',
                f'from:sicon.siam.org after:{after_str}',
                f'subject:"SIAM Journal on Control" after:{after_str}',
                f'(subject:"referee invitation" OR subject:"reviewer invitation") SICON after:{after_str}',
                f'(subject:"accepted to review" OR subject:"declined to review") SICON after:{after_str}'
            ]
            
            all_emails = []
            seen_ids = set()
            
            for query in queries:
                logger.info(f"Searching: {query}")
                
                try:
                    response = self.gmail_service.users().messages().list(
                        userId='me',
                        q=query,
                        maxResults=500
                    ).execute()
                    
                    messages = response.get('messages', [])
                    logger.info(f"  Found {len(messages)} messages")
                    
                    # Get full message details
                    for msg in messages:
                        if msg['id'] in seen_ids:
                            continue
                            
                        try:
                            full_msg = self.gmail_service.users().messages().get(
                                userId='me',
                                id=msg['id'],
                                format='full'
                            ).execute()
                            
                            # Parse email
                            email_data = self._parse_gmail_message(full_msg)
                            if email_data:
                                all_emails.append(email_data)
                                seen_ids.add(msg['id'])
                                
                        except Exception as e:
                            logger.warning(f"Error fetching message {msg['id']}: {e}")
                            
                except Exception as e:
                    logger.error(f"Error with query '{query}': {e}")
                    
            logger.info(f"✅ Fetched {len(all_emails)} unique SICON emails")
            return all_emails
            
        except Exception as e:
            logger.error(f"Failed to fetch emails: {e}")
            return []
    
    def _parse_gmail_message(self, message: Dict) -> Optional[Dict]:
        """Parse Gmail message into our email format"""
        try:
            # Extract headers
            headers = {}
            payload = message.get('payload', {})
            
            for header in payload.get('headers', []):
                name = header.get('name', '').lower()
                if name in ['subject', 'from', 'to', 'date']:
                    headers[name] = header.get('value', '')
            
            # Extract body
            body = self._extract_body(payload)
            
            # Get internal date
            internal_date = message.get('internalDate', '')
            if internal_date:
                # Convert milliseconds to datetime
                timestamp = int(internal_date) / 1000
                date_obj = datetime.fromtimestamp(timestamp)
                date_str = date_obj.isoformat() + 'Z'
            else:
                date_str = headers.get('date', '')
            
            return {
                'id': message.get('id'),
                'subject': headers.get('subject', ''),
                'from': headers.get('from', ''),
                'to': headers.get('to', ''),
                'date': date_str,
                'body': body
            }
            
        except Exception as e:
            logger.warning(f"Error parsing message: {e}")
            return None
    
    def _extract_body(self, payload: Dict) -> str:
        """Extract body text from Gmail payload"""
        body = ''
        
        # Check for plain text part
        if 'parts' in payload:
            for part in payload['parts']:
                if part.get('mimeType') == 'text/plain':
                    data = part.get('body', {}).get('data', '')
                    if data:
                        import base64
                        body = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                        break
        else:
            # Single part message
            data = payload.get('body', {}).get('data', '')
            if data:
                import base64
                body = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
        
        return body
    
    def run_complete_extraction(self, headless: bool = True):
        """Run complete extraction with email timeline integration"""
        logger.info("🚀 Starting SICON extraction with email timeline integration")
        
        # Step 1: Run web extraction
        logger.info("📊 Step 1: Running web extraction...")
        self.web_extractor.run_extraction(headless=headless)
        
        # Step 2: Setup Gmail and fetch emails
        logger.info("📧 Step 2: Setting up email extraction...")
        if self.setup_gmail_service():
            emails = self.fetch_sicon_emails()
            
            if emails:
                # Step 3: Parse email timeline
                logger.info("⏰ Step 3: Parsing email timeline...")
                timeline = self.email_parser.parse_referee_emails(emails)
                
                logger.info(f"📊 Email timeline summary:")
                logger.info(f"  - {len(timeline['invitations'])} invitations")
                logger.info(f"  - {len(timeline['responses'])} responses")
                logger.info(f"  - {len(timeline['reminders'])} reminders")
                
                # Step 4: Integrate with web data
                logger.info("🔄 Step 4: Integrating email timeline with web data...")
                integrate_with_sicon_extractor(self.web_extractor, emails)
                
                # Step 5: Generate enhanced report
                self._generate_enhanced_report()
            else:
                logger.warning("No SICON emails found - using web data only")
        else:
            logger.warning("Gmail not available - using web data only")
        
        return self.web_extractor.manuscripts
    
    def _generate_enhanced_report(self):
        """Generate report with complete timeline data"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = Path(f"sicon_enhanced_extraction_{timestamp}")
        report_path.mkdir(exist_ok=True)
        
        # Save raw data
        with open(report_path / "complete_data.json", 'w') as f:
            json.dump(self.web_extractor.manuscripts, f, indent=2)
        
        # Generate summary report
        with open(report_path / "timeline_report.txt", 'w') as f:
            f.write("SICON EXTRACTION WITH EMAIL TIMELINE REPORT\n")
            f.write("=" * 50 + "\n\n")
            
            total_refs = 0
            refs_with_timeline = 0
            timeline_gaps = 0
            
            for ms in self.web_extractor.manuscripts:
                f.write(f"\n📄 Manuscript {ms['id']}\n")
                f.write(f"Title: {ms.get('title', 'N/A')[:80]}...\n")
                f.write(f"Status: {ms.get('current_stage', 'Unknown')}\n")
                
                # Referee timeline summary
                enhanced_refs = ms.get('enhanced_referees', [])
                gaps = ms.get('timeline_gaps', [])
                email_only = ms.get('email_only_referees', [])
                
                f.write(f"\nReferee Timeline:\n")
                f.write(f"  - {len(enhanced_refs)} referees with email timeline\n")
                f.write(f"  - {len(gaps)} referees missing email data\n")
                f.write(f"  - {len(email_only)} referees found only in emails\n")
                
                # Detailed referee info
                if enhanced_refs:
                    f.write("\nDetailed Timeline:\n")
                    for ref in enhanced_refs:
                        f.write(f"\n  👤 {ref['name']} ({ref['email']})\n")
                        f.write(f"     Initial Contact: {ref.get('initial_contact_date', 'Unknown')}\n")
                        f.write(f"     Response: {ref.get('response_date', 'Not yet')}")
                        if ref.get('email_decision'):
                            f.write(f" - {ref['email_decision'].upper()}")
                        if ref.get('response_time_days'):
                            f.write(f" ({ref['response_time_days']} days)")
                        f.write("\n")
                        if ref.get('reminder_count', 0) > 0:
                            f.write(f"     Reminders sent: {ref['reminder_count']}\n")
                
                total_refs += len(enhanced_refs) + len(gaps)
                refs_with_timeline += len(enhanced_refs)
                timeline_gaps += len(gaps)
            
            # Summary statistics
            f.write(f"\n\nSUMMARY STATISTICS\n")
            f.write("=" * 30 + "\n")
            f.write(f"Total manuscripts: {len(self.web_extractor.manuscripts)}\n")
            f.write(f"Total referees: {total_refs}\n")
            f.write(f"Referees with email timeline: {refs_with_timeline}\n")
            f.write(f"Referees missing timeline: {timeline_gaps}\n")
            
            if total_refs > 0:
                coverage = (refs_with_timeline / total_refs) * 100
                f.write(f"Timeline coverage: {coverage:.1f}%\n")
        
        logger.info(f"✅ Enhanced report saved to {report_path}")


def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(description="SICON extraction with email timeline")
    parser.add_argument('--headless', action='store_true', help='Run in headless mode')
    parser.add_argument('--days-back', type=int, default=180, help='Days back to search emails')
    parser.add_argument('--email-only', action='store_true', help='Only parse emails without web extraction')
    
    args = parser.parse_args()
    
    extractor = SICONEmailTimelineExtractor()
    
    if args.email_only:
        # Just test email parsing
        if extractor.setup_gmail_service():
            emails = extractor.fetch_sicon_emails(days_back=args.days_back)
            timeline = extractor.email_parser.parse_referee_emails(emails)
            print(json.dumps(timeline, indent=2))
    else:
        # Run full extraction
        extractor.run_complete_extraction(headless=args.headless)


if __name__ == "__main__":
    main()