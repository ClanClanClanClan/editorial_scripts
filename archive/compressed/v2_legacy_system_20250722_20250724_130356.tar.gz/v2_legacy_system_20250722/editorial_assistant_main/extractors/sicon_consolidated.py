#!/usr/bin/env python3
"""
SIAM Journal on Control and Optimization (SICON) Consolidated Extractor
Combines all SICON extraction functionality with Phase 1 & 2 improvements.
"""

import os
import sys
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import json
from pathlib import Path
import re

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from bs4 import BeautifulSoup

from editorial_assistant.core.data_models import JournalConfig
from editorial_assistant.core.unified_config import get_config_manager
from editorial_assistant.core.timeline_validator import TimelineValidator

# Phase 3: Platform abstraction imports
from editorial_assistant.core.siam_platform import SIAMPlatform
from editorial_assistant.core.platform_extractor import UnifiedManuscript, UnifiedReferee, PlatformType

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class SICONConsolidatedExtractor(SIAMPlatform):
    """
    Consolidated SICON extractor.
    Integrates all features from various SICON implementations.
    
    Phase 3: Now inherits from SIAMPlatform for unified interface.
    """
    
    def __init__(self, journal_code: str = 'SICON', **kwargs):
        """
        Initialize SICON extractor.
        
        Args:
            journal_code: Journal code (default 'SICON')
            **kwargs: Additional arguments
        """
        # Initialize base class with platform abstraction
        super().__init__(journal_code, **kwargs)
        
        # SICON-specific configuration (backward compatibility)
        self._legacy_init(**kwargs)
        
        # SICON-specific settings
        self.manuscripts = []
        self.referees = []
        
        # Email timeline integration
        if self.use_enhanced_timeline:
            try:
                from scripts.sicon.scripts.sicon.parse_sicon_emails import SICONEmailParser
                from core.working_gmail_utils import get_gmail_service
                self.email_parser = SICONEmailParser()
                self.timeline_validator = TimelineValidator(tolerance_days=2)
                self.gmail_service = None
            except ImportError:
                logger.warning("Email timeline components not available")
                self.use_enhanced_timeline = False
        
        logger.info(f"SICON Extractor initialized - Config: {self.use_config_system}, "
                   f"Navigation: {self.use_navigation_module}, "
                   f"Timeline: {self.use_enhanced_timeline}")
    
    def _legacy_init(self, **kwargs):
        """Initialize legacy SICON-specific settings for backward compatibility."""
        # Get enhanced configuration
        config_manager = get_config_manager()
        sicon_config = config_manager.get_journal_config('SICON')
        
        # Legacy browser setup (will be handled by platform base)
        self.headless = kwargs.get('headless', True)
        
        # Legacy feature flags (Phase 3 integration)
        self.use_config_system = sicon_config.is_feature_enabled('use_config_system')
        self.use_navigation_module = sicon_config.is_feature_enabled('use_navigation_module')
        self.use_enhanced_timeline = sicon_config.is_feature_enabled('use_enhanced_timeline')
        
        # Timeline validation setup
        self.timeline_validator = TimelineValidator()
    
    def _get_required_browser(self) -> str:
        """Override: SICON uses Chrome (default for SIAM)."""
        return 'chrome'
    
    def _extract_manuscript_ids(self) -> List[str]:
        """Override: Extract manuscript IDs from SICON platform."""
        manuscript_ids = []
        
        try:
            self.logger.info("Extracting manuscript IDs from SICON platform")
            
            # Use legacy method to extract manuscript IDs
            raw_data = self._extract_from_web()
            
            # Extract IDs from raw data
            for item in raw_data:
                if 'manuscript_id' in item:
                    manuscript_ids.append(item['manuscript_id'])
            
            self.logger.info(f"Extracted {len(manuscript_ids)} manuscript IDs from SICON")
            return manuscript_ids
            
        except Exception as e:
            self.logger.error(f"Failed to extract manuscript IDs: {e}")
            return []
    
    def _extract_manuscript_details(self, manuscript_id: str) -> Optional[UnifiedManuscript]:
        """Override: Extract detailed information for a SICON manuscript."""
        try:
            self.logger.debug(f"Extracting details for SICON manuscript {manuscript_id}")
            
            # Create unified manuscript object
            manuscript = UnifiedManuscript(
                manuscript_id=manuscript_id,
                platform_id=manuscript_id,
                journal_code=self.journal_code,
                platform_type=PlatformType.SIAM,
                platform_data={'source': 'sicon_web'}
            )
            
            return manuscript
            
        except Exception as e:
            self.logger.error(f"Failed to extract details for manuscript {manuscript_id}: {e}")
            return None
    
    def _extract_referees_from_web(self, manuscript_id: str) -> List[UnifiedReferee]:
        """Override: Extract referees from SICON web interface."""
        referees = []
        
        try:
            self.logger.debug(f"Extracting referees for SICON manuscript {manuscript_id}")
            
            # Use legacy referee extraction method
            referee_data = self._extract_referees_for_manuscript(manuscript_id)
            
            # Convert to unified referees
            for referee in referee_data:
                try:
                    unified_referee = UnifiedReferee(
                        name=referee.get('name', ''),
                        email=referee.get('email', ''),
                        manuscript_id=manuscript_id,
                        platform_type=PlatformType.SIAM,
                        affiliation=referee.get('affiliation'),
                        status=referee.get('status'),
                        invitation_date=referee.get('invitation_date'),
                        response_date=referee.get('response_date'),
                        platform_data=referee
                    )
                    referees.append(unified_referee)
                    
                except Exception as e:
                    self.logger.warning(f"Failed to create unified referee: {e}")
            
            return referees
            
        except Exception as e:
            self.logger.error(f"Failed to extract referees for manuscript {manuscript_id}: {e}")
            return []
    
    # Legacy method compatibility (maintain existing interface)
    def extract_data(self) -> List[Dict[str, Any]]:
        """
        Main extraction method that combines web and email data.
        
        Returns:
            List of manuscripts with validated timeline data
        """
        try:
            # Step 1: Web extraction
            logger.info("Starting SICON web extraction...")
            web_manuscripts = self._extract_from_web()
            logger.info(f"Extracted {len(web_manuscripts)} manuscripts from web")
            
            # Step 2: Email extraction (if validation enabled)
            if self.use_enhanced_timeline:
                logger.info("Starting SICON email extraction...")
                email_data = self._extract_from_emails()
                logger.info(f"Extracted {len(email_data)} emails")
                
                # Step 3: Integrate and validate
                logger.info("Integrating and validating timeline data...")
                validated_manuscripts = self._integrate_and_validate(web_manuscripts, email_data)
                
                # Step 4: Report any critical issues
                self._report_validation_issues(validated_manuscripts)
                
                return validated_manuscripts
            else:
                return web_manuscripts
                
        except Exception as e:
            logger.error(f"SICON extraction failed: {e}")
            raise
            
        finally:
            if self.driver:
                self.driver.quit()
    
    def _extract_from_web(self) -> List[Dict[str, Any]]:
        """Extract manuscripts from SICON website following exact 8-step workflow."""
        try:
            # Initialize browser
            if not self.driver:
                self.driver = self.browser_manager.create_driver()
            
            # Step 1: Login
            self._login()
            
            # Step 2: Navigate to AE dashboard
            self._navigate_to_ae_dashboard()
            
            # Step 3: Extract manuscript IDs
            manuscript_ids = self._extract_manuscript_ids()
            logger.info(f"Found {len(manuscript_ids)} manuscripts")
            
            # Step 4: Extract details for each manuscript
            manuscripts = []
            for manuscript_id in manuscript_ids:
                try:
                    manuscript_data = self._extract_manuscript_details(manuscript_id)
                    if manuscript_data:
                        manuscripts.append(manuscript_data)
                except Exception as e:
                    logger.warning(f"Failed to extract details for {manuscript_id}: {e}")
                    continue
            
            return manuscripts
            
        except Exception as e:
            logger.error(f"Web extraction failed: {e}")
            return []
    
    def _login(self) -> None:
        """Login to SICON using ORCID authentication following exact workflow."""
        try:
            # Step 1: Navigate to SICON URL
            self.driver.get(self.journal_url)
            time.sleep(self.popup_wait_time)
            
            # Handle cookie banners and privacy modals
            self._handle_popups()
            
            # Check if already logged in
            if self._is_logged_in():
                logger.info(f"[{self.journal.code}] Already logged in")
                return
            
            # Step 2: Click ORCID button using exact selectors
            self._click_orcid_button()
            
            # Step 3: ORCID authentication with exact selectors
            self._orcid_authentication()
            
            # Wait for redirect back to SICON
            self._wait_for_url_contains("sicon.siam.org", timeout=30)
            
            # Handle any post-login popups
            self._handle_popups()
            
            logger.info(f"[{self.journal.code}] Successfully logged in")
            
        except Exception as e:
            logger.error(f"[{self.journal.code}] Login failed: {e}")
            raise
    
    def _is_logged_in(self) -> bool:
        """Check if already logged in by looking for AE dashboard elements."""
        try:
            dashboard_indicators = [
                "//tbody[@role='assoc_ed']",
                "//tr[@class='ndt_task']",
                "//a[@class='ndt_task_link']"
            ]
            
            for indicator in dashboard_indicators:
                elements = self.driver.find_elements(By.XPATH, indicator)
                if elements:
                    return True
            
            return False
            
        except Exception:
            return False
    
    def _handle_popups(self) -> None:
        """Handle cookie banners and privacy modals using comprehensive approach."""
        try:
            # JavaScript removal of banners
            js_remove_banners = """
            const selectors = [
                '#cookie-policy-layer-bg',
                '.cookie-banner',
                '.privacy-banner',
                '[class*="cookie"]',
                '[id*="cookie"]',
                '[class*="privacy"]',
                '[id*="privacy"]'
            ];
            selectors.forEach(selector => {
                const elements = document.querySelectorAll(selector);
                elements.forEach(el => el.remove());
            });
            """
            
            self.driver.execute_script(js_remove_banners)
            
            # Handle accept buttons
            self._dismiss_cookie_modal()
            
        except Exception:
            pass
    
    def _click_orcid_button(self) -> None:
        """Click ORCID login button with exact selectors."""
        try:
            # Exact selectors from working implementation
            orcid_selectors = [
                "a[href*='sso_site_redirect'][href*='orcid']",
                "img[src*='orcid']",
                "img[title='ORCID']",
                "a img[src*='orcid_32x32.png']",
                "a[href*='orcid']"
            ]
            
            orcid_element = None
            for selector in orcid_selectors:
                try:
                    elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        if element.is_displayed():
                            # If it's an image, get its parent link
                            if element.tag_name == 'img':
                                orcid_element = element.find_element(By.XPATH, "..")
                            else:
                                orcid_element = element
                            break
                    if orcid_element:
                        break
                except Exception:
                    continue
            
            if not orcid_element:
                raise Exception("No ORCID login element found")
            
            # Try JavaScript click first to bypass cookie issues
            try:
                self.driver.execute_script("arguments[0].click();", orcid_element)
                logger.info("ORCID button clicked (JavaScript)")
            except Exception:
                # Fallback to regular click
                orcid_element.click()
                logger.info("ORCID button clicked (regular)")
            
            time.sleep(self.page_navigation_wait)
            
        except Exception as e:
            logger.error(f"Failed to click ORCID button: {e}")
            raise
    
    def _orcid_authentication(self) -> None:
        """Handle ORCID authentication using inherited method."""
        if not self._handle_orcid_authentication():
            raise Exception("ORCID authentication failed")
    
    def _navigate_to_ae_dashboard(self) -> None:
        """Navigate to Associate Editor dashboard."""
        try:
            # Look for AE dashboard elements
            dashboard_indicators = [
                "//tbody[@role='assoc_ed']",
                "//tr[@class='ndt_task']",
                "//a[@class='ndt_task_link']"
            ]
            
            # Check if already on dashboard
            for indicator in dashboard_indicators:
                elements = self.driver.find_elements(By.XPATH, indicator)
                if elements:
                    logger.info("Already on AE dashboard")
                    return
            
            # If not on dashboard, try to navigate
            ae_links = [
                "//a[contains(text(), 'Associate Editor')]",
                "//a[contains(text(), 'AE')]",
                "//a[contains(@href, 'assoc_ed')]"
            ]
            
            for link_xpath in ae_links:
                try:
                    link = self.driver.find_element(By.XPATH, link_xpath)
                    if link.is_displayed():
                        link.click()
                        time.sleep(self.page_navigation_wait)
                        return
                except Exception:
                    continue
            
            logger.info("AE dashboard navigation completed")
            
        except Exception as e:
            logger.error(f"Failed to navigate to AE dashboard: {e}")
            raise
    
    def _extract_manuscript_ids(self) -> List[str]:
        """Extract manuscript IDs from the dashboard."""
        manuscript_ids = []
        
        try:
            # Wait for dashboard table
            self._wait_for_page_load()
            
            # Find manuscript table rows
            task_rows = self.driver.find_elements(By.XPATH, "//tr[@class='ndt_task']")
            
            for row in task_rows:
                try:
                    # Extract manuscript ID from task link
                    task_links = row.find_elements(By.XPATH, ".//a[@class='ndt_task_link']")
                    for link in task_links:
                        href = link.get_attribute('href')
                        if href:
                            # Extract manuscript ID from URL
                            match = re.search(r'manuscript_id=([^&]+)', href)
                            if match:
                                manuscript_id = match.group(1)
                                if manuscript_id not in manuscript_ids:
                                    manuscript_ids.append(manuscript_id)
                            
                except Exception as e:
                    logger.warning(f"Error extracting ID from row: {e}")
                    continue
            
            logger.info(f"Extracted {len(manuscript_ids)} manuscript IDs")
            
        except Exception as e:
            logger.error(f"Error extracting manuscript IDs: {e}")
            
        return manuscript_ids
    
    def _extract_manuscript_details(self, manuscript_id: str) -> Optional[Dict[str, Any]]:
        """Extract detailed information for a specific manuscript."""
        try:
            # Navigate to manuscript details page
            detail_url = f"{self.site_prefix}manuscript_details.php?manuscript_id={manuscript_id}"
            self.driver.get(detail_url)
            time.sleep(self.page_navigation_wait)
            
            # Extract manuscript information
            manuscript_data = {
                'manuscript_id': manuscript_id,
                'title': '',
                'authors': [],
                'status': '',
                'referees': [],
                'submission_date': '',
                'journal': 'SICON'
            }
            
            # Extract title
            try:
                title_element = self.driver.find_element(By.XPATH, "//td[contains(text(), 'Title:')]/following-sibling::td")
                manuscript_data['title'] = title_element.text.strip()
            except Exception:
                pass
            
            # Extract authors
            try:
                authors_element = self.driver.find_element(By.XPATH, "//td[contains(text(), 'Authors:')]/following-sibling::td")
                authors_text = authors_element.text.strip()
                manuscript_data['authors'] = [author.strip() for author in authors_text.split(',') if author.strip()]
            except Exception:
                pass
            
            # Extract status
            try:
                status_element = self.driver.find_element(By.XPATH, "//td[contains(text(), 'Status:')]/following-sibling::td")
                manuscript_data['status'] = status_element.text.strip()
            except Exception:
                pass
            
            # Extract referee information
            manuscript_data['referees'] = self._extract_referee_details(manuscript_id)
            
            return manuscript_data
            
        except Exception as e:
            logger.error(f"Error extracting details for {manuscript_id}: {e}")
            return None
    
    def _extract_referee_details(self, manuscript_id: str) -> List[Dict[str, Any]]:
        """Extract referee details for a manuscript."""
        referees = []
        
        try:
            # Look for referee tables
            referee_tables = self.driver.find_elements(By.XPATH, "//table[contains(@class, 'referee') or contains(@id, 'referee')]")
            
            for table in referee_tables:
                rows = table.find_elements(By.XPATH, ".//tr")
                
                for row in rows[1:]:  # Skip header
                    cells = row.find_elements(By.TAG_NAME, "td")
                    
                    if len(cells) >= 3:
                        referee = {
                            'name': cells[0].text.strip() if cells[0] else '',
                            'email': self._extract_email_from_cell(cells[1]) if len(cells) > 1 else '',
                            'affiliation': cells[2].text.strip() if len(cells) > 2 else '',
                            'status': cells[3].text.strip() if len(cells) > 3 else '',
                            'manuscript_id': manuscript_id
                        }
                        
                        if referee['name']:  # Only add if name exists
                            referees.append(referee)
            
        except Exception as e:
            logger.error(f"Error extracting referee details: {e}")
            
        return referees
    
    def _extract_email_from_cell(self, cell) -> str:
        """Extract email from table cell."""
        try:
            # Look for mailto links
            email_links = cell.find_elements(By.XPATH, ".//a[contains(@href, 'mailto:')]")
            if email_links:
                href = email_links[0].get_attribute('href')
                return href.replace('mailto:', '')
            
            # Look for email pattern in text
            text = cell.text
            email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
            matches = re.findall(email_pattern, text)
            if matches:
                return matches[0]
                
        except Exception:
            pass
            
        return ''
    
    def _extract_from_emails(self) -> List[Dict[str, Any]]:
        """Extract timeline data from emails (if enhanced timeline enabled)."""
        if not self.use_enhanced_timeline:
            return []
        
        try:
            # Initialize Gmail service
            if not self.gmail_service:
                from core.working_gmail_utils import get_gmail_service
                self.gmail_service = get_gmail_service()
            
            # Search for SICON emails
            from core.working_gmail_utils import search_messages, get_message_details
            
            query = "from:sicon.siam.org OR subject:SICON OR subject:Control"
            message_ids = search_messages(self.gmail_service, query, max_results=100)
            
            emails = []
            for msg_id in message_ids[:50]:  # Limit to recent emails
                try:
                    details = get_message_details(self.gmail_service, msg_id)
                    if details:
                        emails.append(details)
                except Exception as e:
                    logger.warning(f"Failed to get email details for {msg_id}: {e}")
                    continue
            
            return emails
            
        except Exception as e:
            logger.error(f"Email extraction failed: {e}")
            return []
    
    def _integrate_and_validate(self, web_manuscripts: List[Dict], email_data: List[Dict]) -> List[Dict]:
        """Integrate web and email data with validation."""
        if not self.use_enhanced_timeline or not email_data:
            return web_manuscripts
        
        try:
            # Parse emails to extract timeline data
            parsed_emails = self.email_parser.parse_emails(email_data)
            
            # Integrate with web manuscripts
            for manuscript in web_manuscripts:
                manuscript_id = manuscript.get('manuscript_id')
                if manuscript_id:
                    # Find relevant emails for this manuscript
                    relevant_emails = [e for e in parsed_emails if manuscript_id in e.get('body', '')]
                    manuscript['email_timeline'] = relevant_emails
                    
                    # Validate timeline consistency
                    if self.timeline_validator:
                        issues = self.timeline_validator.validate_manuscript_timeline(manuscript)
                        manuscript['validation_issues'] = issues
            
            return web_manuscripts
            
        except Exception as e:
            logger.error(f"Integration failed: {e}")
            return web_manuscripts
    
    def _report_validation_issues(self, manuscripts: List[Dict]) -> None:
        """Report any critical validation issues."""
        critical_issues = []
        
        for manuscript in manuscripts:
            issues = manuscript.get('validation_issues', [])
            for issue in issues:
                if issue.get('severity') == 'critical':
                    critical_issues.append(issue)
        
        if critical_issues:
            logger.warning(f"Found {len(critical_issues)} critical validation issues")
            for issue in critical_issues[:5]:  # Report first 5
                logger.warning(f"Critical issue: {issue.get('message', 'Unknown issue')}")


# Backward compatibility function
def extract_sicon_data(headless: bool = True, validate_timeline: bool = True) -> Dict[str, Any]:
    """
    Backward compatible extraction function.
    
    Args:
        headless: Run browser in headless mode
        validate_timeline: Include email timeline validation
        
    Returns:
        Dictionary containing extraction results
    """
    # Initialize extractor
    extractor = SICONConsolidatedExtractor()
    
    # Override browser settings if needed
    if not headless:
        extractor.browser_manager.headless = False
    
    try:
        # Extract data
        manuscripts = extractor.extract_data()
        
        results = {
            'journal': 'SICON',
            'extraction_date': datetime.now().isoformat(),
            'manuscripts': manuscripts,
            'total_manuscripts': len(manuscripts),
            'total_referees': sum(len(m.get('referees', [])) for m in manuscripts)
        }
        
        return results
        
    except Exception as e:
        logger.error(f"SICON extraction failed: {e}")
        return {
            'journal': 'SICON',
            'extraction_date': datetime.now().isoformat(),
            'error': str(e),
            'manuscripts': [],
            'total_manuscripts': 0,
            'total_referees': 0
        }


if __name__ == "__main__":
    # Test the consolidated extractor
    logging.basicConfig(level=logging.INFO)
    
    print("Testing SICON Consolidated Extractor...")
    print("-" * 60)
    
    # Quick test
    extractor = SICONConsolidatedExtractor()
    print(f"✅ Extractor initialized")
    print(f"   - Journal URL: {extractor.journal_url}")
    print(f"   - Config System: {extractor.use_config_system}")
    print(f"   - Navigation Module: {extractor.use_navigation_module}")
    print(f"   - Enhanced Timeline: {extractor.use_enhanced_timeline}")
    
    print("\n✅ Consolidated SICON Extractor ready for use!")