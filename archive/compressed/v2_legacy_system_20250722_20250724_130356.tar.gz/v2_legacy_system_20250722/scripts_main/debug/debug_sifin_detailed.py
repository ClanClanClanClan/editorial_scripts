#!/usr/bin/env python3
"""
Detailed debug of SIFIN email parsing with improved extraction
"""

import os
import sys
sys.path.append('/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/scripts/sifin')

from parse_sifin_emails import SIFINEmailParser
import logging

# Set up detailed logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def test_improved_extraction():
    """Test the improved extraction with detailed logging"""
    parser = SIFINEmailParser()
    
    if not parser.setup_gmail_service():
        print("❌ Failed to setup Gmail service")
        return
    
    # Test with one manuscript
    test_manuscript = "M174160"
    
    print(f"🔍 Testing improved extraction for {test_manuscript}")
    print("=" * 60)
    
    # Fetch emails with debug logging
    events = parser.fetch_sifin_emails(manuscript_ids=[test_manuscript], days_back=365)
    
    print(f"\n📧 Found {len(events)} events")
    
    # Show details of each event
    for i, event in enumerate(events[:5], 1):  # First 5 events
        print(f"\nEvent {i}:")
        print(f"  Type: {event.event_type}")
        print(f"  Date: {event.date}")
        print(f"  Subject: {event.subject}")
        print(f"  Referee Name: {event.referee_name or 'None'}")
        print(f"  Referee Email: {event.referee_email or 'None'}")
        print(f"  Decision: {event.decision or 'None'}")
    
    # Build timelines
    timelines = parser.build_referee_timelines(events)
    
    print(f"\n📊 Built timelines for {len(timelines)} manuscripts")
    
    # Show timeline details
    for ms_id, ref_timelines in timelines.items():
        print(f"\nManuscript {ms_id}:")
        for ref_key, timeline in ref_timelines.items():
            print(f"  Referee Key: {ref_key}")
            print(f"  Name: {timeline.referee_name}")
            print(f"  Email: {timeline.referee_email}")
            print(f"  Events: {len(timeline.events)}")


if __name__ == "__main__":
    test_improved_extraction()