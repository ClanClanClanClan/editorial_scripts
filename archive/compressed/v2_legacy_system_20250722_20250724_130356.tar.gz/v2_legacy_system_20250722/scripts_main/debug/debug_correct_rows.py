#!/usr/bin/env python3
"""Debug actual referee table structure"""

import os
import sys
import time
from pathlib import Path
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

def debug_correct_rows():
    """Debug the actual referee table structure"""
    
    print("🔍 DEBUGGING CORRECT REFEREE TABLE STRUCTURE")
    print("=" * 60)
    
    # Chrome setup
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        # Quick login (we know this works)
        print("1. Quick login...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        try:
            reject_btn = driver.find_element(By.ID, "onetrust-reject-all-handler")
            reject_btn.click()
        except:
            pass
        
        email_field = driver.find_element(By.ID, "USERID")
        email_field.send_keys(os.getenv('MF_EMAIL'))
        password_field = driver.find_element(By.ID, "PASSWORD")
        password_field.send_keys(os.getenv('MF_PASSWORD'))
        login_btn = driver.find_element(By.ID, "logInButton")
        driver.execute_script("arguments[0].click();", login_btn)
        time.sleep(3)
        
        # Handle 2FA
        try:
            code_input = driver.find_element(By.ID, "TOKEN_VALUE")
            from core.email_utils import fetch_latest_verification_code
            time.sleep(5)
            verification_code = fetch_latest_verification_code('MF', max_wait=60, poll_interval=3)
            if verification_code:
                code_input.clear()
                code_input.send_keys(verification_code)
                try:
                    remember_checkbox = driver.find_element(By.ID, "REMEMBER_THIS_DEVICE")
                    if not remember_checkbox.is_selected():
                        remember_checkbox.click()
                except:
                    pass
                verify_btn = driver.find_element(By.ID, "VERIFY_BTN")
                verify_btn.click()
                time.sleep(15)
        except:
            pass
        
        # Navigate and click Take Action
        print("2. Navigating and clicking Take Action...")
        ae_link = driver.find_element(By.LINK_TEXT, "Associate Editor Center")
        ae_link.click()
        time.sleep(5)
        
        category_link = driver.find_element(By.LINK_TEXT, "Awaiting Reviewer Scores")
        category_link.click()
        time.sleep(5)
        
        # Find and click Take Action
        all_rows = driver.find_elements(By.TAG_NAME, "tr")
        for row in all_rows:
            if 'MAFI-' in row.text:
                cells = row.find_elements(By.TAG_NAME, "td")
                if cells:
                    last_cell = cells[-1]
                    take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
                    if take_action_links:
                        href = take_action_links[0].get_attribute('href')
                        if href and 'javascript:' in href:
                            js_code = href.replace('javascript:', '')
                            driver.execute_script(js_code)
                            time.sleep(5)
                            print("✅ Take Action clicked successfully")
                            break
        
        # Now find the ACTUAL referee table inside the page content
        print("3. FINDING ACTUAL REFEREE TABLE...")
        print("-" * 50)
        
        # Look for the reviewer table specifically - it should be a separate table inside the page
        reviewer_tables = driver.find_elements(By.XPATH, "//table[.//text()[contains(., 'Reviewer List')]]")
        print(f"Found {len(reviewer_tables)} tables containing 'Reviewer List'")
        
        if reviewer_tables:
            reviewer_table = reviewer_tables[0]
            print("🎯 FOUND REVIEWER TABLE!")
            
            # Get all rows from the reviewer table
            reviewer_rows = reviewer_table.find_elements(By.TAG_NAME, "tr")
            print(f"Reviewer table has {len(reviewer_rows)} rows")
            
            referee_names = ['Liang', 'Mrad', 'Dos Reis', 'Strub']
            
            for i, row in enumerate(reviewer_rows):
                row_text = row.text
                if any(name in row_text for name in referee_names):
                    print(f"\n📋 REFEREE ROW {i} ({[name for name in referee_names if name in row_text][0]}):")
                    print(f"Row text: {row_text}")
                    
                    cells = row.find_elements(By.TAG_NAME, "td")
                    print(f"Cells in row: {len(cells)}")
                    
                    for j, cell in enumerate(cells):
                        cell_text = cell.text.strip()
                        if cell_text:
                            print(f"  Cell {j}: '{cell_text[:100]}...' ({len(cell_text)} chars)")
                            
                            # Look for name links
                            name_links = cell.find_elements(By.TAG_NAME, "a")
                            if name_links:
                                for k, link in enumerate(name_links):
                                    href = link.get_attribute('href')
                                    link_text = link.text
                                    print(f"    Link {k}: '{link_text}' -> {href[:50]}...")
                            
                            # Look for ORCID
                            if 'orcid.org' in cell_text:
                                print(f"    ORCID found in cell {j}")
                    
                    print("-" * 40)
        
        # Also try a different approach - look for specific referee name patterns
        print("\n4. SEARCHING FOR REFEREE NAME PATTERNS...")
        print("-" * 50)
        
        referee_name_elements = []
        for name in ['Liang, Gechun', 'Mrad, Mohamed', 'Dos Reis, Goncalo', 'Strub, Moris']:
            elements = driver.find_elements(By.XPATH, f"//a[contains(text(), '{name.split(',')[0]}')]")
            if elements:
                referee_name_elements.extend(elements)
                print(f"✅ Found {len(elements)} elements for {name}")
        
        print(f"\nTotal referee name elements found: {len(referee_name_elements)}")
        
        for i, element in enumerate(referee_name_elements):
            print(f"\nReferee element {i+1}:")
            print(f"  Text: '{element.text}'")
            print(f"  Href: {element.get_attribute('href')}")
            
            # Find the parent row
            parent_row = element
            while parent_row and parent_row.tag_name != 'tr':
                parent_row = parent_row.find_element(By.XPATH, "./..")
            
            if parent_row and parent_row.tag_name == 'tr':
                print(f"  Parent row text: '{parent_row.text[:200]}...'")
                
                # Get all cells in this row
                cells = parent_row.find_elements(By.TAG_NAME, "td")
                print(f"  Cells in parent row: {len(cells)}")
                
                for j, cell in enumerate(cells):
                    cell_text = cell.text.strip()
                    if cell_text and len(cell_text) < 100:  # Only show short cell texts
                        print(f"    Cell {j}: '{cell_text}'")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        driver.quit()

if __name__ == "__main__":
    debug_correct_rows()