#!/usr/bin/env python3
"""
Enhanced Affiliation Inference for SICON Extraction
Infers missing institutional affiliations from email domains and web search
"""

import json
import re
import logging
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import time

# Try to import web search capabilities
try:
    import requests
    from bs4 import BeautifulSoup
    import urllib.parse
    WEB_SEARCH_AVAILABLE = True
except ImportError:
    WEB_SEARCH_AVAILABLE = False
    print("⚠️ Web search dependencies not available. Install with: pip install requests beautifulsoup4")

logger = logging.getLogger(__name__)

class AffiliationInferenceEngine:
    """Enhanced affiliation inference using email domains and web search"""
    
    def __init__(self):
        self.email_domain_mapping = self._build_email_domain_mapping()
        self.session = requests.Session() if WEB_SEARCH_AVAILABLE else None
        if self.session:
            self.session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            })
    
    def _build_email_domain_mapping(self) -> Dict[str, str]:
        """Build comprehensive email domain to institution mapping"""
        return {
            # French universities and institutes
            'u-paris.fr': 'Université de Paris',
            'univ-paris1.fr': 'Université Paris 1 Panthéon-Sorbonne',
            'univ-paris-diderot.fr': 'Université Paris Diderot',
            'sorbonne-universite.fr': 'Sorbonne Université',
            'polytechnique.edu': 'École Polytechnique',
            'polytechnique.fr': 'École Polytechnique',
            'inria.fr': 'INRIA - French National Institute for Research in Digital Science and Technology',
            'centralesupelec.fr': 'CentraleSupélec',
            'univ-evry.fr': 'Université d\'Évry Val d\'Essonne',
            'upem.fr': 'Université Paris-Est Marne-la-Vallée',
            'dauphine.fr': 'Université Paris Dauphine',
            'ensae.fr': 'ENSAE Paris',
            'ens.fr': 'École Normale Supérieure',
            'cnrs.fr': 'CNRS - Centre National de la Recherche Scientifique',
            
            # German universities
            'uni-bielefeld.de': 'Bielefeld University',
            'hu-berlin.de': 'Humboldt University Berlin',
            'tu-berlin.de': 'Technical University of Berlin',
            'lmu.de': 'Ludwig Maximilian University of Munich',
            'uni-frankfurt.de': 'Goethe University Frankfurt',
            'uni-bonn.de': 'University of Bonn',
            
            # US universities
            'umich.edu': 'University of Michigan',
            'uchicago.edu': 'University of Chicago',
            'princeton.edu': 'Princeton University',
            'nyu.edu': 'New York University',
            'columbia.edu': 'Columbia University',
            'harvard.edu': 'Harvard University',
            'mit.edu': 'Massachusetts Institute of Technology',
            'stanford.edu': 'Stanford University',
            'berkeley.edu': 'University of California, Berkeley',
            'ucla.edu': 'University of California, Los Angeles',
            
            # UK universities
            'ox.ac.uk': 'University of Oxford',
            'cam.ac.uk': 'University of Cambridge',
            'imperial.ac.uk': 'Imperial College London',
            'ucl.ac.uk': 'University College London',
            'lse.ac.uk': 'London School of Economics',
            
            # Other European universities
            'kth.se': 'KTH Royal Institute of Technology',
            'chalmers.se': 'Chalmers University of Technology',
            'ethz.ch': 'ETH Zurich',
            'epfl.ch': 'École Polytechnique Fédérale de Lausanne',
            'uva.nl': 'University of Amsterdam',
            'vu.nl': 'Vrije Universiteit Amsterdam',
            
            # Chinese universities
            'sdu.edu.cn': 'Shandong University',
            'tsinghua.edu.cn': 'Tsinghua University',
            'pku.edu.cn': 'Peking University',
            'fudan.edu.cn': 'Fudan University',
            'sjtu.edu.cn': 'Shanghai Jiao Tong University',
            
            # General email patterns
            'gmail.com': None,  # Personal email, search needed
            'yahoo.com': None,  # Personal email, search needed
            'hotmail.com': None,  # Personal email, search needed
        }
    
    def infer_affiliation(self, referee_name: str, email: str) -> Optional[str]:
        """Infer affiliation from email domain and/or web search"""
        try:
            # Step 1: Extract domain from email
            domain = email.split('@')[1].lower() if '@' in email else None
            if not domain:
                return None
            
            # Step 2: Check direct domain mapping
            if domain in self.email_domain_mapping:
                mapped_institution = self.email_domain_mapping[domain]
                if mapped_institution:
                    logger.info(f"✅ Domain mapping: {email} -> {mapped_institution}")
                    return mapped_institution
            
            # Step 3: Try partial domain matching for subdomains
            base_domain = self._extract_base_domain(domain)
            if base_domain != domain and base_domain in self.email_domain_mapping:
                mapped_institution = self.email_domain_mapping[base_domain]
                if mapped_institution:
                    logger.info(f"✅ Base domain mapping: {email} -> {mapped_institution}")
                    return mapped_institution
            
            # Step 4: Try web search if domain mapping failed
            if WEB_SEARCH_AVAILABLE:
                web_affiliation = self._web_search_affiliation(referee_name, email)
                if web_affiliation:
                    logger.info(f"✅ Web search: {referee_name} -> {web_affiliation}")
                    return web_affiliation
            
            logger.info(f"❌ No affiliation found for {referee_name} ({email})")
            return None
            
        except Exception as e:
            logger.error(f"Error inferring affiliation for {referee_name}: {e}")
            return None
    
    def _extract_base_domain(self, domain: str) -> str:
        """Extract base domain from subdomain"""
        parts = domain.split('.')
        if len(parts) >= 2:
            return '.'.join(parts[-2:])
        return domain
    
    def _web_search_affiliation(self, name: str, email: str) -> Optional[str]:
        """Search web for referee affiliation"""
        if not WEB_SEARCH_AVAILABLE or not self.session:
            return None
        
        try:
            # Try multiple search strategies
            search_queries = [
                f'"{name}" "{email}" university',
                f'"{name}" "{email}" affiliation',
                f'"{name}" professor researcher',
                f'"{name}" mathematics statistics'
            ]
            
            for query in search_queries:
                result = self._search_google(query)
                if result:
                    return result
                time.sleep(1)  # Rate limiting
            
            return None
            
        except Exception as e:
            logger.error(f"Web search error for {name}: {e}")
            return None
    
    def _search_google(self, query: str) -> Optional[str]:
        """Search Google for affiliation information"""
        try:
            # Use Google search
            search_url = f"https://www.google.com/search?q={urllib.parse.quote(query)}"
            response = self.session.get(search_url, timeout=10)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Look for university/institution names in search results
                text_content = soup.get_text().lower()
                
                # Common institution patterns
                institution_patterns = [
                    r'university of ([a-zA-Z\s]+)',
                    r'([a-zA-Z\s]+) university',
                    r'([a-zA-Z\s]+) institute',
                    r'([a-zA-Z\s]+) college',
                    r'école ([a-zA-Z\s]+)',
                    r'inria ([a-zA-Z\s]+)',
                    r'cnrs ([a-zA-Z\s]+)',
                    r'princeton university',
                    r'harvard university',
                    r'mit',
                    r'stanford university'
                ]
                
                for pattern in institution_patterns:
                    matches = re.findall(pattern, text_content, re.IGNORECASE)
                    if matches:
                        # Return first reasonable match
                        match = matches[0].strip()
                        if len(match) > 3 and len(match) < 50:  # Reasonable length
                            return match.title()
            
            return None
            
        except Exception as e:
            logger.debug(f"Google search error: {e}")
            return None
    
    def enhance_referee_data(self, extraction_data: List[Dict]) -> List[Dict]:
        """Enhance referee data with inferred affiliations"""
        enhanced_data = []
        
        for manuscript in extraction_data:
            enhanced_manuscript = manuscript.copy()
            
            # Process declined referees
            if 'declined_referees' in manuscript:
                enhanced_declined = []
                for referee in manuscript['declined_referees']:
                    enhanced_referee = referee.copy()
                    
                    # Only infer if affiliation is missing or empty
                    if not referee.get('affiliation') or referee.get('affiliation').strip() == '':
                        inferred_affiliation = self.infer_affiliation(
                            referee.get('name', ''), 
                            referee.get('email', '')
                        )
                        if inferred_affiliation:
                            enhanced_referee['affiliation'] = inferred_affiliation
                            enhanced_referee['affiliation_source'] = 'inferred'
                    
                    enhanced_declined.append(enhanced_referee)
                
                enhanced_manuscript['declined_referees'] = enhanced_declined
            
            # Process accepted referees
            if 'accepted_referees' in manuscript:
                enhanced_accepted = []
                for referee in manuscript['accepted_referees']:
                    enhanced_referee = referee.copy()
                    
                    # Only infer if affiliation is missing or empty
                    if not referee.get('affiliation') or referee.get('affiliation').strip() == '':
                        inferred_affiliation = self.infer_affiliation(
                            referee.get('name', ''), 
                            referee.get('email', '')
                        )
                        if inferred_affiliation:
                            enhanced_referee['affiliation'] = inferred_affiliation
                            enhanced_referee['affiliation_source'] = 'inferred'
                    
                    enhanced_accepted.append(enhanced_referee)
                
                enhanced_manuscript['accepted_referees'] = enhanced_accepted
            
            enhanced_data.append(enhanced_manuscript)
        
        return enhanced_data


def enhance_sicon_extraction(input_file: str, output_file: str = None) -> str:
    """Enhance SICON extraction with improved affiliation inference"""
    
    logger.info("🔍 Starting affiliation inference enhancement")
    
    # Load extraction data
    with open(input_file, 'r') as f:
        extraction_data = json.load(f)
    
    # Initialize inference engine
    inference_engine = AffiliationInferenceEngine()
    
    # Enhance data
    enhanced_data = inference_engine.enhance_referee_data(extraction_data)
    
    # Generate output filename if not provided
    if not output_file:
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        output_file = f"sicon_enhanced_affiliations_{timestamp}.json"
    
    # Save enhanced data
    with open(output_file, 'w') as f:
        json.dump(enhanced_data, f, indent=2)
    
    # Report results
    original_count = 0
    enhanced_count = 0
    
    for manuscript in enhanced_data:
        all_referees = manuscript.get('declined_referees', []) + manuscript.get('accepted_referees', [])
        for referee in all_referees:
            if referee.get('affiliation'):
                enhanced_count += 1
                if referee.get('affiliation_source') != 'inferred':
                    original_count += 1
    
    logger.info(f"📊 Enhancement Results:")
    logger.info(f"   Original affiliations: {original_count}")
    logger.info(f"   Enhanced affiliations: {enhanced_count}")
    logger.info(f"   Improvement: {enhanced_count - original_count} additional affiliations")
    logger.info(f"   Enhanced file: {output_file}")
    
    return output_file


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python enhance_affiliation_inference.py <input_file> [output_file]")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    result_file = enhance_sicon_extraction(input_file, output_file)
    print(f"✅ Enhancement complete: {result_file}")