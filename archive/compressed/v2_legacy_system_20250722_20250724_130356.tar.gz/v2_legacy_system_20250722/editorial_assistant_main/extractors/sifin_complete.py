"""
SIAM Journal on Financial Mathematics (SIFIN) Complete Extractor
With email timeline integration and validation

This is the production-ready version that:
1. Extracts manuscript data from the web
2. Integrates email timeline data
3. Validates for contradictions
4. Returns unified, validated data
"""

import os
import logging
import time
import json
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
from pathlib import Path
from bs4 import BeautifulSoup
import re

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

from editorial_assistant.core.data_models import JournalConfig
from editorial_assistant.extractors.sifin import SIFINExtractor
from editorial_assistant.core.timeline_validator import TimelineValidator, ValidationIssue
from scripts.sifin.parse_sifin_emails import SIFINEmailParser
from core.working_gmail_utils import get_gmail_service, search_messages, get_message_details

logger = logging.getLogger(__name__)


class SIFINCompleteExtractor(SIFINExtractor):
    """
    Complete SIFIN extractor with email timeline integration and validation.
    
    SIFIN has some unique characteristics:
    1. Different email formats than SICON
    2. Referee information sometimes embedded in status emails
    3. May use different status terminology
    """
    
    def __init__(self, journal: JournalConfig, validate_timeline: bool = True):
        super().__init__(journal)
        self.validate_timeline = validate_timeline
        self.email_parser = SIFINEmailParser()
        self.timeline_validator = TimelineValidator(tolerance_days=2)
        self.gmail_service = None
        
    def extract_data(self) -> List[Dict[str, Any]]:
        """
        Main extraction method that combines web and email data.
        
        Returns:
            List of manuscripts with validated timeline data
        """
        try:
            # Step 1: Web extraction
            logger.info("Starting SIFIN web extraction...")
            web_manuscripts = self._extract_from_web()
            logger.info(f"Extracted {len(web_manuscripts)} manuscripts from web")
            
            # Step 2: Email extraction (if validation enabled)
            if self.validate_timeline:
                logger.info("Starting SIFIN email extraction...")
                email_data = self._extract_from_emails()
                logger.info(f"Extracted {len(email_data)} emails")
                
                # Step 3: Integrate and validate
                logger.info("Integrating and validating timeline data...")
                validated_manuscripts = self._integrate_and_validate(web_manuscripts, email_data)
                
                # Step 4: Report any critical issues
                self._report_validation_issues(validated_manuscripts)
                
                return validated_manuscripts
            else:
                return web_manuscripts
                
        except Exception as e:
            logger.error(f"SIFIN extraction failed: {e}")
            raise
            
        finally:
            if self.driver:
                self.driver.quit()
    
    def _extract_from_web(self) -> List[Dict[str, Any]]:
        """Extract manuscripts from SIFIN website."""
        try:
            # Use parent class method
            return self.extract_manuscripts()
            
        except Exception as e:
            logger.error(f"Web extraction failed: {e}")
            return []
    
    def _extract_from_emails(self, days_back: int = 180) -> List[Dict]:
        """Extract SIFIN emails from Gmail."""
        try:
            # Initialize Gmail service
            self.gmail_service = get_gmail_service()
            if not self.gmail_service:
                logger.warning("Gmail service not available - skipping email extraction")
                return []
            
            # Search queries for SIFIN emails - including specific manuscript IDs
            queries = [
                f'subject:SIFIN newer_than:{days_back}d',
                f'from:sifin.siam.org newer_than:{days_back}d',
                f'subject:"SIAM Journal on Financial Mathematics" newer_than:{days_back}d',
                f'subject:M1472 newer_than:{days_back}d',  # Specific manuscripts
                f'subject:M1473 newer_than:{days_back}d',
                f'subject:M1474 newer_than:{days_back}d',
                f'(subject:"referee" OR subject:"reviewer") SIFIN newer_than:{days_back}d',
                f'(subject:"status update" OR subject:"manuscript update") SIFIN newer_than:{days_back}d'
            ]
            
            all_emails = []
            seen_ids = set()
            
            for query in queries:
                logger.info(f"Searching Gmail: {query}")
                messages = search_messages(self.gmail_service, query)
                
                for msg in messages:
                    if msg['id'] not in seen_ids:
                        seen_ids.add(msg['id'])
                        details = get_message_details(self.gmail_service, msg['id'])
                        if details:
                            all_emails.append(details)
            
            logger.info(f"Found {len(all_emails)} SIFIN emails")
            return all_emails
            
        except Exception as e:
            logger.error(f"Email extraction failed: {e}")
            return []
    
    def _integrate_and_validate(self, web_manuscripts: List[Dict], emails: List[Dict]) -> List[Dict]:
        """
        Integrate web and email data, validating for contradictions.
        
        SIFIN-specific handling:
        - Look for referee info in status update emails
        - Handle different status terminology
        - Check email body for referee assignments
        """
        validated_manuscripts = []
        
        for manuscript in web_manuscripts:
            ms_id = manuscript.get('id', '')
            
            # Parse email timeline for this manuscript
            email_timeline = self.email_parser.parse_referee_emails(emails, manuscript_id=ms_id)
            
            # For SIFIN, also look for referee info in status emails
            status_referees = self._extract_referees_from_status_emails(emails, ms_id)
            
            # Get all referees from web
            all_referees = []
            
            # SIFIN uses different structure - adapt to what's in the manuscript data
            if 'referees' in manuscript:
                all_referees.extend(manuscript['referees'])
            if 'declined_referees' in manuscript:
                all_referees.extend(manuscript['declined_referees'])
            
            # Add any referees found only in status emails
            for status_ref in status_referees:
                if not any(ref.get('email', '').lower() == status_ref['email'].lower() for ref in all_referees):
                    all_referees.append(status_ref)
            
            # Validate timeline
            validation_issues = self.timeline_validator.validate_manuscript_timeline(
                ms_id, all_referees, email_timeline
            )
            
            # Enhance referee data with email timeline
            enhanced_referees = self._enhance_referee_data(all_referees, email_timeline, status_referees)
            
            # Update manuscript with validated data
            validated_manuscript = manuscript.copy()
            validated_manuscript['enhanced_referees'] = enhanced_referees
            validated_manuscript['email_timeline'] = email_timeline
            validated_manuscript['status_email_referees'] = status_referees
            validated_manuscript['validation_issues'] = [issue.to_dict() for issue in validation_issues]
            validated_manuscript['has_critical_issues'] = any(
                issue.severity == 'critical' for issue in validation_issues
            )
            
            # Update referee lists with enhanced data
            validated_manuscript['referees'] = [
                ref for ref in enhanced_referees if ref.get('status') in ['accepted', 'complete', 'pending']
            ]
            validated_manuscript['declined_referees'] = [
                ref for ref in enhanced_referees if ref.get('status') == 'declined'
            ]
            
            validated_manuscripts.append(validated_manuscript)
        
        return validated_manuscripts
    
    def _extract_referees_from_status_emails(self, emails: List[Dict], manuscript_id: str) -> List[Dict]:
        """
        Extract referee information from SIFIN status update emails.
        
        SIFIN sometimes includes referee assignments in status emails rather than
        separate invitation emails.
        """
        status_referees = []
        
        for email in emails:
            subject = email.get('subject', '')
            body = email.get('body', '')
            
            # Check if this is a status email for this manuscript
            if manuscript_id in subject and ('status' in subject.lower() or 'update' in subject.lower()):
                # Look for referee information in the body
                # Pattern: "Referee: Name (email@domain.com)"
                referee_pattern = r'Referee:\s*([^(\n]+)\s*\(([^)]+@[^)]+)\)'
                matches = re.findall(referee_pattern, body, re.IGNORECASE)
                
                for name, email_addr in matches:
                    status_referees.append({
                        'name': name.strip(),
                        'email': email_addr.strip().lower(),
                        'source': 'status_email',
                        'status': 'unknown',  # Will be determined from context
                        'found_in_email_date': email.get('date', '')
                    })
                
                # Also look for patterns like "assigned to review"
                assignment_pattern = r'([^,\n]+)\s+(?:has been |was |is )?assigned to review'
                assignment_matches = re.findall(assignment_pattern, body, re.IGNORECASE)
                
                for name in assignment_matches:
                    if '@' not in name:  # Avoid email addresses
                        status_referees.append({
                            'name': name.strip(),
                            'email': '',
                            'source': 'status_email_assignment',
                            'status': 'assigned',
                            'found_in_email_date': email.get('date', '')
                        })
        
        return status_referees
    
    def _enhance_referee_data(self, web_referees: List[Dict], email_timeline: Dict, 
                            status_referees: List[Dict]) -> List[Dict]:
        """
        Enhance web referee data with email timeline information.
        
        SIFIN-specific: Also incorporate status email referee data
        """
        enhanced_referees = []
        
        # Create email lookup maps
        email_invitations = {inv['referee_email'].lower(): inv for inv in email_timeline.get('invitations', [])}
        email_responses = {resp['referee_email'].lower(): resp for resp in email_timeline.get('responses', [])}
        
        # Create status referee lookup
        status_by_email = {ref['email']: ref for ref in status_referees if ref.get('email')}
        status_by_name = {ref['name'].lower(): ref for ref in status_referees if ref.get('name')}
        
        for web_ref in web_referees:
            enhanced_ref = web_ref.copy()
            referee_email = web_ref.get('email', '').lower()
            referee_name = web_ref.get('name', '').lower()
            
            # Check email timeline
            if referee_email in email_invitations:
                invitation = email_invitations[referee_email]
                enhanced_ref['invitation_date'] = invitation.get('date')
                enhanced_ref['invitation_deadline'] = invitation.get('deadline')
                enhanced_ref['email_evidence'] = True
            else:
                enhanced_ref['email_evidence'] = False
                
            if referee_email in email_responses:
                response = email_responses[referee_email]
                enhanced_ref['response_date'] = response.get('date')
                enhanced_ref['email_decision'] = response.get('decision')
            
            # Check status emails
            status_ref = status_by_email.get(referee_email) or status_by_name.get(referee_name)
            if status_ref:
                enhanced_ref['found_in_status_email'] = True
                enhanced_ref['status_email_date'] = status_ref.get('found_in_email_date')
                
                # If we don't have email evidence from invitations, this is still evidence
                if not enhanced_ref.get('email_evidence'):
                    enhanced_ref['email_evidence'] = True
                    enhanced_ref['email_evidence_type'] = 'status_email'
            
            # Validate status consistency
            if enhanced_ref.get('email_decision') and enhanced_ref.get('status'):
                web_status = enhanced_ref['status'].lower()
                email_decision = enhanced_ref['email_decision'].lower()
                
                # SIFIN might use different terminology
                status_mapping = {
                    'declined': ['declined', 'unable', 'unavailable'],
                    'accepted': ['accepted', 'agreed', 'willing'],
                    'pending': ['accepted', 'agreed'],  # Accepted but report not submitted
                    'complete': ['accepted']  # Must have accepted to complete
                }
                
                expected_decisions = status_mapping.get(web_status, [])
                if email_decision not in expected_decisions and email_decision:
                    enhanced_ref['has_contradiction'] = True
                    enhanced_ref['contradiction_details'] = f"Web shows '{web_status}' but email shows '{email_decision}'"
                else:
                    enhanced_ref['has_contradiction'] = False
            
            enhanced_referees.append(enhanced_ref)
        
        # Add email-only referees
        for email, invitation in email_invitations.items():
            if not any(ref.get('email', '').lower() == email for ref in web_referees):
                email_only_ref = {
                    'name': invitation.get('referee_name', ''),
                    'email': invitation.get('referee_email', ''),
                    'status': 'email_only',
                    'invitation_date': invitation.get('date'),
                    'invitation_deadline': invitation.get('deadline'),
                    'email_evidence': True,
                    'web_evidence': False,
                    'warning': 'Found in emails but not on website'
                }
                
                if email in email_responses:
                    response = email_responses[email]
                    email_only_ref['response_date'] = response.get('date')
                    email_only_ref['email_decision'] = response.get('decision')
                
                enhanced_referees.append(email_only_ref)
        
        return enhanced_referees
    
    def _report_validation_issues(self, manuscripts: List[Dict]) -> None:
        """Report critical validation issues that require attention."""
        total_issues = 0
        critical_issues = 0
        
        for ms in manuscripts:
            issues = ms.get('validation_issues', [])
            total_issues += len(issues)
            critical_issues += sum(1 for issue in issues if issue['severity'] == 'critical')
        
        if critical_issues > 0:
            logger.error(f"CRITICAL: Found {critical_issues} timeline contradictions in SIFIN!")
            logger.error("These indicate data integrity issues between web and email sources.")
            
            # Show examples
            for ms in manuscripts[:3]:
                if ms.get('has_critical_issues'):
                    logger.error(f"\nManuscript {ms['id']}:")
                    for issue in ms['validation_issues']:
                        if issue['severity'] == 'critical':
                            logger.error(f"  - {issue['description']}")
        
        # SIFIN-specific warnings
        status_email_count = sum(len(ms.get('status_email_referees', [])) for ms in manuscripts)
        if status_email_count > 0:
            logger.info(f"Found {status_email_count} referee assignments in status emails")
            logger.info("This is common for SIFIN - referee info may be embedded in status updates")
        
        logger.info(f"Timeline validation complete: {total_issues} total issues, {critical_issues} critical")


# SIFIN Email Parser
class SIFINEmailParser:
    """Parse SIFIN emails to extract referee timeline information."""
    
    def __init__(self):
        # SIFIN-specific patterns
        self.invitation_patterns = [
            r'SIFIN:\s*Referee\s+invitation\s+for\s+manuscript\s+(M\d+)',
            r'Invitation\s+to\s+review\s+manuscript\s+(M\d+)\s+for\s+SIFIN',
            r'SIFIN.*invited.*review.*manuscript\s+(M\d+)',
            r'referee.*assigned.*manuscript\s+(M\d+).*SIFIN'
        ]
        
        self.response_patterns = [
            r'SIFIN:\s*Referee\s+(accepted|declined|unable)\s+to\s+review\s+(M\d+)',
            r'(Accepted|Declined|Unable)\s+to\s+review\s+SIFIN\s+manuscript\s+(M\d+)',
            r'SIFIN.*manuscript\s+(M\d+).*referee.*has\s+(accepted|declined|agreed)'
        ]
    
    def parse_referee_emails(self, emails: List[Dict], manuscript_id: str = None) -> Dict[str, List[Dict]]:
        """Parse emails to extract referee timeline data."""
        timeline = {
            'invitations': [],
            'responses': [],
            'reminders': [],
            'status_updates': [],
            'unmatched': []
        }
        
        for email in emails:
            subject = email.get('subject', '')
            body = email.get('body', '')
            full_text = f"{subject} {body}"
            
            # Skip if filtering by manuscript
            if manuscript_id and manuscript_id not in full_text:
                continue
            
            # Check for various email types
            parsed = False
            
            # Invitations
            for pattern in self.invitation_patterns:
                match = re.search(pattern, full_text, re.IGNORECASE)
                if match:
                    timeline['invitations'].append(self._parse_invitation(email, match))
                    parsed = True
                    break
            
            if not parsed:
                # Responses
                for pattern in self.response_patterns:
                    match = re.search(pattern, full_text, re.IGNORECASE)
                    if match:
                        timeline['responses'].append(self._parse_response(email, match))
                        parsed = True
                        break
            
            # Status updates (SIFIN-specific)
            if not parsed and 'status' in subject.lower() and 'SIFIN' in subject:
                timeline['status_updates'].append({
                    'date': email.get('date', ''),
                    'subject': subject,
                    'body_preview': body[:500]
                })
                parsed = True
            
            # Track unmatched SIFIN emails
            if not parsed and 'SIFIN' in subject.upper():
                timeline['unmatched'].append({
                    'date': email.get('date', ''),
                    'subject': subject,
                    'preview': body[:200]
                })
        
        return timeline
    
    def _parse_invitation(self, email: Dict, match) -> Dict:
        """Parse invitation email details."""
        return {
            'type': 'invitation',
            'manuscript_id': match.group(1) if match.groups() else None,
            'date': email.get('date', ''),
            'referee_name': self._extract_referee_name(email),
            'referee_email': email.get('to', ''),
            'subject': email.get('subject', ''),
            'deadline': self._extract_deadline(email.get('body', ''))
        }
    
    def _parse_response(self, email: Dict, match) -> Dict:
        """Parse response email details."""
        # Extract decision
        if len(match.groups()) >= 2:
            decision = match.group(1).lower()
            manuscript_id = match.group(2)
        else:
            decision = 'unknown'
            manuscript_id = match.group(1) if match.groups() else None
        
        # Normalize decision
        if 'accept' in decision or 'agree' in decision:
            decision = 'accepted'
        elif 'declin' in decision or 'unable' in decision:
            decision = 'declined'
        
        return {
            'type': 'response',
            'manuscript_id': manuscript_id,
            'date': email.get('date', ''),
            'decision': decision,
            'referee_name': self._extract_referee_name(email),
            'referee_email': email.get('to', ''),
            'subject': email.get('subject', '')
        }
    
    def _extract_referee_name(self, email: Dict) -> str:
        """Extract referee name from email."""
        to_field = email.get('to', '')
        
        # Extract name from "Name <email>" format
        if '"' in to_field:
            match = re.search(r'"([^"]+)"', to_field)
            if match:
                return match.group(1)
        elif '<' in to_field:
            return to_field.split('<')[0].strip()
        
        return ''
    
    def _extract_deadline(self, body: str) -> Optional[str]:
        """Extract deadline from email body."""
        # Look for deadline patterns
        deadline_patterns = [
            r'deadline[:\s]+([A-Za-z]+ \d+,? \d{4})',
            r'due by[:\s]+([A-Za-z]+ \d+,? \d{4})',
            r'by[:\s]+([A-Za-z]+ \d+,? \d{4})'
        ]
        
        for pattern in deadline_patterns:
            match = re.search(pattern, body, re.IGNORECASE)
            if match:
                return match.group(1)
        
        return None


# Test function
def test_sifin_extraction(validate_timeline: bool = True):
    """Test SIFIN extraction with timeline validation."""
    from editorial_assistant.core.data_models import JournalConfig
    
    config = JournalConfig(
        code="SIFIN",
        name="SIAM Journal on Financial Mathematics",
        url="https://sifin.siam.org/cgi-bin/main.plex",
        platform="siam_orcid",
        credentials={
            "username_env": "ORCID_EMAIL",
            "password_env": "ORCID_PASSWORD"
        }
    )
    
    extractor = SIFINCompleteExtractor(config, validate_timeline=validate_timeline)
    manuscripts = extractor.extract_data()
    
    # Save results
    output_file = f"sifin_complete_extraction_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_file, 'w') as f:
        json.dump(manuscripts, f, indent=2, default=str)
    
    print(f"\nSIFIN extraction complete!")
    print(f"Total manuscripts: {len(manuscripts)}")
    
    # Summary
    total_critical = sum(1 for ms in manuscripts if ms.get('has_critical_issues'))
    if total_critical > 0:
        print(f"\n⚠️  WARNING: {total_critical} manuscripts have critical timeline issues!")
    else:
        print("\n✅ No critical timeline issues found")
    
    # SIFIN-specific summary
    status_email_refs = sum(len(ms.get('status_email_referees', [])) for ms in manuscripts)
    if status_email_refs > 0:
        print(f"\n📧 Found {status_email_refs} referee assignments in status emails")
    
    print(f"\nResults saved to: {output_file}")
    
    return manuscripts


if __name__ == "__main__":
    test_sifin_extraction(validate_timeline=True)