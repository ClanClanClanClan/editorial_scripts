#!/usr/bin/env python3
"""
Foolproof Referee Tracker
Implements comprehensive validation and quality filters for referee identification
"""

import re
import json
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field
from collections import defaultdict
import difflib

# Import base classes
from referee_email_tracker import (
    EmailEvent, RefereeProfile, RefereeAttribution, RefereeState, 
    RefereeAssignment, GenericRefereeTracker
)

logger = logging.getLogger(__name__)

@dataclass
class ValidationResult:
    """Result of referee validation"""
    is_valid: bool
    confidence: float
    reasons: List[str]
    entity_type: str  # 'person', 'manuscript_id', 'system_term', 'noise'

class RefereeEntityValidator:
    """Validates if extracted entities are actual people"""
    
    def __init__(self):
        # Person name patterns
        self.person_name_patterns = [
            r'^[A-Z][a-z]+\s+[A-Z][a-z]+$',  # First Last
            r'^[A-Z][a-z]+\s+[A-Z]\.\s+[A-Z][a-z]+$',  # First M. Last
            r'^[A-Z][a-z]+\s+[A-Z][a-z]+\s+[A-Z][a-z]+$',  # First Middle Last
            r'^[A-Z][a-z]+\s+[A-Z][a-z]+\s+[A-Z][a-z]+\s+[A-Z][a-z]+$',  # First Middle Middle Last
            r'^[A-Z][a-z]+(?:\s+[A-Z][a-z]*)*\s+[A-Z][a-z]+$',  # First ... Last (flexible)
        ]
        
        # Blacklists for known false positives
        self.blacklist = {
            'manuscript_ids': {
                'M174160', 'M174727', 'M175988', 'M176140',
                'M147228', 'M147862', 'M149254', 'M149423'
            },
            'process_terms': {
                'review MS', 'manuscript', 'submission', 'follow-up',
                'reminder', 'overdue', 'invitation', 'response',
                'report', 'review', 'referee', 'reviewer'
            },
            'system_terms': {
                'SIFIN', 'SIAM', 'editorial', 'editor', 'system',
                'automated', 'notification', 'message', 'email'
            },
            'noise_terms': {
                'RE:', 'FW:', 'Dear', 'Sincerely', 'Best', 'Regards',
                'Thank', 'Please', 'Kind', 'Yours', 'Truly'
            },
            'academic_terms': {
                'Professor', 'Dr.', 'Prof.', 'PhD', 'Ph.D.',
                'University', 'College', 'Institute', 'Department'
            }
        }
        
        # Common academic titles that should be stripped
        self.title_patterns = [
            r'^(?:Dr\.?|Prof\.?|Professor)\s+',
            r'\s+(?:PhD|Ph\.D\.)$',
            r'\s+#\d+$',  # Remove referee numbers like "#1", "#2"
        ]
        
        # Suspicious patterns
        self.suspicious_patterns = [
            r'^[A-Z]\d+$',  # Single letter + digits
            r'^\d+$',       # Only digits
            r'^[A-Z]{2,}$', # All caps (likely acronym)
            r'[<>@]',       # Email-like characters
            r'^.{1,2}$',    # Too short
            r'^.{50,}$',    # Too long
        ]
        
    def validate_referee_name(self, name: str) -> ValidationResult:
        """Validate if a name represents a real person"""
        if not name or not name.strip():
            return ValidationResult(False, 0.0, ['empty_name'], 'noise')
        
        name = name.strip()
        reasons = []
        confidence = 1.0
        
        # Check blacklists
        if self._is_blacklisted(name):
            entity_type = self._get_entity_type(name)
            return ValidationResult(False, 0.0, ['blacklisted'], entity_type)
        
        # Clean name by removing titles
        cleaned_name = self._clean_name(name)
        
        # Check suspicious patterns
        if self._is_suspicious(cleaned_name):
            return ValidationResult(False, 0.1, ['suspicious_pattern'], 'noise')
        
        # Check if matches person name patterns
        if not self._matches_person_pattern(cleaned_name):
            confidence *= 0.3
            reasons.append('poor_name_structure')
        
        # Check name quality
        quality_score = self._calculate_name_quality(cleaned_name)
        confidence *= quality_score
        
        if quality_score < 0.5:
            reasons.append('low_quality_name')
        
        # Final validation
        is_valid = confidence > 0.6 and self._has_minimum_name_requirements(cleaned_name)
        
        if not is_valid:
            reasons.append('failed_validation')
        
        return ValidationResult(is_valid, confidence, reasons, 'person' if is_valid else 'noise')
    
    def _is_blacklisted(self, name: str) -> bool:
        """Check if name is in any blacklist"""
        name_lower = name.lower()
        for blacklist in self.blacklist.values():
            if name in blacklist or name_lower in {item.lower() for item in blacklist}:
                return True
        return False
    
    def _get_entity_type(self, name: str) -> str:
        """Determine entity type from blacklists"""
        name_lower = name.lower()
        for entity_type, blacklist in self.blacklist.items():
            if name in blacklist or name_lower in {item.lower() for item in blacklist}:
                return entity_type.replace('_terms', '').replace('_ids', '')
        return 'unknown'
    
    def _clean_name(self, name: str) -> str:
        """Remove titles and clean name"""
        cleaned = name
        for pattern in self.title_patterns:
            cleaned = re.sub(pattern, '', cleaned, flags=re.IGNORECASE)
        return cleaned.strip()
    
    def _is_suspicious(self, name: str) -> bool:
        """Check for suspicious patterns"""
        for pattern in self.suspicious_patterns:
            if re.search(pattern, name):
                return True
        return False
    
    def _matches_person_pattern(self, name: str) -> bool:
        """Check if name matches expected person patterns"""
        for pattern in self.person_name_patterns:
            if re.match(pattern, name):
                return True
        return False
    
    def _calculate_name_quality(self, name: str) -> float:
        """Calculate quality score for name"""
        score = 1.0
        
        # Check length
        if len(name) < 3:
            score *= 0.1
        elif len(name) < 5:
            score *= 0.5
        elif len(name) > 40:
            score *= 0.7
        
        # Check for proper capitalization
        words = name.split()
        if len(words) >= 2:
            properly_capitalized = all(word[0].isupper() and word[1:].islower() 
                                     for word in words if word)
            if properly_capitalized:
                score *= 1.2
            else:
                score *= 0.6
        
        # Check for reasonable word count
        if len(words) < 2:
            score *= 0.3
        elif len(words) > 5:
            score *= 0.8
        
        # Check for alphabetic characters
        if not all(c.isalpha() or c.isspace() or c == '.' for c in name):
            score *= 0.4
        
        return min(score, 1.0)
    
    def _has_minimum_name_requirements(self, name: str) -> bool:
        """Check minimum requirements for person name"""
        words = name.split()
        return (
            len(words) >= 2 and  # At least first and last name
            len(name) >= 3 and   # Minimum length
            all(len(word) >= 1 for word in words)  # No empty words
        )

class CommunicationRoleClassifier:
    """Classifies roles in email communications"""
    
    def __init__(self):
        self.role_patterns = {
            'editorial': {
                'emails': {
                    'dylan.possamai@math.ethz.ch',
                    'dylansmb@gmail.com'
                },
                'domains': {
                    'math.ethz.ch'
                },
                'indicators': {
                    'editor', 'coordinator', 'managing', 'editorial',
                    'associate editor', 'managing editor', 'editor-in-chief'
                }
            },
            'referee': {
                'indicators': {
                    'reviewer', 'referee', 'review request', 'invitation',
                    'agreed to review', 'declined to review', 'submitted report'
                },
                'exclusions': {
                    'editorial', 'managing', 'coordinator', 'editor'
                },
                'context_patterns': [
                    r'invited?\s+(?:you\s+)?to\s+(?:serve\s+as\s+)?(?:a\s+)?(?:referee|reviewer)',
                    r'has\s+(?:agreed|accepted|declined)\s+to\s+(?:referee|review)',
                    r'has\s+submitted\s+(?:a\s+)?(?:referee\s+)?report'
                ]
            },
            'system': {
                'domains': {
                    'sifin.siam.org', 'siam.org', 'editorialmanager.com',
                    'manuscriptcentral.com', 'ees.elsevier.com'
                },
                'indicators': {
                    'automated', 'system', 'notification', 'reminder',
                    'follow-up', 'overdue', 'deadline'
                }
            },
            'author': {
                'indicators': {
                    'corresponding author', 'manuscript author', 'submission',
                    'author response', 'revision', 'resubmission'
                },
                'context_patterns': [
                    r'submitted\s+(?:a\s+)?manuscript',
                    r'author\s+(?:response|revision)',
                    r'corresponding\s+author'
                ]
            }
        }
        
    def classify_email_role(self, email_event: EmailEvent) -> Dict[str, float]:
        """Classify roles with confidence scores"""
        scores = defaultdict(float)
        
        # Check sender/recipient addresses
        all_addresses = [email_event.from_address] + email_event.to_addresses + email_event.cc_addresses
        
        for address in all_addresses:
            if not address:
                continue
                
            # Editorial check
            if self._is_editorial_address(address):
                scores['editorial'] += 0.8
            
            # System check
            if self._is_system_address(address):
                scores['system'] += 0.9
        
        # Check content patterns
        content = f"{email_event.subject} {email_event.body}".lower()
        
        for role, patterns in self.role_patterns.items():
            if role in ['editorial', 'system']:
                continue  # Already checked above
                
            # Check indicators
            for indicator in patterns.get('indicators', []):
                if indicator in content:
                    scores[role] += 0.6
            
            # Check context patterns
            for pattern in patterns.get('context_patterns', []):
                if re.search(pattern, content, re.IGNORECASE):
                    scores[role] += 0.8
        
        # Normalize scores
        total = sum(scores.values())
        if total > 0:
            scores = {role: score/total for role, score in scores.items()}
        
        return dict(scores)
    
    def _is_editorial_address(self, email: str) -> bool:
        """Check if email is editorial"""
        email_lower = email.lower()
        editorial_config = self.role_patterns['editorial']
        
        if email_lower in editorial_config['emails']:
            return True
            
        domain = email_lower.split('@')[-1] if '@' in email_lower else ''
        if domain in editorial_config['domains']:
            return True
            
        return False
    
    def _is_system_address(self, email: str) -> bool:
        """Check if email is from system"""
        domain = email.split('@')[-1].lower() if '@' in email else ''
        return domain in self.role_patterns['system']['domains']

class RefereeEntityResolver:
    """Resolves duplicate referee identities"""
    
    def __init__(self):
        self.similarity_threshold = 0.8
        self.email_weight = 0.5
        self.name_weight = 0.4
        self.domain_weight = 0.1
        
    def resolve_duplicates(self, referee_profiles: List[RefereeProfile]) -> List[RefereeProfile]:
        """Identify and merge duplicate referee profiles"""
        if len(referee_profiles) < 2:
            return referee_profiles
            
        # Build similarity matrix
        similarity_matrix = self._build_similarity_matrix(referee_profiles)
        
        # Find duplicate groups
        duplicate_groups = self._find_duplicate_groups(similarity_matrix)
        
        # Merge duplicates
        merged_profiles = self._merge_duplicate_groups(referee_profiles, duplicate_groups)
        
        return merged_profiles
    
    def _build_similarity_matrix(self, profiles: List[RefereeProfile]) -> List[List[float]]:
        """Build similarity matrix between profiles"""
        n = len(profiles)
        matrix = [[0.0] * n for _ in range(n)]
        
        for i in range(n):
            for j in range(i+1, n):
                similarity = self._calculate_similarity(profiles[i], profiles[j])
                matrix[i][j] = similarity
                matrix[j][i] = similarity
        
        return matrix
    
    def _calculate_similarity(self, profile1: RefereeProfile, profile2: RefereeProfile) -> float:
        """Calculate similarity between two profiles"""
        score = 0.0
        
        # Email similarity
        email_sim = self._calculate_email_similarity(profile1.email_addresses, profile2.email_addresses)
        score += email_sim * self.email_weight
        
        # Name similarity
        name_sim = self._calculate_name_similarity(profile1.name_variations, profile2.name_variations)
        score += name_sim * self.name_weight
        
        # Domain similarity
        domain_sim = self._calculate_domain_similarity(profile1.email_addresses, profile2.email_addresses)
        score += domain_sim * self.domain_weight
        
        return score
    
    def _calculate_email_similarity(self, emails1: Set[str], emails2: Set[str]) -> float:
        """Calculate email similarity"""
        if not emails1 or not emails2:
            return 0.0
            
        # Exact match
        if emails1 & emails2:
            return 1.0
            
        # Check for similar usernames
        usernames1 = {email.split('@')[0].lower() for email in emails1}
        usernames2 = {email.split('@')[0].lower() for email in emails2}
        
        if usernames1 & usernames2:
            return 0.8
            
        return 0.0
    
    def _calculate_name_similarity(self, names1: Set[str], names2: Set[str]) -> float:
        """Calculate name similarity"""
        if not names1 or not names2:
            return 0.0
            
        max_similarity = 0.0
        for name1 in names1:
            for name2 in names2:
                similarity = difflib.SequenceMatcher(None, name1.lower(), name2.lower()).ratio()
                max_similarity = max(max_similarity, similarity)
        
        return max_similarity
    
    def _calculate_domain_similarity(self, emails1: Set[str], emails2: Set[str]) -> float:
        """Calculate domain similarity"""
        if not emails1 or not emails2:
            return 0.0
            
        domains1 = {email.split('@')[1].lower() for email in emails1 if '@' in email}
        domains2 = {email.split('@')[1].lower() for email in emails2 if '@' in email}
        
        if domains1 & domains2:
            return 1.0
            
        return 0.0
    
    def _find_duplicate_groups(self, similarity_matrix: List[List[float]]) -> List[List[int]]:
        """Find groups of duplicate profiles"""
        n = len(similarity_matrix)
        visited = [False] * n
        groups = []
        
        for i in range(n):
            if visited[i]:
                continue
                
            group = [i]
            visited[i] = True
            
            for j in range(i+1, n):
                if not visited[j] and similarity_matrix[i][j] > self.similarity_threshold:
                    group.append(j)
                    visited[j] = True
            
            groups.append(group)
        
        return groups
    
    def _merge_duplicate_groups(self, profiles: List[RefereeProfile], groups: List[List[int]]) -> List[RefereeProfile]:
        """Merge duplicate groups into single profiles"""
        merged_profiles = []
        
        for group in groups:
            if len(group) == 1:
                merged_profiles.append(profiles[group[0]])
            else:
                merged_profile = self._merge_profiles([profiles[i] for i in group])
                merged_profiles.append(merged_profile)
        
        return merged_profiles
    
    def _merge_profiles(self, profiles: List[RefereeProfile]) -> RefereeProfile:
        """Merge multiple profiles into one"""
        merged = RefereeProfile(referee_id=profiles[0].referee_id)
        
        # Merge name variations
        for profile in profiles:
            merged.name_variations.update(profile.name_variations)
        
        # Merge email addresses
        for profile in profiles:
            merged.email_addresses.update(profile.email_addresses)
        
        # Merge manuscript assignments
        for profile in profiles:
            merged.manuscript_assignments.update(profile.manuscript_assignments)
        
        # Merge communication history
        for profile in profiles:
            merged.communication_history.extend(profile.communication_history)
        
        return merged

class FoolproofRefereeTracker(GenericRefereeTracker):
    """Foolproof referee tracker with comprehensive validation"""
    
    def __init__(self):
        super().__init__()
        self.entity_validator = RefereeEntityValidator()
        self.role_classifier = CommunicationRoleClassifier()
        self.entity_resolver = RefereeEntityResolver()
        self.minimum_confidence = 0.7
        
    def process_email(self, email_event: EmailEvent) -> EmailEvent:
        """Process email with foolproof validation"""
        # Basic processing
        email_event = super().process_email(email_event)
        
        # Additional validation for referee attribution
        if email_event.attribution:
            referee_profile = self.referee_profiles.get(email_event.attribution.referee_id)
            if referee_profile:
                # Validate referee names
                valid_names = set()
                for name in referee_profile.name_variations:
                    validation = self.entity_validator.validate_referee_name(name)
                    if validation.is_valid:
                        valid_names.add(name)
                
                # Update profile with only valid names
                referee_profile.name_variations = valid_names
                
                # If no valid names, mark as invalid
                if not valid_names and not referee_profile.email_addresses:
                    email_event.attribution.confidence *= 0.1
        
        return email_event
    
    def finalize_processing(self):
        """Finalize with entity resolution and validation"""
        # Basic finalization
        super().finalize_processing()
        
        # Resolve duplicate referee identities
        referee_list = list(self.referee_profiles.values())
        resolved_profiles = self.entity_resolver.resolve_duplicates(referee_list)
        
        # Build mapping from old IDs to new IDs
        old_to_new_mapping = {}
        for new_profile in resolved_profiles:
            for old_profile in referee_list:
                if old_profile.referee_id == new_profile.referee_id:
                    old_to_new_mapping[old_profile.referee_id] = new_profile.referee_id
                    break
        
        # Rebuild referee profiles dict
        self.referee_profiles = {profile.referee_id: profile for profile in resolved_profiles}
        
        # Update manuscript assignments with new referee IDs
        self._update_manuscript_assignments(old_to_new_mapping)
        
        # Enhanced name-email linking
        self._enhance_name_email_linking()
        
        # Filter low-confidence referees
        self._filter_low_confidence_referees()
    
    def _update_manuscript_assignments(self, old_to_new_mapping: Dict[str, str]):
        """Update manuscript assignments with new referee IDs"""
        updated_assignments = defaultdict(dict)
        
        for manuscript_id, assignments in self.manuscript_assignments.items():
            for old_referee_id, assignment in assignments.items():
                new_referee_id = old_to_new_mapping.get(old_referee_id, old_referee_id)
                assignment.referee_id = new_referee_id
                updated_assignments[manuscript_id][new_referee_id] = assignment
        
        self.manuscript_assignments = updated_assignments
    
    def _enhance_name_email_linking(self):
        """Enhanced name-email linking using manuscript context"""
        # Group referees by manuscript
        manuscript_referees = defaultdict(list)
        for manuscript_id, assignments in self.manuscript_assignments.items():
            for referee_id in assignments.keys():
                if referee_id in self.referee_profiles:
                    manuscript_referees[manuscript_id].append(referee_id)
        
        # For each manuscript, try to match orphaned names with emails
        for manuscript_id, referee_ids in manuscript_referees.items():
            email_only_refs = []
            name_only_refs = []
            complete_refs = []
            
            # Categorize referees
            for ref_id in referee_ids:
                profile = self.referee_profiles[ref_id]
                has_email = len(profile.email_addresses) > 0
                has_name = len(profile.name_variations) > 0
                
                if has_email and has_name:
                    complete_refs.append(ref_id)
                elif has_email and not has_name:
                    email_only_refs.append(ref_id)
                elif has_name and not has_email:
                    name_only_refs.append(ref_id)
            
            # Try to match email-only with name-only refs
            for email_ref_id in email_only_refs:
                email_profile = self.referee_profiles[email_ref_id]
                email = next(iter(email_profile.email_addresses))
                
                # Look for name patterns in communication history
                for email_event in email_profile.communication_history:
                    referee_name = self.pattern_matcher.extract_referee_name(email_event)
                    if referee_name:
                        validation = self.entity_validator.validate_referee_name(referee_name)
                        if validation.is_valid:
                            email_profile.add_name_variation(referee_name)
                            break
    
    def _filter_low_confidence_referees(self):
        """Filter out low-confidence referee identifications"""
        high_confidence_referees = {}
        
        for referee_id, profile in self.referee_profiles.items():
            # Calculate overall confidence
            confidence = self._calculate_referee_confidence(profile)
            
            if confidence >= self.minimum_confidence:
                high_confidence_referees[referee_id] = profile
            else:
                logger.info(f"Filtering out low-confidence referee: {referee_id} (confidence: {confidence:.2f})")
        
        self.referee_profiles = high_confidence_referees
    
    def _calculate_referee_confidence(self, profile: RefereeProfile) -> float:
        """Calculate overall confidence for referee profile"""
        confidence = 0.0
        
        # Email validation
        if profile.email_addresses:
            email_confidence = 0.8  # High confidence for email addresses
            confidence += email_confidence * 0.5
        
        # Name validation
        if profile.name_variations:
            name_validations = [
                self.entity_validator.validate_referee_name(name) 
                for name in profile.name_variations
            ]
            valid_names = [v for v in name_validations if v.is_valid]
            if valid_names:
                avg_name_confidence = sum(v.confidence for v in valid_names) / len(valid_names)
                confidence += avg_name_confidence * 0.3
        
        # Timeline validation
        if profile.communication_history:
            timeline_confidence = min(1.0, len(profile.communication_history) * 0.2)
            confidence += timeline_confidence * 0.2
        
        return confidence
    
    def generate_foolproof_report(self, manuscript_id: str) -> str:
        """Generate foolproof validation report"""
        analytics = self.generate_analytics(manuscript_id)
        
        report = []
        report.append(f"📊 Foolproof Referee Report: {manuscript_id}")
        report.append("=" * 60)
        
        report.append(f"✅ Validated Referees: {analytics['total_referees']}")
        report.append(f"🏢 Editorial Contacts: {analytics['total_editorial_contacts']}")
        report.append(f"📧 Referee Email Coverage: {analytics.get('referee_email_coverage', 0):.1%}")
        report.append("")
        
        # Validated referees
        report.append("👥 VALIDATED REFEREES:")
        for referee_id, referee_data in analytics['referees'].items():
            name = referee_data['name']
            email = referee_data['email']
            
            # Validate name
            validation = self.entity_validator.validate_referee_name(name)
            
            # Get confidence if profile exists
            profile = self.referee_profiles.get(referee_id)
            if profile:
                confidence = self._calculate_referee_confidence(profile)
            else:
                confidence = 0.5  # Default confidence if profile not found
            
            report.append(f"   ✅ {name} ({email})")
            report.append(f"      Confidence: {confidence:.2f}")
            report.append(f"      State: {referee_data['state']}")
            report.append(f"      Timeline Events: {referee_data['timeline_events']}")
            
            if referee_data['invitation_date']:
                report.append(f"      📨 Invited: {referee_data['invitation_date']}")
            if referee_data['submission_date']:
                report.append(f"      📝 Submitted: {referee_data['submission_date']}")
            report.append("")
        
        # Editorial contacts
        if analytics['editorial_contacts']:
            report.append("📧 EDITORIAL CONTACTS:")
            for contact_id, contact_data in analytics['editorial_contacts'].items():
                report.append(f"   📧 {contact_data['name']} ({contact_data['email']})")
                report.append(f"      Timeline Events: {contact_data['timeline_events']}")
                report.append("")
        
        return "\n".join(report)