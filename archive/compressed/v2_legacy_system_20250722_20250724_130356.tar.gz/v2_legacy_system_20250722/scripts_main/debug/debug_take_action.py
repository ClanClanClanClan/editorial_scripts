#!/usr/bin/env python3
"""Debug exactly what's happening with Take Action clicking"""

import os
import sys
import time
from pathlib import Path
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

def debug_take_action():
    """Debug Take Action step by step"""
    
    print("🔍 DEBUGGING TAKE ACTION CLICKING")
    print("=" * 50)
    
    # Chrome setup
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        from core.email_utils import fetch_latest_verification_code
        
        print("1. Navigating to MF...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        print("2. Handling cookies...")
        try:
            reject_btn = driver.find_element(By.ID, "onetrust-reject-all-handler")
            reject_btn.click()
        except:
            pass
        
        print("3. Logging in...")
        email_field = driver.find_element(By.ID, "USERID")
        email_field.send_keys(os.getenv('MF_EMAIL'))
        
        password_field = driver.find_element(By.ID, "PASSWORD")
        password_field.send_keys(os.getenv('MF_PASSWORD'))
        
        login_btn = driver.find_element(By.ID, "logInButton")
        driver.execute_script("arguments[0].click();", login_btn)
        time.sleep(3)
        
        print("4. Handling 2FA if needed...")
        try:
            code_input = driver.find_element(By.ID, "TOKEN_VALUE")
            print("⚠️ 2FA required - waiting for current verification code (NOT clicking resend)")
            
            # Get verification code - wait longer for email to arrive
            print("🔍 Waiting longer for verification email to arrive...")
            code = fetch_latest_verification_code('MF', max_wait=180, poll_interval=5)
            if code:
                code_input.clear()
                code_input.send_keys(code)
                
                try:
                    remember_checkbox = driver.find_element(By.ID, "REMEMBER_THIS_DEVICE")
                    if not remember_checkbox.is_selected():
                        remember_checkbox.click()
                except:
                    pass
                    
                verify_btn = driver.find_element(By.ID, "VERIFY_BTN")
                verify_btn.click()
                time.sleep(15)
                
                # Check if verification worked
                page_text = driver.find_element(By.TAG_NAME, "body").text
                if "Verification Error" in page_text:
                    print("❌ 2FA verification failed!")
                    with open('debug_2fa_failed.html', 'w') as f:
                        f.write(driver.page_source)
                    return
                elif "Associate Editor Center" in page_text:
                    print("✅ 2FA successful - found Associate Editor Center on page")
                else:
                    print("⚠️ 2FA status unclear")
                    
        except Exception as e:
            print(f"No 2FA needed or error: {e}")
        
        # Save page after login/2FA
        print("4.5. Saving post-login page...")
        with open('debug_post_login.html', 'w') as f:
            f.write(driver.page_source)
        
        current_text = driver.find_element(By.TAG_NAME, "body").text
        print(f"Current page contains 'Associate Editor': {'Associate Editor' in current_text}")
        print(f"Current page contains 'Center': {'Center' in current_text}")
        print(f"Current page contains 'Log In': {'Log In' in current_text}")
        print(f"Current URL: {driver.current_url}")
        
        print("5. Navigating to Associate Editor Center...")
        try:
            ae_link = driver.find_element(By.LINK_TEXT, "Associate Editor Center")
            ae_link.click()
            time.sleep(5)
        except Exception as e:
            print(f"❌ Failed to find Associate Editor Center: {e}")
            return
        
        print("6. Navigating to manuscript category...")
        try:
            category_link = driver.find_element(By.LINK_TEXT, "Awaiting Reviewer Scores")
            category_link.click()
            time.sleep(5)
        except Exception as e:
            print(f"❌ Failed to find category: {e}")
            return
        
        print("7. ANALYZING MANUSCRIPT TABLE...")
        print("-" * 40)
        
        # Find all rows
        all_rows = driver.find_elements(By.TAG_NAME, "tr")
        print(f"Total rows found: {len(all_rows)}")
        
        manuscript_rows = []
        for i, row in enumerate(all_rows):
            if 'MAFI-' in row.text:
                manuscript_rows.append((i, row))
                print(f"Manuscript row {i}: {row.text[:100]}...")
        
        print(f"\nFound {len(manuscript_rows)} manuscript rows")
        
        if not manuscript_rows:
            print("❌ NO MANUSCRIPT ROWS FOUND!")
            with open('debug_manuscript_page.html', 'w') as f:
                f.write(driver.page_source)
            return
        
        # Analyze first manuscript row
        row_index, first_row = manuscript_rows[0]
        print(f"\n8. ANALYZING FIRST MANUSCRIPT ROW (index {row_index})...")
        print("-" * 40)
        
        cells = first_row.find_elements(By.TAG_NAME, "td")
        print(f"Row has {len(cells)} cells:")
        
        for j, cell in enumerate(cells):
            cell_text = cell.text.strip()[:50]
            print(f"  Cell {j}: '{cell_text}'")
        
        if not cells:
            print("❌ NO CELLS FOUND IN ROW!")
            return
        
        # Analyze last cell (where Take Action should be)
        last_cell = cells[-1]
        print(f"\n9. ANALYZING LAST CELL (cell {len(cells)-1})...")
        print("-" * 40)
        
        print(f"Last cell text: '{last_cell.text.strip()}'")
        
        # Look for Take Action links
        take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
        print(f"Take Action links with check_off.gif: {len(take_action_links)}")
        
        if take_action_links:
            link = take_action_links[0]
            href = link.get_attribute('href')
            print(f"✅ FOUND Take Action link!")
            print(f"href: {href}")
            
            print(f"\n10. TESTING TAKE ACTION CLICK...")
            print("-" * 40)
            
            if href and 'javascript:' in href:
                js_code = href.replace('javascript:', '')
                print(f"JavaScript code: {js_code}")
                
                print("Executing JavaScript...")
                old_url = driver.current_url
                driver.execute_script(js_code)
                time.sleep(5)
                
                new_url = driver.current_url
                page_text = driver.find_element(By.TAG_NAME, "body").text
                
                print(f"Old URL: {old_url}")
                print(f"New URL: {new_url}")
                print(f"URL changed: {old_url != new_url}")
                print(f"Contains 'Referee': {'Referee' in page_text}")
                print(f"Contains 'Reviewer': {'Reviewer' in page_text}")
                
                if old_url != new_url or 'Referee' in page_text or 'Reviewer' in page_text:
                    print("✅ TAKE ACTION CLICK SUCCESSFUL!")
                else:
                    print("❌ TAKE ACTION CLICK FAILED - NO NAVIGATION")
            else:
                print(f"❌ href is not JavaScript: {href}")
        else:
            print("❌ NO Take Action links found with check_off.gif")
            
            # Try broader search
            all_links = last_cell.find_elements(By.TAG_NAME, "a")
            print(f"All links in last cell: {len(all_links)}")
            for link in all_links:
                href = link.get_attribute('href')
                print(f"  Link href: {href}")
        
        print(f"\n11. SAVING DEBUG FILES...")
        with open('debug_manuscript_page.html', 'w') as f:
            f.write(driver.page_source)
        print("Saved debug_manuscript_page.html")
        
    except Exception as e:
        print(f"❌ Error during debug: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        driver.quit()

if __name__ == "__main__":
    debug_take_action()