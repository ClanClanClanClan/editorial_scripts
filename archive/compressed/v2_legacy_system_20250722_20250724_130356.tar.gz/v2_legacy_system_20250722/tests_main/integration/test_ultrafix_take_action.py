#!/usr/bin/env python3
"""
Test the ULTRAFIX Take Action clicking to see if it actually works
"""

import os
import sys
import time
import logging
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from editorial_assistant.extractors.scholarone import ScholarOneExtractor

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_ultrafix_take_action():
    """Test the ULTRAFIX Take Action clicking."""
    print("🎯 Testing ULTRAFIX Take Action clicking...")
    
    # Load production config
    try:
        with open('.env.production', 'r') as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    key, value = line.strip().split('=', 1)
                    os.environ[key] = value
    except FileNotFoundError:
        print("❌ No .env.production file found")
        return
    
    try:
        # Create extractor with headful mode to see what happens
        extractor = ScholarOneExtractor('MF')
        extractor.headless = False  
        
        # Extract manuscripts (this will test the Take Action clicking)
        print("🔄 Starting extraction with ULTRAFIX...")
        print("⚠️  This will test the bulletproof Take Action clicking")
        print("⚠️  Watch the browser to see if it successfully navigates to manuscript details")
        
        result = extractor.extract()
        
        if not result.manuscripts:
            print("❌ No manuscripts found")
            return
        
        print(f"\n📋 ULTRAFIX RESULTS: Found {len(result.manuscripts)} manuscripts")
        print("="*80)
        
        # Check if we got detailed data (which means Take Action worked)
        detailed_extractions = 0
        
        for i, manuscript in enumerate(result.manuscripts, 1):
            print(f"\n📄 MANUSCRIPT {i}: {manuscript.manuscript_id}")
            print("-" * 40)
            
            # Check for signs that Take Action worked and we got detailed data
            has_detailed_data = False
            
            print(f"Title: {manuscript.title}")
            
            # Check authors
            if manuscript.authors:
                print(f"Authors ({len(manuscript.authors)}):")
                for j, author in enumerate(manuscript.authors, 1):
                    print(f"  {j}. {author.name}")
                    # Check if names are normalized (sign of working detailed extraction)
                    if ',' not in author.name and len(author.name.split()) >= 2:
                        has_detailed_data = True
                        print(f"     ✅ Name normalized correctly!")
            
            # Check for extracted documents
            if hasattr(manuscript, 'pdf_path') and manuscript.pdf_path:
                print(f"PDF: ✅ {manuscript.pdf_path}")
                has_detailed_data = True
            
            if hasattr(manuscript, 'cover_letter') and manuscript.cover_letter:
                print(f"Cover Letter: ✅ ({len(manuscript.cover_letter)} characters)")
                has_detailed_data = True
            
            # Check referees
            if manuscript.referees:
                print(f"Referees ({len(manuscript.referees)}):")
                for j, referee in enumerate(manuscript.referees, 1):
                    print(f"  {j}. {referee.name}")
                    if referee.email:
                        print(f"     Email: ✅ {referee.email}")
                        has_detailed_data = True
                    if hasattr(referee, 'review_report') and referee.review_report:
                        print(f"     Review Report: ✅ ({len(referee.review_report)} chars)")
                        has_detailed_data = True
                has_detailed_data = True
            
            # Check for detailed metadata
            if hasattr(manuscript, 'submission_date') and manuscript.submission_date:
                print(f"Submission Date: ✅ {manuscript.submission_date}")
                has_detailed_data = True
            
            if has_detailed_data:
                detailed_extractions += 1
                print("✅ DETAILED DATA EXTRACTED - Take Action worked!")
            else:
                print("❌ NO DETAILED DATA - Take Action likely failed")
        
        print("\n" + "="*80)
        print(f"📊 ULTRAFIX SUCCESS RATE:")
        print(f"Total Manuscripts: {len(result.manuscripts)}")
        print(f"Detailed Extractions: {detailed_extractions}")
        print(f"Success Rate: {detailed_extractions/len(result.manuscripts)*100:.1f}%")
        
        if detailed_extractions > 0:
            print("🎉 ULTRAFIX SUCCESS! Take Action clicking is working!")
            print("✅ All the parsing improvements (normalization, PDFs, emails, etc.) should now be functional")
        else:
            print("❌ ULTRAFIX FAILED! Take Action clicking still broken")
            print("🔍 Check the debug files generated:")
            print("   - debug_before_click_*.html")
            print("   - debug_failed_click_*.html")
        
        # Check for debug files
        debug_files = list(Path('.').glob('debug_*_click_*.html'))
        if debug_files:
            print(f"\n🔍 Debug files created: {len(debug_files)}")
            for file in debug_files[:3]:  # Show first 3
                print(f"   - {file}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_ultrafix_take_action()