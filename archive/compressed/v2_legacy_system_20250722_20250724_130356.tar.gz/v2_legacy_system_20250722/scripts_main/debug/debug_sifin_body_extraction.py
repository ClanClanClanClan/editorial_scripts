#!/usr/bin/env python3
"""
Debug SIFIN email body extraction to see why referee names aren't being found
"""

import os
import sys
import re
import base64
sys.path.append('/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/scripts/sifin')

from parse_sifin_emails import SIFINEmailParser
import logging

# Set up detailed logging
logging.basicConfig(level=logging.INFO)

def debug_specific_email():
    """Debug a specific email that should contain referee information"""
    parser = SIFINEmailParser()
    
    if not parser.setup_gmail_service():
        print("❌ Failed to setup Gmail service")
        return
    
    # Search for the specific email we know has referee info
    query = 'from:sifin.siam.org subject:"referee report received" M174160'
    
    print(f"🔍 Searching for emails with: {query}")
    
    try:
        response = parser.gmail_service.users().messages().list(
            userId='me',
            q=query,
            maxResults=10
        ).execute()
        
        messages = response.get('messages', [])
        print(f"📧 Found {len(messages)} messages")
        
        if messages:
            # Get the first message
            msg_id = messages[0]['id']
            print(f"\n📄 Analyzing message ID: {msg_id}")
            
            # Get full message
            message = parser.gmail_service.users().messages().get(
                userId='me',
                id=msg_id,
                format='full'
            ).execute()
            
            # Extract headers
            payload = message.get('payload', {})
            headers = {h['name']: h['value'] for h in payload.get('headers', [])}
            
            print(f"\n📬 HEADERS:")
            print(f"   Subject: {headers.get('Subject', '')}")
            print(f"   From: {headers.get('From', '')}")
            print(f"   To: {headers.get('To', '')}")
            
            # Extract body using the parser's method
            body_text = parser._extract_email_body(payload)
            
            print(f"\n📄 BODY TEXT (first 1000 chars):")
            print("-" * 60)
            print(body_text[:1000])
            print("-" * 60)
            
            # Test the referee extraction
            subject = headers.get('Subject', '')
            from_email = headers.get('From', '')
            
            print(f"\n🔍 TESTING REFEREE EXTRACTION:")
            referee_name, referee_email = parser._extract_referee_info(subject, body_text, from_email)
            
            print(f"   Extracted Name: {referee_name}")
            print(f"   Extracted Email: {referee_email}")
            
            # Also test event classification
            event_type, manuscript_id, details = parser._classify_email_event(subject, body_text)
            print(f"\n📊 EVENT CLASSIFICATION:")
            print(f"   Event Type: {event_type}")
            print(f"   Manuscript ID: {manuscript_id}")
            print(f"   Details: {details}")
            
            # Manual pattern testing
            print(f"\n🔬 MANUAL PATTERN TESTING:")
            
            # Test report submission pattern
            report_pattern = r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*(?:\s+[A-Z][a-z]+)?)\s+has\s+submitted\s+a\s+report'
            match = re.search(report_pattern, body_text)
            if match:
                print(f"   Report pattern found: {match.group(1)}")
            else:
                print(f"   Report pattern NOT found")
                
            # Show what the pattern is searching in
            print(f"\n📝 Pattern search text snippet:")
            search_text = subject + "\n" + body_text[:500]
            print(search_text)
            
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    debug_specific_email()