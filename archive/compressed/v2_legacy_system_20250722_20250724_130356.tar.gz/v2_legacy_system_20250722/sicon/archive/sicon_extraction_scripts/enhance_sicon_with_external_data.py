#!/usr/bin/env python3
"""
SICON Data Enhancement with Email Timeline and Online Paper Lookup
Crosschecks referee contacts with email exchanges and enhances metadata with online sources
"""

import os
import re
import json
import logging
import requests
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import time

# Try to import required libraries
try:
    import arxiv
    ARXIV_AVAILABLE = True
except ImportError:
    ARXIV_AVAILABLE = False
    print("⚠️ arxiv library not available. Install with: pip install arxiv")

try:
    from crossref.restful import Works
    CROSSREF_AVAILABLE = True
except ImportError:
    CROSSREF_AVAILABLE = False
    print("⚠️ crossref library not available. Install with: pip install crossref-client")

try:
    from habanero import Crossref
    HABANERO_AVAILABLE = True
except ImportError:
    HABANERO_AVAILABLE = False
    print("⚠️ habanero library not available. Install with: pip install habanero")

# Email integration
try:
    from scripts.sicon.parse_sicon_emails import SICONEmailParser
    EMAIL_PARSER_AVAILABLE = True
except ImportError:
    EMAIL_PARSER_AVAILABLE = False
    print("⚠️ Email parser not available")

logger = logging.getLogger(__name__)

class SICONDataEnhancer:
    """Enhance SICON data with email timeline and online paper metadata"""
    
    def __init__(self):
        self.email_parser = SICONEmailParser() if EMAIL_PARSER_AVAILABLE else None
        self.crossref = Crossref() if HABANERO_AVAILABLE else None
        
    def enhance_manuscript_data(self, manuscript: Dict) -> Dict:
        """
        Enhance manuscript data with online lookups and email timeline
        
        Args:
            manuscript: Original manuscript data from SICON extraction
            
        Returns:
            Enhanced manuscript data with additional metadata
        """
        enhanced = manuscript.copy()
        
        # 1. Enhance with online paper metadata
        online_data = self.lookup_paper_online(manuscript)
        if online_data:
            enhanced.update(online_data)
        
        # 2. Enhance with email timeline
        email_timeline = self.get_email_timeline(manuscript)
        if email_timeline:
            enhanced['email_timeline'] = email_timeline
            enhanced['referees_enhanced'] = self.merge_email_and_web_data(
                manuscript, email_timeline
            )
        
        return enhanced
    
    def lookup_paper_online(self, manuscript: Dict) -> Optional[Dict]:
        """
        Look up paper metadata from arXiv, CrossRef, and other sources
        
        Args:
            manuscript: Manuscript data with title and authors
            
        Returns:
            Dictionary with enhanced metadata
        """
        title = manuscript.get('title', '')
        authors = self.extract_author_names(manuscript)
        
        if not title:
            return None
            
        enhanced_data = {}
        
        # Try arXiv first
        arxiv_data = self.search_arxiv(title, authors)
        if arxiv_data:
            enhanced_data.update(arxiv_data)
            
        # Try CrossRef
        crossref_data = self.search_crossref(title, authors)
        if crossref_data:
            enhanced_data.update(crossref_data)
            
        # Try Google Scholar API (if available)
        scholar_data = self.search_google_scholar(title, authors)
        if scholar_data:
            enhanced_data.update(scholar_data)
            
        return enhanced_data if enhanced_data else None
    
    def search_arxiv(self, title: str, authors: List[str]) -> Optional[Dict]:
        """Search arXiv for paper metadata"""
        if not ARXIV_AVAILABLE:
            return None
            
        try:
            # Clean title for search
            search_title = re.sub(r'[^\w\s]', '', title).strip()
            
            # Search arXiv
            search = arxiv.Search(
                query=f'ti:"{search_title}"',
                max_results=5,
                sort_by=arxiv.SortCriterion.Relevance
            )
            
            for result in search.results():
                # Check if title matches closely
                if self.title_similarity(title, result.title) > 0.8:
                    return {
                        'arxiv_id': result.entry_id.split('/')[-1],
                        'arxiv_url': result.entry_id,
                        'arxiv_submitted': result.published.isoformat(),
                        'arxiv_updated': result.updated.isoformat() if result.updated else None,
                        'arxiv_categories': result.categories,
                        'msc_classification': self.extract_msc_from_categories(result.categories),
                        'arxiv_abstract': result.summary,
                        'arxiv_authors': [author.name for author in result.authors],
                        'arxiv_affiliations': self.extract_affiliations(result.authors),
                        'source': 'arxiv'
                    }
                    
        except Exception as e:
            logger.error(f"Error searching arXiv: {e}")
            
        return None
    
    def search_crossref(self, title: str, authors: List[str]) -> Optional[Dict]:
        """Search CrossRef for paper metadata"""
        if not HABANERO_AVAILABLE:
            return None
            
        try:
            # Search CrossRef
            results = self.crossref.works(
                query=title,
                limit=5,
                sort='relevance'
            )
            
            for item in results['message']['items']:
                # Check title similarity
                crossref_title = item.get('title', [''])[0]
                if self.title_similarity(title, crossref_title) > 0.8:
                    return {
                        'doi': item.get('DOI'),
                        'crossref_url': f"https://doi.org/{item.get('DOI')}" if item.get('DOI') else None,
                        'published_date': self.extract_date(item.get('published-print') or item.get('published-online')),
                        'journal': item.get('container-title', [''])[0],
                        'publisher': item.get('publisher'),
                        'crossref_authors': self.extract_crossref_authors(item.get('author', [])),
                        'crossref_affiliations': self.extract_crossref_affiliations(item.get('author', [])),
                        'subject_areas': item.get('subject', []),
                        'source': 'crossref'
                    }
                    
        except Exception as e:
            logger.error(f"Error searching CrossRef: {e}")
            
        return None
    
    def search_google_scholar(self, title: str, authors: List[str]) -> Optional[Dict]:
        """Search Google Scholar for paper metadata (placeholder)"""
        # This would require a Google Scholar API or scraping
        # For now, return None but structure is ready
        return None
    
    def get_email_timeline(self, manuscript: Dict) -> Optional[Dict]:
        """
        Get email timeline for manuscript referee interactions
        
        This would integrate with Gmail API to fetch actual email exchanges
        """
        if not self.email_parser:
            return None
            
        manuscript_id = manuscript.get('id', '')
        
        # This is where we would fetch actual emails from Gmail
        # For now, return placeholder structure
        return {
            'manuscript_id': manuscript_id,
            'invitations': [],
            'responses': [],
            'reminders': [],
            'notes': 'Email timeline extraction requires Gmail API setup'
        }
    
    def merge_email_and_web_data(self, manuscript: Dict, email_timeline: Dict) -> List[Dict]:
        """
        Merge email timeline with web-scraped referee data
        
        Args:
            manuscript: Original manuscript data
            email_timeline: Email timeline data
            
        Returns:
            List of enhanced referee records
        """
        enhanced_referees = []
        
        # Get all referees
        all_referees = (
            manuscript.get('declined_referees', []) + 
            manuscript.get('accepted_referees', [])
        )
        
        for referee in all_referees:
            enhanced_ref = referee.copy()
            
            # Add email timeline data if available
            email_data = self.find_referee_in_email_timeline(
                referee, email_timeline
            )
            if email_data:
                enhanced_ref.update(email_data)
                
            enhanced_referees.append(enhanced_ref)
            
        return enhanced_referees
    
    def find_referee_in_email_timeline(self, referee: Dict, email_timeline: Dict) -> Optional[Dict]:
        """Find referee's email interactions in timeline"""
        # This would match referee email/name with email timeline
        # For now, return placeholder
        return {
            'email_timeline_available': False,
            'invitation_date': None,
            'response_date': None,
            'reminder_count': 0
        }
    
    def extract_author_names(self, manuscript: Dict) -> List[str]:
        """Extract clean author names from manuscript data"""
        authors = []
        
        # Extract corresponding author
        corresp_author = manuscript.get('corresponding_author', '')
        if corresp_author:
            # Remove institution in parentheses
            clean_name = re.sub(r'\([^)]*\)', '', corresp_author).strip()
            authors.append(clean_name)
            
        # Extract contributing authors
        contrib_authors = manuscript.get('contributing_authors', '')
        if contrib_authors:
            # Split by comma and clean
            for author in contrib_authors.split(','):
                clean_name = author.strip()
                if clean_name:
                    authors.append(clean_name)
                    
        return authors
    
    def title_similarity(self, title1: str, title2: str) -> float:
        """Calculate similarity between two titles"""
        if not title1 or not title2:
            return 0.0
            
        # Simple similarity based on common words
        words1 = set(re.findall(r'\w+', title1.lower()))
        words2 = set(re.findall(r'\w+', title2.lower()))
        
        if not words1 or not words2:
            return 0.0
            
        intersection = words1.intersection(words2)
        union = words1.union(words2)
        
        return len(intersection) / len(union)
    
    def extract_msc_from_categories(self, categories: List[str]) -> List[str]:
        """Extract MSC classification from arXiv categories"""
        # Map arXiv categories to MSC classifications
        msc_mapping = {
            'math.OC': '49-XX, 93-XX',  # Optimization and Control
            'math.PR': '60-XX',          # Probability
            'math.FA': '46-XX',          # Functional Analysis
            'math.AP': '35-XX',          # Partial Differential Equations
            'math.DS': '37-XX',          # Dynamical Systems
            'math.ST': '62-XX',          # Statistics
            'q-fin.MF': '91-XX',         # Mathematical Finance
            'q-fin.RM': '91-XX',         # Risk Management
        }
        
        msc_codes = []
        for category in categories:
            if category in msc_mapping:
                msc_codes.append(msc_mapping[category])
                
        return list(set(msc_codes))  # Remove duplicates
    
    def extract_affiliations(self, authors) -> List[Dict]:
        """Extract affiliations from arXiv authors"""
        affiliations = []
        for author in authors:
            affiliation_data = {
                'author': author.name,
                'affiliation': getattr(author, 'affiliation', '') or 'Not provided'
            }
            affiliations.append(affiliation_data)
        return affiliations
    
    def extract_crossref_authors(self, authors: List[Dict]) -> List[Dict]:
        """Extract author information from CrossRef data"""
        author_list = []
        for author in authors:
            author_data = {
                'given': author.get('given', ''),
                'family': author.get('family', ''),
                'full_name': f"{author.get('given', '')} {author.get('family', '')}".strip(),
                'orcid': author.get('ORCID', '')
            }
            author_list.append(author_data)
        return author_list
    
    def extract_crossref_affiliations(self, authors: List[Dict]) -> List[Dict]:
        """Extract affiliations from CrossRef author data"""
        affiliations = []
        for author in authors:
            affiliation_data = {
                'author': f"{author.get('given', '')} {author.get('family', '')}".strip(),
                'affiliation': author.get('affiliation', [{}])[0].get('name', 'Not provided')
            }
            affiliations.append(affiliation_data)
        return affiliations
    
    def extract_date(self, date_parts: Optional[Dict]) -> Optional[str]:
        """Extract date from CrossRef date format"""
        if not date_parts or 'date-parts' not in date_parts:
            return None
            
        date_list = date_parts['date-parts'][0]
        if len(date_list) >= 3:
            return f"{date_list[0]}-{date_list[1]:02d}-{date_list[2]:02d}"
        elif len(date_list) >= 2:
            return f"{date_list[0]}-{date_list[1]:02d}"
        elif len(date_list) >= 1:
            return str(date_list[0])
            
        return None


def enhance_sicon_extraction(input_file: str, output_file: str = None):
    """
    Enhance SICON extraction with email timeline and online paper lookup
    
    Args:
        input_file: Path to original SICON extraction JSON
        output_file: Path to enhanced output JSON
    """
    enhancer = SICONDataEnhancer()
    
    # Load original data
    with open(input_file, 'r') as f:
        manuscripts = json.load(f)
    
    enhanced_manuscripts = []
    
    for i, manuscript in enumerate(manuscripts, 1):
        print(f"📄 Enhancing manuscript {i}/{len(manuscripts)}: {manuscript.get('id', 'Unknown')}")
        
        # Enhance manuscript data
        enhanced = enhancer.enhance_manuscript_data(manuscript)
        enhanced_manuscripts.append(enhanced)
        
        # Rate limiting for API calls
        time.sleep(1)
    
    # Save enhanced data
    if not output_file:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"sicon_enhanced_{timestamp}.json"
    
    with open(output_file, 'w') as f:
        json.dump(enhanced_manuscripts, f, indent=2)
    
    print(f"✅ Enhanced data saved to: {output_file}")
    
    # Generate summary report
    generate_enhancement_report(enhanced_manuscripts, output_file.replace('.json', '_report.md'))


def generate_enhancement_report(manuscripts: List[Dict], report_file: str):
    """Generate report on data enhancement results"""
    
    with open(report_file, 'w') as f:
        f.write("# SICON Data Enhancement Report\n\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        f.write("## Enhancement Summary\n\n")
        
        # Count enhancements
        arxiv_matches = sum(1 for ms in manuscripts if ms.get('arxiv_id'))
        crossref_matches = sum(1 for ms in manuscripts if ms.get('doi'))
        msc_classifications = sum(1 for ms in manuscripts if ms.get('msc_classification'))
        
        f.write(f"- **Total manuscripts**: {len(manuscripts)}\n")
        f.write(f"- **arXiv matches**: {arxiv_matches}\n")
        f.write(f"- **CrossRef matches**: {crossref_matches}\n")
        f.write(f"- **MSC classifications**: {msc_classifications}\n\n")
        
        # Detailed manuscript analysis
        f.write("## Detailed Results\n\n")
        
        for manuscript in manuscripts:
            f.write(f"### {manuscript.get('id', 'Unknown')} - {manuscript.get('title', 'No title')}\n\n")
            
            # Original data
            f.write("**Original Data:**\n")
            f.write(f"- Authors: {', '.join(manuscript.get('authors', []))}\n")
            f.write(f"- Submission: {manuscript.get('submission_date', 'Unknown')}\n")
            
            # Enhanced data
            if manuscript.get('arxiv_id'):
                f.write(f"\n**arXiv Enhancement:**\n")
                f.write(f"- arXiv ID: {manuscript.get('arxiv_id')}\n")
                f.write(f"- Categories: {', '.join(manuscript.get('arxiv_categories', []))}\n")
                f.write(f"- MSC: {', '.join(manuscript.get('msc_classification', []))}\n")
                
            if manuscript.get('doi'):
                f.write(f"\n**CrossRef Enhancement:**\n")
                f.write(f"- DOI: {manuscript.get('doi')}\n")
                f.write(f"- Journal: {manuscript.get('journal', 'Unknown')}\n")
                f.write(f"- Publisher: {manuscript.get('publisher', 'Unknown')}\n")
                
            f.write("\n")
    
    print(f"✅ Enhancement report saved to: {report_file}")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Enhance SICON data with online lookups")
    parser.add_argument('input_file', help='Input SICON extraction JSON file')
    parser.add_argument('--output', '-o', help='Output enhanced JSON file')
    
    args = parser.parse_args()
    
    enhance_sicon_extraction(args.input_file, args.output)