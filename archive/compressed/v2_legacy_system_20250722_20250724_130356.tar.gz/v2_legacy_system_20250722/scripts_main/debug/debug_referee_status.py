#!/usr/bin/env python3
"""
DEBUG referee status parsing - get the ACTUAL status and dates correctly
"""

import os
import sys
import time
import json
import re
from pathlib import Path
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Load config
load_dotenv('.env.production')

def normalize_name(name):
    """Convert 'Last, First' to 'First Last' format."""
    name = name.strip()
    if ',' in name:
        parts = name.split(',', 1)
        return f"{parts[1].strip()} {parts[0].strip()}"
    return name

def debug_referee_parsing():
    """Debug referee status parsing to get CORRECT data."""
    print("🔍 DEBUGGING REFEREE STATUS PARSING")
    print("=" * 60)
    
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        # Login process
        print("1. Logging in...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        try:
            driver.find_element(By.ID, "onetrust-reject-all-handler").click()
        except:
            pass
        
        driver.find_element(By.ID, "USERID").send_keys(os.getenv('MF_EMAIL'))
        driver.find_element(By.ID, "PASSWORD").send_keys(os.getenv('MF_PASSWORD'))
        driver.execute_script("document.getElementById('logInButton').click();")
        time.sleep(3)
        
        # Handle 2FA
        try:
            code_input = driver.find_element(By.ID, "TOKEN_VALUE")
            print("   2FA required...")
            
            sys.path.insert(0, str(Path(__file__).parent))
            from core.email_utils import fetch_latest_verification_code
            
            time.sleep(5)
            code = fetch_latest_verification_code('MF', max_wait=60, poll_interval=3)
            
            if code:
                code_input.send_keys(code)
                driver.find_element(By.ID, "VERIFY_BTN").click()
                time.sleep(15)
        except:
            pass
        
        # Navigate to manuscripts
        print("2. Navigating to manuscripts...")
        WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.LINK_TEXT, "Associate Editor Center"))
        ).click()
        time.sleep(5)
        
        driver.find_element(By.LINK_TEXT, "Awaiting Reviewer Scores").click()
        time.sleep(5)
        
        # Click Take Action for first manuscript
        print("3. Clicking Take Action...")
        rows = driver.find_elements(By.XPATH, "//tr[contains(.,'MAFI-2025-0166')]")
        for row in rows:
            take_action_links = row.find_elements(By.XPATH, ".//a[contains(@href,'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
            if take_action_links:
                link = take_action_links[0]
                href = link.get_attribute('href')
                driver.execute_script(href.replace('javascript:', ''))
                time.sleep(5)
                break
        
        print("4. DEBUGGING REFEREE TABLE STRUCTURE...")
        
        # Find the referee table
        referee_tables = driver.find_elements(By.XPATH, "//table[contains(.,'Reviewer') or contains(.,'Referee')]")
        print(f"   Found {len(referee_tables)} referee tables")
        
        if referee_tables:
            table = referee_tables[0]
            
            # Get all rows in the table
            all_rows = table.find_elements(By.TAG_NAME, "tr")
            print(f"   Table has {len(all_rows)} total rows")
            
            # Find header row to understand column structure
            for i, row in enumerate(all_rows[:5]):  # Check first 5 rows for headers
                row_text = row.text
                if 'Reviewer' in row_text or 'Status' in row_text or 'Invited' in row_text:
                    print(f"\n   HEADER ROW {i}: {row_text}")
                    cells = row.find_elements(By.TAG_NAME, "td")
                    print(f"   Header has {len(cells)} columns:")
                    for j, cell in enumerate(cells):
                        print(f"     Column {j}: '{cell.text.strip()}'")
            
            print(f"\n5. ANALYZING REFEREE ROWS...")
            
            # Find rows with referee data
            referee_rows = table.find_elements(By.XPATH, ".//tr[.//a[contains(@href,'mailpopup')]]")
            print(f"   Found {len(referee_rows)} rows with mailpopup links")
            
            # Build exclusion list
            known_authors = {'Possamai, Dylan', 'Dylan Possamai', 'Cont, Rama', 'Rama Cont', 
                           'K J, Chandni', 'Chandni K J', 'Zhang, Panpan', 'Panpan Zhang',
                           'Matoussi, Anis', 'Anis Matoussi', 'Guillaume Broux-Quemerais', 
                           'Broux-Quemerais, Guillaume', 'Zhou, Chao', 'Chao Zhou'}
            
            for row_idx, row in enumerate(referee_rows):
                print(f"\n   --- REFEREE ROW {row_idx + 1} ---")
                
                # Get all cells in this row
                cells = row.find_elements(By.TAG_NAME, "td")
                print(f"   Row has {len(cells)} cells")
                
                # Print each cell content for debugging
                for cell_idx, cell in enumerate(cells):
                    cell_text = cell.text.strip()
                    cell_html = cell.get_attribute('innerHTML')
                    if cell_text or 'mailpopup' in cell_html:
                        print(f"     Cell {cell_idx}: '{cell_text}'")
                        if 'mailpopup' in cell_html:
                            print(f"       → Contains mailpopup link")
                
                # Extract referee name
                name_links = row.find_elements(By.XPATH, ".//a[contains(@href,'mailpopup')]")
                referee_name = ''
                
                for link in name_links:
                    text = link.text.strip()
                    if text and '@' not in text and text not in known_authors:
                        if ',' in text or ' ' in text:
                            referee_name = normalize_name(text)
                            print(f"   → REFEREE NAME: {referee_name} (from '{text}')")
                            break
                
                if referee_name:
                    # Now analyze each cell for status and dates
                    print(f"   → ANALYZING STATUS AND DATES FOR {referee_name}:")
                    
                    row_text = row.text
                    print(f"     Full row text: {row_text}")
                    
                    # Look for status patterns in each cell
                    for cell_idx, cell in enumerate(cells):
                        cell_text = cell.text.strip()
                        if cell_text:
                            # Check for status keywords
                            status_found = False
                            if any(keyword in cell_text.lower() for keyword in ['agreed', 'declined', 'invited', 'unavailable', 'completed', 'submitted']):
                                print(f"     Cell {cell_idx} (STATUS?): '{cell_text}'")
                                status_found = True
                            
                            # Check for dates
                            date_pattern = r'\d{2}-\w{3}-\d{4}'
                            if re.search(date_pattern, cell_text):
                                print(f"     Cell {cell_idx} (DATE?): '{cell_text}'")
                    
                    # Extract all dates from the full row text
                    dates_found = re.findall(r'(\d{2}-\w{3}-\d{4})', row_text)
                    if dates_found:
                        print(f"     ALL DATES FOUND: {dates_found}")
                    
                    print()
        
        # Save page source for manual inspection
        with open('referee_debug.html', 'w', encoding='utf-8') as f:
            f.write(driver.page_source)
        print(f"\n💾 Page source saved to referee_debug.html for manual inspection")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        driver.quit()

if __name__ == "__main__":
    debug_referee_parsing()