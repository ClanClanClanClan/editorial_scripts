#!/usr/bin/env python3
"""
Test the unified configuration system integration.
"""

import sys
from pathlib import Path

# Add src to Python path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root / "src"))

from editorial_assistant.core.unified_config import get_config_manager

def test_configuration_system():
    """Test the unified configuration system."""
    
    print("Testing Unified Configuration System")
    print("="*60)
    
    # Get config manager
    config = get_config_manager()
    
    # Test 1: Journal configurations
    print("\n1. Testing Journal Configurations:")
    print("-"*40)
    
    test_journals = ['MF', 'MOR', 'SICON', 'SIFIN']
    for code in test_journals:
        journal = config.get_journal_config(code)
        if journal:
            print(f"✅ {code}: {journal.name}")
            print(f"   - Platform: {journal.platform}")
            print(f"   - URL: {journal.url}")
            print(f"   - Categories: {len(journal.get_categories())} configured")
        else:
            print(f"❌ {code}: Configuration not found!")
    
    # Test 2: Feature flags
    print("\n2. Testing Feature Flags:")
    print("-"*40)
    
    features = ['use_config_system', 'use_navigation_module', 'use_smart_cache']
    journals = ['MF', 'SICON', 'SIFIN']
    
    for journal in journals:
        print(f"\n{journal}:")
        for feature in features:
            enabled = config.is_feature_enabled(feature, journal)
            status = "✅" if enabled else "❌"
            print(f"  {status} {feature}: {enabled}")
    
    # Test 3: Timing configurations
    print("\n3. Testing Timing Configurations:")
    print("-"*40)
    
    for code in ['SICON', 'SIFIN']:
        journal = config.get_journal_config(code)
        if journal:
            print(f"\n{code} Timings:")
            print(f"  - Initial Load: {journal.get_timing('initial_load')}s")
            print(f"  - Page Navigation: {journal.get_timing('page_navigation')}s")
            print(f"  - Redirect Timeout: {journal.get_timing('redirect_timeout')}s")
    
    # Test 4: Special configurations
    print("\n4. Testing Special Configurations:")
    print("-"*40)
    
    # SIFIN Firefox requirement
    sifin = config.get_journal_config('SIFIN')
    if sifin:
        firefox_required = sifin.authentication.get('browser_preference') == 'firefox'
        print(f"SIFIN Firefox Required: {'✅' if firefox_required else '❌'} {firefox_required}")
    
    # SICON 8-step workflow
    sicon = config.get_journal_config('SICON')
    if sicon:
        workflow_steps = sicon.authentication.get('workflow_steps', 0)
        print(f"SICON Workflow Steps: {workflow_steps} (Expected: 8)")
    
    print("\n" + "="*60)
    print("✅ Configuration System Test Complete!")
    
    return True

if __name__ == "__main__":
    test_configuration_system()