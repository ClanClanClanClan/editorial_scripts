#!/usr/bin/env python3
"""
Test SICON Timeline Consistency
Verifies that web-scraped data matches email timeline data
"""

import json
import logging
from pathlib import Path
from datetime import datetime

from editorial_assistant.core.timeline_validator import TimelineValidator
from editorial_assistant.extractors.sicon import SICONExtractor
from scripts.sicon.scripts.sicon.parse_sicon_emails import SICONEmailParser
from core.working_gmail_utils import get_gmail_service, search_messages, get_message_details

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def fetch_sicon_emails(days_back: int = 90):
    """Fetch SICON emails from Gmail"""
    logger.info(f"Fetching SICON emails from last {days_back} days...")
    
    service = get_gmail_service()
    if not service:
        logger.error("Failed to initialize Gmail service")
        return []
    
    # Search for SICON emails
    queries = [
        f'subject:SICON newer_than:{days_back}d',
        f'from:sicon.siam.org newer_than:{days_back}d',
        f'subject:"SIAM Journal on Control" newer_than:{days_back}d'
    ]
    
    all_emails = []
    seen_ids = set()
    
    for query in queries:
        logger.info(f"Searching: {query}")
        messages = search_messages(service, query)
        
        for msg in messages:
            if msg['id'] not in seen_ids:
                seen_ids.add(msg['id'])
                details = get_message_details(service, msg['id'])
                if details:
                    all_emails.append(details)
    
    logger.info(f"Found {len(all_emails)} SICON emails")
    return all_emails


def test_sicon_timeline_consistency():
    """Test SICON timeline consistency between web and email data"""
    logger.info("Starting SICON timeline consistency test...")
    
    # Initialize components
    from editorial_assistant.core.data_models import JournalConfig
    
    # Create SICON config
    sicon_config = JournalConfig(
        code="SICON",
        name="SIAM Journal on Control and Optimization",
        url="https://sicon.siam.org/cgi-bin/main.plex",
        platform="siam_orcid",
        credentials={
            "username": "your_orcid_email",  # Will be loaded from environment
            "password": "your_orcid_password"
        }
    )
    
    # Run web extraction
    logger.info("Running SICON web extraction...")
    extractor = SICONExtractor(sicon_config)
    
    try:
        manuscripts = extractor.extract_data()
        logger.info(f"Extracted {len(manuscripts)} manuscripts from web")
    except Exception as e:
        logger.error(f"Web extraction failed: {e}")
        return
    
    # Fetch emails
    emails = fetch_sicon_emails()
    
    # Parse email timeline
    logger.info("Parsing email timeline...")
    email_parser = SICONEmailParser()
    
    # Initialize validator
    validator = TimelineValidator(tolerance_days=2)
    
    # Validate each manuscript
    all_issues = []
    
    for manuscript in manuscripts:
        ms_id = manuscript.get('id', '')
        logger.info(f"\nValidating manuscript {ms_id}...")
        
        # Get all referees for this manuscript
        all_referees = []
        all_referees.extend(manuscript.get('declined_referees', []))
        all_referees.extend(manuscript.get('accepted_referees', []))
        
        # Parse email timeline for this manuscript
        email_timeline = email_parser.parse_referee_emails(emails, manuscript_id=ms_id)
        
        # Log what we found
        logger.info(f"  Web referees: {len(all_referees)}")
        logger.info(f"  Email invitations: {len(email_timeline.get('invitations', []))}")
        logger.info(f"  Email responses: {len(email_timeline.get('responses', []))}")
        
        # Validate timeline
        issues = validator.validate_manuscript_timeline(ms_id, all_referees, email_timeline)
        
        if issues:
            logger.warning(f"  Found {len(issues)} timeline issues!")
            for issue in issues:
                if issue.severity == 'critical':
                    logger.error(f"    CRITICAL: {issue.description}")
                else:
                    logger.warning(f"    {issue.severity.upper()}: {issue.description}")
        else:
            logger.info(f"  ✓ No timeline inconsistencies found")
        
        all_issues.extend(issues)
    
    # Generate report
    report = validator.generate_validation_report(all_issues)
    
    # Save report
    report_path = Path(f"sicon_timeline_validation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    with open(report_path, 'w') as f:
        json.dump(report, f, indent=2)
    
    # Print summary
    print("\n" + "="*60)
    print("SICON TIMELINE VALIDATION SUMMARY")
    print("="*60)
    print(f"Total manuscripts checked: {len(manuscripts)}")
    print(f"Total issues found: {report['total_issues']}")
    print(f"  - Critical issues: {report['critical_issues']}")
    print(f"  - Warnings: {report['warnings']}")
    print(f"  - Info: {report['info']}")
    
    if report['critical_issues'] > 0:
        print("\nCRITICAL ISSUES REQUIRING IMMEDIATE ATTENTION:")
        for issue_type, issues in report['by_type'].items():
            critical_issues = [i for i in issues if i['severity'] == 'critical']
            if critical_issues:
                print(f"\n{issue_type}:")
                for issue in critical_issues[:3]:  # Show first 3
                    print(f"  - {issue['description']}")
                if len(critical_issues) > 3:
                    print(f"  ... and {len(critical_issues) - 3} more")
    
    print(f"\nFull report saved to: {report_path}")
    
    # Return success/failure
    return report['critical_issues'] == 0


if __name__ == "__main__":
    # Test SICON
    success = test_sicon_timeline_consistency()
    
    if success:
        print("\n✅ SICON TIMELINE VALIDATION PASSED")
    else:
        print("\n❌ SICON TIMELINE VALIDATION FAILED - Critical inconsistencies found")
        print("\nNext steps:")
        print("1. Review the validation report")
        print("2. Fix the extractor to properly integrate email timeline")
        print("3. Ensure web status matches email evidence")
        print("4. Re-run this test until all critical issues are resolved")