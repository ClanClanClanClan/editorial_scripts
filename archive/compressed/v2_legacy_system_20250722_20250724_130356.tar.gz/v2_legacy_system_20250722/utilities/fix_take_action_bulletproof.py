#!/usr/bin/env python3
"""
ULTRATHINK FIX: Completely rewrite Take Action clicking to actually work
"""

take_action_replacement = '''
    def _click_take_action_for_manuscript(self, manuscript_id: str) -> bool:
        """
        BULLETPROOF Take Action clicking that actually works.
        Complete rewrite with extensive debugging and failsafe approaches.
        """
        try:
            self.logger.info(f"🎯 ULTRAFIX: Clicking Take Action for {manuscript_id}")
            
            # Step 1: Save current page for debugging
            with open(f'debug_before_click_{manuscript_id}.html', 'w') as f:
                f.write(self.driver.page_source)
            
            # Step 2: Wait for page to be stable
            time.sleep(2)
            self._wait_for_page_load()
            
            # Step 3: Find ALL possible Take Action approaches
            approaches = []
            
            # Approach 1: Direct link search by manuscript ID + Take Action text
            try:
                links = self.driver.find_elements(By.XPATH, f"//tr[contains(text(), '{manuscript_id}')]//a[contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]")
                for link in links:
                    approaches.append(('direct_link', link))
                    self.logger.info(f"Found direct link approach: {link.get_attribute('href')[:100]}...")
            except:
                pass
            
            # Approach 2: Image-based search (check_off.gif)
            try:
                imgs = self.driver.find_elements(By.XPATH, f"//tr[contains(text(), '{manuscript_id}')]//img[contains(@src, 'check_off.gif')]")
                for img in imgs:
                    parent_link = img.find_element(By.XPATH, "./parent::a")
                    approaches.append(('image_link', parent_link))
                    self.logger.info(f"Found image-based approach: {parent_link.get_attribute('href')[:100]}...")
            except:
                pass
                
            # Approach 3: Table cell navigation
            try:
                rows = self.driver.find_elements(By.XPATH, f"//tr[contains(text(), '{manuscript_id}')]")
                for row in rows:
                    cells = row.find_elements(By.TAG_NAME, "td")
                    if cells:
                        # Check last cell (most likely)
                        last_cell = cells[-1]
                        take_action_links = last_cell.find_elements(By.TAG_NAME, "a")
                        for link in take_action_links:
                            href = link.get_attribute('href')
                            if href and ('ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS' in href or 'javascript:' in href):
                                approaches.append(('table_cell', link))
                                self.logger.info(f"Found table cell approach: {href[:100]}...")
            except:
                pass
            
            # Approach 4: Broad search for any links in manuscript rows
            try:
                manuscript_rows = self.driver.find_elements(By.XPATH, f"//tr[contains(., '{manuscript_id}')]")
                for row in manuscript_rows:
                    all_links = row.find_elements(By.TAG_NAME, "a")
                    for link in all_links:
                        href = link.get_attribute('href')
                        if href and ('DETAILS' in href.upper() or 'javascript:' in href):
                            approaches.append(('broad_search', link))
                            self.logger.info(f"Found broad search approach: {href[:100]}...")
            except:
                pass
            
            self.logger.info(f"Found {len(approaches)} different Take Action approaches to try")
            
            # Step 4: Try each approach systematically
            for i, (approach_name, link) in enumerate(approaches):
                try:
                    self.logger.info(f"Trying approach {i+1}/{len(approaches)}: {approach_name}")
                    
                    # Get link details
                    href = link.get_attribute('href')
                    onclick = link.get_attribute('onclick')
                    
                    self.logger.info(f"Link href: {href}")
                    self.logger.info(f"Link onclick: {onclick}")
                    
                    # Store current URL to detect navigation
                    old_url = self.driver.current_url
                    
                    # Try multiple click methods
                    click_methods = [
                        ('javascript_href', lambda: self._execute_javascript_href(href)),
                        ('direct_click', lambda: link.click()),
                        ('js_click', lambda: self.driver.execute_script("arguments[0].click();", link)),
                        ('onclick_exec', lambda: self.driver.execute_script(onclick) if onclick else None)
                    ]
                    
                    for method_name, method_func in click_methods:
                        try:
                            self.logger.info(f"  Trying {method_name}...")
                            
                            if method_func:
                                method_func()
                                
                                # Wait and check for navigation
                                time.sleep(3)
                                self._wait_for_page_load()
                                
                                new_url = self.driver.current_url
                                if old_url != new_url:
                                    self.logger.info(f"✅ SUCCESS! {approach_name} + {method_name} worked for {manuscript_id}")
                                    return True
                                else:
                                    # Check if page content changed (some actions don't change URL)
                                    new_source = self.driver.page_source
                                    if manuscript_id in new_source and ('manuscript details' in new_source.lower() or 'referee' in new_source.lower()):
                                        self.logger.info(f"✅ SUCCESS! {approach_name} + {method_name} worked (content changed) for {manuscript_id}")
                                        return True
                            
                        except Exception as method_error:
                            self.logger.warning(f"  {method_name} failed: {method_error}")
                            continue
                    
                except Exception as approach_error:
                    self.logger.warning(f"Approach {approach_name} failed: {approach_error}")
                    continue
            
            # Step 5: Ultimate fallback - try to find ANY clickable element near the manuscript ID
            self.logger.warning(f"All standard approaches failed, trying fallback for {manuscript_id}")
            try:
                # Find any element containing the manuscript ID
                manuscript_elements = self.driver.find_elements(By.XPATH, f"//*[contains(text(), '{manuscript_id}')]")
                for element in manuscript_elements:
                    # Look for nearby clickable elements
                    parent = element.find_element(By.XPATH, "./parent::*")
                    nearby_links = parent.find_elements(By.TAG_NAME, "a")
                    for link in nearby_links:
                        href = link.get_attribute('href')
                        if href:
                            self.logger.info(f"Fallback: trying nearby link {href[:100]}...")
                            try:
                                old_url = self.driver.current_url
                                self._execute_javascript_href(href)
                                time.sleep(3)
                                if self.driver.current_url != old_url:
                                    self.logger.info(f"✅ FALLBACK SUCCESS for {manuscript_id}")
                                    return True
                            except:
                                continue
            except:
                pass
            
            # Step 6: Save debug info and fail
            with open(f'debug_failed_click_{manuscript_id}.html', 'w') as f:
                f.write(self.driver.page_source)
            
            self.logger.error(f"❌ COMPLETE FAILURE: Could not click Take Action for {manuscript_id} using any method")
            return False
            
        except Exception as e:
            self.logger.error(f"Critical error in Take Action click: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _execute_javascript_href(self, href: str) -> None:
        """Execute JavaScript from href attribute safely."""
        if not href:
            return
        
        if href.startswith('javascript:'):
            js_code = href.replace('javascript:', '')
            self.logger.info(f"Executing JavaScript: {js_code[:100]}...")
            self.driver.execute_script(js_code)
        else:
            # Direct navigation
            self.logger.info(f"Direct navigation to: {href}")
            self.driver.get(href)
    
    def _wait_for_page_load(self) -> None:
        """Enhanced page load waiting."""
        try:
            # Wait for basic page load
            WebDriverWait(self.driver, 10).until(
                lambda driver: driver.execute_script("return document.readyState") == "complete"
            )
            # Additional wait for dynamic content
            time.sleep(2)
        except:
            # Fallback wait
            time.sleep(5)
'''

print("ULTRATHINK FIX PLAN:")
print("1. Replace broken Take Action clicking with bulletproof method")
print("2. Add extensive debugging and multiple click approaches")
print("3. Try every possible way to click the damn links")
print("4. Save debug files to understand what's happening")
print()
print("REPLACEMENT CODE:")
print("="*80)
print(take_action_replacement)