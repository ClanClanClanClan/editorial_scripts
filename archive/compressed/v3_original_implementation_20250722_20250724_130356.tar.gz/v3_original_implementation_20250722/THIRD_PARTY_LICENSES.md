# Third-Party Licenses

This document contains the licenses for all third-party dependencies used in Editorial Scripts V3.

## Production Dependencies

### Core Python Libraries

**pydantic (MIT License)**
- Version: ^2.5.0
- License: MIT
- Purpose: Data validation and settings management
- Homepage: https://pydantic.dev

**httpx (BSD License)**
- Version: ^0.25.0  
- License: BSD-3-Clause
- Purpose: HTTP client library
- Homepage: https://www.python-httpx.org

**playwright (Apache 2.0)**
- Version: ^1.40.0
- License: Apache-2.0
- Purpose: Browser automation
- Homepage: https://playwright.dev

**sqlalchemy (MIT License)**
- Version: ^2.0.0
- License: MIT
- Purpose: SQL toolkit and Object-Relational Mapping
- Homepage: https://www.sqlalchemy.org

**alembic (MIT License)**
- Version: ^1.13.0
- License: MIT
- Purpose: Database migration tool
- Homepage: https://alembic.sqlalchemy.org

**redis (MIT License)**
- Version: ^5.0.0
- License: MIT
- Purpose: Python Redis client
- Homepage: https://redis-py.readthedocs.io

**structlog (MIT License)**
- Version: ^24.1.0
- License: MIT
- Purpose: Structured logging
- Homepage: https://structlog.org

**tenacity (Apache 2.0)**
- Version: ^8.2.0
- License: Apache-2.0
- Purpose: Retry logic library
- Homepage: https://tenacity.readthedocs.io

**pendulum (MIT License)**
- Version: ^3.0.0
- License: MIT
- Purpose: Date and time manipulation
- Homepage: https://pendulum.eustace.io

### Database Drivers

**asyncpg (Apache 2.0)**
- Version: ^0.29.0
- License: Apache-2.0
- Purpose: Async PostgreSQL driver
- Homepage: https://github.com/MagicStack/asyncpg

**psycopg2-binary (LGPL)**
- Version: ^2.9.0
- License: LGPL-3.0 (with linking exception)
- Purpose: PostgreSQL adapter
- Homepage: https://psycopg.org

## Development Dependencies

### Testing Framework

**pytest (MIT License)**
- Version: ^7.4.0
- License: MIT
- Purpose: Testing framework
- Homepage: https://pytest.org

**pytest-cov (MIT License)**
- Version: ^4.1.0
- License: MIT
- Purpose: Coverage plugin for pytest
- Homepage: https://pytest-cov.readthedocs.io

**pytest-asyncio (Apache 2.0)**
- Version: ^0.21.0
- License: Apache-2.0
- Purpose: Async testing support
- Homepage: https://pytest-asyncio.readthedocs.io

**pytest-mock (MIT License)**
- Version: ^3.12.0
- License: MIT
- Purpose: Mocking library for pytest
- Homepage: https://pytest-mock.readthedocs.io

**pytest-xdist (MIT License)**
- Version: ^3.5.0
- License: MIT
- Purpose: Parallel test execution
- Homepage: https://pytest-xdist.readthedocs.io

**pytest-timeout (MIT License)**
- Version: ^2.2.0
- License: MIT
- Purpose: Test timeout handling
- Homepage: https://pypi.org/project/pytest-timeout/

**pytest-benchmark (BSD License)**
- Version: ^4.0.0
- License: BSD-2-Clause
- Purpose: Performance benchmarking
- Homepage: https://pytest-benchmark.readthedocs.io

**hypothesis (MPL 2.0)**
- Version: ^6.92.0
- License: MPL-2.0
- Purpose: Property-based testing
- Homepage: https://hypothesis.works

**factory-boy (MIT License)**
- Version: ^3.3.0
- License: MIT
- Purpose: Test data generation
- Homepage: https://factoryboy.readthedocs.io

**faker (MIT License)**
- Version: ^22.0.0
- License: MIT
- Purpose: Test data generation
- Homepage: https://faker.readthedocs.io

**mutmut (MIT License)**
- Version: ^2.4.0
- License: MIT
- Purpose: Mutation testing
- Homepage: https://mutmut.readthedocs.io

### Code Quality Tools

**black (MIT License)**
- Version: ^23.12.1
- License: MIT
- Purpose: Code formatter
- Homepage: https://black.readthedocs.io

**isort (MIT License)**
- Version: ^5.13.0
- License: MIT
- Purpose: Import sorting
- Homepage: https://pycqa.github.io/isort/

**ruff (MIT License)**
- Version: ^0.1.9
- License: MIT
- Purpose: Fast Python linter
- Homepage: https://beta.ruff.rs

**mypy (MIT License)**
- Version: ^1.8.0
- License: MIT
- Purpose: Static type checker
- Homepage: https://mypy.readthedocs.io

**bandit (Apache 2.0)**
- Version: ^1.8.6
- License: Apache-2.0
- Purpose: Security linter
- Homepage: https://bandit.readthedocs.io

**safety (MIT License)**
- Version: ^3.0.0
- License: MIT
- Purpose: Dependency vulnerability scanner
- Homepage: https://github.com/pyupio/safety

### Documentation Tools

**mkdocs (BSD License)**
- Version: ^1.5.0
- License: BSD-2-Clause
- Purpose: Documentation generator
- Homepage: https://www.mkdocs.org

**mkdocs-material (MIT License)**
- Version: ^9.5.0
- License: MIT
- Purpose: Material theme for MkDocs
- Homepage: https://squidfunk.github.io/mkdocs-material/

**mkdocstrings (ISC License)**
- Version: ^0.24.0
- License: ISC
- Purpose: API documentation from code
- Homepage: https://mkdocstrings.github.io

### Development Utilities

**pre-commit (MIT License)**
- Version: ^3.6.0
- License: MIT
- Purpose: Git hook management
- Homepage: https://pre-commit.com

**commitizen (MIT License)**
- Version: ^3.13.0
- License: MIT
- Purpose: Conventional commit enforcement
- Homepage: https://commitizen-tools.github.io/commitizen/

## License Compatibility Analysis

All dependencies have been reviewed for license compatibility with Apache 2.0:

### Compatible Licenses
- **MIT License**: Fully compatible, permissive
- **BSD License (2-Clause, 3-Clause)**: Fully compatible, permissive  
- **Apache 2.0**: Same license, fully compatible
- **ISC License**: Fully compatible, permissive

### Special Considerations
- **MPL 2.0 (Hypothesis)**: Compatible, copyleft but file-level scope
- **LGPL-3.0 (psycopg2)**: Compatible with linking exception for dynamic linking

### Excluded Licenses
- **GPL v3+**: Explicitly excluded as per specification
- **AGPL**: Not present in dependencies
- **Commercial/Proprietary**: Not present

## License Audit Process

This document is maintained through:

1. **Automated scanning**: Dependencies analyzed during CI/CD
2. **Manual review**: New dependencies reviewed before adoption
3. **Regular updates**: Quarterly review of all licenses
4. **Legal validation**: Changes reviewed by legal counsel when needed

## Updates and Changes

When updating dependencies:

1. Check license compatibility
2. Update this document
3. Run license scan tools
4. Validate with legal team if needed

## Contact

For questions about licensing or compatibility:

- Create an issue in the GitHub repository
- Contact the maintainers directly
- Consult with legal counsel for complex cases

---

**Last Updated**: July 22, 2025  
**License Audit Status**: ✅ All dependencies compatible with Apache 2.0

## Full License Texts

For complete license texts, refer to:
- Individual package documentation
- PyPI package information  
- Source code repositories
- Local package files in virtual environment

This summary provides compatibility analysis only. Full license terms apply as specified by each package maintainer.