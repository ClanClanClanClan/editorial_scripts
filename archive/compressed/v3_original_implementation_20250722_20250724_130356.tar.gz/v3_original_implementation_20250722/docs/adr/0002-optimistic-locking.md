# ADR-0002: Optimistic Locking Strategy

## Status
Accepted

## Context
Editorial Scripts v3.0 handles concurrent access to manuscripts, reviews, and other editorial data. Multiple users (authors, editors, reviewers) may simultaneously access and modify the same entities, creating potential race conditions and data corruption risks.

The v3.0 specifications mandate:
- Optimistic locking for all aggregate roots
- Version fields on all entities
- Robust concurrency control
- Audit trail preservation
- PostgreSQL-native implementation

Traditional pessimistic locking would severely impact user experience in an editorial workflow where documents may be worked on for extended periods.

## Decision
We will implement **optimistic locking** using versioned entities with the following strategy:

### 1. Version Fields on All Aggregates
```python
class Manuscript(Entity):
    version: int = Field(default=0, ge=0)
    # ... other fields
```

### 2. Database-Level Version Enforcement
```sql
CREATE TABLE manuscript (
    manuscript_id UUID PRIMARY KEY,
    version INTEGER NOT NULL DEFAULT 0,
    -- ... other columns
);
```

### 3. Repository-Level Concurrency Control
```python
async def update_manuscript(self, manuscript: Manuscript) -> Result[Manuscript, ConcurrencyError]:
    query = """
        UPDATE manuscript 
        SET version = version + 1, title = $2, ... 
        WHERE manuscript_id = $1 AND version = $2
        RETURNING version
    """
    if rows_affected == 0:
        return Result.err(ConcurrencyError("Manuscript was modified by another user"))
```

### 4. Application-Level Conflict Resolution
- **Read-Modify-Write Pattern**: Always check version on update
- **Conflict Detection**: Compare expected vs actual version
- **User Notification**: Friendly error messages with merge options
- **Automatic Retry**: For non-conflicting updates

### 5. Event Sourcing Integration
- Version increments trigger domain events
- Event store maintains complete history
- Snapshot aggregates include version
- Replay maintains version consistency

## Implementation Details

### Domain Layer
```python
class OptimisticLockError(DomainError):
    def __init__(self, entity_type: str, entity_id: str, expected: int, actual: int):
        super().__init__(
            f"{entity_type} {entity_id} version mismatch: expected {expected}, got {actual}"
        )
```

### Repository Pattern
```python
@abstractmethod
async def save_manuscript(
    self, 
    manuscript: Manuscript, 
    expected_version: int
) -> Result[Manuscript, OptimisticLockError]:
    pass
```

### HTTP API Layer
- Include version in response headers: `X-Entity-Version: 5`
- Require version in update requests: `If-Match: "5"`
- Return 409 Conflict for version mismatches
- Provide current entity state in conflict response

## Consequences

### Positive
- **No blocking** - Users never wait for locks
- **Better UX** - Conflicts are rare in editorial workflows
- **Scalability** - No lock contention bottlenecks  
- **Consistency** - Prevents lost updates and dirty reads
- **Audit compliance** - Version history maintained
- **Performance** - Fast read operations

### Negative
- **Complexity** - Application must handle conflicts
- **User friction** - Occasional conflict resolution required
- **Development overhead** - More code than naive approach
- **Testing complexity** - Race condition scenarios

### Mitigation Strategies
- **Smart conflict detection** - Compare only meaningful changes
- **Automatic merging** - For non-conflicting concurrent edits
- **User-friendly UX** - Show what changed, offer merge tools
- **Comprehensive testing** - Simulate concurrent access patterns
- **Monitoring** - Track conflict rates and resolution success

### Failure Scenarios
1. **High contention areas** - Multiple rapid edits to same manuscript
   - **Solution**: Real-time collaboration features, edit locks for UI
   
2. **Long-running operations** - Batch updates failing due to conflicts
   - **Solution**: Chunked operations, retry with backoff
   
3. **User confusion** - Not understanding version conflicts
   - **Solution**: Clear error messages, guided conflict resolution

## Monitoring & Observability
- **Conflict rate metrics** - Track per entity type and user
- **Resolution success rate** - How often users resolve conflicts
- **Performance impact** - Version check overhead
- **Error patterns** - Common conflict scenarios

## References
- [Optimistic vs Pessimistic Locking](https://vladmihalcea.com/optimistic-vs-pessimistic-locking/)
- [PostgreSQL Optimistic Locking](https://www.postgresql.org/docs/current/applevel-consistency.html)
- [Domain-Driven Design Aggregates](https://martinfowler.com/bliki/DDD_Aggregate.html)
- [HTTP Conditional Requests](https://developer.mozilla.org/en-US/docs/Web/HTTP/Conditional_requests)