#!/usr/bin/env python3
"""Test the EXACT Take Action links from the HTML you provided"""

import os
import sys
import time
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from dotenv import load_dotenv

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

from core.email_utils import fetch_latest_verification_code

def test_exact_take_action():
    """Test the exact Take Action links we can see in the HTML"""
    
    print("🎯 TESTING EXACT TAKE ACTION LINKS FROM HTML")
    print("=" * 60)
    
    # Chrome setup - VISIBLE
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        # Navigate and login
        print("1. Logging in to MF...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        # Handle cookies
        try:
            reject_btn = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.ID, "onetrust-reject-all-handler"))
            )
            reject_btn.click()
        except:
            pass
        
        # Login
        email_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "USERID"))
        )
        email_field.send_keys(os.getenv('MF_EMAIL'))
        
        password_field = driver.find_element(By.ID, "PASSWORD")
        password_field.send_keys(os.getenv('MF_PASSWORD'))
        
        login_btn = driver.find_element(By.ID, "logInButton")
        login_btn.click()
        time.sleep(5)
        
        # Handle 2FA
        try:
            code_input = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.ID, "TOKEN_VALUE"))
            )
            print("   Getting 2FA code...")
            time.sleep(3)
            code = fetch_latest_verification_code('MF', max_wait=60, poll_interval=3)
            if code:
                code_input.send_keys(code)
                verify_btn = driver.find_element(By.ID, "VERIFY_BTN")
                verify_btn.click()
                time.sleep(10)
        except:
            pass
        
        # Navigate to manuscripts
        print("2. Navigating to manuscripts...")
        
        # Wait for page to load after 2FA, then try to find AE Center
        time.sleep(5)
        
        # Check current page
        page_text = driver.find_element(By.TAG_NAME, "body").text
        print(f"   Page contains 'Associate': {'Associate' in page_text}")
        
        if 'Associate' not in page_text:
            print("   Refreshing page to find AE Center...")
            driver.refresh()
            time.sleep(5)
        
        # Find AE Center
        try:
            ae_link = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.LINK_TEXT, "Associate Editor Center"))
            )
            ae_link.click()
            time.sleep(3)
        except:
            print("❌ Could not find Associate Editor Center")
            return
        
        # Click category
        try:
            category_link = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.LINK_TEXT, "Awaiting Reviewer Scores"))
            )
            category_link.click()
            time.sleep(5)
        except:
            print("❌ Could not find category")
            return
        
        print("3. Looking for Take Action links...")
        
        # Find ALL links with check_off.gif
        check_off_links = driver.find_elements(By.XPATH, "//a[.//img[contains(@src, 'check_off.gif')]]")
        print(f"   Found {len(check_off_links)} Take Action links with check_off.gif")
        
        if not check_off_links:
            print("❌ No Take Action links found!")
            return
        
        # Test first link
        first_link = check_off_links[0]
        href = first_link.get_attribute('href')
        print(f"\n4. Testing first Take Action link...")
        print(f"   href: {href[:100]}...")
        
        # Find which manuscript this is for
        parent_row = first_link.find_element(By.XPATH, "./ancestor::tr")
        row_text = parent_row.text
        
        import re
        ms_id_match = re.search(r'MAFI-\d{4}-\d{4}', row_text)
        ms_id = ms_id_match.group(0) if ms_id_match else "Unknown"
        print(f"   For manuscript: {ms_id}")
        
        # Click it
        print(f"\n5. CLICKING TAKE ACTION...")
        old_url = driver.current_url
        
        if href and 'javascript:' in href:
            js_code = href.replace('javascript:', '')
            print(f"   Executing JavaScript...")
            driver.execute_script(js_code)
        else:
            print("   Using direct click...")
            first_link.click()
        
        time.sleep(5)
        new_url = driver.current_url
        
        print(f"\n6. RESULTS:")
        print(f"   Old URL: {old_url}")
        print(f"   New URL: {new_url}")
        print(f"   Navigation occurred: {old_url != new_url}")
        
        # Check page content
        page_text = driver.find_element(By.TAG_NAME, "body").text
        if 'Referee' in page_text or 'Reviewer' in page_text:
            print(f"   ✅ SUCCESS! On referee details page!")
            print(f"   Found ~{page_text.count('@')} email addresses")
        else:
            print(f"   ❌ Not on referee page")
            print(f"   Page preview: {page_text[:200]}...")
        
        print("\n🔍 Browser stays open for 30 seconds...")
        time.sleep(30)
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        driver.quit()

if __name__ == "__main__":
    test_exact_take_action()