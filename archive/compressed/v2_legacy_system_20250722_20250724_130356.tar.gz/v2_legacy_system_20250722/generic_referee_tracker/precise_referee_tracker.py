#!/usr/bin/env python3
"""
Precise Referee Tracker
Tracks ONLY actual referee correspondence, ignoring system notifications
"""

import re
import json
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set, Tuple
from dataclasses import dataclass, field
from collections import defaultdict
import difflib

logger = logging.getLogger(__name__)

@dataclass
class RefereeCorrespondence:
    """Single email correspondence with a referee"""
    message_id: str
    thread_id: str
    date: datetime
    subject: str
    from_address: str
    to_addresses: List[str]
    body: str
    correspondence_type: str  # 'invitation', 'reminder', 'acceptance', 'decline', 'submission', 'other'
    is_from_referee: bool  # True if from referee to editor, False if editor to referee

@dataclass
class RefereeProfile:
    """Complete profile of a single referee"""
    referee_id: str
    primary_email: str
    all_email_addresses: Set[str] = field(default_factory=set)
    name: Optional[str] = None
    correspondence_history: List[RefereeCorrespondence] = field(default_factory=list)
    
    # Timeline tracking
    invitation_date: Optional[datetime] = None
    response_date: Optional[datetime] = None
    response_decision: Optional[str] = None  # 'accepted', 'declined'
    submission_date: Optional[datetime] = None
    reminder_count: int = 0
    
    def add_email_address(self, email: str):
        """Add an email address for this referee"""
        email = email.strip().lower()
        self.all_email_addresses.add(email)
        if not self.primary_email:
            self.primary_email = email
    
    def add_correspondence(self, correspondence: RefereeCorrespondence):
        """Add correspondence and update timeline"""
        self.correspondence_history.append(correspondence)
        
        # Update timeline based on correspondence type
        if correspondence.correspondence_type == 'invitation' and not correspondence.is_from_referee:
            if not self.invitation_date or correspondence.date < self.invitation_date:
                self.invitation_date = correspondence.date
        
        elif correspondence.correspondence_type in ['acceptance', 'decline'] and correspondence.is_from_referee:
            if not self.response_date or correspondence.date > self.response_date:
                self.response_date = correspondence.date
                self.response_decision = correspondence.correspondence_type.replace('acceptance', 'accepted').replace('decline', 'declined')
        
        elif correspondence.correspondence_type == 'submission' and correspondence.is_from_referee:
            if not self.submission_date or correspondence.date > self.submission_date:
                self.submission_date = correspondence.date
        
        elif correspondence.correspondence_type == 'reminder' and not correspondence.is_from_referee:
            self.reminder_count += 1

class PreciseRefereeTracker:
    """Tracks only actual referee correspondence"""
    
    def __init__(self):
        self.manuscript_referees: Dict[str, Dict[str, RefereeProfile]] = {}  # manuscript_id -> {referee_id: profile}
        self.manuscript_email_mapping: Dict[str, Dict[str, str]] = {}  # manuscript_id -> {email: referee_id}
        
        # Editorial email patterns (to filter out)
        self.editorial_emails = {
            'dylan.possamai@math.ethz.ch',
            'dylansmb@gmail.com',
            'fauth@siam.org',  # SIAM editorial staff
            'possamai@math.ethz.ch'  # Alternative editorial
        }
        
        # Editorial name patterns (to filter out extracted names)
        self.editorial_names = {
            'dylan', 'possamai', 'brian', 'fauth', 'possamaï', 'frank'
        }
        
        # SIAM system domains (to filter out)
        self.system_domains = {
            'siam.org', 'sifin.siam.org', 'sicon.siam.org',
            'editorialmanager.com', 'manuscriptcentral.com'
        }
        
        # System notification patterns (to ignore)
        self.system_notification_patterns = [
            r'follow-up\s+message',
            r'review\s+at\s+three-month\s+mark',
            r'overdue\s+review',
            r'reminder.*overdue',
            r'automated\s+reminder',
            r'system\s+notification',
            r'manuscript.*status',
            r'editorial\s+office'
        ]
        
        # Correspondence type patterns
        self.correspondence_patterns = {
            'invitation': [
                r'request\s+to\s+referee',
                r'invitation.*review',
                r'would\s+you\s+be\s+willing\s+to\s+review',
                r'invited.*serve.*referee'
            ],
            'reminder': [
                r'reminder.*review',
                r'gentle\s+reminder',
                r'follow.*up.*review',
                r'checking\s+on.*review'
            ],
            'acceptance': [
                r'(?:accept|agree).*review',
                r'happy\s+to\s+review',
                r'willing\s+to\s+serve',
                r'yes.*review'
            ],
            'decline': [
                r'(?:decline|unable).*review',
                r'cannot\s+review',
                r'not\s+able\s+to\s+review',
                r'have\s+to\s+decline'
            ],
            'submission': [
                r'(?:attached|enclosed).*review',
                r'my\s+review.*attached',
                r'report.*attached',
                r'completed\s+review'
            ]
        }
    
    def is_system_notification(self, email_data: Dict) -> bool:
        """Check if email is a system notification (should be ignored)"""
        subject = email_data.get('subject', '').lower()
        body = email_data.get('body', '').lower()
        from_addr = email_data.get('from_address', '').lower()
        
        # Check if from system domain
        if any(domain in from_addr for domain in self.system_domains):
            # Additional check: is it a system notification pattern?
            text = f"{subject} {body}"
            for pattern in self.system_notification_patterns:
                if re.search(pattern, text, re.IGNORECASE):
                    return True
        
        return False
    
    def is_referee_email(self, email: str) -> bool:
        """Check if email address belongs to a referee (not editorial or system)"""
        email = email.lower()
        
        # Not editorial
        if email in self.editorial_emails:
            return False
        
        # Not from system domains
        domain = email.split('@')[-1] if '@' in email else ''
        if domain in self.system_domains:
            return False
        
        # Additional checks for common non-referee patterns
        if any(pattern in email for pattern in ['noreply', 'no-reply', 'system', 'automated']):
            return False
        
        return True
    
    def is_valid_referee_name(self, name: str) -> bool:
        """Check if extracted name is a valid referee name (not editorial)"""
        if not name:
            return False
            
        name_lower = name.lower()
        
        # Filter out editorial names
        for editorial_name in self.editorial_names:
            if editorial_name in name_lower:
                return False
        
        # Basic validation - should be at least 2 words for a person's name
        words = name.split()
        if len(words) < 2:
            return False
            
        # Should not contain email-like patterns
        if '@' in name or '<' in name or '>' in name:
            return False
            
        return True
    
    def extract_referee_emails_from_correspondence(self, email_data: Dict) -> List[str]:
        """Extract referee email addresses from correspondence"""
        referee_emails = []
        
        # Check all addresses in TO, FROM, CC
        all_addresses = [email_data.get('from_address', '')] + \
                       email_data.get('to_addresses', []) + \
                       email_data.get('cc_addresses', [])
        
        for email in all_addresses:
            if email and self.is_referee_email(email):
                referee_emails.append(email.lower())
        
        return list(set(referee_emails))  # Remove duplicates
    
    def identify_correspondence_type(self, email_data: Dict) -> str:
        """Identify the type of correspondence"""
        text = f"{email_data.get('subject', '')} {email_data.get('body', '')}"
        
        for corr_type, patterns in self.correspondence_patterns.items():
            for pattern in patterns:
                if re.search(pattern, text, re.IGNORECASE):
                    return corr_type
        
        return 'other'
    
    def determine_correspondence_direction(self, email_data: Dict, referee_emails: List[str]) -> bool:
        """Determine if correspondence is from referee to editor (True) or editor to referee (False)"""
        from_addr = email_data.get('from_address', '').lower()
        
        # If from address is a referee email, it's from referee to editor
        return from_addr in referee_emails
    
    def find_or_create_referee(self, manuscript_id: str, email: str) -> str:
        """Find existing referee by email or create new one for specific manuscript"""
        email = email.lower()
        
        # Initialize manuscript tracking if not exists
        if manuscript_id not in self.manuscript_referees:
            self.manuscript_referees[manuscript_id] = {}
            self.manuscript_email_mapping[manuscript_id] = {}
        
        # Check if we already know this email for this manuscript
        if email in self.manuscript_email_mapping[manuscript_id]:
            return self.manuscript_email_mapping[manuscript_id][email]
        
        # Check if this email belongs to an existing referee (multiple addresses)
        for referee_id, profile in self.manuscript_referees[manuscript_id].items():
            if email in profile.all_email_addresses:
                self.manuscript_email_mapping[manuscript_id][email] = referee_id
                return referee_id
        
        # Create new referee for this manuscript
        referee_count = len(self.manuscript_referees[manuscript_id]) + 1
        referee_id = f"{manuscript_id}_referee_{referee_count}"
        profile = RefereeProfile(referee_id=referee_id, primary_email=email)
        profile.add_email_address(email)
        
        self.manuscript_referees[manuscript_id][referee_id] = profile
        self.manuscript_email_mapping[manuscript_id][email] = referee_id
        
        return referee_id
    
    def extract_referee_name_from_correspondence(self, email_data: Dict) -> Optional[str]:
        """Extract referee name from email content"""
        text = f"{email_data.get('subject', '')} {email_data.get('body', '')}"
        
        # Common name patterns in academic correspondence
        name_patterns = [
            r'Dear\s+(?:Dr\.?\s+|Prof\.?\s+|Professor\s+)?([A-Z][a-z]+(?:\s+[A-Z]\.?\s+)?[A-Z][a-z]+)',
            r'Hi\s+([A-Z][a-z]+)',
            r'Best\s+regards,?\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
            r'Sincerely,?\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
            r'([A-Z][a-z]+(?:\s+[A-Z]\.?\s+)?[A-Z][a-z]+)\s+has\s+(?:accepted|declined)',
            r'From:.*<([^<>]+)>',  # From email signature
        ]
        
        for pattern in name_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                name = match.group(1).strip()
                # Basic validation
                if len(name) > 2 and not any(char.isdigit() for char in name):
                    return name
        
        return None
    
    def process_email(self, email_data: Dict) -> bool:
        """Process a single email and determine if it's referee correspondence"""
        
        # Must have manuscript ID
        manuscript_id = email_data.get('manuscript_id')
        if not manuscript_id:
            return False
        
        # Skip system notifications
        if self.is_system_notification(email_data):
            return False
        
        # Extract referee emails involved
        referee_emails = self.extract_referee_emails_from_correspondence(email_data)
        
        # Skip if no referee emails found
        if not referee_emails:
            return False
        
        # Identify correspondence type and direction
        corr_type = self.identify_correspondence_type(email_data)
        is_from_referee = self.determine_correspondence_direction(email_data, referee_emails)
        
        # Create correspondence object
        correspondence = RefereeCorrespondence(
            message_id=email_data.get('message_id', ''),
            thread_id=email_data.get('thread_id', ''),
            date=email_data.get('date', datetime.now(timezone.utc)),
            subject=email_data.get('subject', ''),
            from_address=email_data.get('from_address', ''),
            to_addresses=email_data.get('to_addresses', []),
            body=email_data.get('body', ''),
            correspondence_type=corr_type,
            is_from_referee=is_from_referee
        )
        
        # Associate with referee(s) for this manuscript
        for referee_email in referee_emails:
            referee_id = self.find_or_create_referee(manuscript_id, referee_email)
            profile = self.manuscript_referees[manuscript_id][referee_id]
            
            # Try to extract name if not already set
            if not profile.name:
                name = self.extract_referee_name_from_correspondence(email_data)
                if name and self.is_valid_referee_name(name):
                    profile.name = name
            
            # Add correspondence to profile
            profile.add_correspondence(correspondence)
        
        return True
    
    def consolidate_referee_profiles(self, manuscript_id: str):
        """Consolidate referee profiles that might represent the same person"""
        if manuscript_id not in self.manuscript_referees:
            return
            
        # Simple consolidation based on name similarity
        consolidated = {}
        
        for referee_id, profile in self.manuscript_referees[manuscript_id].items():
            # Check if this referee should be merged with an existing one
            merged = False
            
            if profile.name:
                for existing_id, existing_profile in consolidated.items():
                    if existing_profile.name and profile.name:
                        # Check name similarity
                        similarity = difflib.SequenceMatcher(None, 
                                                           profile.name.lower(), 
                                                           existing_profile.name.lower()).ratio()
                        
                        if similarity > 0.8:  # High similarity threshold
                            # Merge profiles
                            existing_profile.all_email_addresses.update(profile.all_email_addresses)
                            existing_profile.correspondence_history.extend(profile.correspondence_history)
                            
                            # Update email mappings
                            for email in profile.all_email_addresses:
                                self.manuscript_email_mapping[manuscript_id][email] = existing_id
                            
                            # Update timeline (keep earliest/latest dates)
                            if profile.invitation_date:
                                if not existing_profile.invitation_date or profile.invitation_date < existing_profile.invitation_date:
                                    existing_profile.invitation_date = profile.invitation_date
                            
                            if profile.response_date:
                                if not existing_profile.response_date or profile.response_date > existing_profile.response_date:
                                    existing_profile.response_date = profile.response_date
                                    existing_profile.response_decision = profile.response_decision
                            
                            if profile.submission_date:
                                if not existing_profile.submission_date or profile.submission_date > existing_profile.submission_date:
                                    existing_profile.submission_date = profile.submission_date
                            
                            existing_profile.reminder_count += profile.reminder_count
                            
                            merged = True
                            break
            
            if not merged:
                consolidated[referee_id] = profile
        
        self.manuscript_referees[manuscript_id] = consolidated
    
    def generate_manuscript_analytics(self, manuscript_id: str) -> Dict:
        """Generate analytics for a specific manuscript"""
        if manuscript_id not in self.manuscript_referees:
            return {'manuscript_id': manuscript_id, 'total_referees': 0, 'referees': {}, 'summary': {}}
            
        analytics = {
            'manuscript_id': manuscript_id,
            'total_referees': len(self.manuscript_referees[manuscript_id]),
            'referees': {},
            'summary': {
                'accepted': 0,
                'declined': 0,
                'no_response': 0,
                'submitted_reviews': 0,
                'total_reminders_sent': 0
            }
        }
        
        for referee_id, profile in self.manuscript_referees[manuscript_id].items():
            # Calculate status
            status = 'no_response'
            if profile.response_decision == 'accepted':
                status = 'accepted'
                analytics['summary']['accepted'] += 1
            elif profile.response_decision == 'declined':
                status = 'declined'
                analytics['summary']['declined'] += 1
            else:
                analytics['summary']['no_response'] += 1
            
            if profile.submission_date:
                analytics['summary']['submitted_reviews'] += 1
            
            analytics['summary']['total_reminders_sent'] += profile.reminder_count
            
            analytics['referees'][referee_id] = {
                'name': profile.name or 'Unknown',
                'primary_email': profile.primary_email,
                'all_emails': list(profile.all_email_addresses),
                'status': status,
                'invitation_date': profile.invitation_date.isoformat() if profile.invitation_date else None,
                'response_date': profile.response_date.isoformat() if profile.response_date else None,
                'submission_date': profile.submission_date.isoformat() if profile.submission_date else None,
                'reminders_sent': profile.reminder_count,
                'total_correspondence': len(profile.correspondence_history),
                'correspondence_timeline': [
                    {
                        'date': corr.date.isoformat(),
                        'type': corr.correspondence_type,
                        'direction': 'from_referee' if corr.is_from_referee else 'to_referee',
                        'subject': corr.subject
                    }
                    for corr in sorted(profile.correspondence_history, key=lambda x: x.date)
                ]
            }
        
        return analytics
    
    def generate_report(self, manuscript_id: str) -> str:
        """Generate human-readable report"""
        analytics = self.generate_manuscript_analytics(manuscript_id)
        
        report = []
        report.append(f"📊 Precise Referee Analysis: {manuscript_id}")
        report.append("=" * 60)
        report.append(f"📧 Total Referees Found: {analytics['total_referees']}")
        report.append(f"✅ Accepted: {analytics['summary']['accepted']}")
        report.append(f"❌ Declined: {analytics['summary']['declined']}")
        report.append(f"⏳ No Response: {analytics['summary']['no_response']}")
        report.append(f"📝 Submitted Reviews: {analytics['summary']['submitted_reviews']}")
        report.append(f"🔔 Total Reminders Sent: {analytics['summary']['total_reminders_sent']}")
        report.append("")
        
        report.append("👥 REFEREE DETAILS:")
        for referee_id, data in analytics['referees'].items():
            report.append(f"   📧 {data['name']} ({data['primary_email']})")
            report.append(f"      Status: {data['status']}")
            report.append(f"      Reminders sent: {data['reminders_sent']}")
            report.append(f"      Total correspondence: {data['total_correspondence']}")
            
            if data['invitation_date']:
                report.append(f"      📨 Invited: {data['invitation_date']}")
            if data['response_date']:
                report.append(f"      📞 Responded: {data['response_date']}")
            if data['submission_date']:
                report.append(f"      📝 Submitted: {data['submission_date']}")
            
            if len(data['all_emails']) > 1:
                report.append(f"      📮 Alternative emails: {', '.join(data['all_emails'][1:])}")
            
            report.append("")
        
        return "\n".join(report)

def main():
    """Test the precise referee tracker"""
    tracker = PreciseRefereeTracker()
    
    # This would be integrated with the SIFIN email parser
    print("📊 Precise Referee Tracker initialized")
    print("Ready to process actual referee correspondence only")
    
    return tracker

if __name__ == "__main__":
    main()