#!/usr/bin/env python3
"""
SIFIN Email Timeline Integration
Combines web-scraped data with email timeline for complete analytics
"""

import os
import json
import logging
import re
from datetime import datetime
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict

# Import SIFIN extractors
import sys
sys.path.append('/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/scripts/sifin')
from extract_sifin_firefox import SIFINFirefoxExtractor
from parse_sifin_emails import SIFINEmailParser

logger = logging.getLogger(__name__)

@dataclass
class EnhancedReferee:
    """Enhanced referee data combining web scraping and email timeline"""
    # Web-scraped data
    name: str
    email: str
    affiliation: str
    status: str
    last_contact_date: Optional[str] = None
    
    # Email timeline data
    invitation_date: Optional[str] = None
    response_date: Optional[str] = None
    response_decision: Optional[str] = None
    response_time_days: Optional[int] = None
    reminder_count: int = 0
    submission_date: Optional[str] = None
    review_time_days: Optional[int] = None
    
    # Analytics
    performance_score: Optional[float] = None
    communication_pattern: Optional[str] = None
    workload_indicator: Optional[str] = None

@dataclass
class EnhancedManuscript:
    """Enhanced manuscript data with complete timeline"""
    # Web-scraped data
    manuscript_id: str
    title: str
    submitted: str
    current_stage: str
    corresponding_author: str
    referees: List[EnhancedReferee]
    pdfs: List[Dict]
    comments: List[Dict]
    
    # Email timeline data
    total_reminders_sent: int = 0
    communication_timeline: List[Dict] = None
    
    # Analytics
    avg_response_time: Optional[float] = None
    reminder_effectiveness: Optional[float] = None
    review_completion_rate: Optional[float] = None

class SIFINTimelineIntegrator:
    """Integrates SIFIN web scraping with email timeline data"""
    
    def __init__(self):
        self.web_extractor = SIFINFirefoxExtractor()
        self.email_parser = SIFINEmailParser()
        self.enhanced_manuscripts = []
        
    def load_existing_extraction_file(self) -> List[Dict]:
        """Load existing SIFIN extraction file and assign correct manuscript IDs"""
        try:
            # Load the most recent extraction file
            extraction_file = "/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/sifin_firefox_20250717_094617.json"
            with open(extraction_file, 'r') as f:
                manuscripts = json.load(f)
            
            # Assign correct manuscript IDs based on user's feedback
            # From session summary: M174160, M174727, M175988, M176140
            correct_ids = ["M174160", "M174727", "M175988", "M176140"]
            
            for i, manuscript in enumerate(manuscripts):
                if i < len(correct_ids):
                    manuscript["Manuscript #"] = correct_ids[i]
                    print(f"   📄 Assigned {correct_ids[i]} to manuscript: {manuscript.get('Title', 'Unknown')[:50]}...")
                else:
                    manuscript["Manuscript #"] = f"M{170000 + i}"
            
            return manuscripts
            
        except Exception as e:
            print(f"❌ Error loading existing extraction file: {e}")
            return []
    
    def run_complete_extraction(self, headless: bool = True) -> List[EnhancedManuscript]:
        """Run complete extraction with web scraping and email timeline"""
        print("🚀 Starting SIFIN Complete Timeline Extraction")
        print("=" * 60)
        
        # Step 1: Web scraping - use existing extraction file
        print("\n📍 Step 1: Loading SIFIN Web Scraping Data")
        web_manuscripts = self.load_existing_extraction_file()
        print(f"✅ Loaded {len(web_manuscripts)} manuscripts from existing extraction")
        
        # Step 2: Email timeline extraction
        print("\n📍 Step 2: Email Timeline Extraction")
        if not self.email_parser.setup_gmail_service():
            print("❌ Failed to setup Gmail service")
            return []
        
        # Extract manuscript IDs for email search
        manuscript_ids = [ms.get('Manuscript #', '') for ms in web_manuscripts]
        manuscript_ids = [id for id in manuscript_ids if id]
        
        print(f"🔍 Searching emails for manuscripts: {manuscript_ids}")
        events = self.email_parser.fetch_sifin_emails(manuscript_ids=manuscript_ids, days_back=None)
        timelines = self.email_parser.build_referee_timelines(events)
        
        print(f"✅ Found {len(events)} timeline events")
        
        # Step 3: Data integration
        print("\n📍 Step 3: Data Integration")
        self.enhanced_manuscripts = self._integrate_data(web_manuscripts, timelines)
        
        print(f"✅ Created {len(self.enhanced_manuscripts)} enhanced manuscripts")
        
        # Step 4: Analytics generation
        print("\n📍 Step 4: Analytics Generation")
        self._generate_analytics()
        
        print("✅ Analytics generation complete")
        
        return self.enhanced_manuscripts
    
    def _integrate_data(self, web_manuscripts: List[Dict], email_timelines: Dict) -> List[EnhancedManuscript]:
        """Integrate web-scraped data with email timelines"""
        enhanced_manuscripts = []
        
        for web_ms in web_manuscripts:
            ms_id = web_ms.get('Manuscript #', '')
            if not ms_id:
                continue
            
            # Get email timeline for this manuscript
            email_timeline = email_timelines.get(ms_id, {})
            
            # Enhance referees with email data
            enhanced_referees = []
            web_referees = web_ms.get('Referees', [])
            
            for referee in web_referees:
                enhanced_referee = self._enhance_referee(referee, email_timeline)
                enhanced_referees.append(enhanced_referee)
            
            # Check for email-only referees (referees found in emails but not web)
            email_only_referees = self._find_email_only_referees(web_referees, email_timeline)
            enhanced_referees.extend(email_only_referees)
            
            # Calculate manuscript-level metrics
            total_reminders = sum(
                timeline.reminder_count 
                for timeline in email_timeline.values()
            )
            
            # Create enhanced manuscript
            enhanced_ms = EnhancedManuscript(
                manuscript_id=ms_id,
                title=web_ms.get('Title', ''),
                submitted=web_ms.get('Submitted', ''),
                current_stage=web_ms.get('Current Stage', ''),
                corresponding_author=web_ms.get('Corresponding Author', ''),
                referees=enhanced_referees,
                pdfs=web_ms.get('PDFs', []),
                comments=web_ms.get('Comments', []),
                total_reminders_sent=total_reminders,
                communication_timeline=self._build_communication_timeline(email_timeline)
            )
            
            enhanced_manuscripts.append(enhanced_ms)
        
        return enhanced_manuscripts
    
    def _enhance_referee(self, web_referee: Dict, email_timeline: Dict) -> EnhancedReferee:
        """Enhance a referee with email timeline data"""
        # Extract referee data from web scraping (different field names)
        referee_email = web_referee.get('Referee Email', '') or web_referee.get('email', '')
        referee_name = web_referee.get('Referee Name', '') or web_referee.get('name', '')
        affiliation = web_referee.get('Affiliation', '') or web_referee.get('affiliation', '')
        status = web_referee.get('Status', '') or web_referee.get('status', '')
        
        # Clean referee name for matching (remove #1, #2 suffixes)
        clean_referee_name = re.sub(r'\s*#\d+$', '', referee_name).strip()
        
        # Find matching email timeline (by email or name)
        timeline = None
        for key, tl in email_timeline.items():
            # Try exact email match
            if referee_email and key == referee_email:
                timeline = tl
                break
            # Try exact name match (with clean name)
            if clean_referee_name and (key == clean_referee_name or key == referee_name):
                timeline = tl
                break
        
        # If no exact match, try partial matching
        if not timeline:
            for key, tl in email_timeline.items():
                # Check if key contains the referee's name (partial match)
                if clean_referee_name and clean_referee_name in key:
                    timeline = tl
                    break
                # Check if referee name contains the key (e.g., "Antoine Jacquier" contains "Antoine Jack Jacquier")
                elif clean_referee_name and key in clean_referee_name:
                    timeline = tl
                    break
                # Check email partial match
                elif referee_email and referee_email in key:
                    timeline = tl
                    break
        
        # Create enhanced referee
        enhanced_referee = EnhancedReferee(
            name=referee_name,
            email=referee_email,
            affiliation=affiliation,
            status=status,
            last_contact_date=web_referee.get('last_contact_date', ''),
        )
        
        # Add email timeline data if available
        if timeline:
            enhanced_referee.invitation_date = timeline.invitation_date.isoformat() if timeline.invitation_date else None
            enhanced_referee.response_date = timeline.response_date.isoformat() if timeline.response_date else None
            enhanced_referee.response_decision = timeline.response_decision
            enhanced_referee.response_time_days = timeline.response_time_days
            enhanced_referee.reminder_count = timeline.reminder_count
            enhanced_referee.submission_date = timeline.submission_date.isoformat() if timeline.submission_date else None
            enhanced_referee.review_time_days = timeline.review_time_days
        
        return enhanced_referee
    
    def _find_email_only_referees(self, web_referees: List[Dict], email_timeline: Dict) -> List[EnhancedReferee]:
        """Find referees that appear in emails but not in web data"""
        web_emails = {ref.get('email', '') for ref in web_referees}
        web_names = {ref.get('name', '') for ref in web_referees}
        
        email_only_referees = []
        
        for key, timeline in email_timeline.items():
            # Check if this referee is already in web data
            if key in web_emails or key in web_names:
                continue
            
            # Check if timeline has referee info
            if timeline.referee_email or timeline.referee_name:
                enhanced_referee = EnhancedReferee(
                    name=timeline.referee_name or "Unknown",
                    email=timeline.referee_email or "",
                    affiliation="",
                    status="email_only",
                    invitation_date=timeline.invitation_date.isoformat() if timeline.invitation_date else None,
                    response_date=timeline.response_date.isoformat() if timeline.response_date else None,
                    response_decision=timeline.response_decision,
                    response_time_days=timeline.response_time_days,
                    reminder_count=timeline.reminder_count,
                    submission_date=timeline.submission_date.isoformat() if timeline.submission_date else None,
                    review_time_days=timeline.review_time_days
                )
                email_only_referees.append(enhanced_referee)
        
        return email_only_referees
    
    def _build_communication_timeline(self, email_timeline: Dict) -> List[Dict]:
        """Build a chronological communication timeline"""
        events = []
        
        for referee_key, timeline in email_timeline.items():
            for event in timeline.events:
                events.append({
                    'date': event.date.isoformat(),
                    'type': event.event_type,
                    'referee': referee_key,
                    'details': event.details or {}
                })
        
        # Sort by date
        events.sort(key=lambda x: x['date'])
        return events
    
    def _generate_analytics(self):
        """Generate analytics for enhanced manuscripts"""
        for manuscript in self.enhanced_manuscripts:
            # Calculate manuscript-level metrics
            referees_with_responses = [
                ref for ref in manuscript.referees 
                if ref.response_time_days is not None
            ]
            
            if referees_with_responses:
                manuscript.avg_response_time = sum(
                    ref.response_time_days for ref in referees_with_responses
                ) / len(referees_with_responses)
            
            # Calculate review completion rate
            total_referees = len(manuscript.referees)
            completed_reviews = len([
                ref for ref in manuscript.referees 
                if ref.submission_date is not None
            ])
            
            if total_referees > 0:
                manuscript.review_completion_rate = completed_reviews / total_referees
            
            # Calculate reminder effectiveness
            if manuscript.total_reminders_sent > 0:
                manuscript.reminder_effectiveness = completed_reviews / manuscript.total_reminders_sent
            
            # Generate referee-level analytics
            for referee in manuscript.referees:
                referee.performance_score = self._calculate_referee_performance(referee)
                referee.communication_pattern = self._analyze_communication_pattern(referee)
                referee.workload_indicator = self._assess_workload_indicator(referee)
    
    def _calculate_referee_performance(self, referee: EnhancedReferee) -> float:
        """Calculate overall referee performance score (0-10)"""
        score = 5.0  # Base score
        
        # Response time factor
        if referee.response_time_days is not None:
            if referee.response_time_days <= 3:
                score += 2.0
            elif referee.response_time_days <= 7:
                score += 1.0
            elif referee.response_time_days > 14:
                score -= 1.0
        
        # Review completion factor
        if referee.submission_date:
            score += 2.0
        
        # Reminder factor (fewer reminders = better)
        if referee.reminder_count == 0:
            score += 1.0
        elif referee.reminder_count > 5:
            score -= 1.0
        
        # Review time factor
        if referee.review_time_days is not None:
            if referee.review_time_days <= 14:
                score += 1.0
            elif referee.review_time_days > 30:
                score -= 1.0
        
        return max(0.0, min(10.0, score))
    
    def _analyze_communication_pattern(self, referee: EnhancedReferee) -> str:
        """Analyze referee communication pattern"""
        if referee.response_time_days is None:
            return "no_response"
        
        if referee.response_time_days <= 3:
            return "fast_responder"
        elif referee.response_time_days <= 7:
            return "regular_responder"
        elif referee.response_time_days <= 14:
            return "slow_responder"
        else:
            return "very_slow_responder"
    
    def _assess_workload_indicator(self, referee: EnhancedReferee) -> str:
        """Assess referee workload based on communication patterns"""
        if referee.reminder_count == 0:
            return "light_workload"
        elif referee.reminder_count <= 3:
            return "moderate_workload"
        elif referee.reminder_count <= 8:
            return "heavy_workload"
        else:
            return "overwhelmed"
    
    def generate_comprehensive_report(self) -> str:
        """Generate a comprehensive report of the enhanced data"""
        report = []
        report.append("📊 SIFIN Complete Timeline Analysis Report")
        report.append("=" * 60)
        
        total_manuscripts = len(self.enhanced_manuscripts)
        total_referees = sum(len(ms.referees) for ms in self.enhanced_manuscripts)
        
        report.append(f"📄 Total Manuscripts: {total_manuscripts}")
        report.append(f"👥 Total Referees: {total_referees}")
        report.append("")
        
        # Manuscript-level summary
        for ms in self.enhanced_manuscripts:
            report.append(f"📄 Manuscript {ms.manuscript_id}")
            report.append(f"   Title: {ms.title[:50]}...")
            report.append(f"   Status: {ms.current_stage}")
            report.append(f"   Referees: {len(ms.referees)}")
            report.append(f"   Total Reminders: {ms.total_reminders_sent}")
            
            if ms.avg_response_time:
                report.append(f"   Avg Response Time: {ms.avg_response_time:.1f} days")
            
            if ms.review_completion_rate:
                report.append(f"   Review Completion Rate: {ms.review_completion_rate:.1%}")
            
            if ms.reminder_effectiveness:
                report.append(f"   Reminder Effectiveness: {ms.reminder_effectiveness:.2f}")
            
            report.append("")
            
            # Referee-level details
            for referee in ms.referees:
                report.append(f"   👤 {referee.name} ({referee.email})")
                report.append(f"      Status: {referee.status}")
                report.append(f"      Performance Score: {referee.performance_score:.1f}/10")
                report.append(f"      Communication Pattern: {referee.communication_pattern}")
                report.append(f"      Workload Indicator: {referee.workload_indicator}")
                
                if referee.response_time_days:
                    report.append(f"      Response Time: {referee.response_time_days} days")
                
                if referee.reminder_count > 0:
                    report.append(f"      Reminders Sent: {referee.reminder_count}")
                
                if referee.submission_date:
                    report.append(f"      Review Submitted: {referee.submission_date}")
                
                report.append("")
        
        return "\n".join(report)
    
    def save_results(self, filename: str = None):
        """Save enhanced results to JSON file"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"sifin_enhanced_timeline_{timestamp}.json"
        
        # Convert to serializable format
        serializable_data = {
            'extraction_timestamp': datetime.now().isoformat(),
            'total_manuscripts': len(self.enhanced_manuscripts),
            'total_referees': sum(len(ms.referees) for ms in self.enhanced_manuscripts),
            'manuscripts': [asdict(ms) for ms in self.enhanced_manuscripts]
        }
        
        with open(filename, 'w') as f:
            json.dump(serializable_data, f, indent=2)
        
        print(f"📄 Enhanced timeline data saved to: {filename}")
        return filename


def main():
    """Main function for SIFIN timeline integration"""
    integrator = SIFINTimelineIntegrator()
    
    print("🚀 SIFIN Email Timeline Integration")
    print("=" * 50)
    
    # Run complete extraction
    enhanced_manuscripts = integrator.run_complete_extraction(headless=True)
    
    if not enhanced_manuscripts:
        print("❌ No enhanced manuscripts created")
        return
    
    # Generate and display report
    report = integrator.generate_comprehensive_report()
    print("\n" + report)
    
    # Save results
    filename = integrator.save_results()
    
    print(f"\n🎉 SIFIN Timeline Integration Complete!")
    print(f"📊 Enhanced {len(enhanced_manuscripts)} manuscripts with email timeline data")
    print(f"📄 Results saved to: {filename}")


if __name__ == "__main__":
    main()