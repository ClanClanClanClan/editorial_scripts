#!/usr/bin/env python3
"""
Debug device verification page to find correct element IDs
"""

import os
import sys
import time
import logging
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from editorial_assistant.core.browser_manager import BrowserManager

# Set up logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def debug_device_verification():
    """Debug device verification page elements."""
    logger.info("🔍 Debugging device verification page")
    
    # Load production config
    with open('.env.production', 'r') as f:
        for line in f:
            if '=' in line and not line.startswith('#'):
                key, value = line.strip().split('=', 1)
                os.environ[key] = value
    
    try:
        # Create browser
        browser_manager = BrowserManager(headless=False)
        driver = browser_manager.create_driver()
        
        # Navigate to MF
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        # Accept cookies
        try:
            accept_btn = driver.find_element("id", "onetrust-accept-btn-handler")
            if accept_btn.is_displayed():
                accept_btn.click()
                time.sleep(1)
        except:
            pass
        
        # Fill login form
        user = os.environ.get('MF_EMAIL')
        password = os.environ.get('MF_PASSWORD')
        
        logger.info(f"📧 Logging in with: {user}")
        
        user_box = driver.find_element("id", "USERID")
        pw_box = driver.find_element("id", "PASSWORD")
        
        user_box.clear()
        user_box.send_keys(user)
        pw_box.clear()
        pw_box.send_keys(password)
        
        # Submit login
        login_btn = driver.find_element("id", "logInButton")
        login_btn.click()
        
        # Wait for device verification page
        time.sleep(10)
        
        # Check if we're on device verification page
        page_source = driver.page_source
        current_url = driver.current_url
        
        logger.info(f"📍 Current URL: {current_url}")
        
        if "UNRECOGNIZED_DEVICE" in page_source:
            logger.info("✅ On device verification page")
            
            # Look for all input fields
            inputs = driver.find_elements("tag name", "input")
            logger.info(f"🔍 Found {len(inputs)} input fields:")
            
            for i, input_field in enumerate(inputs):
                input_id = input_field.get_attribute('id')
                input_name = input_field.get_attribute('name')
                input_type = input_field.get_attribute('type')
                input_placeholder = input_field.get_attribute('placeholder')
                input_class = input_field.get_attribute('class')
                
                if input_id or input_name or input_type == 'text':
                    logger.info(f"  Input {i+1}: id='{input_id}', name='{input_name}', type='{input_type}', placeholder='{input_placeholder}', class='{input_class}'")
            
            # Look for any text containing "code" or "verification"
            elements_with_code = driver.find_elements("xpath", "//*[contains(text(), 'code') or contains(text(), 'Code') or contains(text(), 'verification') or contains(text(), 'Verification')]")
            logger.info(f"🔍 Found {len(elements_with_code)} elements with 'code' or 'verification':")
            
            for elem in elements_with_code:
                try:
                    text = elem.text.strip()
                    if text:
                        logger.info(f"  Text: '{text}'")
                except:
                    pass
            
            # Look for buttons
            buttons = driver.find_elements("tag name", "button")
            logger.info(f"🔍 Found {len(buttons)} buttons:")
            
            for button in buttons:
                button_text = button.text.strip()
                button_id = button.get_attribute('id')
                button_class = button.get_attribute('class')
                
                if button_text or button_id:
                    logger.info(f"  Button: text='{button_text}', id='{button_id}', class='{button_class}'")
        
        else:
            logger.warning("❌ Not on device verification page")
        
        # Keep browser open for inspection
        input("Press Enter to close browser...")
        
    except Exception as e:
        logger.error(f"❌ Error debugging device verification: {e}")
        import traceback
        traceback.print_exc()
    finally:
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    debug_device_verification()