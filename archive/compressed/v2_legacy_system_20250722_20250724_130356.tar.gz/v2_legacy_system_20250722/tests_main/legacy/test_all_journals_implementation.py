#!/usr/bin/env python3
"""
Test All Journals Implementation Status
Comprehensive test to verify which journals are truly working
"""

import os
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple

from editorial_assistant.core.data_models import JournalConfig

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class JournalImplementationTester:
    """Tests implementation status of all journals"""
    
    def __init__(self):
        self.results = {}
        self.journals = self._load_journal_configs()
    
    def _load_journal_configs(self) -> Dict[str, JournalConfig]:
        """Load journal configurations"""
        configs = {}
        
        # Define all 8 journals from specifications
        journal_data = {
            "SICON": {
                "name": "SIAM Journal on Control and Optimization",
                "url": "https://sicon.siam.org/cgi-bin/main.plex",
                "platform": "siam_orcid",
                "extractor_class": "SICONExtractor",
                "extractor_path": "editorial_assistant.extractors.sicon"
            },
            "SIFIN": {
                "name": "SIAM Journal on Financial Mathematics",
                "url": "https://sifin.siam.org/cgi-bin/main.plex",
                "platform": "siam_orcid",
                "extractor_class": "SIFINExtractor",
                "extractor_path": "editorial_assistant.extractors.sifin"
            },
            "MF": {
                "name": "Mathematical Finance",
                "url": "https://mc.manuscriptcentral.com/mafi",
                "platform": "scholarone",
                "extractor_class": "MFExtractor",
                "extractor_path": "editorial_assistant.extractors.implementations.mf_extractor"
            },
            "MOR": {
                "name": "Mathematics of Operations Research",
                "url": "https://mc.manuscriptcentral.com/moor",
                "platform": "scholarone",
                "extractor_class": "MORExtractor",
                "extractor_path": "editorial_assistant.extractors.implementations.mor_extractor"
            },
            "JOTA": {
                "name": "Journal of Optimization Theory and Applications",
                "url": "https://www.editorialmanager.com/jota",
                "platform": "editorial_manager",
                "extractor_class": "JOTAExtractor",
                "extractor_path": "editorial_assistant.extractors.jota"
            },
            "MAFE": {
                "name": "Mathematics and Financial Economics",
                "url": "https://www.editorialmanager.com/mafe",
                "platform": "editorial_manager_cloud",
                "extractor_class": "MAFEExtractor",
                "extractor_path": "editorial_assistant.extractors.mafe"
            },
            "FS": {
                "name": "Finance and Stochastics",
                "url": "email-based",
                "platform": "email",
                "extractor_class": "FSExtractor",
                "extractor_path": "editorial_assistant.extractors.fs"
            },
            "NACO": {
                "name": "Nonlinear Analysis",
                "url": "https://msp.org/scripts/submissions/naco",
                "platform": "msp_custom",
                "extractor_class": "NACOExtractor",
                "extractor_path": "editorial_assistant.extractors.naco"
            }
        }
        
        for code, data in journal_data.items():
            config = JournalConfig(
                code=code,
                name=data["name"],
                url=data["url"],
                platform=data["platform"],
                credentials={}  # Will be loaded from environment
            )
            # Store extractor info in a separate dict
            configs[code] = {
                'config': config,
                'extractor_class': data["extractor_class"],
                'extractor_path': data["extractor_path"]
            }
        
        return configs
    
    def test_journal_implementation(self, journal_code: str) -> Dict:
        """Test implementation status of a single journal"""
        logger.info(f"\nTesting {journal_code} implementation...")
        
        journal_info = self.journals[journal_code]
        journal_config = journal_info['config']
        
        result = {
            "code": journal_code,
            "name": journal_config.name,
            "platform": journal_config.platform,
            "url": journal_config.url,
            "extractor_exists": False,
            "extractor_importable": False,
            "has_extract_method": False,
            "has_login_method": False,
            "has_email_integration": False,
            "has_timeline_validation": False,
            "test_extraction_success": False,
            "extracted_data_count": 0,
            "errors": [],
            "warnings": [],
            "implementation_score": 0
        }
        
        # Test 1: Check if extractor file exists
        try:
            import importlib
            module = importlib.import_module(journal_info['extractor_path'])
            result["extractor_exists"] = True
            result["extractor_importable"] = True
            
            # Test 2: Check if extractor class exists
            extractor_class = getattr(module, journal_info['extractor_class'], None)
            if extractor_class:
                # Test 3: Check required methods
                instance = extractor_class(journal_config)
                
                if hasattr(instance, 'extract_data'):
                    result["has_extract_method"] = True
                else:
                    result["errors"].append("Missing extract_data method")
                
                if hasattr(instance, '_login'):
                    result["has_login_method"] = True
                else:
                    result["errors"].append("Missing _login method")
                
                # Test 4: Check for email integration
                source_code = str(module.__file__)
                if source_code:
                    with open(source_code, 'r') as f:
                        content = f.read()
                        if 'email_timeline' in content or 'gmail' in content:
                            result["has_email_integration"] = True
                        else:
                            result["warnings"].append("No email timeline integration found")
                
                # Test 5: Try a limited extraction
                if result["has_extract_method"] and result["has_login_method"]:
                    try:
                        # Set a short timeout for testing
                        logger.info(f"  Attempting test extraction for {journal_code}...")
                        
                        # For email-based journals, skip web extraction test
                        if journal_config.platform == "email":
                            result["test_extraction_success"] = True
                            result["warnings"].append("Email-based journal - web extraction not applicable")
                        else:
                            # Would normally run: manuscripts = instance.extract_data()
                            # But we'll mark as untested to avoid actual web scraping
                            result["warnings"].append("Actual extraction test skipped - manual verification needed")
                            
                    except Exception as e:
                        result["errors"].append(f"Extraction test failed: {str(e)}")
            else:
                result["errors"].append(f"Extractor class {journal_info['extractor_class']} not found")
                
        except ImportError as e:
            result["errors"].append(f"Cannot import extractor: {str(e)}")
        except Exception as e:
            result["errors"].append(f"Unexpected error: {str(e)}")
        
        # Calculate implementation score
        score = 0
        if result["extractor_exists"]: score += 20
        if result["extractor_importable"]: score += 20
        if result["has_extract_method"]: score += 20
        if result["has_login_method"]: score += 20
        if result["has_email_integration"]: score += 10
        if result["has_timeline_validation"]: score += 10
        
        result["implementation_score"] = score
        
        # Determine status
        if score >= 80:
            result["status"] = "IMPLEMENTED"
        elif score >= 50:
            result["status"] = "PARTIALLY_IMPLEMENTED"
        else:
            result["status"] = "NOT_IMPLEMENTED"
        
        return result
    
    def test_all_journals(self) -> Dict:
        """Test all journals and generate comprehensive report"""
        logger.info("Testing all journal implementations...")
        
        for journal_code in self.journals:
            self.results[journal_code] = self.test_journal_implementation(journal_code)
        
        # Generate summary
        summary = {
            "timestamp": datetime.now().isoformat(),
            "total_journals": len(self.journals),
            "implemented": 0,
            "partially_implemented": 0,
            "not_implemented": 0,
            "results": self.results
        }
        
        # Count statuses
        for result in self.results.values():
            if result["status"] == "IMPLEMENTED":
                summary["implemented"] += 1
            elif result["status"] == "PARTIALLY_IMPLEMENTED":
                summary["partially_implemented"] += 1
            else:
                summary["not_implemented"] += 1
        
        return summary
    
    def print_summary(self, summary: Dict):
        """Print a formatted summary of test results"""
        print("\n" + "="*80)
        print("JOURNAL IMPLEMENTATION STATUS REPORT")
        print("="*80)
        print(f"Generated: {summary['timestamp']}")
        print(f"\nTotal Journals: {summary['total_journals']}")
        print(f"  ✅ Fully Implemented: {summary['implemented']}")
        print(f"  ⚠️  Partially Implemented: {summary['partially_implemented']}")
        print(f"  ❌ Not Implemented: {summary['not_implemented']}")
        
        print("\nDETAILED STATUS BY JOURNAL:")
        print("-"*80)
        
        # Group by platform
        by_platform = {}
        for code, result in summary['results'].items():
            platform = result['platform']
            if platform not in by_platform:
                by_platform[platform] = []
            by_platform[platform].append(result)
        
        for platform, journals in by_platform.items():
            print(f"\n{platform.upper()} Platform:")
            for journal in journals:
                status_icon = "✅" if journal['status'] == "IMPLEMENTED" else "⚠️" if journal['status'] == "PARTIALLY_IMPLEMENTED" else "❌"
                print(f"  {status_icon} {journal['code']} - {journal['name']}")
                print(f"     Score: {journal['implementation_score']}/100")
                
                if journal['errors']:
                    print(f"     ❌ Errors: {', '.join(journal['errors'][:2])}")
                if journal['warnings']:
                    print(f"     ⚠️  Warnings: {', '.join(journal['warnings'][:2])}")
                
                # Check specific features
                features = []
                if journal['has_extract_method']: features.append("✓ Extract")
                if journal['has_login_method']: features.append("✓ Login")
                if journal['has_email_integration']: features.append("✓ Email")
                if journal['has_timeline_validation']: features.append("✓ Timeline")
                
                if features:
                    print(f"     Features: {' '.join(features)}")
        
        print("\n" + "="*80)
        print("CRITICAL FINDINGS:")
        print("-"*80)
        
        # Check for email integration
        no_email_integration = [j for j in summary['results'].values() if not j['has_email_integration']]
        if no_email_integration:
            print(f"\n⚠️  {len(no_email_integration)} journals lack email timeline integration:")
            for journal in no_email_integration:
                print(f"   - {journal['code']}: {journal['name']}")
        
        # Check for timeline validation
        no_timeline_validation = [j for j in summary['results'].values() if not j['has_timeline_validation']]
        if no_timeline_validation:
            print(f"\n⚠️  {len(no_timeline_validation)} journals lack timeline validation:")
            for journal in no_timeline_validation:
                print(f"   - {journal['code']}: {journal['name']}")
        
        print("\nRECOMMENDATIONS:")
        print("-"*80)
        print("1. All journals MUST implement email timeline integration")
        print("2. All journals MUST validate timeline consistency between web and email")
        print("3. Priority order for implementation:")
        
        # Sort by implementation score
        sorted_journals = sorted(summary['results'].values(), key=lambda x: x['implementation_score'])
        for i, journal in enumerate(sorted_journals[:3]):
            if journal['implementation_score'] < 100:
                print(f"   {i+1}. {journal['code']} (current score: {journal['implementation_score']})")


def main():
    """Run comprehensive journal implementation tests"""
    tester = JournalImplementationTester()
    summary = tester.test_all_journals()
    
    # Save detailed report
    report_path = Path(f"journal_implementation_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    with open(report_path, 'w') as f:
        json.dump(summary, f, indent=2)
    
    # Print summary
    tester.print_summary(summary)
    
    print(f"\nDetailed report saved to: {report_path}")
    
    # Return whether all journals are implemented
    return summary['implemented'] == summary['total_journals']


if __name__ == "__main__":
    success = main()
    
    if success:
        print("\n✅ ALL JOURNALS FULLY IMPLEMENTED")
    else:
        print("\n❌ NOT ALL JOURNALS ARE FULLY IMPLEMENTED")
        print("\nThe first task is to implement ALL journals with:")
        print("1. Working extractors for all 8 journals")
        print("2. Email timeline integration for each")
        print("3. Timeline consistency validation")
        print("4. No contradictions between web and email data")