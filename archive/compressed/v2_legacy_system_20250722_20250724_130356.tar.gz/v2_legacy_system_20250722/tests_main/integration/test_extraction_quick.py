#!/usr/bin/env python3
"""Quick test of working MF extraction to see current status"""

import os
import sys
import json
from pathlib import Path
from dotenv import load_dotenv

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

def test_working_extraction():
    """Test the current working extraction"""
    from editorial_assistant.extractors.scholarone import ScholarOneExtractor
    
    print("🚀 Testing current working MF extraction...")
    
    try:
        # Create extractor 
        extractor = ScholarOneExtractor('MF', headless=True)
        print("✅ Created MF extractor")
        
        # Run extraction
        print("🎯 Running extraction...")
        result = extractor.extract()
        
        print(f"\n📊 EXTRACTION RESULTS:")
        print(f"Total manuscripts found: {len(result.manuscripts)}")
        
        for i, ms in enumerate(result.manuscripts):
            print(f"\n📄 {i+1}. {ms.manuscript_id}")
            print(f"   Title: {ms.title}")
            print(f"   Authors: {len(ms.authors)}")
            print(f"   Referees: {len(ms.referees)}")
            print(f"   Status: {ms.status}")
            
            for j, ref in enumerate(ms.referees):
                print(f"      {j+1}. {ref.name} - {ref.status}")
        
        # Save results
        result_data = {
            'total_manuscripts': len(result.manuscripts),
            'manuscripts': []
        }
        
        for ms in result.manuscripts:
            ms_data = {
                'id': ms.manuscript_id,
                'title': ms.title,
                'authors': [{'name': a.name, 'is_corresponding': a.is_corresponding} for a in ms.authors],
                'status': ms.status,
                'referees': []
            }
            
            for ref in ms.referees:
                ref_data = {
                    'name': ref.name,
                    'status': ref.status.value if hasattr(ref.status, 'value') else str(ref.status),
                    'email': ref.email,
                    'affiliation': ref.affiliation
                }
                ms_data['referees'].append(ref_data)
            
            result_data['manuscripts'].append(ms_data)
        
        with open('working_extraction_results.json', 'w') as f:
            json.dump(result_data, f, indent=2)
        
        print(f"\n💾 Results saved to working_extraction_results.json")
        return result
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    test_working_extraction()