#!/usr/bin/env python3
"""
Test SIFIN Timeline Consistency
Verifies that web-scraped data matches email timeline data
"""

import json
import logging
from pathlib import Path
from datetime import datetime

from editorial_assistant.core.timeline_validator import TimelineValidator
from editorial_assistant.extractors.sifin import SIFINExtractor
from scripts.sifin.parse_sifin_emails import SIFINEmailParser
from core.working_gmail_utils import get_gmail_service, search_messages, get_message_details

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def fetch_sifin_emails(days_back: int = 90):
    """Fetch SIFIN emails from Gmail"""
    logger.info(f"Fetching SIFIN emails from last {days_back} days...")
    
    service = get_gmail_service()
    if not service:
        logger.error("Failed to initialize Gmail service")
        return []
    
    # Search for SIFIN emails
    queries = [
        f'subject:SIFIN newer_than:{days_back}d',
        f'from:sifin.siam.org newer_than:{days_back}d',
        f'subject:"SIAM Journal on Financial Mathematics" newer_than:{days_back}d',
        f'subject:M1472 newer_than:{days_back}d',  # Specific manuscripts
        f'subject:M1473 newer_than:{days_back}d',
        f'subject:M1474 newer_than:{days_back}d'
    ]
    
    all_emails = []
    seen_ids = set()
    
    for query in queries:
        logger.info(f"Searching: {query}")
        messages = search_messages(service, query)
        
        for msg in messages:
            if msg['id'] not in seen_ids:
                seen_ids.add(msg['id'])
                details = get_message_details(service, msg['id'])
                if details:
                    all_emails.append(details)
    
    logger.info(f"Found {len(all_emails)} SIFIN emails")
    return all_emails


def test_sifin_timeline_consistency():
    """Test SIFIN timeline consistency between web and email data"""
    logger.info("Starting SIFIN timeline consistency test...")
    
    # Initialize components
    from editorial_assistant.core.data_models import JournalConfig
    
    # Create SIFIN config
    sifin_config = JournalConfig(
        code="SIFIN",
        name="SIAM Journal on Financial Mathematics",
        url="https://sifin.siam.org/cgi-bin/main.plex",
        platform="siam_orcid",
        credentials={
            "username": "your_orcid_email",  # Will be loaded from environment
            "password": "your_orcid_password"
        }
    )
    
    # Run web extraction
    logger.info("Running SIFIN web extraction...")
    extractor = SIFINExtractor(sifin_config)
    
    try:
        manuscripts = extractor.extract_data()
        logger.info(f"Extracted {len(manuscripts)} manuscripts from web")
    except Exception as e:
        logger.error(f"Web extraction failed: {e}")
        return
    
    # Fetch emails
    emails = fetch_sifin_emails()
    
    # Parse email timeline
    logger.info("Parsing email timeline...")
    email_parser = SIFINEmailParser()
    
    # Initialize validator
    validator = TimelineValidator(tolerance_days=2)
    
    # Validate each manuscript
    all_issues = []
    
    for manuscript in manuscripts:
        ms_id = manuscript.get('id', '')
        logger.info(f"\nValidating manuscript {ms_id}...")
        
        # Get all referees for this manuscript
        all_referees = []
        all_referees.extend(manuscript.get('declined_referees', []))
        all_referees.extend(manuscript.get('accepted_referees', []))
        
        # Parse email timeline for this manuscript
        email_timeline = email_parser.parse_referee_emails(emails, manuscript_id=ms_id)
        
        # Log what we found
        logger.info(f"  Web referees: {len(all_referees)}")
        logger.info(f"  Email invitations: {len(email_timeline.get('invitations', []))}")
        logger.info(f"  Email responses: {len(email_timeline.get('responses', []))}")
        
        # Special check for SIFIN - look for referee assignments in email body
        if len(all_referees) > len(email_timeline.get('invitations', [])):
            logger.warning(f"  ⚠️  More web referees than email invitations - checking email bodies...")
            
            # SIFIN sometimes includes referee info in status update emails
            for email in emails:
                if ms_id in email.get('subject', '') and 'referee' in email.get('body', '').lower():
                    logger.info(f"    Found potential referee info in: {email.get('subject', '')}")
        
        # Validate timeline
        issues = validator.validate_manuscript_timeline(ms_id, all_referees, email_timeline)
        
        if issues:
            logger.warning(f"  Found {len(issues)} timeline issues!")
            for issue in issues:
                if issue.severity == 'critical':
                    logger.error(f"    CRITICAL: {issue.description}")
                else:
                    logger.warning(f"    {issue.severity.upper()}: {issue.description}")
        else:
            logger.info(f"  ✓ No timeline inconsistencies found")
        
        all_issues.extend(issues)
    
    # Generate report
    report = validator.generate_validation_report(all_issues)
    
    # Save report
    report_path = Path(f"sifin_timeline_validation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    with open(report_path, 'w') as f:
        json.dump(report, f, indent=2)
    
    # Print summary
    print("\n" + "="*60)
    print("SIFIN TIMELINE VALIDATION SUMMARY")
    print("="*60)
    print(f"Total manuscripts checked: {len(manuscripts)}")
    print(f"Total issues found: {report['total_issues']}")
    print(f"  - Critical issues: {report['critical_issues']}")
    print(f"  - Warnings: {report['warnings']}")
    print(f"  - Info: {report['info']}")
    
    # SIFIN-specific issues
    if 'missing_email_record' in report['by_type']:
        missing_count = len(report['by_type']['missing_email_record'])
        print(f"\n⚠️  {missing_count} referees found on web without email records")
        print("   This is common for SIFIN as referee info may be in status emails")
    
    if report['critical_issues'] > 0:
        print("\nCRITICAL ISSUES REQUIRING IMMEDIATE ATTENTION:")
        for issue_type, issues in report['by_type'].items():
            critical_issues = [i for i in issues if i['severity'] == 'critical']
            if critical_issues:
                print(f"\n{issue_type}:")
                for issue in critical_issues[:3]:  # Show first 3
                    print(f"  - {issue['description']}")
                if len(critical_issues) > 3:
                    print(f"  ... and {len(critical_issues) - 3} more")
    
    print(f"\nFull report saved to: {report_path}")
    
    # Return success/failure (more lenient for SIFIN due to email format differences)
    return report['critical_issues'] == 0


if __name__ == "__main__":
    # Test SIFIN
    success = test_sifin_timeline_consistency()
    
    if success:
        print("\n✅ SIFIN TIMELINE VALIDATION PASSED")
    else:
        print("\n❌ SIFIN TIMELINE VALIDATION FAILED - Critical inconsistencies found")
        print("\nNext steps:")
        print("1. Review the validation report")
        print("2. Check if SIFIN uses different email formats for referee assignments")
        print("3. Update the email parser to handle SIFIN-specific patterns")
        print("4. Ensure web status matches email evidence")
        print("5. Re-run this test until all critical issues are resolved")