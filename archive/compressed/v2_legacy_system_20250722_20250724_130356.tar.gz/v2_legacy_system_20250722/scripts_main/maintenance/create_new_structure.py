#!/usr/bin/env python3
"""
Create new directory structure for Phase 1 refactoring.
Safe script that only creates directories, doesn't move files.
"""

import os
import sys
from pathlib import Path

def create_directory_structure():
    """Create the new organized directory structure."""
    
    # Get project root
    project_root = Path(__file__).parent.parent.parent
    
    # Define new directory structure
    directories = [
        # Source code structure
        "src/editorial_assistant/core",
        "src/editorial_assistant/extractors/scholarone",
        "src/editorial_assistant/extractors/siam",
        "src/editorial_assistant/extractors/email",
        "src/editorial_assistant/utils",
        "src/editorial_assistant/cli",
        
        # Test structure
        "tests/unit/extractors",
        "tests/unit/utils",
        "tests/unit/core",
        "tests/integration",
        "tests/performance",
        "tests/fixtures",
        
        # Scripts structure
        "scripts/setup",
        "scripts/deployment",
        "scripts/maintenance",
        "scripts/debug",
        "scripts/utilities",
        "scripts/legacy",
        
        # Documentation structure
        "docs/architecture",
        "docs/user_guides",
        "docs/development",
        "docs/reference",
        
        # Data structure
        "data/cache",
        "data/logs/extraction",
        "data/logs/system",
        "data/exports/mf",
        "data/exports/mor",
        "data/exports/sicon",
        "data/exports/sifin",
        "data/exports/legacy",
        "data/exports/archive",
        "data/temp",
        "data/debug",
        
        # Configuration structure
        "config/journals",
        "config/environments",
        
        # Deployment structure
        "deployment/docker",
        "deployment/systemd",
        "deployment/nginx",
        
        # Archive structure (for historical code)
        "archive/compressed",
    ]
    
    print("Creating new directory structure...")
    print(f"Project root: {project_root}")
    print("-" * 50)
    
    created_count = 0
    
    for directory in directories:
        dir_path = project_root / directory
        if not dir_path.exists():
            try:
                dir_path.mkdir(parents=True, exist_ok=True)
                print(f"✅ Created: {directory}")
                created_count += 1
            except Exception as e:
                print(f"❌ Failed to create {directory}: {e}")
        else:
            print(f"⏭️  Exists: {directory}")
    
    print("-" * 50)
    print(f"✅ Created {created_count} new directories")
    
    # Create .gitkeep files in empty directories
    print("\nAdding .gitkeep files to empty directories...")
    gitkeep_count = 0
    
    for directory in directories:
        dir_path = project_root / directory
        gitkeep_path = dir_path / ".gitkeep"
        if dir_path.exists() and not any(dir_path.iterdir()) and not gitkeep_path.exists():
            gitkeep_path.touch()
            gitkeep_count += 1
    
    print(f"✅ Added {gitkeep_count} .gitkeep files")
    
    # Create __init__.py files for Python packages
    print("\nCreating __init__.py files for Python packages...")
    init_count = 0
    
    python_dirs = [d for d in directories if d.startswith(("src/", "tests/"))]
    
    for directory in python_dirs:
        dir_path = project_root / directory
        init_path = dir_path / "__init__.py"
        if dir_path.exists() and not init_path.exists():
            init_path.write_text('"""Package initialization."""\n')
            init_count += 1
    
    print(f"✅ Created {init_count} __init__.py files")
    
    print("\n✅ Directory structure creation complete!")
    print("\nNext steps:")
    print("1. Run file_migration_plan.py to see what will be moved")
    print("2. Run migrate_files.py to actually move files")
    print("3. Run validate_structure.py to ensure nothing broken")
    
    return True

if __name__ == "__main__":
    success = create_directory_structure()
    sys.exit(0 if success else 1)