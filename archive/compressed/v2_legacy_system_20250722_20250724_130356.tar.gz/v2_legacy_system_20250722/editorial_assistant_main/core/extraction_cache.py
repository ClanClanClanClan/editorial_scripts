#!/usr/bin/env python3
"""
Extraction Result Caching System

This module provides caching for extraction results to avoid redundant
operations and improve performance for repeated requests.

Phase 3: System Integration - Performance Optimization
"""

import os
import json
import time
import hashlib
import logging
import threading
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from enum import Enum

from .unified_config import get_config_manager
from .platform_extractor import UnifiedManuscript, UnifiedReferee

# Logging setup
logger = logging.getLogger(__name__)


class CacheStatus(Enum):
    """Cache entry status."""
    FRESH = "fresh"
    STALE = "stale"
    EXPIRED = "expired"
    INVALID = "invalid"


@dataclass
class CacheEntry:
    """Single cache entry."""
    
    key: str
    data: Dict[str, Any]
    created_at: datetime
    expires_at: datetime
    journal_code: str
    extraction_mode: str
    hit_count: int = 0
    
    def is_valid(self) -> bool:
        """Check if cache entry is still valid."""
        return datetime.now() < self.expires_at
    
    def age_minutes(self) -> float:
        """Get age of cache entry in minutes."""
        return (datetime.now() - self.created_at).total_seconds() / 60
    
    def status(self) -> CacheStatus:
        """Get current cache status."""
        if not self.is_valid():
            return CacheStatus.EXPIRED
        
        # Consider stale if older than 50% of TTL
        total_ttl = (self.expires_at - self.created_at).total_seconds()
        current_age = (datetime.now() - self.created_at).total_seconds()
        
        if current_age > (total_ttl * 0.5):
            return CacheStatus.STALE
        
        return CacheStatus.FRESH


class ExtractionCache:
    """
    Caching system for extraction results.
    
    Features:
    - TTL-based expiration
    - LRU eviction policy
    - Thread-safe operations
    - Persistent storage option
    - Cache statistics
    """
    
    def __init__(self):
        """Initialize the extraction cache."""
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Configuration
        config_manager = get_config_manager()
        self.cache_enabled = config_manager.get_global_setting('enable_extraction_cache', True)
        self.cache_ttl_minutes = config_manager.get_global_setting('cache_ttl_minutes', 60)
        self.max_cache_size = config_manager.get_global_setting('max_cache_entries', 100)
        self.persistent_cache = config_manager.get_global_setting('persistent_cache', True)
        
        # Cache storage
        self._cache: Dict[str, CacheEntry] = {}
        self._access_order: List[str] = []  # LRU tracking
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Statistics
        self._stats = {
            'hits': 0,
            'misses': 0,
            'evictions': 0,
            'expirations': 0,
            'writes': 0
        }
        
        # Persistent storage
        if self.persistent_cache:
            self._cache_dir = Path("data/cache/extractions")
            self._cache_dir.mkdir(parents=True, exist_ok=True)
            self._load_persistent_cache()
        
        self.logger.info(f"Extraction cache initialized - Enabled: {self.cache_enabled}, "
                        f"TTL: {self.cache_ttl_minutes}min, Max size: {self.max_cache_size}")
    
    def _generate_cache_key(self, journal_code: str, extraction_mode: str,
                           filters: Optional[Dict[str, Any]] = None) -> str:
        """Generate a unique cache key for the request."""
        # Create a deterministic string from parameters
        key_parts = [
            f"journal:{journal_code}",
            f"mode:{extraction_mode}"
        ]
        
        if filters:
            # Sort filters for consistent key generation
            for k, v in sorted(filters.items()):
                if v is not None:
                    key_parts.append(f"{k}:{v}")
        
        key_string = "|".join(key_parts)
        
        # Create hash for compact storage
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def get(self, journal_code: str, extraction_mode: str,
            filters: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Get cached extraction results.
        
        Args:
            journal_code: Journal code
            extraction_mode: Extraction mode
            filters: Optional filters applied
            
        Returns:
            Cached data if available and valid, None otherwise
        """
        if not self.cache_enabled:
            return None
        
        key = self._generate_cache_key(journal_code, extraction_mode, filters)
        
        with self._lock:
            entry = self._cache.get(key)
            
            if entry is None:
                self._stats['misses'] += 1
                return None
            
            if not entry.is_valid():
                # Remove expired entry
                self._remove_entry(key)
                self._stats['expirations'] += 1
                self._stats['misses'] += 1
                return None
            
            # Update hit count and LRU order
            entry.hit_count += 1
            self._update_lru_order(key)
            self._stats['hits'] += 1
            
            self.logger.debug(f"Cache hit for {journal_code} (age: {entry.age_minutes():.1f}min, "
                            f"hits: {entry.hit_count})")
            
            return entry.data
    
    def put(self, journal_code: str, extraction_mode: str,
            data: Dict[str, Any], filters: Optional[Dict[str, Any]] = None):
        """
        Store extraction results in cache.
        
        Args:
            journal_code: Journal code
            extraction_mode: Extraction mode
            data: Extraction results to cache
            filters: Optional filters applied
        """
        if not self.cache_enabled:
            return
        
        key = self._generate_cache_key(journal_code, extraction_mode, filters)
        
        with self._lock:
            # Check cache size and evict if necessary
            if len(self._cache) >= self.max_cache_size:
                self._evict_lru()
            
            # Create cache entry
            entry = CacheEntry(
                key=key,
                data=data,
                created_at=datetime.now(),
                expires_at=datetime.now() + timedelta(minutes=self.cache_ttl_minutes),
                journal_code=journal_code,
                extraction_mode=extraction_mode
            )
            
            # Store in cache
            self._cache[key] = entry
            self._update_lru_order(key)
            self._stats['writes'] += 1
            
            # Persist if enabled
            if self.persistent_cache:
                self._persist_entry(entry)
            
            self.logger.debug(f"Cached results for {journal_code} (TTL: {self.cache_ttl_minutes}min)")
    
    def invalidate(self, journal_code: Optional[str] = None):
        """
        Invalidate cache entries.
        
        Args:
            journal_code: Specific journal to invalidate, or None for all
        """
        with self._lock:
            if journal_code:
                # Invalidate specific journal
                keys_to_remove = [
                    key for key, entry in self._cache.items()
                    if entry.journal_code == journal_code
                ]
                
                for key in keys_to_remove:
                    self._remove_entry(key)
                
                self.logger.info(f"Invalidated {len(keys_to_remove)} cache entries for {journal_code}")
            else:
                # Clear entire cache
                count = len(self._cache)
                self._cache.clear()
                self._access_order.clear()
                
                if self.persistent_cache:
                    self._clear_persistent_cache()
                
                self.logger.info(f"Cleared entire cache ({count} entries)")
    
    def _update_lru_order(self, key: str):
        """Update LRU access order."""
        if key in self._access_order:
            self._access_order.remove(key)
        self._access_order.append(key)
    
    def _evict_lru(self):
        """Evict least recently used entry."""
        if not self._access_order:
            return
        
        # Get LRU key
        lru_key = self._access_order[0]
        
        # Remove entry
        self._remove_entry(lru_key)
        self._stats['evictions'] += 1
        
        self.logger.debug(f"Evicted LRU cache entry: {lru_key}")
    
    def _remove_entry(self, key: str):
        """Remove a cache entry."""
        if key in self._cache:
            del self._cache[key]
        
        if key in self._access_order:
            self._access_order.remove(key)
        
        if self.persistent_cache:
            cache_file = self._cache_dir / f"{key}.json"
            if cache_file.exists():
                cache_file.unlink()
    
    def _persist_entry(self, entry: CacheEntry):
        """Persist cache entry to disk."""
        try:
            cache_file = self._cache_dir / f"{entry.key}.json"
            
            # Convert to serializable format
            data = {
                'key': entry.key,
                'data': entry.data,
                'created_at': entry.created_at.isoformat(),
                'expires_at': entry.expires_at.isoformat(),
                'journal_code': entry.journal_code,
                'extraction_mode': entry.extraction_mode,
                'hit_count': entry.hit_count
            }
            
            with open(cache_file, 'w') as f:
                json.dump(data, f, indent=2)
                
        except Exception as e:
            self.logger.error(f"Failed to persist cache entry: {e}")
    
    def _load_persistent_cache(self):
        """Load cache from persistent storage."""
        try:
            loaded = 0
            expired = 0
            
            for cache_file in self._cache_dir.glob("*.json"):
                try:
                    with open(cache_file, 'r') as f:
                        data = json.load(f)
                    
                    # Reconstruct cache entry
                    entry = CacheEntry(
                        key=data['key'],
                        data=data['data'],
                        created_at=datetime.fromisoformat(data['created_at']),
                        expires_at=datetime.fromisoformat(data['expires_at']),
                        journal_code=data['journal_code'],
                        extraction_mode=data['extraction_mode'],
                        hit_count=data.get('hit_count', 0)
                    )
                    
                    # Only load if not expired
                    if entry.is_valid():
                        self._cache[entry.key] = entry
                        self._access_order.append(entry.key)
                        loaded += 1
                    else:
                        cache_file.unlink()
                        expired += 1
                        
                except Exception as e:
                    self.logger.warning(f"Failed to load cache file {cache_file}: {e}")
                    cache_file.unlink()
            
            if loaded > 0 or expired > 0:
                self.logger.info(f"Loaded {loaded} cache entries from disk ({expired} expired)")
                
        except Exception as e:
            self.logger.error(f"Failed to load persistent cache: {e}")
    
    def _clear_persistent_cache(self):
        """Clear all persistent cache files."""
        try:
            for cache_file in self._cache_dir.glob("*.json"):
                cache_file.unlink()
        except Exception as e:
            self.logger.error(f"Failed to clear persistent cache: {e}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self._lock:
            stats = self._stats.copy()
            
            # Calculate hit rate
            total_requests = stats['hits'] + stats['misses']
            if total_requests > 0:
                stats['hit_rate'] = stats['hits'] / total_requests
            else:
                stats['hit_rate'] = 0.0
            
            # Add current cache info
            stats['current_size'] = len(self._cache)
            stats['max_size'] = self.max_cache_size
            
            # Cache entry breakdown
            status_counts = {'fresh': 0, 'stale': 0}
            for entry in self._cache.values():
                status = entry.status()
                if status == CacheStatus.FRESH:
                    status_counts['fresh'] += 1
                elif status == CacheStatus.STALE:
                    status_counts['stale'] += 1
            
            stats['entry_status'] = status_counts
            
            return stats
    
    def warm_cache(self, journal_codes: List[str], extraction_mode: str = 'full'):
        """
        Pre-populate cache for specified journals.
        
        Args:
            journal_codes: List of journal codes to cache
            extraction_mode: Extraction mode to use
        """
        if not self.cache_enabled:
            return
        
        self.logger.info(f"Cache warming requested for {len(journal_codes)} journals")
        
        # This would typically trigger actual extractions
        # For now, just log the request
        for journal_code in journal_codes:
            self.logger.debug(f"Would warm cache for {journal_code} in {extraction_mode} mode")


# Global cache instance
_global_cache: Optional[ExtractionCache] = None
_cache_lock = threading.Lock()


def get_extraction_cache() -> ExtractionCache:
    """Get the global extraction cache instance."""
    global _global_cache
    
    if _global_cache is None:
        with _cache_lock:
            if _global_cache is None:
                _global_cache = ExtractionCache()
    
    return _global_cache