#!/usr/bin/env python3
"""Test Gmail verification code fetching directly"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

def test_gmail():
    """Test Gmail service directly"""
    try:
        from core.email_utils import fetch_latest_verification_code
        
        print("🔍 Testing Gmail verification code fetching...")
        print("This will search for verification emails from the last hour")
        
        code = fetch_latest_verification_code('MF', max_wait=30, poll_interval=5)
        
        if code:
            print(f"✅ Found verification code: {code}")
        else:
            print("❌ No verification code found")
            
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_gmail()