#!/usr/bin/env python3
"""
Setup comprehensive referee analytics database.
Implements the complete schema for AI-ready referee tracking.
"""

import sqlite3
from pathlib import Path
from datetime import datetime

class RefereeAnalyticsDatabaseSetup:
    """Setup complete database for referee analytics and AI tools."""
    
    def __init__(self, db_path: str = "referee_analytics.db"):
        self.db_path = Path(db_path)
        self.conn = None
        
    def setup_database(self):
        """Create all tables and indexes for comprehensive referee tracking."""
        print("🗄️  Setting up Referee Analytics Database")
        print("="*60)
        
        # Connect to database
        self.conn = sqlite3.connect(self.db_path)
        cursor = self.conn.cursor()
        
        # Enable foreign keys
        cursor.execute("PRAGMA foreign_keys = ON")
        
        # Create all tables
        self._create_manuscripts_table(cursor)
        self._create_authors_table(cursor)
        self._create_referees_table(cursor)
        self._create_referee_invitations_table(cursor)
        self._create_referee_reports_table(cursor)
        self._create_email_timeline_table(cursor)
        self._create_downloaded_files_table(cursor)
        self._create_referee_performance_view(cursor)
        self._create_ai_features_table(cursor)
        
        # Commit changes
        self.conn.commit()
        print("\n✅ Database setup complete!")
        print(f"📍 Database location: {self.db_path.absolute()}")
        
    def _create_manuscripts_table(self, cursor):
        """Create manuscripts table."""
        print("  Creating manuscripts table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS manuscripts (
                id VARCHAR(50) PRIMARY KEY,
                title TEXT NOT NULL,
                submission_date DATE,
                last_updated TIMESTAMP,
                status VARCHAR(100),
                status_details TEXT,
                article_type VARCHAR(50),
                special_issue BOOLEAN,
                special_issue_name VARCHAR(200),
                journal_code VARCHAR(10),
                category VARCHAR(100),
                in_review_days INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Create indexes
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_journal ON manuscripts(journal_code)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_status ON manuscripts(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_submission ON manuscripts(submission_date)")
        
    def _create_authors_table(self, cursor):
        """Create authors table."""
        print("  Creating authors table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS authors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                manuscript_id VARCHAR(50),
                name VARCHAR(200) NOT NULL,
                email VARCHAR(200),
                affiliation TEXT,
                is_corresponding BOOLEAN DEFAULT 0,
                orcid_id VARCHAR(50),
                author_order INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (manuscript_id) REFERENCES manuscripts(id)
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_author_email ON authors(email)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_author_orcid ON authors(orcid_id)")
        
    def _create_referees_table(self, cursor):
        """Create referees table."""
        print("  Creating referees table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS referees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email VARCHAR(200) NOT NULL,
                name VARCHAR(200) NOT NULL,
                affiliation TEXT,
                orcid_id VARCHAR(50),
                google_scholar_id VARCHAR(100),
                research_gate_url TEXT,
                personal_website TEXT,
                expertise_keywords TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP,
                UNIQUE(email)
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_referee_name ON referees(name)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_referee_orcid ON referees(orcid_id)")
        
    def _create_referee_invitations_table(self, cursor):
        """Create referee invitations table."""
        print("  Creating referee_invitations table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS referee_invitations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                manuscript_id VARCHAR(50),
                referee_id INTEGER,
                invited_date DATE,
                responded_date DATE,
                response VARCHAR(20),
                decline_reason TEXT,
                due_date DATE,
                report_submitted_date DATE,
                days_to_respond INTEGER,
                days_to_review INTEGER,
                status VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (manuscript_id) REFERENCES manuscripts(id),
                FOREIGN KEY (referee_id) REFERENCES referees(id)
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_inv_manuscript ON referee_invitations(manuscript_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_inv_referee ON referee_invitations(referee_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_inv_response ON referee_invitations(response)")
        
    def _create_referee_reports_table(self, cursor):
        """Create referee reports table."""
        print("  Creating referee_reports table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS referee_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invitation_id INTEGER,
                submitted_date TIMESTAMP,
                recommendation VARCHAR(50),
                confidence_level INTEGER,
                report_text TEXT,
                report_length INTEGER,
                quality_score DECIMAL(3,2),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (invitation_id) REFERENCES referee_invitations(id)
            )
        """)
        
    def _create_email_timeline_table(self, cursor):
        """Create email timeline table."""
        print("  Creating email_timeline table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS email_timeline (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                manuscript_id VARCHAR(50),
                email_id VARCHAR(100),
                direction VARCHAR(10),
                from_address VARCHAR(200),
                to_addresses TEXT,
                cc_addresses TEXT,
                subject TEXT,
                body_text TEXT,
                sent_date TIMESTAMP,
                email_type VARCHAR(50),
                days_since_last INTEGER,
                attachments TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (manuscript_id) REFERENCES manuscripts(id)
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_email_manuscript ON email_timeline(manuscript_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_email_date ON email_timeline(sent_date)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_email_type ON email_timeline(email_type)")
        
    def _create_downloaded_files_table(self, cursor):
        """Create downloaded files table."""
        print("  Creating downloaded_files table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS downloaded_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                manuscript_id VARCHAR(50),
                file_type VARCHAR(50),
                file_name VARCHAR(500),
                file_path TEXT,
                file_size_bytes BIGINT,
                download_date TIMESTAMP,
                checksum VARCHAR(64),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (manuscript_id) REFERENCES manuscripts(id)
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_file_manuscript ON downloaded_files(manuscript_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_file_type ON downloaded_files(file_type)")
        
    def _create_referee_performance_view(self, cursor):
        """Create referee performance analytics view."""
        print("  Creating referee_performance view...")
        cursor.execute("""
            CREATE VIEW IF NOT EXISTS referee_performance AS
            SELECT 
                r.id,
                r.name,
                r.email,
                COUNT(DISTINCT ri.manuscript_id) as total_reviews,
                AVG(ri.days_to_respond) as avg_response_days,
                AVG(ri.days_to_review) as avg_review_days,
                CAST(SUM(CASE WHEN ri.response = 'agreed' THEN 1 ELSE 0 END) AS FLOAT) / 
                    COUNT(*) as acceptance_rate,
                AVG(rr.quality_score) as avg_quality_score
            FROM referees r
            JOIN referee_invitations ri ON r.id = ri.referee_id
            LEFT JOIN referee_reports rr ON ri.id = rr.invitation_id
            GROUP BY r.id, r.name, r.email
        """)
        
    def _create_ai_features_table(self, cursor):
        """Create AI features table for future ML capabilities."""
        print("  Creating ai_features table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS referee_embeddings (
                referee_id INTEGER PRIMARY KEY,
                expertise_embedding BLOB,
                embedding_model VARCHAR(100),
                publication_titles TEXT,
                collaboration_network TEXT,
                computed_at TIMESTAMP,
                FOREIGN KEY (referee_id) REFERENCES referees(id)
            )
        """)
        
        # Additional ML-ready tables
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS referee_expertise_scores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                referee_id INTEGER,
                topic VARCHAR(200),
                score DECIMAL(3,2),
                evidence TEXT,
                computed_at TIMESTAMP,
                FOREIGN KEY (referee_id) REFERENCES referees(id)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS manuscript_referee_matches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                manuscript_id VARCHAR(50),
                referee_id INTEGER,
                match_score DECIMAL(3,2),
                match_reasons TEXT,
                conflicts TEXT,
                computed_at TIMESTAMP,
                FOREIGN KEY (manuscript_id) REFERENCES manuscripts(id),
                FOREIGN KEY (referee_id) REFERENCES referees(id)
            )
        """)
        
    def populate_test_data(self):
        """Populate database with test data from recent extraction."""
        print("\n📊 Populating database with test data...")
        
        cursor = self.conn.cursor()
        
        # Insert test manuscripts
        test_manuscripts = [
            ('MAFI-2025-0166', 'Optimal investment and consumption under forward utilities with relative performance concerns', 
             '2025-06-19', 'Awaiting Reviewer Scores', 'MF', 32),
            ('MAFI-2024-0167', 'Competitive optimal portfolio selection in a non-Markovian financial market: A backward stochastic differential equation study',
             '2025-01-15', 'Awaiting Reviewer Scores', 'MF', 186)
        ]
        
        for ms_id, title, sub_date, status, journal, days in test_manuscripts:
            cursor.execute("""
                INSERT OR IGNORE INTO manuscripts (id, title, submission_date, status, journal_code, in_review_days)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (ms_id, title, sub_date, status, journal, days))
            
        # Insert test referees
        test_referees = [
            ('g.liang@warwick.ac.uk', 'Gechun Liang', 'University of Warwick', '0000-0003-0752-0773'),
            ('mohamed.kamel.mrad@gmail.com', 'Mohamed Mrad', None, None),
            ('g.dosreis@ed.ac.uk', 'Goncalo Dos Reis', 'University of Edinburgh', '0000-0002-4993-2672'),
            ('moris.strub@wbs.ac.uk', 'Moris Strub', 'Warwick Business School', '0000-0002-6303-6700'),
            ('mastrolia@berkeley.edu', 'Thibaut Mastrolia', 'UC Berkeley', '0000-0003-0578-0168'),
            ('hamadene@univ-lemans.fr', 'Said Hamadene', 'Université du Maine', None)
        ]
        
        for email, name, affiliation, orcid in test_referees:
            cursor.execute("""
                INSERT OR IGNORE INTO referees (email, name, affiliation, orcid_id)
                VALUES (?, ?, ?, ?)
            """, (email, name, affiliation, orcid))
            
        self.conn.commit()
        print("✅ Test data populated!")
        
    def show_database_summary(self):
        """Show summary of database contents."""
        print("\n📊 DATABASE SUMMARY")
        print("="*60)
        
        cursor = self.conn.cursor()
        
        # Count records in each table
        tables = ['manuscripts', 'authors', 'referees', 'referee_invitations', 
                  'referee_reports', 'email_timeline', 'downloaded_files']
        
        for table in tables:
            try:
                count = cursor.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                print(f"  {table}: {count} records")
            except:
                print(f"  {table}: 0 records")

def main():
    """Main function."""
    setup = RefereeAnalyticsDatabaseSetup()
    setup.setup_database()
    setup.populate_test_data()
    setup.show_database_summary()

if __name__ == "__main__":
    main()