"""
Timeline Validation System
Ensures consistency between web-scraped data and email timeline data
"""

import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class TimelineInconsistency(Enum):
    """Types of timeline inconsistencies"""
    STATUS_MISMATCH = "status_mismatch"
    DATE_CONTRADICTION = "date_contradiction" 
    MISSING_EMAIL_RECORD = "missing_email_record"
    MISSING_WEB_RECORD = "missing_web_record"
    RESPONSE_WITHOUT_INVITATION = "response_without_invitation"
    IMPOSSIBLE_TIMELINE = "impossible_timeline"
    DUPLICATE_ASSIGNMENT = "duplicate_assignment"


@dataclass
class ValidationIssue:
    """Represents a timeline validation issue"""
    referee_name: str
    referee_email: str
    manuscript_id: str
    issue_type: TimelineInconsistency
    web_data: Dict
    email_data: Dict
    description: str
    severity: str  # 'critical', 'warning', 'info'
    
    def to_dict(self) -> Dict:
        return {
            'referee_name': self.referee_name,
            'referee_email': self.referee_email,
            'manuscript_id': self.manuscript_id,
            'issue_type': self.issue_type.value,
            'web_data': self.web_data,
            'email_data': self.email_data,
            'description': self.description,
            'severity': self.severity
        }


class TimelineValidator:
    """Validates timeline consistency between web and email data"""
    
    def __init__(self, tolerance_days: int = 2):
        """
        Initialize validator
        
        Args:
            tolerance_days: Number of days tolerance for date comparisons
        """
        self.tolerance_days = tolerance_days
        self.issues: List[ValidationIssue] = []
    
    def validate_manuscript_timeline(self, 
                                   manuscript_id: str,
                                   web_referees: List[Dict], 
                                   email_timeline: Dict) -> List[ValidationIssue]:
        """
        Validate timeline consistency for a manuscript
        
        Args:
            manuscript_id: Manuscript identifier
            web_referees: Referee data from web scraping
            email_timeline: Timeline data from email parsing
            
        Returns:
            List of validation issues found
        """
        self.issues = []
        
        # Create lookup structures
        web_by_email = {ref['email'].lower(): ref for ref in web_referees if ref.get('email')}
        web_by_name = {self._normalize_name(ref['name']): ref for ref in web_referees if ref.get('name')}
        
        email_invitations = {inv['referee_email'].lower(): inv for inv in email_timeline.get('invitations', [])}
        email_responses = {resp['referee_email'].lower(): resp for resp in email_timeline.get('responses', [])}
        
        # Check each web referee against email data
        for web_ref in web_referees:
            self._validate_referee_timeline(manuscript_id, web_ref, email_invitations, email_responses)
        
        # Check for email-only referees (in emails but not on web)
        self._check_email_only_referees(manuscript_id, email_timeline, web_by_email, web_by_name)
        
        # Check for responses without invitations
        self._check_orphan_responses(manuscript_id, email_invitations, email_responses)
        
        return self.issues
    
    def _validate_referee_timeline(self,
                                 manuscript_id: str,
                                 web_ref: Dict,
                                 email_invitations: Dict[str, Dict],
                                 email_responses: Dict[str, Dict]) -> None:
        """Validate timeline for a single referee"""
        referee_email = web_ref.get('email', '').lower()
        referee_name = web_ref.get('name', '')
        
        # Get email data for this referee
        invitation = email_invitations.get(referee_email)
        response = email_responses.get(referee_email)
        
        # Check 1: Missing email records for assigned referee
        if not invitation and web_ref.get('status') != 'not_assigned':
            self.issues.append(ValidationIssue(
                referee_name=referee_name,
                referee_email=referee_email,
                manuscript_id=manuscript_id,
                issue_type=TimelineInconsistency.MISSING_EMAIL_RECORD,
                web_data=web_ref,
                email_data={},
                description=f"Referee shows as '{web_ref.get('status')}' on web but no invitation email found",
                severity='warning'
            ))
        
        # Check 2: Status consistency
        if invitation or response:
            self._validate_status_consistency(manuscript_id, web_ref, invitation, response)
        
        # Check 3: Date consistency
        if invitation:
            self._validate_date_consistency(manuscript_id, web_ref, invitation, response)
    
    def _validate_status_consistency(self,
                                   manuscript_id: str,
                                   web_ref: Dict,
                                   invitation: Optional[Dict],
                                   response: Optional[Dict]) -> None:
        """Check if status from web matches email evidence"""
        web_status = web_ref.get('status', '').lower()
        email_decision = response.get('decision', '').lower() if response else None
        
        # Map web statuses to expected email decisions
        status_mapping = {
            'declined': ['declined', 'reject', 'unable'],
            'accepted': ['accepted', 'agree', 'willing'],
            'complete': ['accepted'],  # Must have accepted to complete
            'overdue': ['accepted'],   # Must have accepted to be overdue
            'invited': [None],         # No response yet
            'removed': ['declined', None]
        }
        
        if email_decision:
            expected_decisions = status_mapping.get(web_status, [])
            
            # Check for contradiction
            if email_decision not in expected_decisions and None not in expected_decisions:
                self.issues.append(ValidationIssue(
                    referee_name=web_ref.get('name', ''),
                    referee_email=web_ref.get('email', ''),
                    manuscript_id=manuscript_id,
                    issue_type=TimelineInconsistency.STATUS_MISMATCH,
                    web_data={'status': web_status},
                    email_data={'decision': email_decision},
                    description=f"Web shows status '{web_status}' but email shows referee '{email_decision}'",
                    severity='critical'
                ))
    
    def _validate_date_consistency(self,
                                  manuscript_id: str,
                                  web_ref: Dict,
                                  invitation: Dict,
                                  response: Optional[Dict]) -> None:
        """Validate date consistency between web and email"""
        # Parse dates
        try:
            inv_date = self._parse_date(invitation.get('date'))
            web_contact_date = self._parse_date(web_ref.get('last_contact_date'))
            
            if inv_date and web_contact_date:
                # Check if invitation date is after last contact (impossible)
                if inv_date > web_contact_date + timedelta(days=self.tolerance_days):
                    self.issues.append(ValidationIssue(
                        referee_name=web_ref.get('name', ''),
                        referee_email=web_ref.get('email', ''),
                        manuscript_id=manuscript_id,
                        issue_type=TimelineInconsistency.IMPOSSIBLE_TIMELINE,
                        web_data={'last_contact': web_ref.get('last_contact_date')},
                        email_data={'invitation_date': invitation.get('date')},
                        description=f"Invitation sent {invitation.get('date')} but web shows last contact {web_ref.get('last_contact_date')}",
                        severity='critical'
                    ))
            
            # Check response timeline
            if response:
                resp_date = self._parse_date(response.get('date'))
                if inv_date and resp_date and resp_date < inv_date:
                    self.issues.append(ValidationIssue(
                        referee_name=web_ref.get('name', ''),
                        referee_email=web_ref.get('email', ''),
                        manuscript_id=manuscript_id,
                        issue_type=TimelineInconsistency.IMPOSSIBLE_TIMELINE,
                        web_data=web_ref,
                        email_data={'invitation': invitation.get('date'), 'response': response.get('date')},
                        description=f"Response dated {response.get('date')} before invitation {invitation.get('date')}",
                        severity='critical'
                    ))
                    
        except Exception as e:
            logger.warning(f"Date parsing error: {e}")
    
    def _check_email_only_referees(self,
                                  manuscript_id: str,
                                  email_timeline: Dict,
                                  web_by_email: Dict,
                                  web_by_name: Dict) -> None:
        """Check for referees that appear in emails but not on web"""
        for invitation in email_timeline.get('invitations', []):
            referee_email = invitation.get('referee_email', '').lower()
            referee_name = self._normalize_name(invitation.get('referee_name', ''))
            
            # Skip if found in web data
            if referee_email in web_by_email or referee_name in web_by_name:
                continue
            
            self.issues.append(ValidationIssue(
                referee_name=invitation.get('referee_name', ''),
                referee_email=invitation.get('referee_email', ''),
                manuscript_id=manuscript_id,
                issue_type=TimelineInconsistency.MISSING_WEB_RECORD,
                web_data={},
                email_data=invitation,
                description=f"Referee invited via email on {invitation.get('date')} but not shown on web",
                severity='warning'
            ))
    
    def _check_orphan_responses(self,
                               manuscript_id: str,
                               email_invitations: Dict,
                               email_responses: Dict) -> None:
        """Check for responses without corresponding invitations"""
        for email, response in email_responses.items():
            if email not in email_invitations:
                self.issues.append(ValidationIssue(
                    referee_name=response.get('referee_name', ''),
                    referee_email=response.get('referee_email', ''),
                    manuscript_id=manuscript_id,
                    issue_type=TimelineInconsistency.RESPONSE_WITHOUT_INVITATION,
                    web_data={},
                    email_data=response,
                    description=f"Found {response.get('decision')} response but no invitation email",
                    severity='warning'
                ))
    
    def _normalize_name(self, name: str) -> str:
        """Normalize name for comparison"""
        if not name:
            return ''
        # Remove titles, extra spaces, convert to lowercase
        name = name.lower().strip()
        for title in ['dr.', 'dr', 'prof.', 'prof', 'professor']:
            name = name.replace(title, '').strip()
        return ' '.join(name.split())
    
    def _parse_date(self, date_str: str) -> Optional[datetime]:
        """Parse date string to datetime"""
        if not date_str:
            return None
        
        try:
            # Handle ISO format with Z
            if 'Z' in date_str:
                date_str = date_str.replace('Z', '+00:00')
            
            # Try different formats
            for fmt in ['%Y-%m-%d', '%Y-%m-%dT%H:%M:%S%z', '%Y-%m-%d %H:%M:%S']:
                try:
                    return datetime.strptime(date_str.split('.')[0], fmt)
                except:
                    continue
                    
            # Try fromisoformat as last resort
            return datetime.fromisoformat(date_str)
            
        except Exception:
            return None
    
    def generate_validation_report(self, issues: List[ValidationIssue]) -> Dict:
        """Generate a summary report of validation issues"""
        report = {
            'total_issues': len(issues),
            'critical_issues': len([i for i in issues if i.severity == 'critical']),
            'warnings': len([i for i in issues if i.severity == 'warning']),
            'info': len([i for i in issues if i.severity == 'info']),
            'by_type': {},
            'by_manuscript': {},
            'issues': [issue.to_dict() for issue in issues]
        }
        
        # Group by issue type
        for issue in issues:
            issue_type = issue.issue_type.value
            if issue_type not in report['by_type']:
                report['by_type'][issue_type] = []
            report['by_type'][issue_type].append(issue.to_dict())
        
        # Group by manuscript
        for issue in issues:
            ms_id = issue.manuscript_id
            if ms_id not in report['by_manuscript']:
                report['by_manuscript'][ms_id] = []
            report['by_manuscript'][ms_id].append(issue.to_dict())
        
        return report