#!/usr/bin/env python3
"""
Immediately apply the Take Action fix to ScholarOne extractor.
Run this to fix the clicking issue right now.
"""

import shutil
from datetime import datetime

# Fixed method that properly clicks Take Action
FIXED_METHOD = '''    def _click_take_action_for_manuscript(self, manuscript_id: str) -> bool:
        """
        Find and click Take Action link for a specific manuscript.
        FIXED: Focuses on the LAST COLUMN where Take Action is located.
        """
        try:
            self.logger.info(f"Looking for Take Action link for {manuscript_id}")
            
            # Find ALL rows (don't filter tables too early)
            all_rows = self.driver.find_elements(By.TAG_NAME, "tr")
            
            for row in all_rows:
                try:
                    row_text = row.text.strip()
                    
                    # Skip if doesn't contain our manuscript
                    if not row_text or manuscript_id not in row_text:
                        continue
                    
                    self.logger.info(f"Found row with {manuscript_id}")
                    
                    # Get cells in this row
                    cells = row.find_elements(By.TAG_NAME, "td")
                    if not cells:
                        continue
                    
                    # KEY FIX: Check ONLY the LAST cell
                    last_cell = cells[-1]
                    
                    # Look for check_off.gif image
                    take_action_links = last_cell.find_elements(
                        By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]"
                    )
                    
                    if take_action_links:
                        link = take_action_links[0]
                        self.logger.info("✅ Found Take Action in last column!")
                        
                        # Try click
                        try:
                            link.click()
                            self._wait_for_page_load()
                            return True
                        except:
                            # Execute JavaScript fallback
                            href = link.get_attribute('href')
                            if href and 'javascript:' in href:
                                js_code = href.replace('javascript:', '')
                                self.driver.execute_script(js_code)
                                self._wait_for_page_load()
                                return True
                    
                    # Also check for manuscript details link
                    detail_links = last_cell.find_elements(
                        By.XPATH, ".//a[contains(@href, 'ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS')]"
                    )
                    if detail_links:
                        href = detail_links[0].get_attribute('href')
                        if href and 'javascript:' in href:
                            js_code = href.replace('javascript:', '')
                            self.driver.execute_script(js_code)
                            self._wait_for_page_load()
                            return True
                            
                except Exception as e:
                    continue
            
            self.logger.error(f"❌ Could not find Take Action for {manuscript_id}")
            return False
            
        except Exception as e:
            self.logger.error(f"Error in Take Action click: {e}")
            return False'''

def apply_fix():
    """Apply the fix to ScholarOne extractor."""
    extractor_path = "/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/editorial_assistant/extractors/scholarone.py"
    
    # Backup original
    backup_path = f"{extractor_path}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    shutil.copy2(extractor_path, backup_path)
    print(f"✅ Backed up to: {backup_path}")
    
    # Read current content
    with open(extractor_path, 'r') as f:
        content = f.read()
    
    # Find method boundaries
    method_start = content.find("    def _click_take_action_for_manuscript(self, manuscript_id: str) -> bool:")
    if method_start == -1:
        print("❌ Method not found!")
        return False
    
    # Find next method
    next_method = content.find("\n    def ", method_start + 1)
    if next_method == -1:
        next_method = len(content)
    
    # Replace method
    new_content = content[:method_start] + FIXED_METHOD + content[next_method:]
    
    # Write fixed version
    with open(extractor_path, 'w') as f:
        f.write(new_content)
    
    print("✅ Fix applied successfully!")
    return True

if __name__ == "__main__":
    print("=== Applying Take Action Fix ===")
    if apply_fix():
        print("\n✅ DONE! The Take Action clicking is now fixed.")
        print("\nYou can run: python run_extraction.py mf")
        print("\nThe fix ensures Take Action is found in the LAST COLUMN only.")
    else:
        print("\n❌ Fix failed. Please check the error above.")