#!/usr/bin/env python3
"""Test with fresh 2FA code fetched at the right moment"""

import os
import sys
import time
from pathlib import Path
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

def test_fresh_2fa():
    """Test with fresh 2FA code"""
    
    print("🎯 TESTING WITH FRESH 2FA CODE")
    print("=" * 50)
    
    # Chrome setup
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        print("1. Navigating to MF...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        print("2. Handling cookies...")
        try:
            reject_btn = driver.find_element(By.ID, "onetrust-reject-all-handler")
            reject_btn.click()
        except:
            pass
        
        print("3. Logging in...")
        email_field = driver.find_element(By.ID, "USERID")
        email_field.send_keys(os.getenv('MF_EMAIL'))
        
        password_field = driver.find_element(By.ID, "PASSWORD")
        password_field.send_keys(os.getenv('MF_PASSWORD'))
        
        login_btn = driver.find_element(By.ID, "logInButton")
        driver.execute_script("arguments[0].click();", login_btn)
        time.sleep(3)
        
        print("4. Checking if 2FA is needed...")
        try:
            code_input = driver.find_element(By.ID, "TOKEN_VALUE")
            print("⚠️ 2FA required - getting FRESH verification code NOW")
            
            # NOW get a fresh verification code - this should be from the login we just triggered
            from core.email_utils import fetch_latest_verification_code
            print("🔍 Fetching verification code triggered by this login...")
            
            # Wait a bit for the email to be sent, then fetch
            time.sleep(5)  # Give the email time to be sent
            verification_code = fetch_latest_verification_code('MF', max_wait=60, poll_interval=3)
            
            if not verification_code:
                print("❌ No fresh verification code found")
                return
                
            print(f"✅ Got fresh verification code: {verification_code}")
            
            code_input.clear()
            code_input.send_keys(verification_code)
            
            try:
                remember_checkbox = driver.find_element(By.ID, "REMEMBER_THIS_DEVICE")
                if not remember_checkbox.is_selected():
                    remember_checkbox.click()
                    print("✅ Checked 'Remember this device'")
            except:
                pass
                
            verify_btn = driver.find_element(By.ID, "VERIFY_BTN")
            verify_btn.click()
            time.sleep(15)
            
            # Check if verification worked
            page_text = driver.find_element(By.TAG_NAME, "body").text
            if "Verification Error" in page_text:
                print("❌ 2FA verification failed with fresh code!")
                return
            elif "Associate Editor Center" in page_text:
                print("✅ 2FA successful - found Associate Editor Center on page")
            else:
                print("⚠️ 2FA status unclear - checking current page...")
                current_url = driver.current_url
                print(f"Current URL: {current_url}")
                if "Log In" in page_text:
                    print("❌ Still on login page")
                    return
                else:
                    print("✅ Seems to be logged in")
                
        except Exception as e:
            print(f"No 2FA needed or error: {e}")
        
        print("5. Navigating to Associate Editor Center...")
        try:
            ae_link = driver.find_element(By.LINK_TEXT, "Associate Editor Center")
            ae_link.click()
            time.sleep(5)
            print("✅ Successfully clicked Associate Editor Center")
        except Exception as e:
            print(f"❌ Failed to find Associate Editor Center: {e}")
            
            # Save debug page
            with open('debug_after_2fa.html', 'w') as f:
                f.write(driver.page_source)
            print("💾 Saved debug page")
            return
        
        print("6. Navigating to manuscript category...")
        try:
            category_link = driver.find_element(By.LINK_TEXT, "Awaiting Reviewer Scores")
            category_link.click()
            time.sleep(5)
            print("✅ Navigated to Awaiting Reviewer Scores")
        except Exception as e:
            print(f"❌ Failed to find category: {e}")
            return
        
        print("7. ANALYZING ALL MANUSCRIPT ROWS...")
        print("-" * 40)
        
        # Find manuscript rows
        all_rows = driver.find_elements(By.TAG_NAME, "tr")
        manuscript_rows = []
        for i, row in enumerate(all_rows):
            if 'MAFI-' in row.text:
                manuscript_rows.append((i, row))
        
        print(f"Found {len(manuscript_rows)} manuscript rows")
        
        # Analyze each manuscript row
        for j, (row_index, row) in enumerate(manuscript_rows):
            print(f"\n📄 Manuscript {j+1} (row {row_index}):")
            print(f"   Row text: {row.text[:150]}...")
            
            cells = row.find_elements(By.TAG_NAME, "td")
            print(f"   Has {len(cells)} cells")
            
            if cells:
                last_cell = cells[-1]
                last_cell_text = last_cell.text.strip()
                print(f"   Last cell text: '{last_cell_text}'")
                
                # Look for Take Action with check_off.gif
                take_action_links = last_cell.find_elements(By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]")
                print(f"   Take Action links with check_off.gif: {len(take_action_links)}")
                
                # Look for any links
                all_links = last_cell.find_elements(By.TAG_NAME, "a")
                print(f"   All links in last cell: {len(all_links)}")
                
                for k, link in enumerate(all_links):
                    href = link.get_attribute('href')
                    print(f"     Link {k+1}: {href}")
                    
                    # Check if this is a Take Action link
                    if href and ('ASSOCIATE_EDITOR_MANUSCRIPT_DETAILS' in href or 'javascript:' in href):
                        print(f"     🎯 POTENTIAL TAKE ACTION FOUND!")
                        
                        if take_action_links:  # Test on first manuscript with actual Take Action
                            print(f"\n🚀 TESTING TAKE ACTION ON FIRST MANUSCRIPT...")
                            
                            if 'javascript:' in href:
                                js_code = href.replace('javascript:', '')
                                print(f"JavaScript: {js_code}")
                                
                                old_url = driver.current_url
                                driver.execute_script(js_code)
                                time.sleep(5)
                                
                                new_url = driver.current_url
                                print(f"Old URL: {old_url}")
                                print(f"New URL: {new_url}")
                                print(f"URL changed: {old_url != new_url}")
                                
                                if old_url != new_url:
                                    print("🎉 TAKE ACTION SUCCESSFUL!")
                                    page_text = driver.find_element(By.TAG_NAME, "body").text
                                    if 'Referee' in page_text or 'Reviewer' in page_text:
                                        print("🎉 AND FOUND REFEREE CONTENT!")
                                        return  # Success!
                                else:
                                    print("❌ Take Action failed - no navigation")
                            else:
                                print(f"Direct link (not JavaScript): {href}")
        
        print("\n❌ No working Take Action links found in any manuscript row")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        driver.quit()

if __name__ == "__main__":
    test_fresh_2fa()