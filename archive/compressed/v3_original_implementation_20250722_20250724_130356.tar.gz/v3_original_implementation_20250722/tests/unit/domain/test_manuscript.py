"""Unit tests for Manuscript entity."""


from src.domain.entities import Manuscript
from src.domain.value_objects import Decision, ManuscriptStatus, ManuscriptType
from src.domain.value_objects.manuscript_metadata import ManuscriptMetadata
from src.foundation import Timestamp


class TestManuscript:
    """Test Manuscript entity."""

    def test_create_manuscript(self, sample_manuscript):
        """Test creating a manuscript."""
        assert sample_manuscript.status == ManuscriptStatus.DRAFT
        assert sample_manuscript.version == 1
        assert sample_manuscript.revision_count == 0
        assert sample_manuscript.is_active()

    def test_corresponding_author_in_authors(self, sample_metadata, sample_author):
        """Test that corresponding author is added to authors list."""
        manuscript = Manuscript(
            id="TEST-2024-0001",
            metadata=sample_metadata,
            type=ManuscriptType.RESEARCH_ARTICLE,
            corresponding_author_id=sample_author.id,
            author_ids=[],  # Empty initially
        )

        assert sample_author.id in manuscript.author_ids

    def test_submit_manuscript(self, sample_manuscript):
        """Test submitting a manuscript."""
        result = sample_manuscript.submit()

        assert result.is_ok()
        assert sample_manuscript.status == ManuscriptStatus.SUBMITTED
        assert sample_manuscript.submitted_at is not None
        assert sample_manuscript.review_round == 1

    def test_cannot_submit_non_draft(self, submitted_manuscript):
        """Test cannot submit already submitted manuscript."""
        result = submitted_manuscript.submit()

        assert result.is_err()
        assert "Cannot submit manuscript in status" in result.unwrap_err()

    def test_submit_requires_metadata(self, sample_author):
        """Test submit requires title and abstract."""
        # Create manuscript with minimal metadata
        metadata = ManuscriptMetadata(title="Test Title", abstract="Test Abstract")
        manuscript = Manuscript(
            id="TEST-2024-0001",
            metadata=metadata,
            type=ManuscriptType.RESEARCH_ARTICLE,
            corresponding_author_id=sample_author.id,
            author_ids=[sample_author.id],
        )

        # Test that submit works with proper metadata
        result = manuscript.submit()
        assert result.is_ok()

    def test_assign_editor(self, submitted_manuscript, sample_editor):
        """Test assigning an editor."""
        result = submitted_manuscript.assign_editor(sample_editor.id)

        assert result.is_ok()
        assert submitted_manuscript.editor_id == sample_editor.id
        assert submitted_manuscript.status == ManuscriptStatus.WITH_EDITOR

    def test_cannot_assign_editor_to_draft(self, sample_manuscript, sample_editor):
        """Test cannot assign editor to draft manuscript."""
        result = sample_manuscript.assign_editor(sample_editor.id)

        assert result.is_err()
        assert "Cannot assign editor in status" in result.unwrap_err()

    def test_start_review(self, submitted_manuscript, sample_editor):
        """Test starting review process."""
        submitted_manuscript.assign_editor(sample_editor.id)
        result = submitted_manuscript.start_review()

        assert result.is_ok()
        assert submitted_manuscript.status == ManuscriptStatus.UNDER_REVIEW

    def test_make_decision_accept(self, submitted_manuscript, sample_editor):
        """Test making accept decision."""
        submitted_manuscript.assign_editor(sample_editor.id)
        submitted_manuscript.start_review()

        result = submitted_manuscript.make_decision(Decision.ACCEPT)

        assert result.is_ok()
        assert submitted_manuscript.status == ManuscriptStatus.ACCEPTED
        assert submitted_manuscript.current_decision == Decision.ACCEPT
        assert submitted_manuscript.accepted_at is not None

    def test_make_decision_revision(self, submitted_manuscript, sample_editor):
        """Test making revision decision."""
        submitted_manuscript.assign_editor(sample_editor.id)
        submitted_manuscript.start_review()

        result = submitted_manuscript.make_decision(Decision.MAJOR_REVISION)

        assert result.is_ok()
        assert submitted_manuscript.status == ManuscriptStatus.REVISION_REQUESTED
        assert submitted_manuscript.current_decision == Decision.MAJOR_REVISION

    def test_make_decision_reject(self, submitted_manuscript, sample_editor):
        """Test making reject decision."""
        submitted_manuscript.assign_editor(sample_editor.id)
        submitted_manuscript.start_review()

        result = submitted_manuscript.make_decision(Decision.REJECT)

        assert result.is_ok()
        assert submitted_manuscript.status == ManuscriptStatus.REJECTED
        assert submitted_manuscript.current_decision == Decision.REJECT

    def test_submit_revision(self, submitted_manuscript, sample_editor):
        """Test submitting a revision."""
        submitted_manuscript.assign_editor(sample_editor.id)
        submitted_manuscript.start_review()
        submitted_manuscript.make_decision(Decision.MAJOR_REVISION)

        result = submitted_manuscript.submit_revision()

        assert result.is_ok()
        assert submitted_manuscript.status == ManuscriptStatus.REVISED
        assert submitted_manuscript.revision_count == 1
        assert submitted_manuscript.version == 2

    def test_publish_manuscript(self, submitted_manuscript, sample_editor):
        """Test publishing a manuscript."""
        submitted_manuscript.assign_editor(sample_editor.id)
        submitted_manuscript.start_review()
        submitted_manuscript.make_decision(Decision.ACCEPT)

        result = submitted_manuscript.publish()

        assert result.is_ok()
        assert submitted_manuscript.status == ManuscriptStatus.PUBLISHED
        assert submitted_manuscript.published_at is not None
        assert not submitted_manuscript.is_active()

    def test_withdraw_manuscript(self, submitted_manuscript):
        """Test withdrawing a manuscript."""
        result = submitted_manuscript.withdraw()

        assert result.is_ok()
        assert submitted_manuscript.status == ManuscriptStatus.WITHDRAWN
        assert submitted_manuscript.current_decision == Decision.WITHDRAWN
        assert not submitted_manuscript.is_active()

    def test_cannot_withdraw_published(self, submitted_manuscript, sample_editor):
        """Test cannot withdraw published manuscript."""
        submitted_manuscript.assign_editor(sample_editor.id)
        submitted_manuscript.start_review()
        submitted_manuscript.make_decision(Decision.ACCEPT)
        submitted_manuscript.publish()

        result = submitted_manuscript.withdraw()

        assert result.is_err()
        assert "Cannot withdraw manuscript in status" in result.unwrap_err()

    def test_file_management(self, sample_manuscript):
        """Test adding and removing files."""
        sample_manuscript.add_file("manuscript.pdf", "file123")
        assert "manuscript.pdf" in sample_manuscript.files
        assert sample_manuscript.files["manuscript.pdf"] == "file123"

        result = sample_manuscript.remove_file("manuscript.pdf")
        assert result.is_ok()
        assert "manuscript.pdf" not in sample_manuscript.files

        result = sample_manuscript.remove_file("nonexistent.pdf")
        assert result.is_err()
        assert "File not found" in result.unwrap_err()

    def test_notes_management(self, sample_manuscript):
        """Test adding notes."""
        sample_manuscript.add_note("First review completed")
        sample_manuscript.add_note("Author responded to comments")

        assert len(sample_manuscript.notes) == 2
        assert "First review completed" in sample_manuscript.notes

    def test_days_in_review(self, submitted_manuscript):
        """Test calculating days in review."""
        # Set submission date to 10 days ago
        submitted_manuscript.submitted_at = Timestamp.now().subtract_days(10)

        days = submitted_manuscript.days_in_review()
        assert days == 10

    def test_can_edit_metadata(self, sample_manuscript):
        """Test checking if metadata can be edited."""
        # Draft - can edit
        assert sample_manuscript.can_edit_metadata()

        # Submitted - cannot edit
        sample_manuscript.submit()
        assert not sample_manuscript.can_edit_metadata()

        # Revision requested - can edit
        sample_manuscript.status = ManuscriptStatus.REVISION_REQUESTED
        assert sample_manuscript.can_edit_metadata()
