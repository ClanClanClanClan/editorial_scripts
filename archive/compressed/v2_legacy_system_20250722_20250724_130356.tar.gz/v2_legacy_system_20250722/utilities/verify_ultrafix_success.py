#!/usr/bin/env python3
"""
Verify if ULTRAFIX was successful by checking for recent detailed extraction data
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime, timedelta

def verify_ultrafix_success():
    """Verify if ULTRAFIX succeeded by looking for evidence."""
    print("🔍 ULTRAFIX SUCCESS VERIFICATION")
    print("=" * 50)
    
    # Check debug files timestamp
    debug_files = list(Path('.').glob('debug_before_click*.html'))
    if debug_files:
        latest_debug = max(debug_files, key=lambda x: x.stat().st_mtime)
        debug_time = datetime.fromtimestamp(latest_debug.stat().st_mtime)
        
        print(f"📄 Latest Take Action attempt: {debug_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"   File: {latest_debug.name}")
        
        # Check if it's recent (within last hour)
        if datetime.now() - debug_time < timedelta(hours=1):
            print("✅ Recent Take Action attempt detected")
        else:
            print("⚠️  Take Action attempt is old")
    
    # Check for no failure files (good sign)
    failed_files = list(Path('.').glob('debug_failed_click*.html'))
    if not failed_files:
        print("✅ No failure debug files found - Take Action didn't completely fail")
    else:
        print(f"❌ Found {len(failed_files)} failure debug files")
    
    # Check recent extraction results
    result_files = []
    for pattern in ['*mf*.json', '*MAFI*.json', '*extraction*.json']:
        result_files.extend(Path('.').glob(pattern))
    
    recent_results = []
    cutoff_time = datetime.now() - timedelta(hours=2)
    
    for file in result_files:
        stat = file.stat()
        modified = datetime.fromtimestamp(stat.st_mtime)
        if modified > cutoff_time:
            recent_results.append((file, modified))
    
    if recent_results:
        print(f"\n📊 Recent extraction results (last 2 hours): {len(recent_results)}")
        for file, modified in sorted(recent_results, key=lambda x: x[1], reverse=True):
            print(f"   📄 {file.name} ({modified.strftime('%H:%M:%S')})")
            
            # Try to read and analyze the content
            try:
                with open(file, 'r') as f:
                    data = json.load(f)
                
                if isinstance(data, list) and data:
                    manuscript = data[0]
                    if isinstance(manuscript, dict):
                        referee_count = manuscript.get('referee_count', 0)
                        if referee_count > 0:
                            print(f"      ✅ Contains detailed data: {referee_count} referees")
                        else:
                            print(f"      ❌ No detailed referee data")
                elif isinstance(data, dict):
                    manuscripts = data.get('manuscripts', [])
                    if manuscripts:
                        print(f"      📄 Contains {len(manuscripts)} manuscripts")
                        # Check first manuscript for detailed data
                        if manuscripts[0].get('referees'):
                            print(f"      ✅ Contains detailed referee data")
                        elif manuscripts[0].get('authors'):
                            print(f"      ⚠️  Basic author data only")
                        else:
                            print(f"      ❌ Minimal data")
            except Exception as e:
                print(f"      ❓ Could not analyze: {e}")
    else:
        print("\n❌ No recent extraction results found")
    
    # Overall assessment
    print("\n" + "=" * 50)
    print("📋 OVERALL ASSESSMENT:")
    
    evidence_score = 0
    
    if debug_files:
        evidence_score += 1
        print("✅ Take Action method was called")
    
    if not failed_files:
        evidence_score += 1  
        print("✅ No complete failure detected")
    
    if recent_results:
        evidence_score += 1
        print("✅ Recent extraction activity detected")
    
    # Check if recent results contain detailed data
    detailed_data_found = False
    for file, _ in recent_results:
        try:
            with open(file, 'r') as f:
                content = f.read()
                if 'referee' in content.lower() and ('email' in content.lower() or 'name' in content.lower()):
                    detailed_data_found = True
                    break
        except:
            pass
    
    if detailed_data_found:
        evidence_score += 2
        print("✅ Detailed referee data found in recent results")
    
    print(f"\nEvidence Score: {evidence_score}/5")
    
    if evidence_score >= 4:
        print("🎉 HIGH CONFIDENCE: ULTRAFIX appears to be working!")
        print("   Take Action clicking is likely successful")
    elif evidence_score >= 2:
        print("⚠️  MODERATE CONFIDENCE: Some evidence of ULTRAFIX progress")
        print("   May be working but need more verification")
    else:
        print("❌ LOW CONFIDENCE: Little evidence of ULTRAFIX success")
        print("   Take Action clicking may still be broken")

if __name__ == "__main__":
    verify_ultrafix_success()