#!/usr/bin/env python3
"""SHOW that Take Action clicking works - automated version"""

import os
import sys
import time
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from dotenv import load_dotenv

load_dotenv('.env.production')
sys.path.insert(0, str(Path(__file__).parent))

from core.email_utils import fetch_latest_verification_code

def show_take_action_working():
    """Demonstrate Take Action clicking works"""
    
    print("🎯 DEMONSTRATING TAKE ACTION CLICKING WORKS")
    print("=" * 60)
    
    # Chrome setup - VISIBLE
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        # 1. Navigate to MF
        print("\n1. Navigating to MF...")
        driver.get("https://mc.manuscriptcentral.com/mafi")
        time.sleep(3)
        
        # 2. Handle cookies
        print("2. Handling cookies...")
        try:
            reject_btn = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.ID, "onetrust-reject-all-handler"))
            )
            reject_btn.click()
        except:
            print("   No cookies to reject")
        
        # 3. Login
        print("3. Logging in...")
        email_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "USERID"))
        )
        email_field.send_keys(os.getenv('MF_EMAIL'))
        
        password_field = driver.find_element(By.ID, "PASSWORD")
        password_field.send_keys(os.getenv('MF_PASSWORD'))
        
        login_btn = driver.find_element(By.ID, "logInButton")
        login_btn.click()
        time.sleep(5)
        
        # 4. Handle 2FA
        print("4. Checking for 2FA...")
        try:
            code_input = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.ID, "TOKEN_VALUE"))
            )
            print("   2FA required - getting code...")
            time.sleep(3)
            code = fetch_latest_verification_code('MF', max_wait=60, poll_interval=3)
            if code:
                print(f"   Got code: {code}")
                code_input.send_keys(code)
                verify_btn = driver.find_element(By.ID, "VERIFY_BTN")
                verify_btn.click()
                time.sleep(10)
        except:
            print("   No 2FA needed")
        
        # 5. Navigate to AE Center
        print("5. Going to Associate Editor Center...")
        ae_link = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.LINK_TEXT, "Associate Editor Center"))
        )
        ae_link.click()
        time.sleep(3)
        
        # 6. Click category
        print("6. Clicking Awaiting Reviewer Scores...")
        category_link = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.LINK_TEXT, "Awaiting Reviewer Scores"))
        )
        category_link.click()
        time.sleep(5)
        
        # 7. Find manuscript rows
        print("\n7. FINDING MANUSCRIPT ROWS...")
        all_rows = driver.find_elements(By.TAG_NAME, "tr")
        print(f"   Total rows: {len(all_rows)}")
        
        # Find rows with MAFI-
        manuscript_found = False
        for i, row in enumerate(all_rows):
            row_text = row.text
            if 'MAFI-' in row_text and 'Manuscript ID' not in row_text:
                print(f"\n   Row {i}: {row_text[:80]}...")
                
                # Get cells
                cells = row.find_elements(By.TAG_NAME, "td")
                if cells:
                    last_cell = cells[-1]
                    
                    # Look for Take Action
                    take_action_links = last_cell.find_elements(
                        By.XPATH, ".//a[.//img[contains(@src, 'check_off.gif')]]"
                    )
                    
                    if take_action_links:
                        print(f"   ✅ FOUND TAKE ACTION IN ROW {i}!")
                        manuscript_found = True
                        
                        # Extract manuscript ID
                        import re
                        ms_id_match = re.search(r'MAFI-\d{4}-\d{4}', row_text)
                        ms_id = ms_id_match.group(0) if ms_id_match else "Unknown"
                        
                        # Click it!
                        link = take_action_links[0]
                        href = link.get_attribute('href')
                        print(f"\n8. CLICKING TAKE ACTION FOR {ms_id}...")
                        print(f"   href: {href[:100]}...")
                        
                        old_url = driver.current_url
                        
                        if href and 'javascript:' in href:
                            js_code = href.replace('javascript:', '')
                            driver.execute_script(js_code)
                        else:
                            link.click()
                        
                        time.sleep(5)
                        new_url = driver.current_url
                        
                        print(f"\n9. RESULTS:")
                        print(f"   Old URL: {old_url}")
                        print(f"   New URL: {new_url}")
                        print(f"   Navigation occurred: {old_url != new_url}")
                        
                        page_text = driver.find_element(By.TAG_NAME, "body").text
                        if 'Referee' in page_text or 'Reviewer' in page_text:
                            print(f"\n✅ SUCCESS! TAKE ACTION WORKS!")
                            print(f"   We are now on the referee details page")
                            print(f"   Found ~{page_text.count('@')} email addresses (referees)")
                        
                        break
        
        if not manuscript_found:
            print("\n❌ No manuscripts with Take Action found")
        
        print("\n🔍 Browser will stay open for 30 seconds for inspection...")
        time.sleep(30)
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        driver.quit()

if __name__ == "__main__":
    show_take_action_working()