#!/usr/bin/env python3
"""
Test MOR verification process specifically
"""

import os
import sys
import time
import logging
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from editorial_assistant.core.browser_manager import BrowserManager
from core.email_utils import fetch_latest_verification_code

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_mor_verification():
    """Test MOR verification with detailed debugging."""
    logger.info("🧪 Testing MOR verification process")
    
    # Load production config
    with open('.env.production', 'r') as f:
        for line in f:
            if '=' in line and not line.startswith('#'):
                key, value = line.strip().split('=', 1)
                os.environ[key] = value
    
    try:
        # Create browser
        browser_manager = BrowserManager(headless=False)
        driver = browser_manager.create_driver()
        
        # Navigate to MOR
        logger.info("📍 Navigating to MOR")
        driver.get("https://mc.manuscriptcentral.com/mathor")
        time.sleep(3)
        
        # Accept cookies
        try:
            accept_btn = driver.find_element("id", "onetrust-accept-btn-handler")
            if accept_btn.is_displayed():
                accept_btn.click()
                time.sleep(1)
        except:
            pass
        
        # Login
        logger.info("📍 Logging in to MOR")
        user = os.environ.get('MOR_EMAIL')
        password = os.environ.get('MOR_PASSWORD')
        
        logger.info(f"   Using email: {user}")
        
        user_box = driver.find_element("id", "USERID")
        pw_box = driver.find_element("id", "PASSWORD")
        
        user_box.clear()
        user_box.send_keys(user)
        pw_box.clear()
        pw_box.send_keys(password)
        
        login_btn = driver.find_element("id", "logInButton")
        login_btn.click()
        time.sleep(10)
        
        # Handle device verification if needed
        if "UNRECOGNIZED_DEVICE" in driver.page_source:
            logger.info("📍 Device verification needed - handling step by step")
            
            # Look for verification input field
            verification_input = driver.find_element("id", "TOKEN_VALUE")
            logger.info("✅ Found verification input field")
            
            # Get verification code
            verification_code = fetch_latest_verification_code(journal="MOR", max_wait=300, poll_interval=10)
            
            if verification_code:
                logger.info(f"✅ Got verification code: {verification_code}")
                
                # Clear and enter code
                verification_input.clear()
                verification_input.send_keys(verification_code)
                logger.info("✅ Entered verification code")
                
                # Look for verify button - try multiple approaches
                verify_buttons = driver.find_elements("xpath", "//input[@type='submit' and contains(@value, 'Verify')] | //button[contains(text(), 'Verify')] | //a[contains(text(), 'Verify')]")
                
                if verify_buttons:
                    logger.info("📍 Found Verify button, clicking...")
                    verify_buttons[0].click()
                    time.sleep(10)
                else:
                    logger.info("📍 No Verify button found, trying form submission...")
                    # Try to find the form and submit it
                    try:
                        form = verification_input.find_element("xpath", "./ancestor::form")
                        logger.info("📍 Found form, submitting...")
                        form.submit()
                        time.sleep(10)
                    except:
                        logger.info("📍 No form found, pressing Enter...")
                        verification_input.send_keys("\\n")
                        time.sleep(10)
                
                # Check result
                current_url = driver.current_url
                page_source = driver.page_source
                
                logger.info(f"After verification URL: {current_url}")
                
                # Check for success indicators
                if "UNRECOGNIZED_DEVICE" not in page_source:
                    logger.info("✅ Device verification successful!")
                    
                    # Check for dashboard indicators
                    dashboard_indicators = [
                        "Associate Editor Center",
                        "Author Center",
                        "Reviewer Center",
                        "Dashboard",
                        "Manuscript"
                    ]
                    
                    found_indicators = []
                    for indicator in dashboard_indicators:
                        if indicator in page_source:
                            found_indicators.append(indicator)
                    
                    if found_indicators:
                        logger.info(f"✅ Found dashboard indicators: {found_indicators}")
                        logger.info("✅ MOR CONNECTION SUCCESS!")
                        return True
                    else:
                        logger.warning("❌ No dashboard indicators found")
                        return False
                else:
                    logger.error("❌ Still on device verification page")
                    return False
            else:
                logger.error("❌ No verification code found")
                return False
        else:
            logger.info("✅ No device verification needed")
            return True
        
    except Exception as e:
        logger.error(f"❌ Error in MOR verification: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        input("Press Enter to close browser...")
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    success = test_mor_verification()
    if success:
        print("✅ MOR VERIFICATION SUCCESS!")
    else:
        print("❌ MOR VERIFICATION FAILED!")