#!/usr/bin/env python3
"""
Fix for SIFIN referee extraction in parse_sifin_emails.py
This script patches the _extract_referee_info method to properly extract referee information
"""

import re
from typing import Tuple, Optional

def create_improved_extract_referee_info():
    """
    Returns the improved _extract_referee_info method code as a string
    """
    return '''def _extract_referee_info(self, subject: str, body: str, from_email: str) -> Tuple[Optional[str], Optional[str]]:
        """Extract referee name and email from email content - IMPROVED VERSION"""
        referee_name = None
        referee_email = None
        
        # Combine subject and body for searching
        full_text = f"{subject}\\n{body}"
        
        # Pattern 1: Report submission emails
        # Example: "Antoine Jack Jacquier has submitted a report for..."
        report_patterns = [
            r'([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*(?:\\s+[A-Z][a-z]+)?)\\s+has\\s+submitted\\s+a\\s+report',
            r'Report\\s+from\\s+([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*)',
            r'Referee\\s+report\\s+from\\s+([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*)',
        ]
        
        for pattern in report_patterns:
            match = re.search(pattern, full_text)
            if match:
                referee_name = match.group(1).strip()
                # Clean up common issues
                if referee_name and not referee_name.startswith('Dear'):
                    break
        
        # Pattern 2: Referee response emails
        response_patterns = [
            r'that\\s+([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*(?:\\s+[A-Z][a-z]+)?)\\s+has\\s+(?:accepted|declined)\\s+to\\s+review',
            r'([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*(?:\\s+[A-Z][a-z]+)?)\\s+has\\s+(?:accepted|declined)\\s+to\\s+review',
            r'Referee\\s+([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*)\\s+(?:accepted|declined)',
            r'([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*)\\s+(?:accepted|declined)\\s+the\\s+invitation',
        ]
        
        if not referee_name:
            for pattern in response_patterns:
                match = re.search(pattern, full_text, re.IGNORECASE)
                if match:
                    referee_name = match.group(1).strip()
                    break
        
        # Pattern 3: Invitation emails
        invitation_patterns = [
            r'Invitation\\s+sent\\s+to\\s+([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*)',
            r'invited\\s+([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*)\\s+to\\s+review',
            r'Review\\s+invitation\\s+for\\s+([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*)',
        ]
        
        if not referee_name:
            for pattern in invitation_patterns:
                match = re.search(pattern, full_text, re.IGNORECASE)
                if match:
                    referee_name = match.group(1).strip()
                    break
        
        # Pattern 4: Look for names between specific markers
        if not referee_name:
            context_patterns = [
                r'(?:Referee|Reviewer):\\s*([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*)',
                r'Name:\\s*([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*)',
            ]
            
            for pattern in context_patterns:
                match = re.search(pattern, full_text)
                if match:
                    candidate = match.group(1).strip()
                    # Validate it's a real name
                    if candidate and len(candidate.split()) >= 2:
                        referee_name = candidate
                        break
        
        # Extract referee email if present
        if referee_name:
            # Look for email near the referee name
            name_pos = full_text.find(referee_name)
            if name_pos != -1:
                name_vicinity = full_text[max(0, name_pos - 100):name_pos + 200]
                email_pattern = r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,})'
                email_match = re.search(email_pattern, name_vicinity)
                if email_match:
                    candidate_email = email_match.group(1)
                    # Filter out SIAM emails
                    if not any(domain in candidate_email for domain in ['siam.org', 'sifin.siam.org']):
                        referee_email = candidate_email
        
        # If no email found in vicinity, search more broadly
        if referee_name and not referee_email:
            # Look for emails that might belong to the referee
            all_emails = re.findall(r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,})', full_text)
            for email in all_emails:
                # Skip SIAM/system emails
                if not any(domain in email.lower() for domain in ['siam.org', 'sifin.siam.org', 'noreply', 'do-not-reply']):
                    # Check if email username matches referee name
                    email_user = email.split('@')[0].lower()
                    referee_parts = referee_name.lower().split()
                    if any(part in email_user for part in referee_parts if len(part) > 2):
                        referee_email = email
                        break
        
        # Log extraction results for debugging
        logger.debug(f"Extracted referee - Name: {referee_name}, Email: {referee_email}")
        
        return referee_name, referee_email'''


def patch_parse_sifin_emails():
    """
    Patch the parse_sifin_emails.py file with improved referee extraction
    """
    import sys
    sys.path.append('/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/scripts/sifin')
    
    # Read the original file
    with open('/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/scripts/sifin/parse_sifin_emails.py', 'r') as f:
        content = f.read()
    
    # Find the method to replace
    method_start = content.find('def _extract_referee_info(self, subject: str, body: str, from_email: str) -> Tuple[Optional[str], Optional[str]]:')
    if method_start == -1:
        print("❌ Could not find _extract_referee_info method")
        return False
    
    # Find the end of the method (next method definition or class end)
    method_end = content.find('\n    def ', method_start + 1)
    if method_end == -1:
        # Try to find the build_referee_timelines method
        method_end = content.find('\n    def build_referee_timelines(', method_start)
    
    if method_end == -1:
        print("❌ Could not find end of _extract_referee_info method")
        return False
    
    # Extract indentation (should be 4 spaces for a method)
    indentation = '    '
    
    # Get the improved method code and add proper indentation
    improved_method = create_improved_extract_referee_info()
    improved_method_lines = improved_method.split('\n')
    improved_method_indented = '\n'.join([indentation + line if line else line for line in improved_method_lines])
    
    # Replace the method
    new_content = content[:method_start] + improved_method_indented + content[method_end:]
    
    # Save to a new file first for safety
    output_file = '/Users/dylanpossamai/Library/CloudStorage/Dropbox/Work/editorial_scripts/scripts/sifin/parse_sifin_emails_fixed.py'
    with open(output_file, 'w') as f:
        f.write(new_content)
    
    print(f"✅ Created fixed version: {output_file}")
    return True


if __name__ == "__main__":
    print("🔧 SIFIN Referee Extraction Fix")
    print("=" * 50)
    
    if patch_parse_sifin_emails():
        print("\n✅ Successfully created fixed version")
        print("\nTo apply the fix, run:")
        print("  cp scripts/sifin/parse_sifin_emails_fixed.py scripts/sifin/parse_sifin_emails.py")
    else:
        print("\n❌ Failed to patch the file")