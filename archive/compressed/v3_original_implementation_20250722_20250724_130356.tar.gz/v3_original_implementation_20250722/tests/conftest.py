"""Pytest configuration and shared fixtures."""

import pytest
from faker import Faker

from src.domain.entities import Author, Editor, Manuscript, Referee
from src.domain.value_objects import (
    Keywords,
    ManuscriptMetadata,
    ManuscriptStatus,
    ManuscriptType,
    Subject,
)
from src.foundation import EmailAddress, FullName, Institution


@pytest.fixture
def faker():
    """Provide Faker instance."""
    return Faker()


@pytest.fixture
def sample_email():
    """Provide sample email address."""
    return EmailAddress(value="test@example.com")


@pytest.fixture
def sample_full_name(faker):
    """Provide sample full name."""
    return FullName(
        first_name=faker.first_name(),
        last_name=faker.last_name(),
        middle_name=faker.first_name() if faker.boolean() else None,
    )


@pytest.fixture
def sample_institution(faker):
    """Provide sample institution."""
    return Institution(
        name=faker.company(),
        department=faker.job() + " Department",
        country=faker.country(),
    )


@pytest.fixture
def sample_subject():
    """Provide sample subject."""
    return Subject(
        code="CS",
        name="Computer Science",
    )


@pytest.fixture
def sample_keywords():
    """Provide sample keywords."""
    return Keywords(values={"machine learning", "neural networks", "deep learning"})


@pytest.fixture
def sample_metadata(faker, sample_keywords, sample_subject):
    """Provide sample manuscript metadata."""
    return ManuscriptMetadata(
        title=faker.sentence(nb_words=10),
        abstract=faker.text(max_nb_chars=500),
        keywords=sample_keywords,
        subjects=[sample_subject],
        word_count=faker.random_int(min=3000, max=8000),
        page_count=faker.random_int(min=10, max=30),
    )


@pytest.fixture
def sample_author(faker, sample_email, sample_full_name, sample_institution):
    """Provide sample author."""
    return Author(
        id=faker.uuid4(),
        name=sample_full_name,
        email=sample_email,
        institution=sample_institution,
        orcid=f"0000-000{faker.random_int(min=1, max=9)}-{faker.random_int(min=1000, max=9999)}-{faker.random_int(min=1000, max=9999)}",
    )


@pytest.fixture
def sample_editor(faker, sample_full_name, sample_institution):
    """Provide sample editor."""
    return Editor(
        id=faker.uuid4(),
        name=sample_full_name,
        email=EmailAddress(
            value=f"{sample_full_name.first_name.lower()}.{sample_full_name.last_name.lower()}@journal.com"
        ),
        institution=sample_institution,
        expertise_keywords=["machine learning", "artificial intelligence"],
        subject_areas=["CS", "AI"],
    )


@pytest.fixture
def sample_referee(faker, sample_full_name, sample_institution):
    """Provide sample referee."""
    return Referee(
        id=faker.uuid4(),
        name=sample_full_name,
        email=EmailAddress(
            value=f"{sample_full_name.first_name.lower()}.{sample_full_name.last_name.lower()}@university.edu"
        ),
        institution=sample_institution,
        expertise_keywords=["neural networks", "deep learning"],
    )


@pytest.fixture
def sample_manuscript(faker, sample_metadata, sample_author):
    """Provide sample manuscript."""
    return Manuscript(
        id="TEST-2024-0001",
        metadata=sample_metadata,
        type=ManuscriptType.RESEARCH_ARTICLE,
        status=ManuscriptStatus.DRAFT,
        corresponding_author_id=sample_author.id,
        author_ids=[sample_author.id],
    )


@pytest.fixture
def submitted_manuscript(sample_manuscript):
    """Provide submitted manuscript."""
    result = sample_manuscript.submit()
    assert result.is_ok()
    return sample_manuscript
